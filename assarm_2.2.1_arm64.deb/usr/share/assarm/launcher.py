#!/usr/bin/python3
"""Desktop window for one of the assembly courses (AssArm, assx86, assRISC-V, assARM64, assAVR).

The course is a single self-contained web page; this shows it in a WebKitGTK view with its own
window, icon and storage. Progress is kept by the page in local storage under
~/.local/share/<package>, so it survives restarts and upgrades of the package.

Settings come from app.json next to this file: {"id", "name", "page", "package", "icon"}.
Keys: F11 full screen, Ctrl+plus / Ctrl+minus / Ctrl+0 zoom, Ctrl+R reload, Ctrl+Q quit.
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = json.load(open(os.path.join(HERE, 'app.json'), encoding='utf-8'))

# WebKit runs web content inside a bubblewrap sandbox, which needs unprivileged user
# namespaces. Ubuntu 23.10 and later restrict those (kernel.apparmor_restrict_unprivileged_userns),
# and a blocked sandbox leaves an empty window or closes the app - the same failure that closed
# the old Electron build. This window only ever shows its own bundled page (every other address
# opens in the system browser), so where the system blocks the sandbox we turn it off; elsewhere
# WebKit keeps it. ASS_SANDBOX=0 or 1 forces the choice.
def _userns_restricted():
    try:
        with open('/proc/sys/kernel/apparmor_restrict_unprivileged_userns') as f:
            return f.read().strip() == '1'
    except OSError:
        return False
_force = os.environ.get('ASS_SANDBOX')
if _force == '0' or (_force != '1' and _userns_restricted()):
    os.environ['WEBKIT_DISABLE_SANDBOX_THIS_IS_DANGEROUS'] = '1'
# With NVIDIA's own driver, WebKitGTK's DMA-BUF renderer can leave the window blank; the
# shared-memory renderer it falls back to is plenty for a page of text and small canvases.
if os.path.exists('/proc/driver/nvidia/version'):
    os.environ.setdefault('WEBKIT_DISABLE_DMABUF_RENDERER', '1')

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
for _v in ('4.1', '4.0'):
    try:
        gi.require_version('WebKit2', _v)
        break
    except ValueError:
        continue
from gi.repository import Gdk, Gio, GLib, Gtk, WebKit2   # noqa: E402

PAGE = os.path.join(HERE, CFG['page'])
PAGE_URI = Gio.File.new_for_path(PAGE).get_uri()
GLib.set_prgname(CFG['id'])            # X11 WM_CLASS; on Wayland the application id is used: both match the .desktop file
GLib.set_application_name(CFG['name'])


class CourseApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=CFG['id'], flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.win = None
        self.view = None
        self.fullscreen = False

    def do_activate(self):
        if self.win:                       # a second launch just brings the window forward
            self.win.present()
            return
        win = Gtk.ApplicationWindow(application=self, title=CFG['name'])
        win.set_default_size(*self.window_size())
        win.set_icon_name(CFG['icon'])
        data = os.path.join(GLib.get_user_data_dir(), CFG['package'])
        cache = os.path.join(GLib.get_user_cache_dir(), CFG['package'])
        manager = WebKit2.WebsiteDataManager(base_data_directory=data, base_cache_directory=cache)
        context = WebKit2.WebContext.new_with_website_data_manager(manager)
        context.set_cache_model(WebKit2.CacheModel.DOCUMENT_VIEWER)
        view = WebKit2.WebView.new_with_context(context)
        s = view.get_settings()
        s.set_enable_developer_extras(bool(os.environ.get('ASS_DEVTOOLS')))
        s.set_javascript_can_open_windows_automatically(False)
        s.set_enable_back_forward_navigation_gestures(False)
        view.connect('decide-policy', self.on_policy)
        view.connect('context-menu', self.on_context_menu)
        view.connect('web-process-terminated', self.on_crash)
        win.connect('key-press-event', self.on_key)
        win.connect('window-state-event', self.on_state)
        win.add(view)
        self.win, self.view = win, view
        view.load_uri(PAGE_URI)
        win.show_all()
        if os.environ.get('ASS_SELFTEST'):
            SelfTest(self, os.environ['ASS_SELFTEST'])

    @staticmethod
    def window_size():
        """1280 x 860, or a little less than the screen's free area on small screens"""
        try:
            disp = Gdk.Display.get_default()
            mon = disp.get_primary_monitor() or disp.get_monitor(0)
            area = mon.get_workarea()
            return min(1280, int(area.width * 0.92)), min(860, int(area.height * 0.92))
        except Exception:                          # noqa: BLE001 - no monitor information: use the default
            return 1280, 860

    # links: the course page stays in the window, everything else opens in the browser
    def on_policy(self, view, decision, kind):
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri()
            if uri.split('#')[0] != PAGE_URI:
                decision.ignore()
                if uri.startswith(('http:', 'https:', 'mailto:')):
                    try:
                        Gtk.show_uri_on_window(self.win, uri, Gdk.CURRENT_TIME)
                    except GLib.Error:
                        pass
                return True
        return False

    def on_context_menu(self, view, menu, event, hit):
        # keep copy / paste / select all; drop "Back", "Reload", "Open link in new window"
        keep = {WebKit2.ContextMenuAction.COPY, WebKit2.ContextMenuAction.CUT, WebKit2.ContextMenuAction.PASTE,
                WebKit2.ContextMenuAction.SELECT_ALL, WebKit2.ContextMenuAction.INSPECT_ELEMENT}
        for item in list(menu.get_items()):
            if item.get_stock_action() not in keep:
                menu.remove(item)
        return menu.get_n_items() == 0

    def on_crash(self, view, reason):
        GLib.timeout_add(300, lambda: (view.load_uri(PAGE_URI), False)[1])

    def on_state(self, win, event):
        self.fullscreen = bool(event.new_window_state & Gdk.WindowState.FULLSCREEN)
        return False

    def on_key(self, win, event):
        ctrl = event.state & Gdk.ModifierType.CONTROL_MASK
        k = event.keyval
        if k == Gdk.KEY_F11 or (k == Gdk.KEY_Escape and self.fullscreen):
            if self.fullscreen or k == Gdk.KEY_Escape:
                win.unfullscreen()
            else:
                win.fullscreen()
            return True
        if ctrl and k in (Gdk.KEY_q, Gdk.KEY_w):
            self.quit()
            return True
        if ctrl and k == Gdk.KEY_r:
            self.view.reload()
            return True
        if ctrl and k in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
            self.view.set_zoom_level(min(3.0, self.view.get_zoom_level() + 0.1))
            return True
        if ctrl and k in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            self.view.set_zoom_level(max(0.5, self.view.get_zoom_level() - 0.1))
            return True
        if ctrl and k in (Gdk.KEY_0, Gdk.KEY_KP_0):
            self.view.set_zoom_level(1.0)
            return True
        return False


class SelfTest:
    """Packaging check (ASS_SELFTEST=<json file>): open a lesson, run the given code through the
    real page, and report the verdict and the stored progress; optionally save a screenshot
    ("screenshot": path, "full": true for the whole page)."""
    JS = r"""
    (function (T) {
      function done(r) { document.title = 'SELFTEST:' + JSON.stringify(r); }   // WebKit cuts titles at 1000 characters
      function summary(s) {                                                    // so report stored progress as counts
        try { var d = JSON.parse(s || 'null'); return d && { done: Object.keys(d.done || {}).length, u1l1: !!(d.done || {}).u1l1, xp: d.xp }; }
        catch (e) { return 'unreadable'; }
      }
      try {
        var C = window.COURSE, ids = [];
        C.units.forEach(function (u) { u.lessons.forEach(function (l) { ids.push(l); }); });
        var L = ids.filter(function (l) { return l.id === T.lesson; })[0];
        var before = localStorage.getItem(C.storeKey);
        var rows = Array.prototype.slice.call(document.querySelectorAll('button.lrow'));
        var row = rows.filter(function (b) { var t = b.querySelector('b'); return t && t.textContent === L.title; })[0];
        if (!row) return done({ error: 'lesson row not found (locked?)', lessons: ids.length, stored: summary(before) });
        row.click();
        setTimeout(function () {
          var ta = document.querySelector('textarea.code');
          ta.value = T.code === 'SOLUTION' ? L.ex.solution : T.code;
          ta.dispatchEvent(new Event('input', { bubbles: true }));
          var run = Array.prototype.slice.call(document.querySelectorAll('button.btn.primary')).filter(function (b) { return b.textContent === 'Run'; })[0];
          run.click();
          setTimeout(function () {
            var v = document.querySelector('.verdict');
            done({ lesson: L.id, lessons: ids.length, verdict: v && !v.hidden ? v.textContent.slice(0, 160) : '',
                   stored: summary(localStorage.getItem(C.storeKey)), before: summary(before), ua: navigator.userAgent.slice(0, 160) });
          }, T.wait || 1500);
        }, 400);
      } catch (e) { done({ error: String(e) }); }
    })(%s);
    """

    SEED = r"""
    (function (T) {
      var C = window.COURSE, done = {};
      C.units.forEach(function (u) { u.lessons.forEach(function (l) { if (l.id !== T.lesson) done[l.id] = true; }); });
      localStorage.setItem(C.storeKey, JSON.stringify({ done: done, code: {}, xp: 0, lastDay: null, streak: 1 }));
      location.reload();
    })(%s);
    """

    def __init__(self, app, path):
        self.app, self.t = app, json.load(open(path))
        self.sent = False
        self.seeded = not self.t.get('unlock')
        app.view.connect('load-changed', self.loaded)
        app.view.connect('notify::title', self.titled)
        GLib.timeout_add_seconds(int(self.t.get('timeout', 60)), self.give_up)

    def loaded(self, view, event):
        if event == WebKit2.LoadEvent.FINISHED and not self.sent:
            if not self.seeded:                    # unlock every lesson first, then reload
                self.seeded = True
                GLib.timeout_add(400, self.run_js, self.SEED % json.dumps(self.t))
                return
            self.sent = True
            GLib.timeout_add(600, self.run_js, self.JS % json.dumps(self.t))

    def run_js(self, js):
        if hasattr(self.app.view, 'evaluate_javascript'):
            self.app.view.evaluate_javascript(js, -1, None, None, None, None, None)
        else:
            self.app.view.run_javascript(js, None, None, None)
        return False

    def titled(self, view, _):
        title = view.get_title() or ''
        if title.startswith('SELFTEST:'):
            print(title[9:], flush=True)
            shot = self.t.get('screenshot')
            if shot:
                region = WebKit2.SnapshotRegion.FULL_DOCUMENT if self.t.get('full') else WebKit2.SnapshotRegion.VISIBLE
                view.get_snapshot(region, WebKit2.SnapshotOptions.NONE, None, self.snapped, shot)
            else:
                GLib.timeout_add(200, self.app.quit)

    def snapped(self, view, result, shot):
        try:
            view.get_snapshot_finish(result).write_to_png(shot)
        except Exception as e:                     # noqa: BLE001
            print(json.dumps({'screenshot_error': str(e)}), flush=True)
        GLib.timeout_add(200, self.app.quit)

    def give_up(self):
        print(json.dumps({'error': 'timeout', 'title': self.app.view.get_title()}), flush=True)
        self.app.quit()
        return False


if __name__ == '__main__':
    sys.exit(CourseApp().run(sys.argv[:1]))
