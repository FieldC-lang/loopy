/* AssArm: Loops — curriculum part 8 : Unit 12, capstone */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u12', n: 12, title: 'Loops in the Wild', icon: '★', color: '#e0af68',
    blurb: 'Five real routines, built from everything in the course — finishing with a demo that draws, buzzes and counts cycles.',
    lessons: [

/* ----------------------------------------------------------------- 12.1 */
{
  id: 'u12l1', title: 'memset, complete', goal: 'Assemble head, bulk and tail into a routine that handles every input.',
  teach: [
    { t: 'p', x: 'You have built all the pieces. Here they are as one function, with the calling convention, the guards and the tail all in place.' },
    { t: 'code', cap: 'memset(void *s, int c, size_t n)', x: '@ r0 = dest, r1 = byte value, r2 = count.  Returns dest.\nmemset:\n    push {r0, r4-r6, lr}\n    cmp  r2, #0\n    beq  9f                  @ zero length: nothing to do\n\n    and  r1, r1, #0xFF\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16 @ the byte, replicated\n\n    cmp  r2, #16\n    blo  4f                  @ too small to be worth aligning\n\n1:  ands r3, r0, #3          @ head: bytes until aligned\n    beq  2f\n    strb r1, [r0], #1\n    sub  r2, r2, #1\n    b    1b\n\n2:  mov  r4, r1              @ bulk: 16 bytes per pass\n    mov  r5, r1\n    mov  r6, r1\n3:  cmp  r2, #16\n    blo  4f\n    stmia r0!, {r1, r4, r5, r6}\n    sub  r2, r2, #16\n    b    3b\n\n4:  cmp  r2, #0              @ tail: whatever is left\n    beq  9f\n    strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n\n9:  pop  {r0, r4-r6, pc}' },
    { t: 'h', x: 'Every line justified' },
    { t: 'table', head: ['Line', 'Why'], rows: [
      ['<code>push {r0, ...}</code>', 'The return value is the original pointer, which the loop destroys'],
      ['<code>cmp r2, #0</code>', 'Zero length must not enter a bottom-tested loop'],
      ['The three ORRs', 'Loop-invariant work, hoisted'],
      ['<code>cmp r2, #16</code>', 'Below a threshold, aligning costs more than it saves'],
      ['<code>ands r3, r0, #3</code>', 'STM demands word alignment'],
      ['<code>pop {r0, ..., pc}</code>', 'Restore, recover the return value, and return — one instruction']
    ] },
    { t: 'note', x: 'The small-size check is real and it matters. For n = 8, the head, the ORRs and the three extra MOVs cost more than eight <code>STRB</code>s. Every production memset has a threshold like this, and its value is chosen by measurement on the target core.' }
  ],
  real: {
    title: 'What the real one adds',
    text: 'A production memset adds a NEON path for large sizes, uses eight registers rather than four in the bulk loop, and often special-cases zero because zeroing can use non-temporal or cache-line-zeroing instructions on some cores. The structure above is the part that does not change.',
    noasm: true,
    code: '@ larger block, more registers, same shape\n3:  cmp  r2, #32\n    blo  4f\n    stmia r0!, {r1, r4-r10}\n    sub  r2, r2, #32\n    b    3b'
  },
  deep: {
    kind: 'pitfall',
    title: 'The byte is not the value you think it is',
    text: 'A production memset spends about five instructions — masking the byte, three ORRs to replicate it across a word, and a size check — before the copy loop even runs. That setup earns its keep by making one routine correct for any pointer and any length. It earns nothing at all if the byte handed to it is not the byte you meant.',
    a: { lab: 'The bug', lang: 'c', code: 'uint8_t *buf = malloc(64);\n/* "set every bit": actually writes 0x01 into all 64 bytes */\nmemset(buf, 1, sizeof(buf));' },
    b: { lab: 'The fix', lang: 'c', code: 'uint8_t *buf = malloc(64);\nmemset(buf, 0xFF, 64);   /* the value you meant, and the real length */' },
    note: 'Two separate bugs, both silent: <code>memset</code>\'s second argument is a byte value, not a boolean, so 1 fills with 0x01, not 0xFF; and <code>sizeof(buf)</code> on a pointer gives 4 on ARMv7, not the size of what it points to. The compiler warns about neither.'
  },
  refs: [
    { src: 'ISO/IEC 9899, 7.24.6.1 — memset', cite: 'memset copies the value of c, converted to unsigned char, into each of the first n characters of the object pointed to by s, and returns s.' },
    { src: 'AAPCS (IHI 0042)', cite: 'The first four arguments are passed in r0–r3 and the result is returned in r0; r4–r11 must be preserved.' }
  ],
  ex: [
    { k: 'code', q: 'Fill the 20 bytes at <code>buf</code> with 0xAB using a head/bulk/tail structure. (20 = 16 + 4, so both paths run.)', start: '    ldr  r0, =buf\n    mov  r1, #0xAB\n    mov  r2, #20\n\n.data\nbuf: .space 20\n', check: [{ memLabel: 'buf', bytes: [0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB, 0xAB] }], solution: '    ldr  r0, =buf\n    mov  r1, #0xAB\n    mov  r2, #20\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16\n    mov  r4, r1\n    mov  r5, r1\n    mov  r6, r1\n3:  cmp  r2, #16\n    blo  4f\n    stmia r0!, {r1, r4, r5, r6}\n    sub  r2, r2, #16\n    b    3b\n4:  cmp  r2, #0\n    beq  9f\n    strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n9:\n\n.data\nbuf: .space 20\n', hints: ['Replicate the byte, copy it into four registers, then STM 16 bytes at a time.', 'The last 4 bytes go through the byte tail.'], why: 'One block store plus four byte stores. The structure scales from 1 byte to a megabyte without changing.' },
    { k: 'code', q: 'Make it safe for n = 0: the buffer must be left untouched.', start: '    ldr  r0, =buf\n    mov  r1, #0xFF\n    mov  r2, #0\n4:  strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n\n.data\nbuf: .space 8\n', check: [{ memLabel: 'buf', bytes: [0, 0, 0, 0, 0, 0, 0, 0] }], solution: '    ldr  r0, =buf\n    mov  r1, #0xFF\n    mov  r2, #0\n    cmp  r2, #0\n    beq  9f\n4:  strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n9:\n\n.data\nbuf: .space 8\n', hints: ['One <code>cmp r2, #0</code> and one forward branch, before the loop.'], why: 'Run the starter and watch it write 4 billion bytes before the emulator stops it. Two instructions prevent that.' },
    { k: 'mcq', q: 'Why does memset push r0 and pop it back into r0?', opts: ['To align the stack', 'Because the loop advances r0, but the function must return the original pointer', 'To save a register', 'It does not'], a: 1, why: 'The C standard says memset returns s. The loop destroys it, so it has to be saved.' },
    { k: 'mcq', q: 'Why does memset skip the alignment head for small sizes?', opts: ['Small buffers are always aligned', 'The setup — head, replication, extra MOVs — costs more than simply storing a handful of bytes', 'STM does not work on small buffers', 'It does not skip it'], a: 1, why: 'Every real implementation has such a threshold, and its value comes from measurement on the target core.' },
    { k: 'mcq', q: 'A function receives <code>uint8_t *buf</code> and calls <code>memset(buf, 0, sizeof(buf))</code>. What does this actually zero?', opts: ['The whole buffer, whatever its size', 'Only 4 bytes (or 8), the size of the pointer itself', 'Nothing — this does not compile', 'Exactly one element'], a: 1, why: '<code>sizeof</code> on a pointer gives the size of the pointer, not of the memory it points to. The real length has to arrive as a separate parameter, because inside the function there is no other way to know it.' }
  ]
},

/* ----------------------------------------------------------------- 12.2 */
{
  id: 'u12l2', title: 'strlen, word at a time', goal: 'Find a zero byte four bytes per iteration with pure arithmetic.',
  teach: [
    { t: 'p', x: 'The naive <code>strlen</code> reads one byte per iteration. The fast one reads four, and detects whether any of them is zero using a single arithmetic expression — no comparisons, no branching per byte.' },
    { t: 'code', cap: 'The zero-byte test', x: '@ r3 holds four bytes. This expression is non-zero iff any byte is zero.\n@     (x - 0x01010101) & ~x & 0x80808080\n    sub  r4, r3, r6          @ r6 = 0x01010101\n    bic  r4, r4, r3          @ AND with NOT x\n    ands r4, r4, r7          @ r7 = 0x80808080\n    bne  found_a_zero' },
    { t: 'h', x: 'Why it works' },
    { t: 'p', x: 'Subtracting 1 from a byte that is 0x00 borrows, turning it into 0xFF and setting its top bit. Subtracting 1 from any non-zero byte cannot set a top bit that was not already set. So <code>x − 0x01010101</code> has a new top bit exactly where a zero byte was — and ANDing with <code>~x</code> discards the bytes that already had their top bit set, which are the false positives.' },
    { t: 'note', x: 'The test can still report a false positive in one case: a byte of 0x80 followed by a byte of 0x00 can set the flag for the wrong byte. That is why the fast path, having found <i>a</i> zero somewhere in the word, falls back to checking the four bytes individually. Detect fast, confirm slowly.' },
    { t: 'code', cap: 'The full loop', x: 'strlen:\n    mov  r1, r0\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n1:  ldr  r3, [r1], #4\n    sub  r4, r3, r6\n    bic  r4, r4, r3\n    ands r4, r4, r7\n    beq  1b                  @ no zero in these four bytes\n\n@ a zero is somewhere in r3: find which byte\n    sub  r1, r1, #4\n2:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    bne  2b\n    sub  r0, r1, r0\n    sub  r0, r0, #1\n    bx   lr' },
    { t: 'h', x: 'The alignment requirement' },
    { t: 'p', x: 'Reading four bytes at a time can read past the end of the string — up to three bytes past the terminator. That is safe only if the read cannot cross into an unmapped page, which is guaranteed when the pointer is word-aligned, because a word-aligned 4-byte read never straddles a page boundary. So the real routine aligns first, with a byte loop, and only then goes fast.' }
  ],
  real: {
    title: 'SWAR: SIMD within a register',
    text: 'This technique — packing several small values into one word and operating on all of them with ordinary integer instructions — is called SWAR, and it predates SIMD hardware by decades. It is still how strlen, memchr and strchr are implemented on cores without NEON, and it is still competitive with NEON for short strings.',
    code: '@ the same trick finds a specific byte, not just zero\n    eor  r3, r3, r8          @ r8 = the wanted byte, replicated\n    sub  r4, r3, r6\n    bic  r4, r4, r3\n    ands r4, r4, r7'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler will not find this trick for you',
    text: 'The word-at-a-time technique is something a person writes on purpose, not something a compiler invents. Handed the plain, byte-at-a-time version below, gcc -O2 keeps it exactly that shape: one load, one compare, one branch, once per byte. Autovectorising a loop whose trip count depends on the data it is reading, and whose exit condition is the result of a load, is not a transformation the compiler will attempt.',
    a: { lab: 'C', lang: 'c', code: 'size_t mystrlen(const char *p) {\n    const char *s = p;\n    while (*p) p++;\n    return p - s;\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: 'mystrlen:\n    mov  r1, r0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    bne  1b\n    sub  r0, r1, r0\n    sub  r0, r0, #1\n    bx   lr' },
    note: 'Nothing here is unoptimised — one load, one compare, one branch per byte is as tight as a scalar loop gets. The four-bytes-at-a-time version is only faster because a person supplied a fact the compiler is not allowed to assume: that reading up to three bytes past the end is safe, on this particular, aligned pointer.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — BIC', cite: 'BIC performs a bitwise AND of the first operand with the complement of the second.' },
    { src: 'Bit Twiddling Hacks (Sean Eron Anderson, Stanford)', cite: 'The expression (v - 0x01010101UL) & ~v & 0x80808080UL is non-zero if and only if v contains a zero byte.' }
  ],
  ex: [
    { k: 'code', q: 'Test whether the word 0x41004243 contains a zero byte, using the SWAR expression. Leave 1 in r0 if it does, 0 if not.', start: '    ldr  r3, =0x41004243\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n', check: [{ reg: 'r0', eq: 1 }, { notContains: 'ldrb' }], solution: '    ldr  r3, =0x41004243\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n    sub  r4, r3, r6\n    bic  r4, r4, r3\n    ands r4, r4, r7\n    movne r0, #1\n    moveq r0, #0\n', hints: ['<code>sub</code>, <code>bic</code>, <code>ands</code> — in that order.', 'Then two conditional moves.'], why: 'The second byte is 0x00, so the expression is non-zero. Four bytes tested without a single comparison.' },
    { k: 'code', q: 'Confirm the negative case: 0x41424344 has no zero byte, so r0 must end up 0.', start: '    ldr  r3, =0x41424344\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n    mov  r0, #9\n', check: [{ reg: 'r0', eq: 0 }], solution: '    ldr  r3, =0x41424344\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n    mov  r0, #9\n    sub  r4, r3, r6\n    bic  r4, r4, r3\n    ands r4, r4, r7\n    movne r0, #1\n    moveq r0, #0\n', hints: ['Identical code to the last exercise — only the data changed.'], why: 'No borrow reaches any top bit, so the expression is zero and the loop would continue.' },
    { k: 'code', q: 'Write the full word-at-a-time strlen for the string at <code>msg</code> (which is word-aligned). Length in r0.', start: '    ldr  r0, =msg\n    mov  r1, r0\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n1:\n\n.data\n.balign 4\nmsg: .asciz "ARMv7 LOOPS"\n', check: [{ reg: 'r0', eq: 11 }], solution: '    ldr  r0, =msg\n    mov  r1, r0\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n1:  ldr  r3, [r1], #4\n    sub  r4, r3, r6\n    bic  r4, r4, r3\n    ands r4, r4, r7\n    beq  1b\n    sub  r1, r1, #4\n2:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    bne  2b\n    sub  r0, r1, r0\n    sub  r0, r0, #1\n\n.data\n.balign 4\nmsg: .asciz "ARMv7 LOOPS"\n', hints: ['Fast loop until the expression is non-zero, then back up four bytes and scan bytes.', 'Finish with the two subtractions that turn the pointer into a length.'], why: '"ARMv7 LOOPS" is 11 characters. Three fast iterations found the word containing the terminator; the byte loop then ran at most four times.' },
    { k: 'mcq', q: 'Why does the fast loop fall back to a byte scan once it fires?', opts: ['For readability', 'The test says a zero is somewhere in the word, and can occasionally false-positive, so the exact position must be confirmed', 'To reset the flags', 'It does not'], a: 1, why: 'Detect fast, confirm slowly — the byte loop runs at most four times, once per string.' },
    { k: 'mcq', q: 'Why must the pointer be word-aligned before the fast loop starts?', opts: ['LDR requires it', 'So that reading up to three bytes past the terminator can never cross into an unmapped page', 'To make it faster', 'Both of the first two'], a: 3, why: 'Both: LDR wants alignment, and an aligned 4-byte read is guaranteed to stay within one page, which makes the over-read safe.' }
  ]
},

/* ----------------------------------------------------------------- 12.3 */
{
  id: 'u12l3', title: 'Searching', goal: 'Find a byte, a word, or a substring — and know why the naive version is usually right.',
  teach: [
    { t: 'p', x: 'Search loops come in three sizes, and the right one is almost never the clever one.' },
    { t: 'code', cap: 'memchr: find a byte', x: '@ r0 = buffer, r1 = byte, r2 = length. Returns a pointer or 0.\n1:  cmp  r2, #0\n    beq  2f\n    ldrb r3, [r0], #1\n    sub  r2, r2, #1\n    cmp  r3, r1\n    bne  1b\n    sub  r0, r0, #1          @ found: back up to point at it\n    bx   lr\n2:  mov  r0, #0              @ not found\n    bx   lr' },
    { t: 'h', x: 'The SWAR version' },
    { t: 'p', x: 'The same trick as <code>strlen</code>: XOR the word with the wanted byte replicated four times, and any matching byte becomes zero. Then the zero-detect expression finds it.' },
    { t: 'code', cap: 'Four bytes at a time', x: '    and  r1, r1, #0xFF\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16 @ the wanted byte, replicated\n1:  ldr  r3, [r0], #4\n    eor  r4, r3, r1          @ matching bytes become 0x00\n    sub  r5, r4, r6\n    bic  r5, r5, r4\n    ands r5, r5, r7\n    beq  1b' },
    { t: 'h', x: 'Substring search' },
    { t: 'p', x: 'The naive algorithm — try every starting position — is O(n×m) in the worst case and almost exactly O(n) in practice, because mismatches happen on the first character nearly every time. Knuth–Morris–Pratt is O(n) guaranteed but has a per-character cost the naive version does not, and needs a precomputed table.' },
    { t: 'code', cap: 'Naive substring search', x: '@ r0 = haystack, r1 = needle, r2 = haystack len, r3 = needle len\nouter:\n    mov  r4, r0\n    mov  r5, r1\n    mov  r6, r3\ninner:\n    ldrb r7, [r4], #1\n    ldrb r8, [r5], #1\n    cmp  r7, r8\n    bne  next\n    subs r6, r6, #1\n    bne  inner\n    bx   lr                  @ r0 points at the match\nnext:\n    add  r0, r0, #1\n    subs r2, r2, #1\n    bne  outer' },
    { t: 'note', x: 'For short needles and ordinary text, measure before reaching for KMP or Boyer–Moore. The naive loop\'s inner iteration is three instructions with perfect branch prediction on the common path; the clever algorithms pay table lookups to avoid comparisons that were nearly free.' }
  ],
  real: {
    title: 'Why glibc\'s memchr is 200 lines',
    text: 'Alignment head, SWAR body, a tail, a threshold below which the byte loop wins, and a separate NEON path. The algorithm is four lines. Everything else is making it correct and fast across every input size and alignment — which is what production code looks like.',
    code: '@ the four lines that matter\n    eor  r4, r3, r1\n    sub  r5, r4, r6\n    bic  r5, r5, r4\n    ands r5, r5, r7'
  },
  deep: {
    kind: 'compiler',
    title: 'An early exit is invisible and expensive',
    text: 'A loop that returns the moment it finds what it wants cannot be unrolled or vectorised without changing what the program can observe — a vectorised version would have to read several bytes past the match it should have stopped at. A loop that only counts matches and never exits early has no such restriction, and gcc will unroll it freely. In the source the two loops look almost identical; the compiler treats them completely differently.',
    a: { lab: 'C', lang: 'c', code: 'const uint8_t *find(const uint8_t *p, uint8_t x, size_t n) {\n    const uint8_t *end = p + n;\n    while (p < end && *p != x) p++;\n    return p;   /* == end when x was not found */\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: 'find:\n    add  r3, r0, r2\n1:  cmp  r0, r3\n    beq  2f\n    ldrb r12, [r0]\n    cmp  r12, r1\n    addne r0, r0, #1\n    bne  1b\n2:  bx   lr' },
    note: 'A result equal to <code>end</code> means "not found", and it is a perfectly valid-looking address — one past the last element of the buffer. Code that forgets to compare the return value against <code>end</code> before dereferencing it reads whatever happens to sit there instead of crashing cleanly.'
  },
  refs: [
    { src: 'ISO/IEC 9899, 7.24.5.1 — memchr', cite: 'memchr locates the first occurrence of c, converted to unsigned char, in the first n characters of the object pointed to by s.' },
    { src: 'Bit Twiddling Hacks (Sean Eron Anderson, Stanford)', cite: 'To determine whether a word contains a byte equal to n, XOR the word with a word of repeated n and apply the zero-byte test.' }
  ],
  ex: [
    { k: 'code', q: 'Find the first 0x37 in the 8 bytes at <code>buf</code>. Leave its index in r0, or −1 if absent.', start: '    ldr  r1, =buf\n    mov  r2, #8\n    mov  r0, #0\n1:\n\n.data\nbuf: .byte 0x11,0x22,0x33,0x37,0x44,0x37,0x55,0x66\n', check: [{ reg: 'r0', eq: 3 }], solution: '    ldr  r1, =buf\n    mov  r2, #8\n    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0x37\n    beq  2f\n    add  r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n    mvn  r0, #0\n2:\n\n.data\nbuf: .byte 0x11,0x22,0x33,0x37,0x44,0x37,0x55,0x66\n', hints: ['Compare each byte, break on a match.', '<code>mvn r0, #0</code> on the fall-through path gives −1.'], why: 'The first 0x37 is at index 3. The second one at index 5 is never reached.' },
    { k: 'code', q: 'SWAR version: check whether the word 0x11223744 contains the byte 0x37. Leave 1 in r0 if it does.', start: '    ldr  r3, =0x11223744\n    mov  r1, #0x37\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n', check: [{ reg: 'r0', eq: 1 }, { contains: 'eor' }], solution: '    ldr  r3, =0x11223744\n    mov  r1, #0x37\n    ldr  r6, =0x01010101\n    ldr  r7, =0x80808080\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16\n    eor  r4, r3, r1\n    sub  r5, r4, r6\n    bic  r5, r5, r4\n    ands r5, r5, r7\n    movne r0, #1\n    moveq r0, #0\n', hints: ['Replicate 0x37 into all four lanes, then XOR.', 'A matching byte becomes 0x00, which the zero-detect then finds.'], why: 'Byte 1 of the word is 0x37, so the XOR produces a zero byte and the test fires.' },
    { k: 'code', q: 'Naive substring search: find "CD" inside "ABCDE". Leave the index in r0.', start: '    ldr  r0, =hay\n    ldr  r1, =ndl\n    mov  r2, #5\n    mov  r3, #2\n    mov  r9, #0        @ index\n\n.data\nhay: .ascii "ABCDE"\nndl: .ascii "CD"\n', check: [{ reg: 'r9', eq: 2 }], solution: '    ldr  r0, =hay\n    ldr  r1, =ndl\n    mov  r2, #5\n    mov  r3, #2\n    mov  r9, #0\nouter:\n    mov  r4, r0\n    mov  r5, r1\n    mov  r6, r3\ninner:\n    ldrb r7, [r4], #1\n    ldrb r8, [r5], #1\n    cmp  r7, r8\n    bne  next\n    subs r6, r6, #1\n    bne  inner\n    b    found\nnext:\n    add  r0, r0, #1\n    add  r9, r9, #1\n    subs r2, r2, #1\n    bne  outer\n    mvn  r9, #0\nfound:\n\n.data\nhay: .ascii "ABCDE"\nndl: .ascii "CD"\n', hints: ['Outer loop over starting positions, inner loop over the needle.', 'Reset the three inner pointers at the top of each outer pass.'], why: '"CD" starts at index 2. The inner loop mismatched immediately at indices 0 and 1.' },
    { k: 'mcq', q: 'Why is naive substring search usually fine?', opts: ['It is O(n)', 'Mismatches almost always occur on the first character, so the inner loop rarely runs more than once', 'It uses less memory', 'It is not fine'], a: 1, why: 'The worst case is bad but requires adversarial input. For ordinary text the expected cost is very close to linear.' },
    { k: 'mcq', q: 'A search function returns a pointer equal to <code>end</code> (one past the last element) when the target is not found. What must the caller do before using the result?', opts: ['Nothing — it is always safe to dereference', 'Compare it against <code>end</code> first, the way <code>std::find</code> callers must', 'Free it', 'Check that it is NULL'], a: 1, why: 'A "not found" result that looks like a valid pointer is only safe if every caller remembers to compare it against the end before dereferencing it.' }
  ]
},

/* ----------------------------------------------------------------- 12.4 */
{
  id: 'u12l4', title: 'Blending a row of pixels', goal: 'Write the loop at the heart of every 2D renderer.',
  teach: [
    { t: 'p', x: 'Alpha blending computes, for each channel, <code>out = (src × a + dst × (255 − a)) / 255</code>. It is a multiply-heavy loop over independent elements — a textbook case for everything in Units 7 and 11.' },
    { t: 'code', cap: 'One channel, scalar', x: '@ r1 = src, r2 = dst, r0 = out, r3 = count, r4 = alpha 0..255\n    rsb  r5, r4, #255        @ 255 - alpha, hoisted\n1:  ldrb r6, [r1], #1\n    ldrb r7, [r2], #1\n    mul  r6, r6, r4\n    mla  r6, r7, r5, r6      @ src*a + dst*(255-a)\n    lsr  r6, r6, #8          @ approximate divide by 255\n    strb r6, [r0], #1\n    subs r3, r3, #1\n    bne  1b' },
    { t: 'note', x: '<code>LSR #8</code> divides by 256, not 255. The error is under half a percent and invisible, and it is what almost every real blender does — dividing by 255 exactly would cost a multiply by a magic constant or a division, per pixel. Where exactness matters, the trick is <code>x += x >> 8</code> before the shift, which corrects almost all of the bias for two extra instructions.' },
    { t: 'h', x: 'Why this loop is so well studied' },
    { t: 'p', x: 'It runs once per pixel per layer, so a full-screen blend on a 1920×1080 display is two million iterations per frame, sixty times a second. Every instruction in the body costs 124 million executions per second. That is why blending was the first thing NEON was pointed at.' },
    { t: 'code', noasm: true, cap: 'The vectorised shape', x: '@ eight pixels of one channel per pass\n1:  vld1.8 {d0}, [r1]!\n    vld1.8 {d1}, [r2]!\n    vmull.u8 q2, d0, d4      @ widen 8->16 and multiply by alpha\n    vmlal.u8 q2, d1, d5      @ accumulate dst * (255-alpha)\n    vshrn.i16 d6, q2, #8     @ shift and narrow back to 8 bits\n    vst1.8 {d6}, [r0]!\n    subs r3, r3, #8\n    bne  1b' },
    { t: 'p', x: 'Eight pixels per iteration instead of one, and the widening multiply avoids any intermediate overflow. This is the loop that draws every user interface you have ever used.' }
  ],
  real: {
    title: 'Skia, Cairo, and your phone',
    text: 'Every 2D graphics library ships hand-written NEON blend loops, usually several per pixel format. On a phone without GPU compositing for a given surface, this loop is what puts the pixels on the screen — and its cost is a measurable part of the battery life of scrolling a list.',
    code: '@ the scalar fallback every library still carries\n    mul  r6, r6, r4\n    mla  r6, r7, r5, r6\n    lsr  r6, r6, #8'
  },
  deep: {
    kind: 'cores',
    title: 'Saturation, one lane or four',
    text: 'Blending two already-opaque colours — screen, additive glow, anything that adds rather than interpolates — can push a channel over 255, and <code>USAT</code> clamps it back into range in a single instruction with no branch. Cortex-A cores, and the Cortex-M4 and M7, carry the ARMv6 SIMD extension on top of that: <code>UQADD8</code> and <code>USUB8</code> add or subtract four packed 8-bit lanes in one instruction, each lane saturating on its own. Cortex-M0, M0+ and M3 have no such extension, so a saturating add there costs one <code>USAT</code> per channel — exactly like the loop below.',
    code: '@ clamp one channel of src+dst into 0..255\n    add  r6, r6, r7\n    usat r6, #8, r6',
    note: '<code>UQADD8</code> would do all four channels of a pixel in the single instruction it takes this code to do one. This app\'s assembler does not implement it, so every saturating add here is written the way a Cortex-M0 or M3 has to write it anyway: one lane, one <code>USAT</code>.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — MLA', cite: 'MLA multiplies two register values and adds a third, producing the low 32 bits of the result.' },
    { src: 'Porter, T. & Duff, T. (1984), "Compositing Digital Images", SIGGRAPH', cite: 'The over operator combines source and destination colours weighted by the source alpha and its complement.' }
  ],
  ex: [
    { k: 'code', q: 'Blend 4 pixels: src at <code>s</code>, dst at <code>d</code>, alpha 128. Write the results to <code>o</code>.', start: '    ldr  r1, =s\n    ldr  r2, =d\n    ldr  r0, =o\n    mov  r3, #4\n    mov  r4, #128\n\n.data\ns: .byte 200, 100, 0, 255\nd: .byte 0, 100, 200, 255\no: .space 4\n', check: [{ memLabel: 'o', bytes: [100, 99, 99, 254] }], solution: '    ldr  r1, =s\n    ldr  r2, =d\n    ldr  r0, =o\n    mov  r3, #4\n    mov  r4, #128\n    rsb  r5, r4, #255\n1:  ldrb r6, [r1], #1\n    ldrb r7, [r2], #1\n    mul  r6, r6, r4\n    mla  r6, r7, r5, r6\n    lsr  r6, r6, #8\n    strb r6, [r0], #1\n    subs r3, r3, #1\n    bne  1b\n\n.data\ns: .byte 200, 100, 0, 255\nd: .byte 0, 100, 200, 255\no: .space 4\n', hints: ['Hoist <code>rsb r5, r4, #255</code> above the loop.', '<code>mul</code> then <code>mla</code> then <code>lsr #8</code>.'], why: 'Pixel 0: 200×128 + 0×127 = 25600, ≫8 = 100. Pixel 1: 100×128 + 100×127 = 25500, ≫8 = 99 — the exact answer is 100, and the shift-by-256 approximation is what loses it. Pixel 3: two opaque whites blend to 254, not 255.' },
    { k: 'mcq', q: 'Why does the blend shift right by 8 rather than dividing by 255?', opts: ['255 is not a power of two, so dividing exactly would cost a multiply or a division on every pixel; the error from 256 is under half a percent and invisible', 'Shifting is more accurate', '255 would overflow', 'It is a bug'], a: 0, why: 'A correction term <code>x += x &gt;&gt; 8</code> removes almost all the bias for two extra instructions, where exactness matters.' },
    { k: 'code', q: 'Make the divide exact. The correct rounding form is <code>t = x + 128</code> then <code>(t + (t &gt;&gt; 8)) &gt;&gt; 8</code>. Add those two instructions and blend the same 4 pixels.', start: '    ldr  r1, =s\n    ldr  r2, =d\n    ldr  r0, =o\n    mov  r3, #4\n    mov  r4, #128\n    rsb  r5, r4, #255\n1:  ldrb r6, [r1], #1\n    ldrb r7, [r2], #1\n    mul  r6, r6, r4\n    mla  r6, r7, r5, r6\n    lsr  r6, r6, #8\n    strb r6, [r0], #1\n    subs r3, r3, #1\n    bne  1b\n\n.data\ns: .byte 200, 100, 0, 255\nd: .byte 0, 100, 200, 255\no: .space 4\n', check: [{ memLabel: 'o', bytes: [100, 100, 100, 255] }], solution: '    ldr  r1, =s\n    ldr  r2, =d\n    ldr  r0, =o\n    mov  r3, #4\n    mov  r4, #128\n    rsb  r5, r4, #255\n1:  ldrb r6, [r1], #1\n    ldrb r7, [r2], #1\n    mul  r6, r6, r4\n    mla  r6, r7, r5, r6\n    add  r6, r6, #128\n    add  r6, r6, r6, lsr #8\n    lsr  r6, r6, #8\n    strb r6, [r0], #1\n    subs r3, r3, #1\n    bne  1b\n\n.data\ns: .byte 200, 100, 0, 255\nd: .byte 0, 100, 200, 255\no: .space 4\n', hints: ['<code>add r6, r6, #128</code> first, then <code>add r6, r6, r6, lsr #8</code>, then the final <code>lsr #8</code>.', 'The barrel shifter does the shift as part of the add, so the correction costs two instructions and no extra registers.'], why: 'Every pixel is now the correctly rounded value: 100, 100, 100, 255. White over white finally gives white, which is the artefact the correction exists to remove — and it cost two instructions, not a division.' },
    { k: 'mcq', q: 'Why was blending the first target for NEON?', opts: ['It is easy', 'It runs once per pixel per layer — millions of iterations per frame — with a simple, branch-free, independent body', 'It needs floating point', 'It was not'], a: 1, why: 'Huge iteration count plus a perfectly vectorisable body is the ideal SIMD profile.' },
    { k: 'mcq', q: 'Why can\'t this app\'s blend loop use a single <code>UQADD8</code> instead of four <code>USAT</code>s?', opts: ['UQADD8 is slower on every core', 'The app\'s assembler does not implement it, though real Cortex-A, M4 and M7 cores do', 'USAT is more accurate', 'It cannot be done on any ARMv7 core'], a: 1, why: 'UQADD8 is part of the ARMv6 SIMD extension, present on Cortex-A cores and on M4/M7, but this app\'s assembler only supports USAT — which is exactly the fallback a Cortex-M0 or M3 needs too, since they lack the extension entirely.' }
  ]
},

/* ----------------------------------------------------------------- 12.5 */
{
  id: 'u12l5', title: 'Final boss: the demo', goal: 'Put a framebuffer, a buzzer pin and a timing loop together in one program.',
  teach: [
    { t: 'p', x: 'This is the last lesson. You are going to write a small demo: clear the framebuffer, draw a pattern with a nested loop, and toggle the buzzer pin in a timed loop. Every technique in the course appears in it.' },
    { t: 'table', head: ['Part', 'From'], rows: [
      ['Clear the framebuffer with a block store', 'Units 5 and 9'],
      ['Nested loop over rows and bytes', 'Unit 4'],
      ['Row address from the stride multiply', 'Unit 9'],
      ['A pattern that changes per row', 'Unit 3'],
      ['Toggle the buzzer pin in a timed loop', 'Unit 8'],
      ['Count the cycles and check the budget', 'Unit 7']
    ] },
    { t: 'code', cap: 'The skeleton', x: '    ldr  r7, =0x20000000     @ framebuffer: 320x240, 1bpp, 40-byte stride\n    ldr  r11, =0x20020000    @ GPIO — any access toggles the buzzer pin\n\n@ ---- clear: 9600 bytes, 16 per pass ----\n    mov  r0, r7\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r2, #600\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b\n\n@ ---- draw: rows 1-7, each filled with its own row number ----\n    mov  r6, #1              @ row\n2:  add  r0, r6, r6, lsl #2  @ row*5\n    lsl  r0, r0, #3          @ row*40\n    add  r0, r0, r7\n    mov  r8, #40\n3:  strb r6, [r0], #1\n    subs r8, r8, #1\n    bne  3b\n    add  r6, r6, #1\n    cmp  r6, #8\n    blo  2b\n\n@ ---- buzzer: eight toggles with a delay ----\n    mov  r4, #8\n4:  ldr  r2, [r11]\n    mov  r5, #40\n5:  subs r5, r5, #1\n    bne  5b\n    subs r4, r4, #1\n    bne  4b' },
    { t: 'note', x: 'Run it. The machine panel draws the pattern and the buzzer trace picks up eight edges — a screen, a sound and a timing budget, out of one program. That combination runs on everything from games consoles to point-of-sale terminals to industrial control panels.' },
    { t: 'h', x: 'What to do next' },
    { t: 'p', x: 'Read compiler output. Take a C loop you understand, build it for ARMv7 with <code>-O2</code>, and find the four parts. You will recognise the hoisting, the rotation, the post-indexing and the unrolling — and where the compiler did something you would not have, that is the interesting part.' },
    { t: 'p', x: 'Then read a real library. ARM\'s optimised-routines, CMSIS-DSP, and the string functions in any libc are the best-written loops in the world, and after this course they are readable.' }
  ],
  real: {
    title: 'The loop is the unit of performance',
    text: 'Almost all the time in almost all programs is spent in a small number of loops. Everything in this course — flags, addressing modes, block transfers, predication, hoisting, unrolling, vectors — exists to make those few loops faster. That is the whole subject.',
    code: '@ if you remember one thing:\n1:  ldr  r3, [r1], #4\n    subs r2, r2, #1\n    add  r0, r0, r3\n    bne  1b\n@ post-indexed load, flag-setting decrement, scheduled, one branch.'
  },
  deep: {
    kind: 'cores',
    title: 'What thirty instructions actually cost',
    text: 'The final program in this lesson is a complete, if small, ARMv7 workload: a block-store clear, a strided row address built from a shift and an add instead of a multiply, a per-row pattern, and a timed GPIO toggle loop. Run through this course\'s cycle model, the whole thing costs 8,787 cycles and 3,373 instructions end to end — roughly 6,000 cycles clearing the framebuffer, 1,450 drawing seven rows, and 1,300 toggling the pin eight times. Treat each modelled cycle as one core clock and a 900 MHz Cortex-A7, the core in a Raspberry Pi 2, finishes all of it in under ten microseconds.',
    code: '@ the same 9,600-byte clear, 8 registers instead of 4\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r6, #0\n    mov  r8, #0\n    mov  r9, #0\n    mov  r10, #0\n    mov  r2, #300\n1:  stmia r0!, {r1, r3, r4, r5, r6, r8, r9, r10}\n    subs  r2, r2, #1\n    bne   1b',
    note: 'Same order of writes, same total bytes, 4,213 cycles instead of 6,009 — thirty percent faster for widening one instruction from four registers to eight. Every other technique in this course shows up the same way: not as a rewrite, but as a small, local change to a loop that was already correct.'
  },
  refs: [
    { src: 'ARM Architecture Reference Manual, ARMv7-A/R edition (DDI 0406C)', cite: 'The complete architectural definition of everything in this course.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D)', cite: 'The practical companion: cache behaviour, pipeline effects, and the optimisation guidance behind Units 7 and 11.' },
    { src: 'ARMv7-M Architecture Reference Manual (DDI 0403E.b)', cite: 'The other half of ARMv7: the Cortex-M encoding of the same architecture family, Thumb-2 only, no A32.' }
  ],
  ex: [
    { k: 'code', q: 'Clear the framebuffer, then fill row 0 with 0xFF so the whole top row lights up.', start: '    ldr  r7, =0x20000000\n', check: [{ fbBytes: 40 }, { fbPixel: [0, 0], eq: 1 }, { fbPixel: [319, 0], eq: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r0, r7\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r2, #600\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b\n    mov  r0, r7\n    mov  r1, #0xFF\n    mov  r2, #40\n2:  strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  2b\n', hints: ['Block-clear first, then a 40-byte fill at offset 0.', '0xFF lights every pixel in a byte — bit 7 is the leftmost pixel, bit 0 the rightmost.'], why: 'Exactly 40 non-zero bytes: one full row, 320 pixels wide. Bit 7 of byte 0 is pixel 0; bit 0 of byte 39 is pixel 319 — the two ends of the row.' },
    { k: 'code', q: 'Draw rows 1–7, each filled with its own row number as the byte pattern. Row y starts at offset y × 40, the framebuffer stride — leave row 0 blank.', start: '    ldr  r7, =0x20000000\n    mov  r6, #1        @ start at row 1 so row 0 stays blank\n2:\n', check: [{ fbBytes: 280 }, { fbPixel: [7, 1], eq: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r6, #1\n2:  add  r0, r6, r6, lsl #2\n    lsl  r0, r0, #3\n    add  r0, r0, r7\n    mov  r8, #40\n3:  strb r6, [r0], #1\n    subs r8, r8, #1\n    bne  3b\n    add  r6, r6, #1\n    cmp  r6, #8\n    blo  2b\n', hints: ['Row offset is row × 40 — a shift and an add, not a lookup table.', 'The byte stored is the row number itself.'], why: 'Seven rows of 40 bytes is 280 non-zero bytes. Row numbers 1–7 all have bit 7 clear, and bit 7 is the leftmost pixel, so none of these rows lights its left edge — pixel (7,1) is lit because 1 = 0b00000001 sets the rightmost pixel of that byte instead.' },
    { k: 'code', q: 'The full demo: clear the framebuffer, fill rows 1–7 with the row number, then toggle the buzzer pin 8 times with a 40-iteration delay between toggles.', start: '    ldr  r7, =0x20000000\n    ldr  r11, =0x20020000\n', check: [{ fbBytes: 280 }, { gpio: 8 }, { minCycles: 4000 }], solution: '    ldr  r7, =0x20000000\n    ldr  r11, =0x20020000\n    mov  r0, r7\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r2, #600\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b\n    mov  r6, #1\n2:  add  r0, r6, r6, lsl #2\n    lsl  r0, r0, #3\n    add  r0, r0, r7\n    mov  r8, #40\n3:  strb r6, [r0], #1\n    subs r8, r8, #1\n    bne  3b\n    add  r6, r6, #1\n    cmp  r6, #8\n    blo  2b\n    mov  r4, #8\n4:  ldr  r2, [r11]\n    mov  r5, #40\n5:  subs r5, r5, #1\n    bne  5b\n    subs r4, r4, #1\n    bne  4b\n', hints: ['Three sections in order: clear, draw, sound.', 'Keep the framebuffer base in r7 and the GPIO address in r11 the whole time.'], why: 'Framebuffer, buzzer and timing from one program — every technique in this course is somewhere in those thirty instructions.' },
    { k: 'mcq', q: 'What single shape do all the loops in this course share?', opts: ['A counter', 'Initialise, do the work, move towards the exit, test and branch backwards', 'A memory access', 'A conditional instruction'], a: 1, why: 'Init, body, update, test. Everything else is optimisation.' },
    { k: 'mcq', q: 'What is the best next step after this course?', opts: ['Memorise the instruction set', 'Read optimised compiler output and real library source, and find the four parts in them', 'Write everything in assembly', 'Learn ARMv8 first'], a: 1, why: 'Reading good loops is how the patterns stop being techniques and start being instincts.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
