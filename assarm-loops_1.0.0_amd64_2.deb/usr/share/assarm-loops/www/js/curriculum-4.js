/* AssArm: Loops — curriculum part 4 : Unit 8, timing loops and bit-banging */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u8', n: 8, title: 'Timing Loops & Bit-Banging', icon: '⏱', color: '#ff9e64',
    blurb: 'Loops whose output is not a number but a length of time — the loops that drive pins, buzzers, serial lines and every peripheral your chip does not have.',
    lessons: [

/* ------------------------------------------------------------------ 8.1 */
{
  id: 'u8l1', title: 'The delay loop', goal: 'Write a loop whose product is elapsed time.',
  teach: [
    { t: 'p', x: 'Every loop so far produced a value. A <b>delay loop</b> produces nothing at all — its only output is the time it took. That sounds like a waste of a processor, and often it is, but sometimes it is the only tool that works.' },
    { t: 'code', cap: 'The simplest delay', x: '    mov  r0, #1000\n1:  subs r0, r0, #1\n    bne  1b' },
    { t: 'h', x: 'Working out the constant' },
    { t: 'p', x: 'You want a delay of <i>T</i> seconds on a core running at <i>f</i> Hz, with a loop body costing <i>c</i> cycles. The count is <code>N = T × f / c</code>.' },
    { t: 'table', head: ['Want', 'Core clock', 'Body cost', 'Count'], rows: [
      ['1 ms', '16 MHz Cortex-M0', '3 cycles', '≈ 5,333'],
      ['1 ms', '48 MHz Cortex-M4', '2 cycles', '≈ 24,000'],
      ['1 ms', '1 GHz Cortex-A7', '2 cycles', '≈ 500,000'],
      ['1 µs', '48 MHz Cortex-M4', '2 cycles', '≈ 24'],
      ['10 s', '1 GHz Cortex-A7', '2 cycles', '5,000,000,000 — too big for one register']
    ] },
    { t: 'note', x: 'A 32-bit counter at 2 cycles per iteration tops out at about 8.6 seconds on a 1 GHz core. Longer delays need a nested loop — and that is the main reason delay loops are usually written with two levels.' },
    { t: 'h', x: 'Nested delay' },
    { t: 'code', cap: 'Two levels multiply', x: '    mov  r1, #100        @ outer\n1:  mov  r0, #1000       @ inner\n2:  subs r0, r0, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n@ roughly 100 * 1000 iterations' },
    { t: 'h', x: 'The compiler will delete it' },
    { t: 'p', x: 'A delay loop written in C with nothing in its body has no observable effect, so an optimising compiler is entitled to remove it entirely — and will. That is <i>the</i> reason delay loops are written in assembly, or with a <code>volatile</code> counter, or with an inline-assembly barrier. In assembly the problem does not arise: what you write is what runs.' },
    { t: 'h', x: 'And an interrupt will lengthen it' },
    { t: 'p', x: 'A delay loop measures instructions executed, not time elapsed. If an interrupt fires in the middle, the handler\'s cycles are added to your delay. A loop calibrated with interrupts disabled will be reliably longer than asked with them enabled — which is fine for "wait at least 5 µs" and fatal for "toggle this pin every 5 µs".' }
  ],
  real: {
    title: 'Waiting for hardware that has no ready signal',
    text: 'Plenty of real chips need a fixed settling time and give you no way to ask whether they are ready: an ADC after changing its input mux, a relay after switching, an LCD controller after a reset, a radio leaving sleep, an I²C device after a soft reset. The datasheet says "wait 5 µs" and a delay loop is the honest implementation.',
    code: '@ ~5 us at 48 MHz, 2 cycles per iteration\n    mov  r0, #120\n1:  subs r0, r0, #1\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'Why the C version disappears',
    text: 'An empty loop over a plain <code>int</code> has no effect the standard can observe, so the optimiser deletes it. Marking the counter <code>volatile</code> forces a load and a store every iteration, which keeps the loop but makes its cost memory-dependent and hard to calibrate. Writing the loop in inline assembly is the only version that gives you exactly the instructions you asked for.',
    a: { lab: 'C — gone at -O2', lang: 'c', code: 'void delay(int n) {\n    for (int i = 0; i < n; i++)\n        ;\n}\n// gcc -O2 emits:\n//     bx lr' },
    b: { lab: 'Inline asm — survives', lang: 'c', code: 'void delay(int n) {\n    __asm__ volatile (\n      "1: subs %0, %0, #1\\n"\n      "   bne  1b\\n"\n      : "+r" (n) :: "cc");\n}' },
    note: 'The <code>volatile</code> on the asm block is what stops the compiler hoisting it out of a loop or deleting it as unused; the <code>"cc"</code> clobber tells it the condition flags are destroyed.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — SUB, B', cite: 'Neither instruction has a defined cycle cost in the architecture; timing is implementation-defined and documented per core.' },
    { src: 'ISO/IEC 9899, 5.1.2.3 — Program execution', cite: 'An implementation may omit any part of a program whose evaluation produces no needed side effects.' }
  ],
  ex: [
    { k: 'mcq', q: 'Why are delay loops usually written in assembly rather than C?', opts: ['C is too slow', 'An empty C loop has no observable effect, so the optimiser may delete it', 'C cannot count down', 'Assembly runs at a fixed clock'], a: 1, why: 'The C version needs <code>volatile</code>, an inline-asm barrier, or a compiler intrinsic. In assembly, what you write is what executes.' },
    { k: 'code', q: 'Write a delay loop that executes exactly 500 iterations. This machine model charges 4 cycles per trip, so aim for roughly 2000 cycles.', start: '    @ your delay here\n', check: [{ minCycles: 1900 }, { maxCycles: 2100 }], solution: '    mov  r0, #500\n1:  subs r0, r0, #1\n    bne  1b\n', hints: ['<code>mov r0, #500</code> then a two-instruction countdown.'], why: '500 iterations at 4 cycles each is 2000, plus a little setup. Change the count and watch the cycle figure move with it.' },
    { k: 'mcq', q: 'A 1 GHz core, a 2-cycle loop body, and you want 1 millisecond. What count?', opts: ['1,000', '500,000', '2,000,000', '1,000,000'], a: 1, why: '1 ms is 1,000,000 cycles; at 2 cycles per iteration that is 500,000 iterations.' },
    { k: 'code', q: 'Build a nested delay: outer 20, inner 50, so the body runs 1000 times in total. Leave the total iteration count in r5.', start: '    mov  r5, #0\n    mov  r1, #20\n1:\n', check: [{ reg: 'r5', eq: 1000 }], solution: '    mov  r5, #0\n    mov  r1, #20\n1:  mov  r0, #50\n2:  add  r5, r5, #1\n    subs r0, r0, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n', hints: ['Reset the inner counter inside the outer loop.', 'Count the trips in r5.'], why: '20 × 50 = 1000. Nesting is how you get delays longer than one register can count.' },
    { k: 'mcq', q: 'An interrupt fires during a delay loop. What happens to the delay?', opts: ['It is unaffected', 'It gets longer by the duration of the handler', 'It gets shorter', 'The loop restarts'], a: 1, why: 'A delay loop counts instructions, not time. That is fine for "wait at least n"; it is not fine for generating a waveform.' }
  ]
},

/* ------------------------------------------------------------------ 8.2 */
{
  id: 'u8l2', title: 'The quadratic delay trap', goal: 'Recognise a nested delay whose cost grows with the square of its argument.',
  teach: [
    { t: 'p', x: 'Here is a delay routine of the kind that turns up in real firmware. It looks reasonable. Work out how long it takes for a given <code>r0</code> before reading on.' },
    { t: 'code', cap: 'What does this cost?', x: 'wait:\n    mov  r1, r0          @ outer count = the argument\n1:  mov  r2, r1          @ inner count = the CURRENT outer count\n2:  subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n    bx   lr' },
    { t: 'p', x: 'The trap is on the third line. The inner counter is reloaded from <code>r1</code>, which is shrinking — not from <code>r0</code>, which is not. So the inner loop runs A times, then A−1, then A−2, all the way down to 1. The total is the sum of the first A integers:' },
    { t: 'table', head: ['Argument A', 'Inner iterations', 'Relative to A = 10'], rows: [
      ['10', '55', '1×'],
      ['20', '210', '3.8×'],
      ['50', '1,275', '23×'],
      ['100', '5,050', '92×'],
      ['255', '32,640', '593×']
    ] },
    { t: 'note', x: '<code>A(A+1)/2</code> — quadratic. Double the argument and you quadruple the wait. A device that behaves at a low setting and becomes mysteriously unresponsive at a high one very often has one of these in it.' },
    { t: 'h', x: 'The linear version' },
    { t: 'code', cap: 'One counter, one meaning', x: 'delay:\n1:  subs r0, r0, #1\n    bne  1b\n    bx   lr' },
    { t: 'p', x: 'Predictable: double the argument, double the wait. If one register cannot count high enough, nest deliberately — with the inner count <b>constant</b> — so the cost is outer × inner rather than a triangular number.' },
    { t: 'code', cap: 'A deliberate nest is still linear in its arguments', x: 'delay_long:\n@ r0 = outer, r1 = inner (constant)\n1:  mov  r2, r1          @ reload from r1, which never changes\n2:  subs r2, r2, #1\n    bne  2b\n    subs r0, r0, #1\n    bne  1b\n    bx   lr' },
    { t: 'h', x: 'How the bug gets written' },
    { t: 'p', x: 'Almost always by accident, in one of two ways: a nested delay where the inner reload picks up the wrong register, or — far more common in C — a delay function that calls another delay function inside a loop. <code>for (i = 0; i &lt; n; i++) delay_ms(n);</code> is quadratic and looks entirely innocent.' }
  ],
  real: {
    title: 'Quadratic waits in the wild',
    text: 'The pattern shows up in bit-banged bus drivers whose retry loop calls a settle delay scaled by the retry count, and in LED animations whose "speed" parameter feeds both the step count and the per-step delay. The symptom is always the same: fine at low values, apparently hung at high ones.',
    code: '@ the accidental version: the inner reload uses the shrinking counter\n1:  mov  r2, r1          @ <- should be a constant, or r0\n2:  subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b'
  },
  deep: {
    kind: 'pitfall',
    title: 'One register, two jobs',
    text: 'The whole bug is a single register doing double duty. <code>r1</code> is both the outer loop counter and the source of the inner loop count, so the two are coupled. The fix is one character — reload from <code>r0</code>, or from a register that nothing in the loop writes — and the routine becomes linear.',
    a: { lab: 'Quadratic — A(A+1)/2 iterations', code: 'wait:\n    mov  r1, r0\n1:  mov  r2, r1        @ shrinking source\n2:  subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n    bx   lr' },
    b: { lab: 'Linear — A×A iterations, predictably', code: 'wait:\n    mov  r1, r0\n1:  mov  r2, r0        @ constant source\n2:  subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n    bx   lr' },
    note: 'A good habit for any nested loop: write down, next to the inner reload, which register it comes from and whether the loop can change it. It catches this and the "inner counter initialised outside the outer loop" bug from Unit 4 at the same time.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — SUBS', cite: 'The S suffix makes the subtraction update the condition flags, which is what the terminating branch of each level of the nest reads.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop nesting', cite: 'The total cost of a nested loop is the product of the iteration counts; a counter shared between levels couples them.' }
  ],
  ex: [
    { k: 'code', q: 'Run the quadratic routine with r0 = 6 and count the total inner iterations in r5. It should be 1+2+3+4+5+6 = 21.', start: '    mov  r0, #6\n    mov  r5, #0\n    mov  r1, r0\n1:\n', check: [{ reg: 'r5', eq: 21 }], solution: '    mov  r0, #6\n    mov  r5, #0\n    mov  r1, r0\n1:  mov  r2, r1\n2:  add  r5, r5, #1\n    subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n', hints: ['The inner count is a copy of the CURRENT outer count, not of the original argument.', 'That single detail is what makes it quadratic.'], why: 'Copy r1 into r2 at the top of each outer pass and the inner loop shrinks by one each time — the triangular number.' },
    { k: 'code', q: 'Now fix it: reload the inner counter from r0 so the routine is linear. With r0 = 6 the total should be 36.', start: '    mov  r0, #6\n    mov  r5, #0\n    mov  r1, r0\n1:  mov  r2, r1\n2:  add  r5, r5, #1\n    subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n', check: [{ reg: 'r5', eq: 36 }], solution: '    mov  r0, #6\n    mov  r5, #0\n    mov  r1, r0\n1:  mov  r2, r0\n2:  add  r5, r5, #1\n    subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n', hints: ['Change one register in the inner reload.', 'r0 never changes; r1 shrinks.'], why: '6 × 6 = 36 instead of 21. One character, and the routine now scales predictably.' },
    { k: 'mcq', q: 'Using A(A+1)/2, how much longer does the quadratic routine take at A = 200 than at A = 100?', opts: ['Twice as long', 'About four times as long', 'The same', 'About 40 times as long'], a: 1, why: '20,100 versus 5,050 — the square term dominates, so doubling the argument quadruples the wait.' },
    { k: 'code', q: 'Write a purely linear delay: r0 iterations, no nesting, counting the trips in r5. Use r0 = 40.', start: '    mov  r0, #40\n    mov  r5, #0\n', check: [{ reg: 'r5', eq: 40 }, { maxInsn: 130 }], solution: '    mov  r0, #40\n    mov  r5, #0\n1:  add  r5, r5, #1\n    subs r0, r0, #1\n    bne  1b\n', hints: ['One loop, no inner loop.'], why: 'Linear delays are predictable: double the argument, double the wait. Prefer them unless you have a reason not to.' },
    { k: 'mcq', q: 'What is the C equivalent of this bug?', opts: ['Using <code>int</code> instead of <code>long</code>', 'A loop that calls a delay function whose argument is the loop counter', 'Forgetting <code>volatile</code>', 'Calling delay twice'], a: 1, why: '<code>for (i = 0; i &lt; n; i++) delay(n);</code> looks innocent and is quadratic in n.' }
  ]
},

/* ------------------------------------------------------------------ 8.3 */
{
  id: 'u8l3', title: 'A square wave from a loop', goal: 'Drive a pin at a chosen frequency with nothing but a loop.',
  teach: [
    { t: 'p', x: 'The simplest output any chip has is a pin that can be high or low. Toggle it at a steady rate and you have a square wave; put a piezo buzzer across it and you have a tone. The pitch is set entirely by <i>how long your loop takes</i>, which makes every note a delay-loop calculation.' },
    { t: 'p', x: 'This machine has such a pin at <b>0x20020000</b>. Any access to that address toggles it, and the machine panel draws the resulting waveform.' },
    { t: 'code', cap: 'Eight toggles', x: '    ldr  r0, =0x20020000  @ the GPIO toggle register\n    mov  r1, #8\n1:  ldr  r2, [r0]         @ the ACCESS is the toggle; r2 is meaningless\n    subs r1, r1, #1\n    bne  1b' },
    { t: 'note', x: 'Note what is happening: the <i>side effect of the access</i> is the output, and the value loaded is discarded. This is what memory-mapped I/O means, and it is why <code>volatile</code> exists in C — the compiler must not be allowed to notice that r2 is unused and delete the load.' },
    { t: 'h', x: 'A tone is a toggle plus a wait' },
    { t: 'code', cap: 'The complete tone loop', x: '@ r3 = half-period in loop iterations, r4 = number of half-cycles\n    ldr  r0, =0x20020000\n1:  ldr  r2, [r0]         @ toggle\n    mov  r5, r3           @ reload the delay\n2:  subs r5, r5, #1       @ wait out the half period\n    bne  2b\n    subs r4, r4, #1\n    bne  1b' },
    { t: 'p', x: 'Bigger <code>r3</code> means a longer half-period, which means a lower note. The relationship is inverse: to go up an octave, halve r3.' },
    { t: 'h', x: 'Real GPIO has set and clear registers' },
    { t: 'p', x: 'A toggle register is a convenience. Most ARM microcontrollers instead give you separate <b>set</b> and <b>clear</b> registers — write a bit mask to BSRR/GPIOx_SET and the pin goes high, write it to the clear register and it goes low. Two registers instead of one read-modify-write, which is both faster and atomic with respect to interrupts.' },
    { t: 'code', cap: 'What the same loop looks like on real hardware', x: '@ r4 = GPIO block, r8 = the pin mask\n1:  str  r8, [r4, #GPIO_SET]\n    mov  r5, r3\n2:  subs r5, r5, #1\n    bne  2b\n    str  r8, [r4, #GPIO_CLR]\n    mov  r5, r3\n3:  subs r5, r5, #1\n    bne  3b\n    subs r6, r6, #1\n    bne  1b' },
    { t: 'h', x: 'Why it sounds hard' },
    { t: 'p', x: 'A square wave contains the fundamental plus every odd harmonic, which is why a bit-banged buzzer has that distinctive buzzy edge. Varying the ratio of high time to low time — pulse-width modulation — changes the harmonic content and, fed to an LED or a motor instead, changes the average voltage.' }
  ],
  real: {
    title: 'Bit-banged PWM',
    text: 'The same loop with different on and off times becomes PWM: dimming an LED, driving a motor, generating an analogue-ish voltage through an RC filter. Hardware timers do it better, but every board has more GPIO pins than timer channels, and this loop is what you fall back on for the pins that did not get one.',
    code: '@ bit-banged PWM: r6 = on time, r7 = off time\n1:  str  r8, [r5, #GPIO_SET]\n    mov  r0, r6\n2:  subs r0, r0, #1\n    bne  2b\n    str  r8, [r5, #GPIO_CLR]\n    mov  r0, r7\n3:  subs r0, r0, #1\n    bne  3b\n    b    1b'
  },
  deep: {
    kind: 'pitfall',
    title: 'The load the compiler deleted',
    text: 'A read whose result is unused is dead code, and an optimiser will remove it — taking your toggle with it. The fix is <code>volatile</code> on the pointer, which tells the compiler the access itself is the point. The same applies to reading a status register to clear it, a very common hardware idiom that looks like a no-op to the optimiser.',
    a: { lab: 'Silently removed at -O2', lang: 'c', code: 'uint32_t *gpio = (uint32_t *)0x20020000;\n\nfor (int i = 0; i < 8; i++)\n    (void)*gpio;      // deleted' },
    b: { lab: 'Survives', lang: 'c', code: 'volatile uint32_t *gpio =\n    (volatile uint32_t *)0x20020000;\n\nfor (int i = 0; i < 8; i++)\n    (void)*gpio;      // kept' },
    note: 'Device memory also stops the core itself from merging, reordering or repeating the access. <code>volatile</code> constrains the compiler; the memory type constrains the hardware. You need both.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Memory types and attributes', cite: 'Accesses to Device memory have side effects and must not be reordered, merged or repeated by the implementation.' },
    { src: 'ISO/IEC 9899, 6.7.3 — volatile', cite: 'An object that has volatile-qualified type may be modified in ways unknown to the implementation, so accesses to it must not be optimised away.' }
  ],
  ex: [
    { k: 'code', q: 'Toggle the pin exactly 16 times.', start: '    ldr  r0, =0x20020000\n    mov  r1, #16\n1:\n', check: [{ gpio: 16 }], solution: '    ldr  r0, =0x20020000\n    mov  r1, #16\n1:  ldr  r2, [r0]\n    subs r1, r1, #1\n    bne  1b\n', hints: ['A load from the GPIO address is the toggle.', 'Discard the loaded value — it means nothing.'], why: 'Watch the waveform in the machine panel: sixteen edges.' },
    { k: 'mcq', q: 'Why is the value loaded from the toggle register meaningless?', opts: ['It is always zero', 'The hardware responds to the fact of the access, not to the data — the toggle is a side effect of decoding the address', 'It is the pin state', 'It is the frequency'], a: 1, why: 'Memory-mapped I/O in its purest form: the address bus doing the work.' },
    { k: 'code', q: 'Play a tone: toggle the pin 12 times with a 20-iteration delay between each toggle.', start: '    ldr  r0, =0x20020000\n    mov  r4, #12\n1:\n', check: [{ gpio: 12 }, { minCycles: 500 }], solution: '    ldr  r0, =0x20020000\n    mov  r4, #12\n1:  ldr  r2, [r0]\n    mov  r5, #20\n2:  subs r5, r5, #1\n    bne  2b\n    subs r4, r4, #1\n    bne  1b\n', hints: ['Toggle, then an inner delay loop, then the outer counter.', 'Reload the delay counter inside the outer loop.'], why: 'Twelve edges is six full cycles of a square wave. The delay sets the pitch.' },
    { k: 'mcq', q: 'To raise the pitch by one octave, what do you do to the half-period delay count?', opts: ['Double it', 'Halve it', 'Add 12', 'Nothing'], a: 1, why: 'An octave up is twice the frequency, which is half the period.' },
    { k: 'code', q: 'Play a rising two-note sequence: 8 toggles with delay 30, then 8 toggles with delay 15.', start: '    ldr  r0, =0x20020000\n    mov  r3, #30\n    mov  r6, #2\n3:\n', check: [{ gpio: 16 }], solution: '    ldr  r0, =0x20020000\n    mov  r3, #30\n    mov  r6, #2\n3:  mov  r4, #8\n1:  ldr  r2, [r0]\n    mov  r5, r3\n2:  subs r5, r5, #1\n    bne  2b\n    subs r4, r4, #1\n    bne  1b\n    lsr  r3, r3, #1\n    subs r6, r6, #1\n    bne  3b\n', hints: ['Wrap the tone loop in an outer loop that runs twice.', 'Halve r3 between the two notes with <code>lsr r3, r3, #1</code>.'], why: 'Three nested loops — note, half-cycle, delay — is exactly how a bit-banged music routine is built.' }
  ]
},

/* ------------------------------------------------------------------ 8.4 */
{
  id: 'u8l4', title: 'From frequency to loop count', goal: 'Turn a wanted frequency into the constant a loop needs.',
  teach: [
    { t: 'p', x: 'Given a frequency you want and a core you are running on, the arithmetic is short.' },
    { t: 'table', head: ['Step', 'Formula'], rows: [
      ['Period', 'T = 1 / f seconds'],
      ['Half-period (one toggle interval)', 'T/2 = 1 / (2f)'],
      ['Cycles per half-period', 'C = clock / (2f)'],
      ['Loop iterations', 'N = (C − overhead) / cycles_per_iteration']
    ] },
    { t: 'code', noasm: true, cap: 'Concert A on a 48 MHz Cortex-M4', x: '@ f = 440 Hz\n@ C = 48,000,000 / 880 = 54,545 cycles per half-period\n@ inner loop body = 2 cycles\n@ N = (54,545 - ~10 overhead) / 2 ~= 27,267' },
    { t: 'code', cap: 'The same note on a 16 MHz Cortex-M0', x: '@ C = 16,000,000 / 880 = 18,182 cycles\n@ inner loop body = 3 cycles on M0 (the branch costs more)\n@ N = 6,060\n    ldr  r3, =6060' },
    { t: 'note', x: 'The body cost differs between cores: a taken branch is 3 cycles on a Cortex-M0 and often 1 on an M4 with branch prediction. Recalibrating for a new core is not optional, and it is the main argument for measuring rather than computing.' },
    { t: 'h', x: 'Building a scale' },
    { t: 'p', x: 'Equal temperament multiplies the frequency by the twelfth root of two per semitone — about 1.05946. Since the loop count is inversely proportional to frequency, each semitone <i>divides</i> the count by that factor. In integer assembly the practical answer is a lookup table of twelve precomputed counts, exactly as in Unit 6.' },
    { t: 'code', cap: 'A note table, one entry per semitone', x: 'notes:\n    .hword 1911, 1804, 1703, 1607, 1517, 1432\n    .hword 1351, 1276, 1204, 1136, 1073, 1012' },
    { t: 'p', x: 'The twelfth entry is very nearly half the first — that is an octave, and it is a good check that your table is right.' },
    { t: 'h', x: 'Why this all moved into hardware' },
    { t: 'p', x: 'Because the CPU is fully occupied while a note is playing, this technique cannot do anything else at the same time. A hardware timer in PWM mode produces the same square wave with no CPU involvement at all, and every ARM microcontroller has several. The bit-banged tone survives where the timers are all spoken for, or on the cheapest parts that have almost none.' }
  ],
  real: {
    title: 'The beep in an appliance',
    text: 'A cost-reduced controller has a piezo buzzer on a GPIO pin and no spare timer channel. Its beep is a loop exactly like this one, and its error tone is the same loop with a different table entry. The technique did not survive out of nostalgia; it survived because it costs nothing in silicon.',
    code: '@ pick a note from the table and play it\n    ldr  r6, =notes\n    ldrh r3, [r6, r7, lsl #1]   @ r7 = semitone index\n    mov  r4, #200               @ duration in half-cycles\n1:  ldr  r2, [r0]\n    mov  r5, r3\n2:  subs r5, r5, #1\n    bne  2b\n    subs r4, r4, #1\n    bne  1b'
  },
  deep: {
    kind: 'cores',
    title: 'The same loop, three different speeds',
    text: 'The loop body is <code>SUBS</code> plus a taken <code>BNE</code>, and what that costs depends entirely on the core. A Cortex-M0 has no branch prediction and a short pipeline, so a taken branch costs 3 cycles. A Cortex-M4 folds many branches to 1. A Cortex-A7 predicts them, so the loop is nearly free until the predictor is wrong.',
    a: { lab: 'The body', code: '2:  subs r5, r5, #1\n    bne  2b' },
    b: { lab: 'What it costs', lang: 'c', code: '// Cortex-M0   1 + 3 = 4 cycles\n// Cortex-M3   1 + 2 = 3 cycles\n// Cortex-M4   1 + 1..3 (branch folding)\n// Cortex-A7   ~2, once predicted\n//\n// The same constant gives four\n// different frequencies.' },
    note: 'This is why every serious delay implementation measures against a real timer at start-up rather than trusting a computed constant. Lesson 8.7 builds that.'
  },
  refs: [
    { src: 'ARM Cortex-M0 Technical Reference Manual, Instruction timing', cite: 'A taken branch takes three cycles on Cortex-M0; a not-taken branch takes one.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDRH', cite: 'LDRH loads a halfword and zero-extends it, making 16-bit tables an economical choice for constants below 65536.' }
  ],
  ex: [
    { k: 'mcq', q: 'A 48 MHz core, a 2-cycle loop body, and you want 1 kHz. Roughly what half-period count?', opts: ['1,000', '12,000', '24,000', '48,000'], a: 1, why: '48,000,000 / 2000 = 24,000 cycles per half-period; at 2 cycles per iteration that is 12,000 iterations.' },
    { k: 'mcq', q: 'Going up one semitone multiplies the frequency by about 1.05946. What does it do to the loop count?', opts: ['Multiplies it by 1.05946', 'Divides it by 1.05946', 'Adds 12', 'Nothing'], a: 1, why: 'Count is inversely proportional to frequency, so higher notes have smaller counts.' },
    { k: 'code', q: 'Read the third entry (index 2) of the note table into r3 with one instruction, then use it to play 6 toggles.', start: '    ldr  r0, =0x20020000\n    ldr  r6, =notes\n    mov  r7, #2\n\n.data\nnotes: .hword 40, 38, 36, 34, 32, 30\n', check: [{ reg: 'r3', eq: 36 }, { gpio: 6 }], solution: '    ldr  r0, =0x20020000\n    ldr  r6, =notes\n    mov  r7, #2\n    ldrh r3, [r6, r7, lsl #1]\n    mov  r4, #6\n1:  ldr  r2, [r0]\n    mov  r5, r3\n2:  subs r5, r5, #1\n    bne  2b\n    subs r4, r4, #1\n    bne  1b\n\n.data\nnotes: .hword 40, 38, 36, 34, 32, 30\n', hints: ['Halfwords are 2 bytes, so the index shift is <code>lsl #1</code>.', '<code>ldrh r3, [r6, r7, lsl #1]</code>.'], why: 'A table of halfwords plus a scaled index is the whole note-selection mechanism.' },
    { k: 'mcq', q: 'Why does the same loop constant give a different note on a Cortex-M0 and a Cortex-M4?', opts: ['Different clock only', 'The cost of the loop body differs — a taken branch is 3 cycles on M0 and can be 1 on M4', 'M0 has no GPIO', 'It does not'], a: 1, why: 'Body cost is part of the formula, and it is a property of the core, not the architecture.' },
    { k: 'mcq', q: 'In a note table, the twelfth entry should be roughly what fraction of the first?', opts: ['One quarter', 'One half', 'Double', 'The same'], a: 1, why: 'Twelve semitones is an octave: twice the frequency, so half the count.' }
  ]
},

/* ------------------------------------------------------------------ 8.5 */
{
  id: 'u8l5', title: 'Bit-banging a serial line', goal: 'Shift bits out of a register in a precisely timed loop.',
  teach: [
    { t: 'p', x: 'Bit-banging means implementing a communication protocol entirely in software: set a pin, wait, set it again. It needs a loop that is both correct and correctly <i>timed</i>, which is the hardest combination in this unit.' },
    { t: 'code', cap: 'Transmit one byte, 8N1, LSB first', x: '@ r0 = byte to send, r4 = port, r6 = pin state, r5 = bit delay\n    bic  r6, r6, #TXD        @ start bit: line low\n    str  r6, [r4]\n    bl   bit_delay\n    mov  r7, #8\n1:  tst  r0, #1              @ look at the low bit\n    biceq r6, r6, #TXD       @ 0: line low\n    orrne r6, r6, #TXD       @ 1: line high\n    str  r6, [r4]\n    lsr  r0, r0, #1          @ next bit into position\n    bl   bit_delay\n    subs r7, r7, #1\n    bne  1b\n    orr  r6, r6, #TXD        @ stop bit: line high\n    str  r6, [r4]\n    bl   bit_delay' },
    { t: 'p', x: 'Three things make this loop characteristic of bit-banging: the <b>shift</b> that brings the next bit into the test position, the <b>conditional pair</b> that sets or clears the pin without branching, and the <b>delay</b> that defines the baud rate.' },
    { t: 'note', x: 'The conditional pair matters for timing, not just elegance. A branch would make the "0" path and the "1" path take different numbers of cycles, so the bit period would depend on the data — which is exactly the kind of jitter that breaks a receiver.' },
    { t: 'h', x: 'Receiving is harder' },
    { t: 'p', x: 'Transmitting, you own the clock. Receiving, you must find the start bit\'s falling edge and then sample each bit in the <i>middle</i> of its cell, which means waiting half a bit period first and then a full period between samples. Get that half-period wrong and you sample near the transitions, where the line is least reliable and the two clocks least agreed.' },
    { t: 'code', cap: 'Receive: half a bit, then eight full bits', x: '1:  ldr  r1, [r4]            @ wait for the start bit\n    tst  r1, #RXD\n    bne  1b\n    mov  r5, r8              @ HALF a bit period\n    bl   delay\n    mov  r7, #8\n2:  bl   bit_delay           @ a FULL period puts us mid-cell\n    ldr  r1, [r4]\n    lsr  r0, r0, #1\n    tst  r1, #RXD\n    orrne r0, r0, #0x80      @ shift the bit in at the top\n    subs r7, r7, #1\n    bne  2b' },
    { t: 'h', x: 'The clock accuracy budget' },
    { t: 'p', x: 'By the last bit of a byte you are 9.5 bit-times from the edge you synchronised on. If your clock is 5% fast you are half a bit out by then and will start misreading — which is why bit-banged serial on an RC oscillator is unreliable and on a crystal is fine. Two tenths of a percent is comfortable; two percent is the edge of the cliff.' }
  ],
  real: {
    title: 'Software serial is everywhere',
    text: 'Arduino\'s SoftwareSerial, the bit-banged SPI in a hundred sensor drivers, and WS2812 LED strips whose protocol needs 800 kHz pulses with about 150 ns of tolerance — all the same loop. It exists because pins are cheap and peripherals are not, and because the peripheral you need is always the one your chip does not have.',
    code: '@ bit-bang SPI: clock out 8 bits, MSB first\n    mov  r7, #8\n1:  tst  r0, #0x80\n    strne r8, [r4, #SET]\n    streq r8, [r4, #CLR]\n    str  r9, [r4, #SET]      @ clock high\n    lsl  r0, r0, #1\n    str  r9, [r4, #CLR]      @ clock low\n    subs r7, r7, #1\n    bne  1b'
  },
  deep: {
    kind: 'cores',
    title: 'Why this only works with interrupts off',
    text: 'A bit-banged transmitter is a real-time deadline every bit period. An interrupt taken in the middle of a bit stretches it by the whole duration of the handler, and the receiver sees a framing error. Production bit-bang drivers disable interrupts around the byte — which means the byte duration is a hard limit on your interrupt latency.',
    a: { lab: 'The guard', code: '    mrs  r3, cpsr\n    cpsid i                  @ interrupts off\n    bl   send_byte\n    msr  cpsr_c, r3          @ restore exactly what it was' },
    b: { lab: 'The cost', lang: 'c', code: '// 9600 baud, 10 bits per byte\n//   = 1.04 ms with interrupts off\n//\n// Anything needing better than\n// 1 ms latency is now broken.\n//\n// At 115200 baud it is 87 us,\n// which is usually acceptable.' },
    note: 'Saving and restoring the whole CPSR rather than blindly re-enabling matters: if the caller already had interrupts disabled, <code>cpsie i</code> would silently turn them back on underneath it.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — TST, ORR, BIC', cite: 'TST sets the flags from a bitwise AND without writing a result, allowing a following conditional ORR or BIC to set or clear a bit.' },
    { src: 'ARM ARM (DDI 0406C), Chapter B9 — CPS', cite: 'CPSID and CPSIE change the interrupt mask bits in the CPSR without otherwise disturbing it.' }
  ],
  ex: [
    { k: 'code', q: 'Shift the 8 bits of 0xB4 out of r0 one at a time, LSB first, and count how many are 1s in r2.', start: '    mov  r0, #0xB4\n    mov  r2, #0\n    mov  r7, #8\n1:\n', check: [{ reg: 'r2', eq: 4 }], solution: '    mov  r0, #0xB4\n    mov  r2, #0\n    mov  r7, #8\n1:  tst  r0, #1\n    addne r2, r2, #1\n    lsr  r0, r0, #1\n    subs r7, r7, #1\n    bne  1b\n', hints: ['<code>tst r0, #1</code> then a conditional add.', '<code>lsr r0, r0, #1</code> brings the next bit down.'], why: '0xB4 is 1011 0100 — four set bits. This is the transmit loop with the pin write replaced by a counter.' },
    { k: 'mcq', q: 'Why use <code>BICEQ</code>/<code>ORRNE</code> rather than a branch to set the pin?', opts: ['It is shorter', 'Both paths then take the same number of cycles, so the bit period does not depend on the data', 'BIC is faster than B', 'Branches cannot set pins'], a: 1, why: 'Data-dependent timing is jitter, and jitter is what makes a receiver mis-sample.' },
    { k: 'code', q: 'Receive: build a byte from 8 bits arriving LSB-first. The bits are 1,0,1,1,0,1,0,1 from the table. Answer in r0.', start: '    ldr  r6, =bits\n    mov  r0, #0\n    mov  r7, #8\n1:\n\n.data\nbits: .byte 1,0,1,1,0,1,0,1\n', check: [{ reg: 'r0', eq: 0xAD }], solution: '    ldr  r6, =bits\n    mov  r0, #0\n    mov  r7, #8\n1:  ldrb r1, [r6], #1\n    lsr  r0, r0, #1\n    tst  r1, #1\n    orrne r0, r0, #0x80\n    subs r7, r7, #1\n    bne  1b\n\n.data\nbits: .byte 1,0,1,1,0,1,0,1\n', hints: ['Shift r0 right first, then OR the new bit in at bit 7.', 'After eight shifts the first bit received has reached bit 0.'], why: 'LSB first means the first bit ends up lowest — 1010 1101 = 0xAD.' },
    { k: 'mcq', q: 'When receiving, why wait half a bit period after the start edge?', opts: ['To save power', 'So that every subsequent full-period wait lands in the middle of a bit cell, away from the transitions', 'To detect the stop bit', 'It is not needed'], a: 1, why: 'Sampling near an edge is sampling where the signal is least settled and the two clocks least agreed.' },
    { k: 'mcq', q: 'Why do bit-bang drivers disable interrupts for the whole byte?', opts: ['To save power', 'An interrupt in the middle of a bit stretches it, and the receiver sees a framing error', 'Because GPIO needs it', 'They do not'], a: 1, why: 'And the cost is that the byte duration becomes a floor on your interrupt latency.' }
  ]
},

/* ------------------------------------------------------------------ 8.6 */
{
  id: 'u8l6', title: 'Polling loops', goal: 'Wait for hardware correctly, with a timeout and without burning the battery.',
  teach: [
    { t: 'p', x: 'A polling loop reads a status register over and over until a bit changes. It is the most common loop in driver code and it has three standard faults.' },
    { t: 'code', cap: 'The naive version', x: '1:  ldr  r0, [r4, #STATUS]\n    tst  r0, #READY\n    beq  1b' },
    { t: 'table', head: ['Fault', 'Consequence', 'Fix'], rows: [
      ['No timeout', 'Broken hardware hangs the system for ever', 'Count the attempts and give up'],
      ['No sleep', 'The core runs at full clock doing nothing', '<code>WFI</code> or <code>WFE</code>, or a short delay'],
      ['Wrong memory type', 'The read is cached or reordered and never changes', 'Map the register as Device memory']
    ] },
    { t: 'code', cap: 'The version you should write', x: '    ldr  r5, =100000         @ timeout\n1:  ldr  r0, [r4, #STATUS]\n    tst  r0, #READY\n    bne  2f                  @ ready: done\n    subs r5, r5, #1\n    bne  1b\n    @ ---- fell through: the device never became ready ----\n    mvn  r0, #0              @ return -1\n    b    3f\n2:  mov  r0, #0              @ success\n3:' },
    { t: 'note', x: 'A timeout turns a hang into an error, and an error is something the rest of the system can handle. This is the difference between a device that fails and a product that freezes.' },
    { t: 'h', x: 'Ordering' },
    { t: 'p', x: 'If the status register is mapped as <b>Device</b> memory, the architecture guarantees the accesses are not merged, reordered or repeated — that is what Device memory means. If it is mapped as Normal memory, the core may legitimately cache the value and your loop will spin on a stale copy for ever. Getting the memory type right is part of writing the loop.' },
    { t: 'h', x: 'When not to poll at all' },
    { t: 'p', x: 'If the wait could be long, an interrupt is better: the core does something else, or sleeps, and the device wakes it. Poll when the wait is short and predictable — a few microseconds — and the cost of setting up an interrupt exceeds the cost of spinning.' }
  ],
  real: {
    title: 'Every driver you have ever read',
    text: 'Wait for the UART transmit buffer to empty. Wait for the SD card to finish a write. Wait for the PLL to lock. Wait for the DMA to complete. All the same five lines, and the ones written carefully all have a timeout.',
    code: 'uart_putc:\n    ldr  r5, =10000\n1:  ldr  r1, [r4, #UART_FR]\n    tst  r1, #TXFF           @ transmit FIFO full?\n    beq  2f\n    subs r5, r5, #1\n    bne  1b\n    bx   lr                  @ timed out; drop the character\n2:  str  r0, [r4, #UART_DR]\n    bx   lr'
  },
  deep: {
    kind: 'compiler',
    title: 'The loop that never ends because the load was hoisted',
    text: 'Without <code>volatile</code>, the compiler sees a loop that reads the same address repeatedly and writes nothing. It is entitled to hoist that read out of the loop and spin on a register — which never changes, so the loop never exits. The generated code is a two-instruction infinite loop, and it is a genuinely common bug in first-draft driver code.',
    a: { lab: 'Without volatile — hangs', lang: 'c', code: 'uint32_t *sr = (uint32_t *)0x40000000;\n\nwhile ((*sr & READY) == 0)\n    ;\n\n// gcc -O2:\n//     ldr r3, [r0]\n//     tst r3, #1\n//   1: beq 1b        <- reads once' },
    b: { lab: 'With volatile — polls', lang: 'c', code: 'volatile uint32_t *sr =\n    (volatile uint32_t *)0x40000000;\n\nwhile ((*sr & READY) == 0)\n    ;\n\n// gcc -O2:\n//   1: ldr r3, [r0]  <- every trip\n//     tst r3, #1\n//     beq 1b' },
    note: 'In hand-written assembly this cannot happen — the load is inside the loop because you put it there. It is one of the few places where assembly is straightforwardly less dangerous than C.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Memory types', cite: 'Accesses to Device memory are not repeated, merged or reordered with respect to each other, which is required for correct polling of status registers.' },
    { src: 'ARM ARM (DDI 0406C), Chapter B1 — WFE and WFI', cite: 'WFE and WFI allow the processor to enter a low-power state until an event or interrupt occurs.' }
  ],
  ex: [
    { k: 'code', q: 'Poll the KEY register at 0x20020008 for bit 7, but give up after 50 attempts. Leave the number of attempts in r1. (No key will ever arrive, so expect 50.)', start: '    ldr  r4, =0x20020008\n    mov  r1, #0\n1:\n', check: [{ reg: 'r1', eq: 50 }], solution: '    ldr  r4, =0x20020008\n    mov  r1, #0\n1:  ldr  r0, [r4]\n    add  r1, r1, #1\n    tst  r0, #0x80\n    bne  2f\n    cmp  r1, #50\n    blo  1b\n2:\n', hints: ['Count the attempts and compare against 50 at the bottom.', 'Leave the loop early if the bit is ever set.'], why: 'Two exits: ready, and timed out. Both must leave a sensible answer.' },
    { k: 'mcq', q: 'What is the worst consequence of a polling loop with no timeout?', opts: ['It is slower', 'Broken or absent hardware makes the whole system hang, with no way to report the failure', 'It uses more memory', 'It cannot be interrupted'], a: 1, why: 'A timeout converts a hang into an error the rest of the system can act on.' },
    { k: 'mcq', q: 'Why must a status register be mapped as Device memory?', opts: ['It is faster', 'Otherwise the core may cache the value and your loop spins on a stale copy for ever', 'To allow byte access', 'It need not be'], a: 1, why: 'Device memory forbids merging, reordering and repeating — which is exactly what polling depends on.' },
    { k: 'mcq', q: 'When is polling the right choice over an interrupt?', opts: ['Always', 'When the expected wait is short and predictable, so the setup cost of an interrupt exceeds the spin', 'When the device is slow', 'Never'], a: 1, why: 'For a few microseconds, spinning wins. For milliseconds, sleeping wins.' },
    { k: 'code', q: 'Write a polling loop that reads the cycle counter at 0x20020004 until it exceeds 200, then leaves the final reading in r0.', start: '    ldr  r4, =0x20020004\n1:\n', check: [{ regex: 'ldr\\s+r0,\\s*\\[r4\\]', desc: 'Read the cycle counter with <code>ldr r0, [r4]</code>.' }, { maxInsn: 400 }], solution: '    ldr  r4, =0x20020004\n1:  ldr  r0, [r4]\n    cmp  r0, #200\n    bls  1b\n', hints: ['Read, compare against 200, branch back while not greater.', 'The counter advances as your loop runs — that is what makes it terminate.'], why: 'A polling loop against a counter your own loop is advancing: the simplest possible proof that the loop makes progress.' }
  ]
},

/* ------------------------------------------------------------------ 8.7 */
{
  id: 'u8l7', title: 'Why delay loops still ship', goal: 'Judge when a timing loop is right, and calibrate it instead of guessing.',
  teach: [
    { t: 'p', x: 'Delay loops are widely disparaged and still absolutely everywhere. Both facts are justified. Here is the honest accounting.' },
    { t: 'table', head: ['In favour', 'Against'], rows: [
      ['Works before any peripheral is configured', 'The core clock may change under you (DVFS, PLL switch)'],
      ['Needs no timer, no interrupt, no driver', 'Burns full power for the whole delay'],
      ['Deterministic on a simple in-order core', 'Not deterministic at all with cache and prediction'],
      ['A few bytes of code', 'Must be recalibrated for every core and clock speed'],
      ['Cannot be pre-empted by its own subsystem', 'Can be pre-empted by an interrupt, making the delay longer than asked'],
      ['The only option for sub-microsecond precision on many parts', 'Compilers will delete the C version']
    ] },
    { t: 'h', x: 'The case that always holds' },
    { t: 'p', x: 'Very early boot. Before the clock tree is configured, before any timer exists, before RAM is initialised, a processor still sometimes has to wait — for a PLL to lock, for a voltage rail to settle. There is nothing else available. Every SoC bootrom on earth contains a delay loop for this reason.' },
    { t: 'code', cap: 'The first loop a chip runs', x: 'wait_pll:\n    ldr  r0, =0x20000       @ calibrated for the boot clock\n1:  subs r0, r0, #1\n    bne  1b' },
    { t: 'h', x: 'The case that never holds' },
    { t: 'p', x: 'A delay loop as the main timing mechanism of an application on a multitasking OS. Your loop can be pre-empted at any moment, your thread can be migrated to a different core, and frequency scaling can change the clock mid-loop. On Linux you use <code>clock_nanosleep</code>; on an RTOS you use the tick. The loop will be wrong, and it will be wrong intermittently, which is the worst kind of wrong.' },
    { t: 'note', x: 'The middle ground — a bare-metal Cortex-M with a fixed clock and interrupts disabled — is where delay loops remain genuinely correct, and where a great deal of firmware lives. Even there, a hardware timer is better if one is spare.' },
    { t: 'h', x: 'Calibrating instead of guessing' },
    { t: 'p', x: 'The professional compromise: at start-up, run your loop a known number of times against a real timer, measure, and compute the iterations-per-microsecond. Then every later delay is derived rather than hard-coded, and the same binary is correct on a 48 MHz part and a 480 MHz one.' },
    { t: 'code', cap: 'Measure once, derive for ever', x: '@ r4 = a free-running cycle counter (DWT_CYCCNT on Cortex-M)\ncalibrate:\n    ldr  r5, [r4]            @ timestamp before\n    ldr  r0, =10000\n1:  subs r0, r0, #1\n    bne  1b\n    ldr  r6, [r4]            @ timestamp after\n    sub  r6, r6, r5          @ cycles for 10000 iterations\n    @ ... divide to get cycles-per-iteration, store it ...\n\nudelay:\n@ r0 = microseconds, r1 = loops_per_us measured above\n    mul  r0, r0, r1\n1:  subs r0, r0, #1\n    bne  1b\n    bx   lr' },
    { t: 'p', x: 'Linux has done exactly this since 1993. The number it prints at boot is called BogoMIPS, and the joke in the name is an admission of how rough the measurement is — it measures how fast this core runs this empty loop, and nothing else.' }
  ],
  real: {
    title: 'What replaced it',
    text: 'On Cortex-M the DWT cycle counter and SysTick both give you a real time base for a few lines of setup. On Cortex-A the generic timer, CNTVCT, counts at a fixed frequency regardless of what the core clock is doing — which is exactly the property a delay loop lacks. Where either exists, use it.',
    code: '@ Cortex-A generic timer: a delay immune to frequency scaling\n@ (CNTFRQ gives the tick rate, CNTVCT the count)\n    mrrc p15, 1, r2, r3, c14     @ read CNTVCT into r3:r2\n    add  r2, r2, r0              @ target = now + n ticks\n1:  mrrc p15, 1, r4, r5, c14\n    subs r4, r4, r2\n    bmi  1b'
  },
  deep: {
    kind: 'cores',
    title: 'What frequency scaling does to a calibrated loop',
    text: 'Calibration fixes the "which core is this" problem but not the "what speed is it running at right now" problem. A loop calibrated at 1.2 GHz and then executed while the governor has dropped the core to 300 MHz runs four times slower than asked. Linux pins the calibration to a fixed reference and re-derives on frequency change; bare-metal firmware that switches PLLs has to do the same by hand.',
    a: { lab: 'Fragile', code: '@ constant baked in at build time\n    ldr  r0, =24000\n1:  subs r0, r0, #1\n    bne  1b' },
    b: { lab: 'Better', code: '@ derived from a value measured at run time,\n@ and re-measured after any clock change\n    ldr  r1, =loops_per_us\n    ldr  r1, [r1]\n    mul  r0, r0, r1\n1:  subs r0, r0, #1\n    bne  1b' },
    note: 'And better still: do not count instructions at all. A counter that ticks at a fixed frequency — the generic timer, or a hardware timer peripheral — does not care what the core clock is doing.'
  },
  refs: [
    { src: 'Linux kernel, init/calibrate.c', cite: 'The kernel calibrates a delay loop against the timer interrupt at boot and reports the result as BogoMIPS; udelay() is derived from it.' },
    { src: 'ARM ARM (DDI 0406C), Chapter B8 — The Generic Timer', cite: 'CNTFRQ reports the frequency of the system counter, which is independent of the processor clock frequency.' }
  ],
  ex: [
    { k: 'mcq', q: 'Where is a delay loop always the right answer?', opts: ['In application code on Linux', 'In very early boot, before any timer or clock configuration exists', 'In an interrupt handler', 'In a graphics loop'], a: 1, why: 'When there is genuinely no timer yet, counting is all you have.' },
    { k: 'mcq', q: 'Why is a delay loop wrong as an application-level timer on Linux?', opts: ['It is too accurate', 'Pre-emption, core migration and frequency scaling all change its duration unpredictably', 'Linux forbids loops', 'It uses too much memory'], a: 1, why: 'Intermittently wrong is worse than consistently wrong, because it cannot be calibrated away.' },
    { k: 'code', q: 'Write a calibrated delay: r1 holds loops-per-unit (5), r0 holds units wanted (9). Multiply, then loop, and leave the number of iterations performed in r5.', start: '    mov  r1, #5\n    mov  r0, #9\n    mov  r5, #0\n', check: [{ reg: 'r5', eq: 45 }], solution: '    mov  r1, #5\n    mov  r0, #9\n    mov  r5, #0\n    mul  r0, r0, r1\n1:  add  r5, r5, #1\n    subs r0, r0, #1\n    bne  1b\n', hints: ['<code>mul r0, r0, r1</code> before the loop.', 'Count the trips in r5.'], why: '9 × 5 = 45. Deriving the count from a measured rate is what turns a fragile constant into a portable one.' },
    { k: 'code', q: 'Calibrate against the cycle counter at 0x20020004: time 100 iterations of an empty loop and leave the elapsed cycles in r6.', start: '    ldr  r4, =0x20020004\n    ldr  r5, [r4]        @ before\n    mov  r0, #100\n', check: [{ reg: 'r6', eq: 402 }], solution: '    ldr  r4, =0x20020004\n    ldr  r5, [r4]\n    mov  r0, #100\n1:  subs r0, r0, #1\n    bne  1b\n    ldr  r7, [r4]\n    sub  r6, r7, r5\n', hints: ['Read the counter, run the loop, read it again, subtract.'], why: '100 iterations at 4 cycles each, plus the two counter reads — 402 on this machine model. That number is exactly what a real calibration routine divides to get cycles-per-iteration.' },
    { k: 'mcq', q: 'What is BogoMIPS actually measuring?', opts: ['Instructions per second', 'How fast this core runs this particular empty delay loop, used to calibrate udelay()', 'Memory bandwidth', 'Cache size'], a: 1, why: 'The name is an admission: it is not a performance metric, it is a loop calibration.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
