/* AssArm: Loops — curriculum part 6 : Unit 10, dispatch loops */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u10', n: 10, title: 'Dispatch Loops', icon: '⇶', color: '#bb9af7',
    blurb: 'Loops that decide what to do next by looking it up: interpreters, state machines, superloops and ring buffers.',
    lessons: [

/* ----------------------------------------------------------------- 10.1 */
{
  id: 'u10l1', title: 'The interpreter loop', goal: 'Build the fetch-decode-execute loop that every virtual machine is made of.',
  teach: [
    { t: 'p', x: 'An interpreter is a loop. Fetch a byte, use it to decide what to do, do it, go round again. Three steps, and every bytecode VM in existence — Python, the JVM, Lua, a regex engine, a printer\'s page-description language — is this loop with a bigger table.' },
    { t: 'code', cap: 'Fetch, decode, execute', x: '@ r10 = virtual PC, r11 = handler table\nnext:\n    ldrb r0, [r10], #1        @ FETCH the opcode, advance the virtual PC\n    ldr  pc, [r11, r0, lsl #2] @ DECODE and EXECUTE: jump to its handler\n\nop_add:\n    @ ... do the work ...\n    b    next                 @ and back round the loop' },
    { t: 'note', x: 'There is no explicit "execute" step. The jump <i>is</i> the execute, and each handler ends by branching back to <code>next</code>. Two instructions of overhead per virtual instruction is about as tight as a portable interpreter gets.' },
    { t: 'h', x: 'Threaded dispatch' },
    { t: 'p', x: 'A refinement: instead of every handler branching back to a shared <code>next</code>, each handler ends with its <i>own</i> copy of the fetch-and-jump. That gives the branch predictor a separate history for each opcode, and since bytecode sequences are highly repetitive it predicts far better. The technique is called <b>threaded dispatch</b> and it is worth 20–30% in real interpreters.' },
    { t: 'code', cap: 'Each handler dispatches for itself', x: 'op_add:\n    @ ... do the work ...\n    ldrb r0, [r10], #1        @ this handler\'s own fetch\n    ldr  pc, [r11, r0, lsl #2]\n\nop_sub:\n    @ ... do the work ...\n    ldrb r0, [r10], #1        @ and this one\'s\n    ldr  pc, [r11, r0, lsl #2]' },
    { t: 'h', x: 'Register allocation is the whole design' },
    { t: 'p', x: 'An interpreter loop wants the virtual PC, the handler table, the virtual stack pointer and a scratch register or two pinned in real registers for its entire lifetime. ARMv7\'s thirteen general-purpose registers make that comfortable. Try the same design with only a handful of registers and the interpreter spends its time spilling those values to the stack and reloading them on every dispatch, which is real overhead on what should be a two-instruction loop.' }
  ],
  real: {
    title: 'CPython\'s eval loop',
    text: 'The core of CPython is a loop that fetches a bytecode and dispatches on it. Builds with computed-goto support use threaded dispatch for the branch-prediction reason above; builds without it use a switch. The difference between them is measurable across the whole language.',
    code: '@ the shape, on ARM\nnext:\n    ldrb r0, [r10], #1\n    ldr  pc, [r11, r0, lsl #2]'
  },
  deep: {
    kind: 'compiler',
    title: 'A switch compiles to one shared branch',
    text: 'A plain interpreter loop gives gcc exactly one <code>switch</code>, and gcc lowers it to a single indirect branch that every case reaches by falling through to the bottom of the loop. GCC\'s computed-goto extension, <code>goto *targets[op]</code>, asks for something different: a separate indirect branch compiled into <b>every</b> case, each at its own address. The C changes by one line; the compiled control-flow graph changes completely, from one dispatch site to as many as there are opcodes.',
    a: { lab: 'C (switch-based dispatch)', lang: 'c', code: 'for (;;) {\n    switch (*pc++) {\n    case OP_ADD: acc += arg; break;\n    case OP_SUB: acc -= arg; break;\n    }\n}' },
    b: { lab: 'gcc -O2, ARMv7 (one shared dispatch site)', code: 'loop:\n    ldrb r0, [r10], #1\n    ldr  pc, [r11, r0, lsl #2]   @ every case reaches this same LDR\nop_add:\n    add  r2, r2, r3\n    b    loop\nop_sub:\n    sub  r2, r2, r3\n    b    loop' },
    note: 'Rewrite the loop with a computed goto instead and gcc compiles a separate copy of that <code>LDR pc</code> into every case rather than one shared copy at the bottom, which on a Cortex-A7 means measurably fewer branch mispredictions, because each copy earns its own entry in the branch predictor.'
  },
  refs: [
    { src: 'Ertl, M.A. and Gregg, D. (2003), "The Behavior of Efficient Virtual Machine Interpreters on Modern Architectures", Euro-Par 2003', cite: 'Threaded dispatch, where every opcode branches through its own indirect jump, consistently reduces branch mispredictions compared with a single dispatch switch, because it gives the branch predictor a separate history per opcode.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR with PC as destination', cite: 'A load into PC causes a branch to the loaded address, which is the standard implementation of a jump table.' }
  ],
  ex: [
    { k: 'code', q: 'Build a tiny interpreter. The program at <code>prog</code> is a list of opcodes: 0 = add 1, 1 = double, 2 = halt. Run it and leave the accumulator in r0.', start: '    ldr  r10, =prog\n    ldr  r11, =table\n    mov  r0, #3          @ accumulator\nnext:\n    @ fetch and dispatch\n\nop_inc:\n    add  r0, r0, #1\n    b    next\nop_dbl:\n    lsl  r0, r0, #1\n    b    next\nop_halt:\n    b    done\ndone:\n\n.data\ntable: .word op_inc, op_dbl, op_halt\nprog:  .byte 0, 1, 0, 1, 2\n', check: [{ reg: 'r0', eq: 18 }], solution: '    ldr  r10, =prog\n    ldr  r11, =table\n    mov  r0, #3\nnext:\n    ldrb r1, [r10], #1\n    ldr  pc, [r11, r1, lsl #2]\n\nop_inc:\n    add  r0, r0, #1\n    b    next\nop_dbl:\n    lsl  r0, r0, #1\n    b    next\nop_halt:\n    b    done\ndone:\n\n.data\ntable: .word op_inc, op_dbl, op_halt\nprog:  .byte 0, 1, 0, 1, 2\n', hints: ['<code>ldrb r1, [r10], #1</code> fetches the opcode and advances the virtual PC.', '<code>ldr pc, [r11, r1, lsl #2]</code> is the whole decode-and-execute step.'], why: '3 → 4 → 8 → 9 → 18, then halt. You have written a virtual machine in two instructions.' },
    { k: 'mcq', q: 'In <code>ldr pc, [r11, r0, lsl #2]</code>, what is r0?', opts: ['A pointer', 'The opcode, used as an index into a table of handler addresses', 'The accumulator', 'The stack pointer'], a: 1, why: 'Opcode times four is the offset of that opcode\'s handler address in the table.' },
    { k: 'mcq', q: 'Why does threaded dispatch beat a single shared dispatch point?', opts: ['Fewer instructions', 'Each handler gets its own indirect branch, so the predictor can learn which opcodes tend to follow which', 'It uses less memory', 'It avoids the table'], a: 1, why: 'Bytecode sequences are repetitive, and per-site history captures that. One shared branch site averages everything together and predicts badly.' },
    { k: 'mcq', q: 'An interpreter keeps the virtual PC, the handler table and the virtual stack pointer pinned in real registers for the whole run. Why does that matter?', opts: ['It makes the source shorter', 'Reloading any of them from memory on every dispatch would add real overhead to what is otherwise a two-instruction loop', 'ARMv7 requires it', 'It has no effect on speed'], a: 1, why: 'Two instructions of dispatch overhead is already about as tight as it gets; spilling any of those values to the stack adds load and store traffic to every single opcode.' },
    { k: 'code', q: 'Add an opcode 3 = "subtract 5" to the interpreter, and run the program 0,3,1,2 starting from 10.', start: '    ldr  r10, =prog\n    ldr  r11, =table\n    mov  r0, #10\nnext:\n    ldrb r1, [r10], #1\n    ldr  pc, [r11, r1, lsl #2]\n\nop_inc:\n    add  r0, r0, #1\n    b    next\nop_dbl:\n    lsl  r0, r0, #1\n    b    next\nop_halt:\n    b    done\ndone:\n\n.data\ntable: .word op_inc, op_dbl, op_halt\nprog:  .byte 0, 3, 1, 2\n', check: [{ reg: 'r0', eq: 12 }], solution: '    ldr  r10, =prog\n    ldr  r11, =table\n    mov  r0, #10\nnext:\n    ldrb r1, [r10], #1\n    ldr  pc, [r11, r1, lsl #2]\n\nop_inc:\n    add  r0, r0, #1\n    b    next\nop_dbl:\n    lsl  r0, r0, #1\n    b    next\nop_halt:\n    b    done\nop_sub5:\n    sub  r0, r0, #5\n    b    next\ndone:\n\n.data\ntable: .word op_inc, op_dbl, op_halt, op_sub5\nprog:  .byte 0, 3, 1, 2\n', hints: ['Write a new handler and add its address as the fourth entry of the table.', 'Table entries are in opcode order: 0, 1, 2, 3.'], why: '10 → 11 → 6 → 12, then halt. Adding an instruction to a VM is adding a table entry.' }
  ]
},

/* ----------------------------------------------------------------- 10.2 */
{
  id: 'u10l2', title: 'Jump tables', goal: 'Dispatch on a value without a chain of comparisons.',
  teach: [
    { t: 'p', x: 'A jump table turns "which of these n cases is it?" into one bounds check and one indirect branch. It is what a C <code>switch</code> compiles to when the cases are dense.' },
    { t: 'code', cap: 'Table of addresses', x: '@ r0 = case number, 0..3\n    cmp  r0, #4\n    bhs  default              @ bounds check FIRST, always\n    ldr  r1, =cases\n    ldr  pc, [r1, r0, lsl #2]\n\n.data\ncases: .word case0, case1, case2, case3' },
    { t: 'note', x: 'The bounds check is not optional. Without it, a value outside the range indexes past the end of the table and branches to whatever bytes happen to be there. This is a classic exploitable bug, and it is one <code>CMP</code>/<code>BHS</code> away from being impossible.' },
    { t: 'h', x: 'Table of branches' },
    { t: 'p', x: 'The other form stores <i>instructions</i> rather than addresses: compute a PC offset and land in a ladder of branches. It avoids the data load, at the cost of an extra branch.' },
    { t: 'code', cap: 'Branch ladder', x: '    cmp  r0, #4\n    bhs  default\n    add  pc, pc, r0, lsl #2   @ PC reads as +8, so we land past the NOP\n    nop\n    b    case0\n    b    case1\n    b    case2\n    b    case3' },
    { t: 'p', x: 'That <code>nop</code> is there because reading PC gives you the current instruction\'s address plus 8. With the <code>ADD</code> at address A, PC reads as A+8 — which is the instruction after the <code>nop</code>, i.e. <code>b case0</code>. Getting this off by one is the classic mistake with this technique.' },
    { t: 'h', x: 'When a table is the wrong answer' },
    { t: 'p', x: 'Sparse cases — 1, 7, 400, 9000 — would need an enormous table. Compilers switch to a binary search over comparisons at that point, and so should you. A rule of thumb: if more than about half the table entries would point at the default case, use comparisons.' }
  ],
  real: {
    title: 'Syscall dispatch',
    text: 'An operating system kernel receives a syscall number and must reach the right handler. It is a bounds check and a table lookup, and the bounds check is one of the most security-critical instructions in the whole kernel.',
    code: 'syscall_entry:\n    cmp  r7, #NR_SYSCALLS\n    bhs  bad_syscall\n    ldr  r8, =sys_call_table\n    ldr  pc, [r8, r7, lsl #2]'
  },
  deep: {
    kind: 'compiler',
    title: 'gcc picks the switch strategy for you',
    text: 'Given a <code>switch</code>, gcc picks a lowering strategy from how many cases there are and how densely they are packed: a small or sparse set becomes a chain of compares, a dense run becomes a jump table, and a large sparse set becomes a binary search that narrows the range before a final compare. In Thumb-2 that table is usually built from the dedicated <code>TBB</code>/<code>TBH</code> table-branch instructions, which read a one- or two-byte offset straight out of the table instead of a full address; A32 has no such instruction, so it falls back to the explicit address table and a plain <code>LDR</code> into <code>pc</code> shown below. Either way, <code>-fno-jump-tables</code> forces the compare chain regardless of density, because some safety-critical and security-hardened builds want every branch target visible to static analysis rather than sitting in a table.',
    a: { lab: 'C', lang: 'c', code: 'int classify(int c) {\n    switch (c) {\n    case 1: return 10;\n    case 2: return 20;\n    case 3: return 30;\n    case 4: return 40;\n    default: return -1;\n    }\n}' },
    b: { lab: 'gcc -O2, ARMv7 (dense cases: a jump table)', code: '    sub  r3, r0, #1\n    cmp  r3, #3\n    bhi  default\n    ldr  r2, =table\n    ldr  pc, [r2, r3, lsl #2]\ntable:\n    .word case1, case2, case3, case4\ncase1: mov r0, #10\n    bx   lr\ncase2: mov r0, #20\n    bx   lr\ncase3: mov r0, #30\n    bx   lr\ncase4: mov r0, #40\n    bx   lr\ndefault:\n    mov  r0, #99\n    bx   lr' },
    note: 'Keep the table in <code>.rodata</code> rather than splicing it into <code>.text</code>: on a core with separate instruction and data caches, a table living among the instructions wastes icache capacity on words that are never executed as code.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR, ADD with PC as destination', cite: 'Writing to PC performs a branch; when PC is read as a source operand in ARM state its value is the address of the current instruction plus 8.' },
    { src: 'CWE-129: Improper Validation of Array Index', cite: 'An unchecked index used to select a jump target allows control transfer to an arbitrary location.' }
  ],
  ex: [
    { k: 'code', q: 'Dispatch on r0 = 2 through a jump table of four cases, each of which sets r5 to 10, 20, 30 or 40.', start: '    mov  r0, #2\n    ldr  r1, =cases\n    @ bounds check and dispatch here\n\nc0: mov  r5, #10\n    b    end\nc1: mov  r5, #20\n    b    end\nc2: mov  r5, #30\n    b    end\nc3: mov  r5, #40\n    b    end\ndefault:\n    mov  r5, #99\nend:\n\n.data\ncases: .word c0, c1, c2, c3\n', check: [{ reg: 'r5', eq: 30 }], solution: '    mov  r0, #2\n    ldr  r1, =cases\n    cmp  r0, #4\n    bhs  default\n    ldr  pc, [r1, r0, lsl #2]\n\nc0: mov  r5, #10\n    b    end\nc1: mov  r5, #20\n    b    end\nc2: mov  r5, #30\n    b    end\nc3: mov  r5, #40\n    b    end\ndefault:\n    mov  r5, #99\nend:\n\n.data\ncases: .word c0, c1, c2, c3\n', hints: ['<code>cmp r0, #4</code> then <code>bhs default</code>.', 'Then <code>ldr pc, [r1, r0, lsl #2]</code>.'], why: 'Case 2 sets r5 to 30. Note the unsigned <code>bhs</code> — a signed test would let a negative index through.' },
    { k: 'code', q: 'Now prove the bounds check matters: set r0 to 7 and confirm you land in <code>default</code> with r5 = 99.', start: '    mov  r0, #7\n    ldr  r1, =cases\n    ldr  pc, [r1, r0, lsl #2]\n\nc0: mov  r5, #10\n    b    end\nc1: mov  r5, #20\n    b    end\ndefault:\n    mov  r5, #99\nend:\n\n.data\ncases: .word c0, c1\n', check: [{ reg: 'r5', eq: 99 }], solution: '    mov  r0, #7\n    ldr  r1, =cases\n    cmp  r0, #2\n    bhs  default\n    ldr  pc, [r1, r0, lsl #2]\n\nc0: mov  r5, #10\n    b    end\nc1: mov  r5, #20\n    b    end\ndefault:\n    mov  r5, #99\nend:\n\n.data\ncases: .word c0, c1\n', hints: ['The table has only two entries, so the check is <code>cmp r0, #2</code>.', 'Without the check, index 7 reads 28 bytes past the table.'], why: 'Run the starter first and watch it jump somewhere meaningless. That is what an unchecked table index does.' },
    { k: 'mcq', q: 'In the branch-ladder form, why is there a <code>nop</code> after <code>add pc, pc, r0, lsl #2</code>?', opts: ['To align the code', 'Because reading PC gives the current address plus 8, so index 0 must land on the first branch — one slot further on', 'To set the flags', 'It is optional'], a: 1, why: 'The +8 pipeline offset is baked into the architecture, and this is where it bites in practice.' },
    { k: 'mcq', q: 'When should you use comparisons instead of a jump table?', opts: ['Always', 'When the cases are sparse, so most of the table would point at the default', 'When there are more than 4 cases', 'Never'], a: 1, why: 'A table for cases 1, 7, 400 and 9000 would be 36 KB of mostly-default entries.' },
    { k: 'mcq', q: 'Why might a security-hardened build pass <code>-fno-jump-tables</code> to gcc?', opts: ['To make the binary smaller', 'A jump table is computed control flow, and forcing plain compare-and-branch chains instead makes every branch target visible to static analysis', 'It makes the program faster', 'It is required on ARMv7'], a: 1, why: '<code>-fno-jump-tables</code> trades away the speed and density of a table for branch targets a verification tool can enumerate directly from the source.' }
  ]
},

/* ----------------------------------------------------------------- 10.3 */
{
  id: 'u10l3', title: 'State machines', goal: 'Write a loop whose behaviour depends on what happened before.',
  teach: [
    { t: 'p', x: 'A state machine is a dispatch loop where the table index is not the input but the <b>current state</b>. Each iteration consumes one input, does something, and chooses the next state.' },
    { t: 'code', cap: 'The shape', x: '@ r4 = current state, r1 = input pointer, r2 = count\n1:  ldrb r0, [r1], #1         @ one input symbol\n    ldr  r5, =states\n    ldr  r6, [r5, r4, lsl #2] @ this state\'s handler\n    blx  r6                   @ it returns the next state in r4\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'h', x: 'Or as a table of transitions' },
    { t: 'p', x: 'When each state does nothing but choose the next one, the handlers disappear and you are left with a two-dimensional table indexed by state and input — the fastest form, and the one a lexer generator emits.' },
    { t: 'code', cap: 'Table-driven transitions', x: '@ next_state = table[state * NUM_INPUTS + input_class]\n1:  ldrb r0, [r1], #1\n    ldrb r0, [r7, r0]         @ classify the byte (a 256-entry table)\n    mla  r8, r4, r9, r0       @ state * NUM_INPUTS + class\n    ldrb r4, [r5, r8]         @ the new state\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'note', x: 'Three loads, one multiply-add and the loop control: six instructions per input byte, with no branches at all except the loop\'s own. That is why table-driven lexers are fast — and why they are unreadable without the generator that produced the table.' },
    { t: 'h', x: 'Where state machines appear' },
    { t: 'p', x: 'Protocol parsers, lexers, UTF-8 decoders, JSON readers, USB device stacks, button debouncers, motor controllers, and the UART receiver in the deep dive below. Any time the meaning of an input depends on what came before it, this is the loop.' }
  ],
  real: {
    title: 'A UTF-8 decoder',
    text: 'UTF-8 validation is a state machine over byte classes, and the well-known DFA implementation is about ten lines: classify the byte, look up the transition, repeat. It rejects every invalid sequence — overlong encodings, surrogates, truncated sequences — without a single explicit comparison.',
    code: '1:  ldrb r0, [r1], #1\n    ldrb r3, [r7, r0]         @ byte class\n    add  r8, r3, r4           @ class + state\n    ldrb r4, [r5, r8]         @ next state\n    cmp  r4, #REJECT\n    beq  invalid\n    subs r2, r2, #1\n    bne  1b'
  },
  deep: {
    kind: 'pitfall',
    title: 'Reading a data register twice loses a byte',
    text: '<code>volatile</code> stops the compiler from caching a hardware register across two reads, but it cannot stop you from writing two reads where you meant one. On a real UART, reading the data register is destructive: it pops the next byte out of the receive FIFO, so reading it a second time to "use it again" does not return the value you already had. It returns whatever byte arrived after it, or garbage if none has.',
    code: 'recv_state:\n    ldr  r0, [r9, #UART_DR]   @ pop one byte from the FIFO\n    bl   log_byte              @ fine: r0 still holds it\n    ldr  r0, [r9, #UART_DR]   @ BUG: this pops the NEXT byte, not the one just logged\n    strb r0, [r6], #1          @ stores the wrong byte; the logged one is gone for good\n    mov  r4, #STATE_RECV\n    bx   lr',
    note: 'The fix is one line shorter: read <code>UART_DR</code> once into r0 and reuse that same register for both the log call and the store. The bug is invisible in a debugger that re-reads the register just to display it, which is exactly why it survives so long in the field.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Memory ordering and Device memory', cite: 'A read of a Device-type memory location may have side effects defined by the peripheral, so two reads of the same address are not guaranteed to return the same value.' },
    { src: 'ARM Cortex-M Programming Guide to Memory Barrier Instructions', cite: 'A peripheral register may have a read side effect; software must capture the value in a local variable rather than reading the register a second time to use it again.' }
  ],
  ex: [
    { k: 'code', q: 'Run a two-state machine over the bytes at <code>inp</code>. State 0 counts A (65); seeing B (66) moves to state 1, where nothing is counted until another A returns to state 0. Count in r5.', start: '    ldr  r1, =inp\n    mov  r2, #8\n    mov  r4, #0        @ state\n    mov  r5, #0        @ count\n1:\n\n.data\ninp: .byte 65,65,66,65,65,66,66,65\n', check: [{ reg: 'r5', eq: 3 }], solution: '    ldr  r1, =inp\n    mov  r2, #8\n    mov  r4, #0\n    mov  r5, #0\n1:  ldrb r0, [r1], #1\n    cmp  r4, #0\n    bne  3f\n    cmp  r0, #65\n    addeq r5, r5, #1\n    cmp  r0, #66\n    moveq r4, #1\n    b    4f\n3:  cmp  r0, #65\n    moveq r4, #0\n4:  subs r2, r2, #1\n    bne  1b\n\n.data\ninp: .byte 65,65,66,65,65,66,66,65\n', hints: ['Branch on the state first, then on the input.', 'In state 0: count As, and switch to state 1 on a B.'], why: 'A A B A A B B A. The first two As count (2). B switches to state 1. The next A only switches back — it is consumed by the transition, not counted. The following A counts (3). B switches to state 1, the second B does nothing, the last A switches back. Total 3.' },
    { k: 'mcq', q: 'In a state machine loop, what indexes the dispatch?', opts: ['The input', 'The current state — usually combined with the input class', 'The loop counter', 'The address'], a: 1, why: 'That is what makes it a state machine rather than a plain dispatch: the behaviour depends on history.' },
    { k: 'mcq', q: 'Why are table-driven lexers fast?', opts: ['They use NEON', 'Per input byte they cost a few loads and no branches at all beyond the loop', 'They skip whitespace', 'They are not'], a: 1, why: 'Every decision has been precomputed into the table, so nothing is left for the branch predictor to get wrong.' },
    { k: 'code', q: 'Table-driven version: transitions are at <code>tt</code> as state×2 + input (0 or 1). Start in state 0, run the 5 inputs, leave the final state in r4.', start: '    ldr  r1, =inp\n    ldr  r5, =tt\n    mov  r2, #5\n    mov  r4, #0\n1:\n\n.data\ntt:  .byte 0,1, 1,0        @ state0: in0->0 in1->1 ; state1: in0->1 in1->0\ninp: .byte 1,0,0,1,1\n', check: [{ reg: 'r4', eq: 1 }], solution: '    ldr  r1, =inp\n    ldr  r5, =tt\n    mov  r2, #5\n    mov  r4, #0\n1:  ldrb r0, [r1], #1\n    add  r8, r0, r4, lsl #1\n    ldrb r4, [r5, r8]\n    subs r2, r2, #1\n    bne  1b\n\n.data\ntt:  .byte 0,1, 1,0\ninp: .byte 1,0,0,1,1\n', hints: ['The table index is state × 2 + input.', '<code>add r8, r0, r4, lsl #1</code> computes it in one instruction.'], why: 'Inputs 1,0,0,1,1 drive the state 0→1→1→1→0→1. Five instructions per input and not one conditional branch in the body.' },
    { k: 'mcq', q: 'A UART receive handler reads the data register once to log the byte, then reads it again to store it. What goes wrong?', opts: ['Nothing, the value is the same both times', 'Reading the data register is destructive on real hardware, so the second read returns a different byte and the logged one is lost', 'The compiler removes the second read', 'It only fails with optimisations enabled'], a: 1, why: '<code>volatile</code> guarantees the compiler issues both reads; it says nothing about the reads being safe to repeat, because the hardware itself changes state on every one.' }
  ]
},

/* ----------------------------------------------------------------- 10.4 */
{
  id: 'u10l4', title: 'The superloop', goal: 'Structure a whole embedded program as one loop.',
  teach: [
    { t: 'p', x: 'The overwhelming majority of embedded firmware has no operating system. It has a loop. Initialise the hardware, then go round for ever: read the inputs, update the state, drive the outputs.' },
    { t: 'code', cap: 'The classic superloop', x: 'main:\n    bl   clocks_init\n    bl   gpio_init\n    bl   uart_init\nloop:\n    bl   read_sensors\n    bl   update_control\n    bl   drive_outputs\n    bl   service_comms\n    b    loop' },
    { t: 'h', x: 'Adding timing' },
    { t: 'p', x: 'A bare superloop runs as fast as it can, which means its period depends on how much work each pass happens to do. To make it periodic, wait for a tick at the top:' },
    { t: 'code', cap: 'A 1 kHz control loop', x: 'loop:\n1:  ldrb r0, [r9]             @ flag set by the timer interrupt\n    cmp  r0, #0\n    bne  2f\n    wfi                       @ sleep until something happens\n    b    1b\n2:  mov  r0, #0\n    strb r0, [r9]             @ clear the flag\n    bl   do_one_period\n    b    loop' },
    { t: 'note', x: 'The tick flag is written by an interrupt handler and read by the loop. In C it must be <code>volatile</code>, and on a multi-core system it needs a barrier. In single-core firmware with the flag in normal memory, a plain load is correct because the interrupt and the loop run on the same core.' },
    { t: 'h', x: 'Cooperative tasks' },
    { t: 'p', x: 'The next step up: give each subsystem a counter, and run it only when its counter expires. That is a scheduler in about ten instructions, and it is where an enormous amount of firmware lives — between "one loop" and "a real RTOS".' },
    { t: 'code', cap: 'Run each task at its own rate', x: 'loop:\n    bl   wait_tick\n    subs r4, r4, #1\n    blne skip1\n    bl   task_fast            @ every tick\n    mov  r4, #1\nskip1:\n    subs r5, r5, #1\n    bne  skip2\n    bl   task_slow            @ every 100 ticks\n    mov  r5, #100\nskip2:\n    b    loop' },
    { t: 'h', x: 'What goes wrong' },
    { t: 'p', x: 'One task that occasionally takes too long delays every other task. A superloop has no pre-emption, so its worst-case latency is the sum of everything in it. That is the reason to move to an RTOS — not features, but the ability to bound one task\'s effect on another.' }
  ],
  real: {
    title: 'A drone flight controller',
    text: 'Read the gyro, run the PID loops, mix the outputs, write the motor PWM, service telemetry — at 8 kHz, in a superloop, on a Cortex-M4. The loop period is the control period, and every microsecond of jitter shows up as a twitch in flight. It is the same structure as the microwave controller, with much tighter deadlines.',
    code: 'flight_loop:\n    bl   wait_for_gyro_ready\n    bl   read_gyro\n    bl   run_pid\n    bl   mix_and_output\n    bl   service_telemetry\n    b    flight_loop'
  },
  deep: {
    kind: 'cores',
    title: 'WFI is not a NOP that waits',
    text: 'On a Cortex-M, <code>WFI</code> asks the core to sleep: it gates the processor clock, and on many parts drops the core voltage too, until an interrupt arrives. A superloop that spends most of a period waiting for the next tick can sleep through nearly all of it, which is why the tick-wait loop above is built around <code>WFI</code> rather than a busy spin. The saving is not free: a deeper sleep state takes longer to leave than a light one, and on some parts the clocks and any PLL must re-lock before the first instruction after the wake-up runs.',
    code: 'idle:\n    ldrb r0, [r9]              @ tick flag\n    cmp  r0, #0\n    bne  got_tick\n    wfi                        @ clock-gated sleep; wakes on any interrupt\n    b    idle\ngot_tick:\n    mov  r0, #0\n    strb r0, [r9]\n    bl   kick_watchdog          @ prove the loop is still alive before doing real work\n    bl   do_one_period\n    b    idle',
    note: 'The watchdog kick belongs right after the wake-up, not at the end of the period\'s work: if <code>do_one_period</code> is what hangs, kicking before it runs would feed the watchdog while the fault is already happening, which defeats the entire point of having one.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter B1 — WFI', cite: 'WFI suspends execution until an interrupt occurs, allowing a polling superloop to idle at low power between ticks.' },
    { src: 'ARM Cortex-M Programming Guide', cite: 'A flag shared between an interrupt handler and the main loop must be declared volatile so that the compiler reloads it on every iteration.' }
  ],
  ex: [
    { k: 'code', q: 'Write a superloop that runs <code>task</code> exactly 5 times then exits. (Real ones never exit; this one counts so the checker can see it.)', start: '    mov  r6, #5\n    mov  r5, #0\nloop:\n\n    b    done\ntask:\n    add  r5, r5, #7\n    bx   lr\ndone:\n', check: [{ reg: 'r5', eq: 35 }], solution: '    mov  r6, #5\n    mov  r5, #0\nloop:\n    bl   task\n    subs r6, r6, #1\n    bne  loop\n    b    done\ntask:\n    add  r5, r5, #7\n    bx   lr\ndone:\n', hints: ['<code>bl task</code> inside the loop.', 'Count down r6 and branch back.'], why: '5 × 7 = 35. Note that r5 and r6 are callee-saved, so the task cannot clobber the loop state.' },
    { k: 'code', q: 'Cooperative scheduling: run <code>fast</code> every pass and <code>slow</code> every 3rd pass, for 9 passes. fast adds 1 to r5, slow adds 10 to r5.', start: '    mov  r6, #9\n    mov  r5, #0\n    mov  r7, #3\nloop:\n\n    b    done\nfast:\n    add  r5, r5, #1\n    bx   lr\nslow:\n    add  r5, r5, #10\n    bx   lr\ndone:\n', check: [{ reg: 'r5', eq: 39 }], solution: '    mov  r6, #9\n    mov  r5, #0\n    mov  r7, #3\nloop:\n    bl   fast\n    subs r7, r7, #1\n    bne  skip\n    bl   slow\n    mov  r7, #3\nskip:\n    subs r6, r6, #1\n    bne  loop\n    b    done\nfast:\n    add  r5, r5, #1\n    bx   lr\nslow:\n    add  r5, r5, #10\n    bx   lr\ndone:\n', hints: ['Decrement r7 each pass; when it hits zero, run <code>slow</code> and reset it to 3.', 'Careful: r7 is not callee-saved by convention, but nothing here clobbers it.'], why: '9 fast calls (9) plus 3 slow calls (30) = 39. That is a scheduler.' },
    { k: 'mcq', q: 'What is the worst-case latency of a superloop?', opts: ['One instruction', 'The sum of everything in the loop — there is no pre-emption', 'Zero', 'It depends on the clock only'], a: 1, why: 'A single task that overruns delays every other task, which is precisely the reason to reach for an RTOS.' },
    { k: 'mcq', q: 'Why does a superloop need a tick wait to run at a fixed rate?', opts: ['To save power', 'Without it the loop period varies with how much work each pass happens to do', 'To allow interrupts', 'It does not'], a: 1, why: 'A control loop\'s gains are tuned for a fixed period between samples; let the period drift with whatever each pass happens to do and the same PID math misbehaves.' },
    { k: 'mcq', q: 'Why must a flag shared with an interrupt handler be <code>volatile</code> in C?', opts: ['For thread safety', 'So the compiler reloads it every iteration instead of caching it in a register and looping for ever', 'To make it atomic', 'It need not be'], a: 1, why: 'The compiler cannot see that an interrupt writes it. Without volatile it may hoist the load right out of the loop.' }
  ]
},

/* ----------------------------------------------------------------- 10.5 */
{
  id: 'u10l5', title: 'Ring buffers', goal: 'Move data between a loop and an interrupt without locks.',
  teach: [
    { t: 'p', x: 'A ring buffer is a fixed array with a write index and a read index, both wrapping round. It is how an interrupt handler hands data to a main loop, and it is the single most useful data structure in embedded programming.' },
    { t: 'code', cap: 'Push (from the interrupt)', x: '@ r4 = buffer, r5 = head, r6 = tail, r7 = mask (size-1)\n    add  r8, r5, #1\n    and  r8, r8, r7           @ wrap\n    cmp  r8, r6\n    beq  full                 @ would collide with the tail\n    strb r0, [r4, r5]\n    mov  r5, r8' },
    { t: 'code', cap: 'Pop (from the main loop)', x: '    cmp  r6, r5\n    beq  empty\n    ldrb r0, [r4, r6]\n    add  r6, r6, #1\n    and  r6, r6, r7' },
    { t: 'note', x: 'Make the size a <b>power of two</b> and the wrap is an <code>AND</code> — one instruction, no branch, no division. A non-power-of-two size needs a compare-and-reset or a modulo, both of which are worse in every way.' },
    { t: 'h', x: 'Why it needs no lock' },
    { t: 'p', x: 'With exactly one producer and one consumer, the producer only ever writes <code>head</code> and the consumer only ever writes <code>tail</code>. Neither writes what the other writes, so no update can be lost. That is why a single-producer single-consumer ring is lock-free by construction — and why adding a second producer breaks it completely.' },
    { t: 'h', x: 'Full versus empty' },
    { t: 'p', x: 'Both conditions want <code>head == tail</code>, so the ring has to give something up. The usual answer, and the one above, is to waste one slot: the buffer is "full" when advancing head would make it equal tail. A 64-byte ring holds 63 bytes. The alternative — a separate count — is exact but is written by both sides, which reintroduces the race.' }
  ],
  real: {
    title: 'Every UART driver',
    text: 'Characters arrive at unpredictable times and must not be lost. The receive interrupt pushes into a ring; the main loop pops from it when convenient. The same structure carries audio samples to a DAC, key events to an application, and packets to a network stack.',
    code: 'uart_rx_isr:\n    ldr  r0, [r9, #UART_DR]\n    add  r8, r5, #1\n    and  r8, r8, r7\n    cmp  r8, r6\n    bxeq lr                   @ full: drop the byte\n    strb r0, [r4, r5]\n    mov  r5, r8\n    bx   lr'
  },
  deep: {
    kind: 'cores',
    title: 'DMB matters on Cortex-A, not single-core Cortex-M',
    text: 'On a single-core Cortex-M, the interrupt handler and the main loop run on the one core, and a core always sees its own memory accesses in program order, so a ring buffer\'s producer and consumer never need a barrier between writing the data and publishing the new index. A multi-core Cortex-A part is a different machine: each core\'s stores can become visible to other cores out of order, so the consumer on one core can see an updated head before it sees the data the producer wrote just before updating it. A <code>DMB</code> before the index update on the producer\'s side, and one after reading it on the consumer\'s side, restores the ordering the single-core version never had to ask for.',
    a: { lab: 'single-core Cortex-M: push from the ISR', code: '@ producer and consumer share the one core: no barrier needed\n    add  r8, r5, #1\n    and  r8, r8, r7\n    strb r0, [r4, r5]        @ write the data\n    mov  r5, r8               @ then publish the new head' },
    b: { lab: 'multi-core Cortex-A: push seen by another core', code: '@ core 0, the producer\n    strb r0, [r4, r5]        @ write the data\n    dmb                       @ make it visible before the index update is\n    add  r8, r5, #1\n    and  r8, r8, r7\n    str  r8, [r9]             @ core 1 can now safely see the new head' },
    note: 'The power-of-two mask that wraps the index is unaffected by any of this — it is arithmetic, not visibility, and it is easy to conflate the two when a lock-free structure only misbehaves occasionally.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — AND (immediate)', cite: 'A bitwise AND with size−1 computes a modulo for power-of-two sizes in a single instruction.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Memory ordering', cite: 'On a single processor, accesses appear in program order to that processor; cross-core producer/consumer sharing requires explicit barriers.' }
  ],
  ex: [
    { k: 'code', q: 'Push the 5 bytes at <code>src</code> into an 8-entry ring at <code>ring</code>, then pop them all back into <code>out</code>.', start: '    ldr  r4, =ring\n    ldr  r1, =src\n    ldr  r2, =out\n    mov  r5, #0        @ head\n    mov  r6, #0        @ tail\n    mov  r7, #7        @ mask\n\n.data\nring: .space 8\nsrc:  .byte 11,22,33,44,55\nout:  .space 5\n', check: [{ memLabel: 'out', bytes: [11, 22, 33, 44, 55] }], solution: '    ldr  r4, =ring\n    ldr  r1, =src\n    ldr  r2, =out\n    mov  r5, #0\n    mov  r6, #0\n    mov  r7, #7\n    mov  r3, #5\n1:  ldrb r0, [r1], #1\n    strb r0, [r4, r5]\n    add  r5, r5, #1\n    and  r5, r5, r7\n    subs r3, r3, #1\n    bne  1b\n    mov  r3, #5\n2:  ldrb r0, [r4, r6]\n    strb r0, [r2], #1\n    add  r6, r6, #1\n    and  r6, r6, r7\n    subs r3, r3, #1\n    bne  2b\n\n.data\nring: .space 8\nsrc:  .byte 11,22,33,44,55\nout:  .space 5\n', hints: ['Push loop: store at [r4, r5], then advance and mask r5.', 'Pop loop: load from [r4, r6], then advance and mask r6.'], why: 'FIFO order preserved. The mask is the whole wrapping mechanism.' },
    { k: 'mcq', q: 'Why make a ring buffer a power-of-two size?', opts: ['It uses less memory', 'The wrap becomes a single AND instead of a compare-and-reset or a division', 'It is required by the architecture', 'For alignment'], a: 1, why: 'One instruction, no branch, no data-dependent timing.' },
    { k: 'mcq', q: 'Why is a single-producer single-consumer ring lock-free?', opts: ['It uses atomics', 'The producer only writes head and the consumer only writes tail, so neither can lose the other\'s update', 'It disables interrupts', 'It is not'], a: 1, why: 'Add a second producer and two writers share <code>head</code> — at which point you do need atomics.' },
    { k: 'code', q: 'Demonstrate the wrap: push 10 bytes into an 8-entry ring (ignoring fullness) and show that <code>ring[0]</code> ends up holding the 9th byte.', start: '    ldr  r4, =ring\n    ldr  r1, =src\n    mov  r5, #0\n    mov  r7, #7\n    mov  r3, #10\n1:\n\n.data\nring: .space 8\nsrc:  .byte 1,2,3,4,5,6,7,8,9,10\n', check: [{ memLabel: 'ring', bytes: [9, 10, 3, 4, 5, 6, 7, 8] }], solution: '    ldr  r4, =ring\n    ldr  r1, =src\n    mov  r5, #0\n    mov  r7, #7\n    mov  r3, #10\n1:  ldrb r0, [r1], #1\n    strb r0, [r4, r5]\n    add  r5, r5, #1\n    and  r5, r5, r7\n    subs r3, r3, #1\n    bne  1b\n\n.data\nring: .space 8\nsrc:  .byte 1,2,3,4,5,6,7,8,9,10\n', hints: ['After 8 pushes the masked index is back to 0.', 'Bytes 9 and 10 overwrite slots 0 and 1.'], why: 'Overwriting old data is exactly what happens when a ring overflows — which is why the real push checks for fullness first.' },
    { k: 'mcq', q: 'Why does a ring buffer usually waste one slot?', opts: ['For alignment', 'Because head == tail must mean either empty or full, and distinguishing them needs either a wasted slot or a count written by both sides', 'To leave room for a terminator', 'It does not'], a: 1, why: 'A separate count is exact but is written by producer and consumer alike, which reintroduces the race the design was avoiding.' }
  ]
},

/* ----------------------------------------------------------------- 10.6 */
{
  id: 'u10l6', title: 'Checksums and CRC', goal: 'Write the accumulate-over-bytes loop that every protocol needs.',
  teach: [
    { t: 'p', x: 'A checksum loop reads every byte and folds it into a running value. The loop shape is identical whichever algorithm you pick; only the fold changes.' },
    { t: 'code', cap: 'The simplest: add everything up', x: '    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n    and  r0, r0, #0xFF' },
    { t: 'p', x: 'Cheap and weak: it cannot detect reordered bytes, and two errors can cancel. Good enough for a memory test, not for a protocol.' },
    { t: 'h', x: 'Fletcher: two sums for the price of one loop' },
    { t: 'code', cap: 'Position-sensitive, still only adds', x: '    mov  r0, #0               @ sum1\n    mov  r4, #0               @ sum2\n1:  ldrb r3, [r1], #1\n    add  r0, r0, r3\n    add  r4, r4, r0           @ sum2 accumulates sum1, so order matters\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'h', x: 'CRC: the table-driven fold' },
    { t: 'code', cap: 'One byte per iteration, using a 256-entry table', x: '@ r0 = crc (starts 0xFFFFFFFF), r4 = table\n1:  ldrb r3, [r1], #1\n    eor  r3, r3, r0\n    and  r3, r3, #0xFF\n    ldr  r3, [r4, r3, lsl #2]\n    eor  r0, r3, r0, lsr #8\n    subs r2, r2, #1\n    bne  1b\n    mvn  r0, r0               @ final inversion' },
    { t: 'note', x: 'Look at <code>eor r0, r3, r0, lsr #8</code>: the barrel shifter does the 8-bit shift as part of the XOR, so the fold is one instruction. That is a small but perfect example of why ARM code is compact.' },
    { t: 'h', x: 'Building the CRC table' },
    { t: 'p', x: 'The table is itself built by a loop — for each of 256 byte values, shift right eight times, XOR-ing the polynomial whenever a bit falls out. Eight iterations, 256 times, once: 2048 iterations to save eight per byte for the rest of the program\'s life.' }
  ],
  real: {
    title: 'Every frame on every wire',
    text: 'Ethernet frames, USB packets, ZIP entries, PNG chunks, CAN messages, SD card blocks — all CRC-checked, all with this loop. ARMv8 added a hardware CRC32 instruction because the loop was common enough to justify silicon; on ARMv7 the table is what you have.',
    code: '@ ARMv8-A does this in one instruction per word:\n@     crc32w w0, w0, w1\n@ On ARMv7 the table-driven loop above is the fast path.'
  },
  deep: {
    kind: 'pitfall',
    title: 'A checksum blind to swapped bytes',
    text: 'A plain sum or a running XOR is commutative, so it cannot tell "0x01 then 0x02" from "0x02 then 0x01": swap any two bytes in the message and the total comes out identical. That is not a theoretical concern: a byte-wide buffer glitch, a misordered DMA burst, or two adjacent bytes corrupted in place all transpose data in exactly this way, and a plain checksum waves it straight through. Fletcher\'s second running sum already fixes this, because accumulating the first sum again and again weights an earlier byte more heavily than a later one.',
    code: '    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    add  r0, r0, r3        @ commutative: byte order never changes the total\n    subs r2, r2, #1\n    bne  1b\n    and  r0, r0, #0xFF',
    note: 'A CRC does not share the blind spot, and for a stronger reason than Fletcher\'s: each byte is shifted through the running value before the next one is folded in, so a byte\'s position changes which bits of the final remainder it lands in, not merely whether it is present.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — EOR with shifted register', cite: 'The second operand of a data-processing instruction may be shifted, allowing an XOR with a shifted value in a single instruction.' },
    { src: 'Koopman, P. and Chakravarty, T. (2004), "Cyclic Redundancy Code (CRC) Polynomial Selection For Embedded Networks", DSN 2004', cite: 'A CRC\'s ability to catch burst errors and reordered bits comes from treating the message as a polynomial over GF(2), not from folding bytes with a commutative operator such as addition or XOR.' }
  ],
  ex: [
    { k: 'code', q: 'Compute a simple 8-bit additive checksum over the 6 bytes at <code>d</code>. Answer in r0.', start: '    ldr  r1, =d\n    mov  r2, #6\n    mov  r0, #0\n1:\n\n.data\nd: .byte 0x10, 0x20, 0x30, 0x40, 0x50, 0x60\n', check: [{ reg: 'r0', eq: 0x50 }], solution: '    ldr  r1, =d\n    mov  r2, #6\n    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n    and  r0, r0, #0xFF\n\n.data\nd: .byte 0x10, 0x20, 0x30, 0x40, 0x50, 0x60\n', hints: ['Add every byte, then mask to 8 bits.'], why: '0x10+0x20+0x30+0x40+0x50+0x60 = 0x150, masked to 0x50.' },
    { k: 'code', q: 'Compute a running XOR checksum over the same 6 bytes — cheaper than a CRC, and weak in exactly the way the deep dive above describes.', start: '    ldr  r1, =d\n    mov  r2, #6\n    mov  r0, #0\n1:\n\n.data\nd: .byte 0x10, 0x20, 0x30, 0x40, 0x50, 0x60\n', check: [{ reg: 'r0', eq: 0x70 }], solution: '    ldr  r1, =d\n    mov  r2, #6\n    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    eor  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\nd: .byte 0x10, 0x20, 0x30, 0x40, 0x50, 0x60\n', hints: ['Replace the add with <code>eor</code>.'], why: '0x10^0x20 = 0x30, ^0x30 = 0x00, ^0x40 = 0x40, ^0x50 = 0x10, ^0x60 = 0x70. XOR chains are cheap and weak — reorder the bytes and the answer is identical.' },
    { k: 'code', q: 'Fletcher-16: two running sums over the 4 bytes at <code>d</code>, both masked to 8 bits at the end. Leave sum1 in r0 and sum2 in r4.', start: '    ldr  r1, =d\n    mov  r2, #4\n    mov  r0, #0\n    mov  r4, #0\n1:\n\n.data\nd: .byte 1,2,3,4\n', check: [{ reg: 'r0', eq: 10 }, { reg: 'r4', eq: 20 }], solution: '    ldr  r1, =d\n    mov  r2, #4\n    mov  r0, #0\n    mov  r4, #0\n1:  ldrb r3, [r1], #1\n    add  r0, r0, r3\n    add  r4, r4, r0\n    subs r2, r2, #1\n    bne  1b\n    and  r0, r0, #0xFF\n    and  r4, r4, #0xFF\n\n.data\nd: .byte 1,2,3,4\n', hints: ['sum1 accumulates the bytes; sum2 accumulates sum1.', 'One extra add per byte is the whole cost.'], why: 'sum1 = 1+2+3+4 = 10. sum2 = 1+3+6+10 = 20. Because sum2 weights earlier bytes more heavily, reordering now changes the answer.' },
    { k: 'mcq', q: 'Why is a plain additive checksum weak?', opts: ['It is slow', 'It cannot detect reordered bytes, and two errors can cancel out', 'It only works on words', 'It is not weak'], a: 1, why: 'Addition is commutative, so order is invisible to it. Fletcher fixes exactly that with a second, weighted sum.' },
    { k: 'mcq', q: 'ARMv8-A added a hardware <code>CRC32</code> instruction. What does ARMv7 have to do instead?', opts: ['Nothing, ARMv7 has the same instruction', 'Compute the CRC in software, typically with the byte-at-a-time table method', 'Use NEON exclusively', 'Skip CRC checking entirely'], a: 1, why: 'The table-driven loop earlier in this lesson is the ARMv7 fast path: one <code>LDR</code>, one shift and one <code>EOR</code> per byte, with the polynomial folded into the table ahead of time.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
