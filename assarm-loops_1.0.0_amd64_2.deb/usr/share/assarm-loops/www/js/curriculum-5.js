/* AssArm: Loops — curriculum part 5 : Unit 9, framebuffer loops */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u9', n: 9, title: 'Framebuffer Loops', icon: '▦', color: '#7dcfff',
    blurb: 'A display is a rectangle of memory. Every loop in this unit lights real pixels in the machine panel.',
    lessons: [

/* ------------------------------------------------------------------ 9.1 */
{
  id: 'u9l1', title: 'A framebuffer is just memory', goal: 'Know the four numbers that describe any display buffer.',
  teach: [
    { t: 'p', x: 'This app gives you a real framebuffer at address <b>0x20000000</b>: 320 × 240 pixels, one bit per pixel. Anything you store there appears in the machine panel immediately.' },
    { t: 'p', x: 'Four numbers describe it, and they describe every framebuffer you will ever meet:' },
    { t: 'table', head: ['Number', 'Here', 'What it means'], rows: [
      ['Base address', '<code>0x20000000</code>', 'where the buffer starts'],
      ['Width × height', '320 × 240', 'the visible pixels'],
      ['Bits per pixel', '1', 'how much memory one pixel takes'],
      ['<b>Stride</b>', '40 bytes', 'how far apart two vertically adjacent pixels are']
    ] },
    { t: 'h', x: 'Stride is not width' },
    { t: 'p', x: 'The stride — Linux calls it <code>line_length</code>, Windows calls it the pitch — is the distance in <i>bytes</i> from the start of one row to the start of the next. It is often larger than the visible row, because hardware likes rows to begin on a nice boundary. Here 320 pixels at 1 bpp is exactly 40 bytes, so stride equals row length; on a 32-bpp panel 1366 pixels wide you will typically find a stride of 5504 bytes rather than 5464.' },
    { t: 'code', noasm: true, cap: 'The address of any pixel', x: 'byte   = base + y * stride + (x >> 3)     @ 1 bit per pixel\nmask   =  0x80 >> (x & 7)                @ bit 7 is the LEFTMOST pixel\n\n@ at 8 bpp:   byte = base + y * stride + x\n@ at 16 bpp:  byte = base + y * stride + x * 2\n@ at 32 bpp:  byte = base + y * stride + x * 4' },
    { t: 'note', x: '<b>Always multiply by the stride, never by the width.</b> Code that uses the width works perfectly on the developer\'s machine and draws a diagonal smear on the one panel whose stride is padded. It is one of the most common display bugs there is.' },
    { t: 'h', x: 'Why 40 is an interesting number' },
    { t: 'p', x: 'The stride here is 40, which is not a power of two. That means <code>y * stride</code> is a genuine multiply, not a shift — exactly the situation on real panels whose line length is padded to something like 40, 96 or 5504 bytes. Lesson 9.3 is about what to do when a multiply sits in your innermost loop.' },
    { t: 'h', x: 'Inside a byte' },
    { t: 'p', x: 'At one bit per pixel, each byte holds eight pixels, and <b>bit 7 is the leftmost</b>. That is the convention used by Linux\'s monochrome framebuffer, by XBM bitmaps, and by most small LCD and e-paper controllers. So the byte <code>0b10000000</code> lights only the first pixel of its group, and <code>0xFF</code> lights all eight.' }
  ],
  real: {
    title: 'Reading the geometry at run time',
    text: 'On Linux you do not hard-code any of these four numbers — you ask the driver for them with two ioctls and read <code>xres</code>, <code>yres</code>, <code>bits_per_pixel</code> and <code>line_length</code> out of the structures. Firmware for a fixed panel does hard-code them, and then a display part change becomes a four-constant edit.',
    code: '@ the four values, hoisted into registers before any drawing starts\n@ r7 = base, r9 = stride, r10 = bytes per pixel, r6 = height\n    ldr  r7, =0x20000000\n    mov  r9, #40\n    mov  r6, #240'
  },
  deep: {
    kind: 'compiler',
    title: 'A non-power-of-two stride costs a multiply',
    text: 'Given a stride the compiler cannot see the value of, it must emit a real multiply for every pixel address. Given a constant stride it will happily turn the multiply into shifts and adds — 40 = 32 + 8 — which is two instructions instead of one multiply with a three-cycle latency.',
    a: { lab: 'C', lang: 'c', code: 'void plot(uint8_t *fb, int stride,\n          int x, int y) {\n    fb[y * stride + (x >> 3)]\n        |= 0x80 >> (x & 7);\n}' },
    b: { lab: 'gcc -O2, ARMv7, stride known to be 40', code: '    add  r1, r2, r2, lsl #2   @ y*5\n    lsl  r1, r1, #3           @ y*40\n    asr  r3, r0, #3\n    add  r1, r1, r3\n    ldrb r3, [r7, r1]\n    and  r0, r0, #7\n    mov  r2, #0x80\n    lsr  r2, r2, r0\n    orr  r3, r3, r2\n    strb r3, [r7, r1]' },
    note: 'This is Unit 7\'s strength reduction happening automatically, and it only happens because the stride is a compile-time constant. Pass it in as a variable and you get a <code>MUL</code> per pixel instead.'
  },
  refs: [
    { src: 'Linux kernel documentation, Documentation/fb/api.rst', cite: 'fb_fix_screeninfo.line_length gives the distance in bytes between the start of two consecutive lines; it is not necessarily xres multiplied by the pixel size.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — STRB', cite: 'STRB stores the least significant byte of the register to the addressed byte, leaving the surrounding memory unchanged.' }
  ],
  ex: [
    { k: 'mcq', q: 'What is the stride of this framebuffer?', opts: ['320 bytes', '40 bytes', '240 bytes', '8 bytes'], a: 1, why: '320 pixels at 1 bit per pixel is 40 bytes per row, and here the rows are not padded, so the stride is 40.' },
    { k: 'mcq', q: 'Why should address arithmetic use the stride rather than the width?', opts: ['They are always the same', 'On a panel whose rows are padded, using the width walks off the row and the image shears diagonally', 'The width is not a constant', 'It should use the width'], a: 1, why: 'Stride ≥ width × bytes-per-pixel, and the difference is invisible until you meet a panel that pads.' },
    { k: 'mcq', q: 'At 1 bpp with this convention, which bit of a byte is the leftmost pixel?', opts: ['Bit 0', 'Bit 3', 'Bit 7', 'It depends on the row'], a: 2, why: 'Bit 7 first, matching Linux mono framebuffers, XBM, and most LCD controllers.' },
    { k: 'code', q: 'Compute the byte offset of the start of row 100, using the stride. Answer in r0.', start: '    mov  r1, #100       @ the row\n    mov  r9, #40        @ the stride\n', check: [{ reg: 'r0', eq: 4000 }], solution: '    mov  r1, #100\n    mov  r9, #40\n    mul  r0, r1, r9\n', hints: ['One multiply: row number times stride.'], why: '100 × 40 = 4000. Every row address in this unit is that multiply.' },
    { k: 'code', q: 'Now do it without <code>MUL</code>: 40 = (5 × 8), and 5 × y is <code>y + 4y</code>. Answer still 4000 in r0.', start: '    mov  r1, #100\n', check: [{ reg: 'r0', eq: 4000 }, { notContains: 'mul' }], solution: '    mov  r1, #100\n    add  r0, r1, r1, lsl #2\n    lsl  r0, r0, #3\n', hints: ['<code>add r0, r1, r1, lsl #2</code> gives 5×y.', 'Then shift left by 3 for ×8.'], why: 'Two barrel-shifter instructions replace a multiply — exactly what the compiler does when it knows the stride.' }
  ]
},

/* ------------------------------------------------------------------ 9.2 */
{
  id: 'u9l2', title: 'Clearing the screen', goal: 'Write the fastest loop in the unit, and watch it run.',
  teach: [
    { t: 'p', x: 'Clearing sets every byte of the buffer to the same value, so the geometry does not matter at all — it is a flat 9600-byte fill, and everything from Unit 5 applies directly.' },
    { t: 'code', cap: 'Byte by byte: correct and slow', x: '    ldr  r0, =0x20000000\n    mov  r1, #0\n    mov  r2, #9600\n1:  strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'code', cap: 'Word by word: four times fewer iterations', x: '    ldr  r0, =0x20000000\n    mov  r1, #0\n    mov  r2, #2400\n1:  str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'code', cap: 'Block store: sixteen bytes per pass', x: '    ldr  r0, =0x20000000\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r2, #600\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b' },
    { t: 'note', x: 'Run all three in the exercises below and compare the reported cycle counts. The block version does the same work in roughly a tenth of the instructions — the same optimisation as Unit 5, applied to a screen instead of a buffer.' },
    { t: 'h', x: 'Filling with a pattern' },
    { t: 'p', x: 'Storing <code>0xFF</code> lights all eight pixels of a byte. Storing <code>0x55</code> — binary 01010101 — lights alternate pixels, giving vertical stripes. Because eight pixels fit exactly in a byte, patterns repeat cleanly, which is why 1-bpp dithering and fill patterns are almost always 8 or 16 pixels wide.' },
    { t: 'code', cap: 'A striped screen', x: '    ldr  r0, =0x20000000\n    ldr  r1, =0x55555555\n    mov  r2, #2400\n1:  str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'h', x: 'Clearing part of the screen' },
    { t: 'p', x: 'Clearing a rectangle is a different loop, because the rows are not contiguous — you clear <code>w</code> bytes, then add the stride, then do it again. That nested shape is the one you will use for every partial redraw.' }
  ],
  real: {
    title: 'Clearing is the first thing every frame does',
    text: 'Every frame of every graphical application begins by clearing a buffer, and on an embedded system with no GPU that is a CPU fill loop. A 320×240 16-bpp panel is 150 KB; an STM32 at 168 MHz clearing it with an 8-register STM spends about a millisecond, which is a sixth of a 60 Hz frame — enough that it is worth doing properly.',
    code: '@ clear a 16-bpp framebuffer to a background colour\n    orr  r1, r6, r6, lsl #16   @ two pixels per word\n    mov  r3, r1\n    mov  r4, r1\n    mov  r5, r1\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b'
  },
  deep: {
    kind: 'cores',
    title: 'Why a full-line store is nearly free',
    text: 'When you write part of a cache line the core must first fetch the old line from memory so it can merge your bytes into it. When you write <b>every</b> byte of a line it can skip that fetch entirely — there is nothing to preserve. A 4-register STM writes 16 bytes; an 8-register STM writes 32, which is a whole cache line on many Cortex-A cores, and that alone can double fill throughput.',
    code: '@ 32 bytes per pass: one full cache line on a typical Cortex-A\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r6, #0\n    mov  r8, #0\n    mov  r9, #0\n    mov  r10, #0\n1:  stmia r0!, {r1, r3, r4, r5, r6, r8, r9, r10}\n    subs  r2, r2, #32\n    bne   1b',
    note: 'The framebuffer is usually mapped as non-cacheable write-combining rather than normal cacheable memory, and there the win comes from the write-combining buffer filling completely instead of dribbling out in partial bursts. Different mechanism, same advice: write whole lines.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Cache behaviour on writes', cite: 'Writing a complete cache line can avoid the read-for-ownership of that line, improving store throughput.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — STM', cite: 'STM stores the listed registers to consecutive words beginning at the address determined by the addressing mode.' }
  ],
  ex: [
    { k: 'code', q: 'Fill the whole framebuffer with 0xFF so every pixel lights. Use a word loop.', start: '    ldr  r0, =0x20000000\n', check: [{ fbBytes: 9600 }], solution: '    ldr  r0, =0x20000000\n    ldr  r1, =0xFFFFFFFF\n    mov  r2, #2400\n1:  str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  1b\n', hints: ['9600 bytes is 2400 words.', '<code>ldr r1, =0xFFFFFFFF</code> for the fill value.'], why: 'Watch the machine panel go white. All 9600 bytes came from one four-instruction loop.' },
    { k: 'code', q: 'Now do it with an STM of four registers, and get the executed instruction count under 2000.', start: '    ldr  r0, =0x20000000\n', check: [{ fbBytes: 9600 }, { maxInsn: 2000 }], solution: '    ldr  r0, =0x20000000\n    ldr  r1, =0xFFFFFFFF\n    mov  r3, r1\n    mov  r4, r1\n    mov  r5, r1\n    mov  r2, #600\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b\n', hints: ['Four registers of 0xFFFFFFFF is 16 bytes per iteration.', '9600 / 16 = 600 iterations.'], why: 'Three instructions × 600 instead of four × 2400. Compare the cycle counts.' },
    { k: 'code', q: 'Draw vertical stripes: fill the screen with 0x55555555 so alternate pixels light.', start: '    ldr  r0, =0x20000000\n', check: [{ fbBytes: 9600 }, { fbPixel: [0, 0], eq: 0 }, { fbPixel: [1, 0], eq: 1 }], solution: '    ldr  r0, =0x20000000\n    ldr  r1, =0x55555555\n    mov  r2, #2400\n1:  str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  1b\n', hints: ['0x55 is 0101 0101.', 'Bit 7 is the leftmost pixel, and bit 7 of 0x55 is clear — so pixel 0 stays dark and pixel 1 lights.'], why: 'Reading the bits left to right from bit 7 gives 0,1,0,1,… which is why the first pixel is the dark one.' },
    { k: 'code', q: 'Clear a 16-byte-wide, 10-row rectangle at the top-left of an otherwise white screen. You will need the stride.', start: '    ldr  r0, =0x20000000\n    ldr  r1, =0xFFFFFFFF\n    mov  r2, #2400\n9:  str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  9b\n    @ now clear the rectangle\n    ldr  r0, =0x20000000\n', check: [{ fbBytes: 9440 }, { fbPixel: [0, 0], eq: 0 }, { fbPixel: [0, 10], eq: 1 }, { fbPixel: [128, 0], eq: 1 }], solution: '    ldr  r0, =0x20000000\n    ldr  r1, =0xFFFFFFFF\n    mov  r2, #2400\n9:  str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  9b\n    ldr  r0, =0x20000000\n    mov  r6, #0\n    mov  r5, #0\n1:  mov  r3, #40\n    mul  r4, r6, r3\n    add  r4, r4, r0\n    mov  r8, #16\n2:  strb r5, [r4], #1\n    subs r8, r8, #1\n    bne  2b\n    add  r6, r6, #1\n    cmp  r6, #10\n    blo  1b\n', hints: ['Outer loop over 10 rows, inner loop over 16 bytes.', 'Recompute the row address as y × 40 at the top of each outer pass.'], why: '9600 − 160 = 9440 bytes still set. Rows are not contiguous, so a rectangle is always a nested loop.' },
    { k: 'mcq', q: 'Why does clearing the whole screen not need the stride?', opts: ['The stride is 1', 'Every byte gets the same value, so the order you visit them in does not matter', 'The stride is built into STR', 'It does need it'], a: 1, why: 'Geometry only matters when the address has to mean something. For a uniform fill it does not — but for a rectangle it does.' }
  ]
},

/* ------------------------------------------------------------------ 9.3 */
{
  id: 'u9l3', title: 'Getting the multiply out of the loop', goal: 'Replace y × stride with a running add, or a row table.',
  teach: [
    { t: 'p', x: 'Every row address is <code>y × stride</code>. Computed naively that is a multiply per row, and if you are careless, a multiply per <i>pixel</i>. There are three ways to get rid of it, in increasing order of firepower.' },
    { t: 'h', x: '1. Hoist it out of the inner loop' },
    { t: 'code', cap: 'Compute the row address once per row, not once per pixel', x: '    mov  r6, #0               @ y\n    mov  r9, #40              @ stride\n1:  mul  r0, r6, r9           @ ONCE per row\n    add  r0, r0, r7\n    mov  r8, #0               @ x\n2:  strb r5, [r0, r8]         @ no multiply in here at all\n    add  r8, r8, #1\n    cmp  r8, #40\n    blo  2b\n    add  r6, r6, #1\n    cmp  r6, #240\n    blo  1b' },
    { t: 'h', x: '2. Strength-reduce it to an add' },
    { t: 'code', cap: 'The row pointer walks itself', x: '    ldr  r0, =0x20000000      @ row pointer, starts at row 0\n    mov  r6, #240\n1:  @ ... draw into the row at r0 ...\n    add  r0, r0, #40          @ one add replaces the multiply\n    subs r6, r6, #1\n    bne  1b' },
    { t: 'p', x: 'There is no multiply anywhere. This is the version to write when you walk rows in order, and it is what Unit 7 called strength reduction.' },
    { t: 'h', x: '3. Build a row table' },
    { t: 'code', cap: '240 entries, built once', x: '    ldr  r6, =rowtab\n    mov  r1, #0\n    mov  r9, #40\n1:  mul  r0, r1, r9\n    str  r0, [r6, r1, lsl #2]\n    add  r1, r1, #1\n    cmp  r1, #240\n    blo  1b\n\n@ afterwards, any row address is one load:\n    ldr  r0, [r6, r2, lsl #2]' },
    { t: 'note', x: 'The table wins when you jump between rows in an unpredictable order — a line, a sprite, a glyph — because then the running-add trick does not apply. It also hides the geometry, so the same drawing code works on a padded buffer, a rotated one, or one stored bottom-up, just by rebuilding the table.' },
    { t: 'h', x: 'When the table stops paying' },
    { t: 'p', x: '240 entries is 960 bytes — fifteen cache lines, permanently resident once touched. Scale the same idea to a 4096-row buffer and the table is 16 KB, which will start missing the cache, and the arithmetic wins again. Table size is the whole decision.' }
  ],
  real: {
    title: 'Scanline tables in real renderers',
    text: 'Software rasterisers, terminal emulators and embedded display drivers all keep a table of row start addresses. It removes a multiply from the inner loop and it insulates the drawing code from the buffer\'s layout — so the same rasteriser works on a linear buffer, a padded one, or a bottom-up one, with no change but the table.',
    code: '@ plot into any layout: the table hides the geometry\n    ldr  r0, [r6, r2, lsl #2]    @ row base for y\n    strb r3, [r0, r1]            @ x is a plain byte offset'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler does this for you — when it can prove it is safe',
    text: 'Given a loop whose row index only ever increases by one, LLVM and GCC both turn <code>y * stride</code> into a pointer that advances by <code>stride</code> each iteration. They stop being able to do it the moment the loop might write to the variable holding the stride, which is why a stride read from a struct inside the loop kills the optimisation dead.',
    a: { lab: 'C', lang: 'c', code: 'for (int y = 0; y < h; y++) {\n    uint8_t *row = fb + y * stride;\n    for (int x = 0; x < w; x++)\n        row[x] = 0;\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: '@ y*stride became a running add:\n.L4:\n    mov  r2, r5            @ row pointer\n    mov  r3, r6            @ width\n.L3:\n    strb r7, [r2], #1\n    subs r3, r3, #1\n    bne  .L3\n    add  r5, r5, r8        @ row += stride\n    subs r4, r4, #1\n    bne  .L4' },
    note: 'Write <code>fb[y * dev->stride + x]</code> with <code>dev</code> reachable through a pointer the loop also writes through, and the compiler must reload <code>dev->stride</code> and redo the multiply on every single pixel.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop-invariant code motion and strength reduction', cite: 'Address computations that advance by a fixed amount should be maintained incrementally rather than recomputed from an index.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR (register)', cite: 'A register offset scaled by LSL #2 indexes a table of 32-bit words in a single instruction.' }
  ],
  ex: [
    { k: 'code', q: 'Build the first 8 entries of a row table at <code>rowtab</code>: 0, 40, 80, 120, 160, 200, 240, 280.', start: '    ldr  r6, =rowtab\n    mov  r1, #0\n1:\n\n.data\nrowtab: .space 32\n', check: [{ memLabel: 'rowtab', words: [0, 40, 80, 120, 160, 200, 240, 280] }], solution: '    ldr  r6, =rowtab\n    mov  r1, #0\n    mov  r9, #40\n1:  mul  r0, r1, r9\n    str  r0, [r6, r1, lsl #2]\n    add  r1, r1, #1\n    cmp  r1, #8\n    blo  1b\n\n.data\nrowtab: .space 32\n', hints: ['Multiply the row number by the stride, then store with a scaled index.', '<code>str r0, [r6, r1, lsl #2]</code>.'], why: 'Eight multiplies paid once; every later row address is a single load.' },
    { k: 'code', q: 'Build all 240 entries, then read entry 137 into r0.', start: '    ldr  r6, =rowtab\n    mov  r1, #0\n1:\n\n.data\nrowtab: .space 960\n', check: [{ reg: 'r0', eq: 5480 }], solution: '    ldr  r6, =rowtab\n    mov  r1, #0\n    mov  r9, #40\n1:  mul  r0, r1, r9\n    str  r0, [r6, r1, lsl #2]\n    add  r1, r1, #1\n    cmp  r1, #240\n    blo  1b\n    mov  r7, #137\n    ldr  r0, [r6, r7, lsl #2]\n\n.data\nrowtab: .space 960\n', hints: ['Same loop, limit 240 instead of 8.', 'Then one scaled load with index 137.'], why: '137 × 40 = 5480. After the build loop, every row costs one instruction.' },
    { k: 'code', q: 'Draw one lit byte at the start of all 240 rows, using the running-add trick and no multiply at all.', start: '    ldr  r0, =0x20000000\n    mov  r1, #0xFF\n    mov  r6, #240\n1:\n', check: [{ fbBytes: 240 }, { notContains: 'mul' }, { fbPixel: [0, 0], eq: 1 }, { fbPixel: [0, 239], eq: 1 }], solution: '    ldr  r0, =0x20000000\n    mov  r1, #0xFF\n    mov  r6, #240\n1:  strb r1, [r0]\n    add  r0, r0, #40\n    subs r6, r6, #1\n    bne  1b\n', hints: ['Store at the row pointer, then add the stride to it.', 'No index, no multiply — the pointer is the loop variable.'], why: 'A vertical bar down the left edge, 240 bytes written, and not one multiply executed.' },
    { k: 'mcq', q: 'When does a row table beat a running add?', opts: ['Always', 'When rows are visited out of order — a line, a sprite, a glyph — so there is no "next row" to add to', 'When the stride is a power of two', 'Never'], a: 1, why: 'The running add only works if you walk rows in sequence. Random row access is what the table is for.' },
    { k: 'mcq', q: 'What stops a compiler turning <code>y * stride</code> into a running add?', opts: ['Nothing ever does', 'If the loop might write through a pointer that could alias the stride, it must reload it and redo the multiply every time', 'A stride of 40', 'Using unsigned arithmetic'], a: 1, why: 'Aliasing again — the same reason Unit 7 said hand-written assembly can hoist what a compiler cannot.' }
  ]
},

/* ------------------------------------------------------------------ 9.4 */
{
  id: 'u9l4', title: 'Plotting a pixel', goal: 'Turn an (x, y) coordinate into a single bit, and light it.',
  teach: [
    { t: 'p', x: 'With the row address solved, plotting is three more steps: find which byte in the row, find which bit in the byte, and merge it in without disturbing the seven neighbours.' },
    { t: 'table', head: ['Step', 'Arithmetic', 'Instruction'], rows: [
      ['Row address', 'y × stride', '<code>mul</code>, or a table load'],
      ['Byte within the row', 'x ÷ 8', '<code>lsr #3</code>'],
      ['Bit within the byte', 'x mod 8', '<code>and #7</code>'],
      ['Mask', '0x80 ≫ bit', '<code>lsr</code> by a register'],
      ['Merge', 'OR it in', '<code>orr</code>']
    ] },
    { t: 'note', x: 'Everything here is a shift or a mask because 8 is a power of two. That is the practical reason 1, 2, 4, 8, 16 and 32 bits per pixel exist and nothing in between: any other value would put a division in the innermost loop of every drawing routine ever written.' },
    { t: 'code', cap: 'Plot (r1, r2)', x: '@ r7 = base, r1 = x, r2 = y\n    mov  r9, #40\n    mul  r0, r2, r9           @ row offset\n    add  r0, r0, r7           @ absolute row address\n    lsr  r4, r1, #3           @ byte index  = x / 8\n    and  r5, r1, #7           @ bit index   = x mod 8\n    mov  r8, #0x80\n    lsr  r8, r8, r5           @ the mask, bit 7 first\n    ldrb r3, [r0, r4]\n    orr  r3, r3, r8\n    strb r3, [r0, r4]' },
    { t: 'h', x: 'Read-modify-write' },
    { t: 'p', x: 'Because seven other pixels share the byte, you cannot simply store the mask — you must load, OR, and store back. That read-modify-write is why plotting single pixels is slow on <i>any</i> packed-bit display, and why fast drawing code always tries to work a whole byte or word at a time.' },
    { t: 'h', x: 'Set, clear and toggle' },
    { t: 'code', cap: 'Three operations, one shape', x: '    orr  r3, r3, r8      @ set the pixel\n    bic  r3, r3, r8      @ clear the pixel\n    eor  r3, r3, r8      @ toggle the pixel' },
    { t: 'p', x: 'And a fourth: <code>and r3, r3, r8</code> keeps only that pixel and clears the other seven, which is occasionally what a mask operation wants.' }
  ],
  real: {
    title: 'Every monochrome display driver',
    text: 'SSD1306 OLEDs, e-paper panels, LED matrices and thermal printer buffers are all packed one bit per pixel, and every driver contains this exact read-modify-write plot. They are all slow enough that the libraries push you towards drawing into a RAM buffer and pushing whole pages to the panel, rather than plotting straight to the device.',
    code: '@ SSD1306: pages of 8 VERTICAL pixels per byte — same idea, rotated\n    lsr  r4, r2, #3          @ page = y >> 3\n    and  r5, r2, #7          @ bit within the page\n    mov  r8, #1\n    lsl  r8, r8, r5\n    ldrb r3, [r0, r4]\n    orr  r3, r3, r8\n    strb r3, [r0, r4]'
  },
  deep: {
    kind: 'pitfall',
    title: 'Storing the mask instead of merging it',
    text: 'The mistake is writing <code>strb r8, [r0, r4]</code> — storing the mask directly. It lights your pixel and clears the seven around it, so a diagonal line comes out as a dotted one and a filled shape comes out as a sparse grid. It happens because the buggy version looks simpler and is one instruction shorter, and because the very first pixel you test looks correct.',
    a: { lab: 'Wrong', code: '    mov  r8, #0x80\n    lsr  r8, r8, r5\n    strb r8, [r0, r4]     @ wipes the neighbours' },
    b: { lab: 'Right', code: '    mov  r8, #0x80\n    lsr  r8, r8, r5\n    ldrb r3, [r0, r4]\n    orr  r3, r3, r8\n    strb r3, [r0, r4]' },
    note: 'The tell-tale symptom is that a shape looks right when drawn on a blank screen and destroys whatever it is drawn over. If you see that, you have a missing read-modify-write somewhere.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LSR (register)', cite: 'A register may be shifted by an amount held in another register, which is what produces a bit mask from a pixel index in a single instruction.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — ORR, BIC, EOR', cite: 'ORR sets the bits of the mask, BIC clears them, and EOR inverts them, giving set, clear and toggle directly.' }
  ],
  ex: [
    { k: 'code', q: 'Light the single pixel at x = 0, y = 0.', start: '    ldr  r7, =0x20000000\n', check: [{ fbPixel: [0, 0], eq: 1 }, { fbBytes: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0x80\n    strb r8, [r7]\n', hints: ['Row 0 is at offset 0, byte 0.', 'Bit 7 is the leftmost pixel, so the value is 0x80.'], why: 'One pixel, one store. Look closely at the top-left of the panel.' },
    { k: 'code', q: 'Light the pixel at x = 10, y = 0. (10 ÷ 8 = byte 1, 10 mod 8 = bit index 2, so the mask is 0x80 ≫ 2.)', start: '    ldr  r7, =0x20000000\n', check: [{ fbPixel: [10, 0], eq: 1 }, { fbBytes: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0x20\n    strb r8, [r7, #1]\n', hints: ['0x80 &gt;&gt; 2 = 0x20.', 'Store it at offset 1.'], why: 'Eight pixels per byte, bit 7 first — so x = 10 is the third pixel of byte 1.' },
    { k: 'code', q: 'Write a general plot for x = 17, y = 3, computing the row, byte, bit and mask properly, and merging with a read-modify-write.', start: '    ldr  r7, =0x20000000\n    mov  r1, #17\n    mov  r2, #3\n', check: [{ fbPixel: [17, 3], eq: 1 }, { fbBytes: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r1, #17\n    mov  r2, #3\n    mov  r9, #40\n    mul  r0, r2, r9\n    add  r0, r0, r7\n    lsr  r4, r1, #3\n    and  r5, r1, #7\n    mov  r8, #0x80\n    lsr  r8, r8, r5\n    ldrb r3, [r0, r4]\n    orr  r3, r3, r8\n    strb r3, [r0, r4]\n', hints: ['Row 3 is at offset 3 × 40 = 120.', '17 &gt;&gt; 3 = 2, 17 &amp; 7 = 1, so the mask is 0x40 in byte 2.'], why: 'Twelve instructions is a general pixel plot. This is why every graphics library wants you to draw runs, not points.' },
    { k: 'code', q: 'Now clear it again with <code>BIC</code>, leaving the screen completely blank.', start: '    ldr  r7, =0x20000000\n    mov  r8, #0x40\n    strb r8, [r7, #122]      @ pixel (17,3) is lit\n    @ now clear just that pixel\n', check: [{ fbBytes: 0 }, { contains: 'bic' }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0x40\n    strb r8, [r7, #122]\n    ldrb r3, [r7, #122]\n    bic  r3, r3, r8\n    strb r3, [r7, #122]\n', hints: ['Load the byte, <code>bic</code> the mask out of it, store it back.'], why: 'BIC is AND-NOT: it clears exactly the bits of the mask and leaves the other seven pixels alone.' },
    { k: 'mcq', q: 'Why must plotting be a read-modify-write?', opts: ['Because of the stride', 'Because seven other pixels share the same byte and must be preserved', 'Because STRB is slow', 'It need not be'], a: 1, why: 'Packed-bit displays always pay this, which is why fast drawing works a whole byte or word at a time.' }
  ]
},

/* ------------------------------------------------------------------ 9.5 */
{
  id: 'u9l5', title: 'Drawing a line', goal: 'Build Bresenham\'s algorithm — a loop with a decision variable.',
  teach: [
    { t: 'p', x: 'Bresenham\'s line algorithm draws a line using only integer addition, subtraction and comparison — no division, no floating point. It is a loop with one plotted pixel per iteration and a running <b>error term</b> that decides when to step in the minor axis.' },
    { t: 'code', noasm: true, cap: 'The idea, for a shallow line', x: '@ dx > dy, so we step x every iteration and y sometimes\n@ err starts at dx/2\n@ each iteration:  err -= dy\n@                  if err < 0:  y += 1;  err += dx' },
    { t: 'code', cap: 'A horizontal-ish line, ARMv7', x: '@ r1 = x, r2 = y, r3 = dx, r4 = dy, r5 = err, r6 = counter\n    lsr  r5, r3, #1          @ err = dx / 2\n    mov  r6, r3              @ counter = dx\n1:  bl   plot                @ plot (r1, r2)\n    add  r1, r1, #1          @ always step x\n    subs r5, r5, r4          @ err -= dy\n    addmi r2, r2, #1         @ if err went negative, step y\n    addmi r5, r5, r3         @   and err += dx\n    subs r6, r6, #1\n    bne  1b' },
    { t: 'note', x: 'Look at the two conditional instructions. The "step in y" decision is predication, not a branch — and it is the perfect case for it, because the decision alternates in a pattern no branch predictor can learn.' },
    { t: 'h', x: 'Why it works' },
    { t: 'p', x: 'The error term tracks how far the ideal line has drifted from the pixels drawn so far, scaled by dx so that everything stays an integer. When the drift exceeds half a pixel, you step. That is the whole insight, and it is why the algorithm needs no division: multiplying through by 2dx clears every fraction.' },
    { t: 'h', x: 'The eight octants' },
    { t: 'p', x: 'The version above handles one eighth of the possible directions: rightwards, downwards, shallower than 45°. A complete implementation either duplicates the loop eight times, or normalises the direction into step values (±1 in each axis) and swaps the roles of x and y for steep lines. The second approach is one loop with four extra registers, and it is the one to write.' },
    { t: 'h', x: 'The fast case' },
    { t: 'p', x: 'Purely horizontal and purely vertical lines are worth special-casing, because a horizontal line is a run of whole bytes — one <code>memset</code>-shaped loop with a partial byte at each end — rather than one read-modify-write per pixel. Most real line routines test for those two cases first.' }
  ],
  real: {
    title: 'Bresenham is everywhere',
    text: 'Line drawing, circle drawing, the inner loop of texture mapping, CNC and 3D-printer motion control, audio sample-rate conversion, and the scaling of any image by a non-integer factor. Any time you need to advance one counter n times while advancing another m times as evenly as possible, this is the loop.',
    code: '@ resample: emit r6 output samples from r3 input samples, evenly\n    lsr  r5, r6, #1\n1:  ldr  r0, [r1]\n    str  r0, [r2], #4\n    subs r5, r5, r3\n    addmi r1, r1, #4\n    addmi r5, r5, r6\n    subs r6, r6, #1\n    bne  1b'
  },
  deep: {
    kind: 'cores',
    title: 'Why the predicated step is worth two instructions',
    text: 'Whether a line steps in the minor axis on a given pixel depends on the slope, and for any slope that is not a simple fraction the pattern looks random to a branch predictor. On a Cortex-A7 a mispredict costs about eight cycles, and a 45.3° line will mispredict roughly half the time. Two predicated adds cost two cycles, every time, with no variance.',
    a: { lab: 'Branching — 2 or ~10 cycles', code: '    subs r5, r5, r4\n    bpl  1f\n    add  r2, r2, #1\n    add  r5, r5, r3\n1:' },
    b: { lab: 'Predicated — always 3 cycles', code: '    subs r5, r5, r4\n    addmi r2, r2, #1\n    addmi r5, r5, r3' },
    note: 'This is the case Unit 6 described in the abstract: a short body with an unpredictable condition. ARMv8\'s A64 dropped general predication, and there the same loop is written with CSEL and a conditional add instead.'
  },
  refs: [
    { src: 'Bresenham, J. E. (1965), "Algorithm for computer control of a digital plotter", IBM Systems Journal 4(1)', cite: 'The algorithm selects between two candidate pixels at each step using an integer error term, avoiding division entirely.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — Conditional execution', cite: 'A data-processing instruction with a condition suffix executes only when the condition holds, with no branch and no pipeline disruption.' }
  ],
  ex: [
    { k: 'code', q: 'Draw a horizontal line: light pixels x = 0…15 on row 0. (Two whole bytes, so no read-modify-write needed.)', start: '    ldr  r7, =0x20000000\n', check: [{ fbPixel: [0, 0], eq: 1 }, { fbPixel: [15, 0], eq: 1 }, { fbPixel: [16, 0], eq: 0 }, { fbBytes: 2 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7]\n    strb r8, [r7, #1]\n', hints: ['Eight pixels per byte, so x = 0…15 is exactly bytes 0 and 1.', '0xFF lights all eight pixels of a byte.'], why: 'A horizontal line that lands on byte boundaries needs no read-modify-write at all — which is why fast fills work in whole bytes.' },
    { k: 'code', q: 'Draw a vertical line: light pixel x = 0 on rows 0 to 9, using the stride.', start: '    ldr  r7, =0x20000000\n    mov  r2, #0\n1:\n', check: [{ fbPixel: [0, 0], eq: 1 }, { fbPixel: [0, 9], eq: 1 }, { fbBytes: 10 }], solution: '    ldr  r7, =0x20000000\n    mov  r2, #0\n    mov  r8, #0x80\n1:  strb r8, [r7]\n    add  r7, r7, #40\n    add  r2, r2, #1\n    cmp  r2, #10\n    blo  1b\n', hints: ['Store 0x80 at the row pointer, then add the stride.'], why: 'A vertical line touches ten different bytes 40 apart — which is why vertical lines are slower than horizontal ones on every packed framebuffer.' },
    { k: 'code', q: 'Bresenham: draw a shallow line from (0,0) with dx = 16, dy = 5. At least 5 pixels should light.', start: '    ldr  r7, =0x20000000\n    mov  r1, #0        @ x\n    mov  r2, #0        @ y\n    mov  r3, #16       @ dx\n    mov  r4, #5        @ dy\n    lsr  r5, r3, #1    @ err\n    mov  r6, r3\n1:\n', check: [{ fbPixel: [0, 0], eq: 1 }, { fbAtLeast: 5 }], solution: '    ldr  r7, =0x20000000\n    mov  r1, #0\n    mov  r2, #0\n    mov  r3, #16\n    mov  r4, #5\n    lsr  r5, r3, #1\n    mov  r6, r3\n1:  mov  r9, #40\n    mul  r0, r2, r9\n    add  r0, r0, r7\n    lsr  r10, r1, #3\n    and  r11, r1, #7\n    mov  r8, #0x80\n    lsr  r8, r8, r11\n    ldrb r12, [r0, r10]\n    orr  r12, r12, r8\n    strb r12, [r0, r10]\n    add  r1, r1, #1\n    subs r5, r5, r4\n    addmi r2, r2, #1\n    addmi r5, r5, r3\n    subs r6, r6, #1\n    bne  1b\n', hints: ['Plot, then <code>add r1, r1, #1</code>, then <code>subs r5, r5, r4</code> and two <code>addmi</code>s.', 'The row offset is y × 40.'], why: 'Sixteen plotted pixels descending five rows — a real Bresenham line on a real framebuffer.' },
    { k: 'mcq', q: 'Why does Bresenham need no division?', opts: ['It uses floating point instead', 'The error term is scaled by dx, which clears every fraction and leaves only integer adds and compares', 'It only draws horizontal lines', 'It does need division'], a: 1, why: 'Multiplying through by 2dx is the trick that makes the whole algorithm integer.' },
    { k: 'mcq', q: 'Why do real line routines special-case horizontal lines?', opts: ['They are more common', 'A horizontal run is whole bytes, so it becomes a fill loop instead of one read-modify-write per pixel', 'Bresenham fails on them', 'They do not'], a: 1, why: 'Eight or thirty-two pixels per store instead of one, and no load at all in the middle of the run.' }
  ]
},

/* ------------------------------------------------------------------ 9.6 */
{
  id: 'u9l6', title: 'Scrolling', goal: 'Move the whole screen with an overlapping copy — and pick the right direction.',
  teach: [
    { t: 'p', x: 'Scrolling is a copy of the buffer onto itself, which makes it the overlap problem from Unit 3 applied to real pixels. Scroll up and the destination is below the source in memory, so forwards is safe. Scroll down and it is not.' },
    { t: 'code', cap: 'Scroll up by one row', x: '@ move rows 1..239 up one place: dst = row 0, src = row 1\n    ldr  r0, =0x20000000\n    add  r1, r0, #40         @ source = one row down\n    ldr  r2, =9560           @ 239 rows x 40 bytes\n1:  ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'p', x: 'Because the buffer is linear, that is <b>one</b> copy of 9560 bytes — not 239 separate row copies. A linear layout is worth a great deal here, and it is the main reason framebuffers are laid out the way they are.' },
    { t: 'h', x: 'Faster: move words, or blocks' },
    { t: 'code', cap: 'The same scroll, 32 bytes per pass', x: '    ldr  r0, =0x20000000\n    add  r1, r0, #40\n    ldr  r2, =9560\n1:  cmp  r2, #32\n    blo  2f\n    ldmia r1!, {r4-r11}\n    stmia r0!, {r4-r11}\n    sub  r2, r2, #32\n    b    1b\n2:  cmp  r2, #0\n    beq  3f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  2b\n3:' },
    { t: 'note', x: 'Note the head/bulk/tail shape from Unit 5 again. 9560 is not a multiple of 32, so the tail is not optional.' },
    { t: 'h', x: 'Scrolling down needs the other direction' },
    { t: 'p', x: 'Moving rows <i>down</i> means the destination is at a higher address than the source, and the ranges overlap. A forward copy would overwrite rows it has not read yet. Start at the bottom and walk backwards, exactly as in Unit 3.' },
    { t: 'h', x: 'The thing that beats copying' },
    { t: 'p', x: 'Do not copy at all. Many display controllers have a <b>start-line</b> or <b>display offset</b> register: change it and the picture scrolls with no memory traffic whatsoever. Linux exposes the same idea through <code>FBIOPAN_DISPLAY</code>. When the hardware offers it, a scroll becomes one register write, and the only work left is drawing the one new row.' },
    { t: 'code', cap: 'What the software version of that looks like', x: '@ a ring buffer of rows: move an index, not the data\n    add  r5, r5, #1\n    cmp  r5, #240\n    movhs r5, #0            @ wrap the top-of-screen row index' }
  ],
  real: {
    title: 'Terminal emulators do not memmove',
    text: 'A scrolling terminal either memmoves its character grid or keeps a ring buffer and moves an index. The ring buffer is strictly better and every serious terminal uses one — which is the software version of a hardware start-line register: move a pointer, not the bytes.',
    code: '@ ring-buffer scroll: one add and one mask, no copying\n    add  r5, r5, #1\n    and  r5, r5, r6          @ r6 = rows-1, a power-of-two mask'
  },
  deep: {
    kind: 'pitfall',
    title: 'memcpy where you needed memmove',
    text: 'A scroll is a copy of a buffer onto itself, so the ranges always overlap. Calling <code>memcpy</code> for it is undefined behaviour, and the reason it is a nasty bug rather than an obvious one is that it usually <i>works</i>: a forward byte-at-a-time memcpy happens to do the right thing when the destination is below the source. Swap in a version that copies backwards, or vectorises, or runs on a different core, and the picture smears.',
    a: { lab: 'Undefined — happens to work, until it does not', lang: 'c', code: 'memcpy(fb, fb + stride,\n       (h - 1) * stride);' },
    b: { lab: 'Defined for overlap', lang: 'c', code: 'memmove(fb, fb + stride,\n        (h - 1) * stride);' },
    note: 'The symptom when it finally breaks is the first row of the scrolled region repeated down the screen — the classic smear. If you ever see that, look for a memcpy on an overlapping range.'
  },
  refs: [
    { src: 'ISO/IEC 9899, 7.24.2.1 and 7.24.2.2', cite: 'memcpy has undefined behaviour if the objects overlap; memmove behaves as if the source were first copied into a temporary buffer.' },
    { src: 'Linux kernel documentation, Documentation/fb/api.rst', cite: 'FBIOPAN_DISPLAY changes the visible portion of the framebuffer without moving any pixel data.' }
  ],
  ex: [
    { k: 'code', q: 'Put a lit byte on row 1, then scroll the whole framebuffer up by one row so it lands on row 0.', start: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7, #40]       @ one lit byte at the start of row 1\n    @ now scroll up by one row\n', check: [{ fbPixel: [0, 0], eq: 1 }, { fbPixel: [0, 1], eq: 0 }, { fbBytes: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7, #40]\n    mov  r0, r7\n    add  r1, r7, #40\n    ldr  r2, =9560\n1:  ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b\n', hints: ['Source is 40 bytes above the destination.', '239 rows × 40 bytes = 9560 bytes to move.'], why: 'The lit byte has moved from row 1 to row 0, and row 1 now holds what row 2 held. That is a scroll.' },
    { k: 'code', q: 'Scroll DOWN by one row instead: put a lit byte on row 0, then move every row down one. Copy backwards.', start: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7]\n    @ now scroll down by one row\n', check: [{ fbPixel: [0, 1], eq: 1 }, { fbBytes: 2 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7]\n    ldr  r2, =9560\n    add  r1, r7, r2          @ source end   = start of row 239\n    add  r0, r1, #40         @ dest end     = one row further on\n1:  ldrb r3, [r1, #-1]!\n    strb r3, [r0, #-1]!\n    subs r2, r2, #1\n    bne  1b\n', hints: ['Start both pointers one past the end of their ranges and pre-decrement.', '<code>ldrb r3, [r1, #-1]!</code>.'], why: 'The lit byte moved from row 0 to row 1 without smearing, because the copy ran from the bottom up. Row 0 still holds its old contents — two lit bytes in total — which is why a real scroll-down finishes by clearing the newly exposed row.' },
    { k: 'code', q: 'Scroll up again, but move 32 bytes per pass with LDM/STM, and finish in under 2000 executed instructions.', start: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7, #40]\n', check: [{ fbPixel: [0, 0], eq: 1 }, { maxInsn: 2000 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7, #40]\n    mov  r0, r7\n    add  r1, r7, #40\n    ldr  r2, =9560\n1:  cmp  r2, #32\n    blo  2f\n    ldmia r1!, {r3-r6, r9-r12}\n    stmia r0!, {r3-r6, r9-r12}\n    sub  r2, r2, #32\n    b    1b\n2:  cmp  r2, #0\n    beq  3f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  2b\n3:\n', hints: ['Eight registers is 32 bytes per pass.', '9560 = 298 × 32 + 24, so the byte tail runs 24 times.'], why: 'About 1500 instructions instead of 38,000. The tail is what makes it correct for a length that is not a multiple of 32.' },
    { k: 'mcq', q: 'Scrolling DOWN copies each row to the row below it. Which direction must the copy run?', opts: ['Forwards', 'Backwards, starting from the last row', 'Either', 'It cannot be done in place'], a: 1, why: 'Destination above source in memory means a forward copy overwrites rows it has not read yet.' },
    { k: 'mcq', q: 'What beats copying entirely?', opts: ['Copying faster', 'A display start-line register, or a ring buffer — move a pointer, not the pixels', 'Using two threads', 'Clearing first'], a: 1, why: 'Both replace moving bytes with moving an index, which is the single biggest optimisation available for scrolling.' }
  ]
},

/* ------------------------------------------------------------------ 9.7 */
{
  id: 'u9l7', title: 'Sprites, masks and XOR', goal: 'Blit a shape onto the screen, and erase it for free.',
  teach: [
    { t: 'p', x: 'A sprite is a small rectangle of pixels copied onto the screen. The loop is a nested copy — rows outer, bytes inner — with one complication per drawing style.' },
    { t: 'code', cap: 'Opaque blit: overwrite everything', x: '@ r1 = sprite data, r0 = screen row address, r6 = height, r7 = width in bytes\n1:  mov  r3, r7\n    mov  r8, r0              @ screen pointer for this row\n2:  ldrb r4, [r1], #1\n    strb r4, [r8], #1\n    subs r3, r3, #1\n    bne  2b\n    add  r0, r0, #40         @ next screen row: add the stride\n    subs r6, r6, #1\n    bne  1b' },
    { t: 'h', x: 'Masked blit: transparency' },
    { t: 'p', x: 'An opaque blit paints a rectangle, background and all. To make the background transparent you need a second bitmap — the <b>mask</b> — with 1s where the sprite is solid. Then: clear the screen bits the sprite will occupy, and OR the sprite in.' },
    { t: 'code', cap: 'Two operations per byte', x: '2:  ldrb r4, [r1], #1        @ sprite data\n    ldrb r5, [r2], #1        @ mask: 1 where the sprite is solid\n    ldrb r9, [r8]\n    bic  r9, r9, r5          @ punch a hole\n    orr  r9, r9, r4          @ drop the sprite in\n    strb r9, [r8], #1' },
    { t: 'h', x: 'XOR: draw and erase with one operation' },
    { t: 'p', x: 'XOR-ing a sprite onto the screen and then XOR-ing it again in the same place restores the original pixels exactly. No mask, no saved background, no clear — just draw twice. The cost is that the sprite inverts wherever it overlaps something already drawn.' },
    { t: 'code', cap: 'The erase routine is the draw routine', x: '2:  ldrb r4, [r1], #1\n    ldrb r9, [r8]\n    eor  r9, r9, r4\n    strb r9, [r8], #1' },
    { t: 'note', x: 'Eight pixels per byte means a sprite that moves one pixel sideways does not move one byte sideways. You either shift the sprite data on the fly — a shift and two ORs per byte — or you keep <b>eight pre-shifted copies</b> of it, one per bit offset, and pick the right one. That is memory traded for work, the same trade as the row table.' },
    { t: 'code', cap: 'Picking the pre-shifted variant', x: '@ r1 = x, r13 = bytes per variant, r14 = base of the variant table\n    and  r12, r1, #7          @ which of the eight alignments\n    mla  r1, r12, r13, r14    @ the right pre-shifted copy' }
  ],
  real: {
    title: 'Pre-shifted assets are still a technique',
    text: 'Bitmap font renderers cache pre-shifted glyphs. Tile engines on microcontrollers store pre-rotated tiles. Anywhere the per-pixel shift would dominate the blit, precomputing the variants wins — you spend eight times the memory to remove a shift, a mask and an OR from the innermost loop.',
    code: '@ the on-the-fly alternative: shift across a byte boundary\n    ldrb r4, [r1], #1\n    lsl  r5, r4, #24\n    orr  r6, r6, r5, lsr r12   @ high part into this byte\n    lsl  r7, r4, r11           @ low part carried into the next'
  },
  deep: {
    kind: 'compiler',
    title: 'What a byte blit looks like at -O2',
    text: 'The inner loop of a blit is so simple that compilers do very well on it — post-indexed loads and stores, the counter folded into the loop control, often unrolled by four. What a compiler will not do is vectorise it without knowing the buffers do not overlap, which is what <code>restrict</code> is for.',
    a: { lab: 'C', lang: 'c', code: 'void blit(uint8_t *restrict d,\n          const uint8_t *restrict s,\n          int n) {\n    for (int i = 0; i < n; i++)\n        d[i] ^= s[i];\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: '.L3:\n    ldrb r3, [r1], #1\n    ldrb r2, [r0]\n    eor  r3, r3, r2\n    strb r3, [r0], #1\n    subs ip, ip, #1\n    bne  .L3' },
    note: 'Drop the two <code>restrict</code> qualifiers and the compiler must assume the destination might alias the source, which blocks unrolling and any use of NEON — a one-word change that can halve the speed of the loop.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — BIC, ORR, EOR', cite: 'BIC clears the bits set in its second operand, ORR sets them, and EOR toggles them, giving the three primitive blit operations directly.' },
    { src: 'ISO/IEC 9899, 6.7.3 — restrict', cite: 'The restrict qualifier lets a compiler assume that accesses through one pointer do not alias accesses through another, enabling unrolling and vectorisation of copy loops.' }
  ],
  ex: [
    { k: 'code', q: 'XOR-blit a 3-byte pattern onto row 0 twice. The screen must end up completely blank, proving XOR erases itself.', start: '    ldr  r7, =0x20000000\n    ldr  r6, =spr\n    mov  r5, #2         @ do it twice\n3:\n\n.data\nspr: .byte 0x2A, 0x55, 0x7F\n', check: [{ fbBytes: 0 }, { contains: 'eor' }], solution: '    ldr  r7, =0x20000000\n    ldr  r6, =spr\n    mov  r5, #2\n3:  mov  r1, r6\n    mov  r8, r7\n    mov  r3, #3\n2:  ldrb r4, [r1], #1\n    ldrb r9, [r8]\n    eor  r9, r9, r4\n    strb r9, [r8], #1\n    subs r3, r3, #1\n    bne  2b\n    subs r5, r5, #1\n    bne  3b\n\n.data\nspr: .byte 0x2A, 0x55, 0x7F\n', hints: ['Reset the sprite and screen pointers at the top of each of the two passes.', 'a XOR b XOR b = a.'], why: 'Zero non-zero bytes left. The draw routine and the erase routine are the same code.' },
    { k: 'code', q: 'Opaque-blit a sprite 3 bytes wide and 2 rows tall at the top-left, remembering to add the stride between rows.', start: '    ldr  r7, =0x20000000\n    ldr  r6, =spr\n\n.data\nspr: .byte 0x11, 0x22, 0x44, 0x08, 0x10, 0x20\n', check: [{ fbBytes: 6 }, { fbPixel: [3, 0], eq: 1 }, { fbPixel: [11, 1], eq: 1 }], solution: '    ldr  r7, =0x20000000\n    ldr  r6, =spr\n    mov  r5, #2\n    mov  r0, r7\n1:  mov  r3, #3\n    mov  r8, r0\n2:  ldrb r4, [r6], #1\n    strb r4, [r8], #1\n    subs r3, r3, #1\n    bne  2b\n    add  r0, r0, #40\n    subs r5, r5, #1\n    bne  1b\n\n.data\nspr: .byte 0x11, 0x22, 0x44, 0x08, 0x10, 0x20\n', hints: ['Outer loop over the two rows, inner loop over the three bytes.', 'Between rows, advance the screen pointer by the stride, not by 3.'], why: 'Six bytes written, on two consecutive rows. Advance by 3 instead of 40 and the second row lands inside the first.' },
    { k: 'code', q: 'Masked blit: draw the sprite over an already-white screen so only the solid parts show. Mask is 1 where the sprite is solid.', start: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7]\n    strb r8, [r7, #1]\n    ldr  r6, =spr\n    ldr  r2, =msk\n    @ blit 2 bytes over the white row\n\n.data\nspr: .byte 0x0F, 0xF0\nmsk: .byte 0x3F, 0xFC\n', check: [{ memLabel: 'spr', bytes: [0x0F, 0xF0] }, { fbPixel: [0, 0], eq: 1 }, { fbPixel: [2, 0], eq: 0 }, { fbPixel: [7, 0], eq: 1 }], solution: '    ldr  r7, =0x20000000\n    mov  r8, #0xFF\n    strb r8, [r7]\n    strb r8, [r7, #1]\n    ldr  r6, =spr\n    ldr  r2, =msk\n    mov  r0, r7\n    mov  r3, #2\n2:  ldrb r4, [r6], #1\n    ldrb r5, [r2], #1\n    ldrb r9, [r0]\n    bic  r9, r9, r5\n    orr  r9, r9, r4\n    strb r9, [r0], #1\n    subs r3, r3, #1\n    bne  2b\n\n.data\nspr: .byte 0x0F, 0xF0\nmsk: .byte 0x3F, 0xFC\n', hints: ['<code>bic</code> the mask out of the screen byte, then <code>orr</code> the sprite data in.', 'Byte 0: 0xFF BIC 0x3F = 0xC0, then ORR 0x0F = 0xCF.'], why: 'The two pixels outside the mask keep their white background; everything under the mask shows the sprite.' },
    { k: 'mcq', q: 'What does a sprite mask contain?', opts: ['The sprite colours', '1s where the sprite is solid, so the screen bits underneath can be cleared before the sprite is ORed in', 'The background', 'The sprite width'], a: 1, why: 'BIC with the mask punches the hole; ORR with the data fills it.' },
    { k: 'mcq', q: 'Why keep eight pre-shifted copies of a sprite?', opts: ['For eight colours', 'A byte holds eight pixels, so a one-pixel horizontal move needs a different bit alignment — eight of them before it repeats', 'To handle the stride', 'For animation'], a: 1, why: 'Memory traded for work in the innermost loop, exactly like the row table trading memory for arithmetic.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
