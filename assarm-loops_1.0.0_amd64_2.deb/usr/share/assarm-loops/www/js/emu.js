/* ============================================================================
 *  AssArm: Loops  --  ARMv7-A (A32) assembler + emulator
 *  ---------------------------------------------------------------------------
 *  A teaching emulator. It implements the integer core that loops are built
 *  from, plus enough VFPv3 / NEON to make vectorised loops real, plus the
 *  peripherals an ARMv7 board actually has -- a linear monochrome framebuffer,
 *  a character console and a GPIO pin driving a buzzer -- so that framebuffer
 *  loops and timing loops produce something you can see and hear.
 *
 *  Memory map
 *    0x00008000  .text        64 KiB   code
 *    0x00018000  .data/.bss   64 KiB   user data
 *    0x00028000  stack        16 KiB   SP starts at 0x0002C000, grows down
 *    0x20000000  FB          9600 B    320x240, 1 bpp, 40-byte stride,
 *                                      bit 7 of each byte is the LEFTMOST pixel
 *    0x20010000  TEXT         960 B    40x24 ASCII character console
 *    0x20020000  MMIO
 *                 +0x00  GPIO      any access toggles the buzzer pin
 *                 +0x04  CYCLES    read-only cycle counter
 *                 +0x08  KEY       last key (bit7 = key ready)
 *                 +0x0C  UART      write a byte -> console
 *                 +0x10  RANDOM    read -> pseudo-random word
 *                 +0x14  HALT      write -> stop the machine
 * ========================================================================== */
(function (global) {
  'use strict';

  /* ---------------------------------------------------------------- memory */
  const MAP = {
    TEXT_BASE: 0x00008000, TEXT_SIZE: 0x10000,
    DATA_BASE: 0x00018000, DATA_SIZE: 0x10000,
    STACK_BASE: 0x00028000, STACK_SIZE: 0x4000,
    SP_INIT: 0x0002C000,
    FB: 0x20000000, FB_SIZE: 9600, FB_W: 320, FB_H: 240, FB_STRIDE: 40,
    TPAGE: 0x20010000, TPAGE_SIZE: 960,
    MMIO: 0x20020000,
    GPIO: 0x20020000, CYCLES: 0x20020004, KEY: 0x20020008,
    UART: 0x2002000C, RANDOM: 0x20020010, HALT: 0x20020014
  };

  const COND = ['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al'];
  const COND_ALIAS = { hs: 'cs', lo: 'cc' };
  const REGNAME = { sp: 13, lr: 14, pc: 15, ip: 12, fp: 11, sl: 10, sb: 9 };

  function u32(x) { return x >>> 0; }
  function s32(x) { return x | 0; }

  let LENIENT = false;

  class AsmError extends Error {
    constructor(msg, line) { super(msg); this.line = line; this.isAsm = true; }
  }

  /* =========================================================================
   *  Expression evaluator  (immediates, .word values, .equ)
   * ====================================================================== */
  function evalExpr(src, syms, line, pcVal) {
    let i = 0;
    const s = src;
    function ws() { while (i < s.length && /\s/.test(s[i])) i++; }
    function primary() {
      ws();
      if (i >= s.length) throw new AsmError('unexpected end of expression', line);
      const c = s[i];
      if (c === '(') { i++; const v = expr(); ws(); if (s[i] !== ')') throw new AsmError('missing )', line); i++; return v; }
      if (c === '-') { i++; return -primary(); }
      if (c === '+') { i++; return primary(); }
      if (c === '~') { i++; return ~primary(); }
      if (c === "'") {
        i++;
        let ch = s[i];
        if (ch === '\\') { i++; ch = ({ n: '\n', t: '\t', r: '\r', '0': '\0', '\\': '\\', "'": "'" })[s[i]] || s[i]; }
        i++;
        if (s[i] === "'") i++;
        return ch.charCodeAt(0);
      }
      if (c === '.' && !/[A-Za-z0-9_$.]/.test(s[i + 1] || '')) { i++; return pcVal; }
      let m = /^0[xX][0-9a-fA-F_]+/.exec(s.slice(i));
      if (m) { i += m[0].length; return parseInt(m[0].replace(/_/g, '').slice(2), 16); }
      m = /^0[bB][01_]+/.exec(s.slice(i));
      if (m) { i += m[0].length; return parseInt(m[0].replace(/_/g, '').slice(2), 2); }
      m = /^\d[\d_]*/.exec(s.slice(i));
      if (m) { i += m[0].length; return parseInt(m[0].replace(/_/g, ''), 10); }
      m = /^[A-Za-z_.$][A-Za-z0-9_.$]*/.exec(s.slice(i));
      if (m) {
        i += m[0].length;
        const name = m[0];
        if (Object.prototype.hasOwnProperty.call(syms, name)) return syms[name];
        if (LENIENT) return 0;
        throw new AsmError('unknown symbol "' + name + '"', line);
      }
      throw new AsmError('cannot parse expression near "' + s.slice(i) + '"', line);
    }
    function mul() {
      let v = primary();
      for (;;) {
        ws();
        if (s[i] === '*') { i++; v = (v * primary()) | 0; }
        else if (s[i] === '/' && s[i + 1] !== '/') { i++; const d = primary(); if (d === 0) throw new AsmError('divide by zero', line); v = (v / d) | 0; }
        else if (s[i] === '%') { i++; v = v % primary(); }
        else return v;
      }
    }
    function add() {
      let v = mul();
      for (;;) {
        ws();
        if (s[i] === '+') { i++; v = (v + mul()) | 0; }
        else if (s[i] === '-') { i++; v = (v - mul()) | 0; }
        else return v;
      }
    }
    function shift() {
      let v = add();
      for (;;) {
        ws();
        if (s[i] === '<' && s[i + 1] === '<') { i += 2; v = v << add(); }
        else if (s[i] === '>' && s[i + 1] === '>') { i += 2; v = v >> add(); }
        else return v;
      }
    }
    function expr() {
      let v = shift();
      for (;;) {
        ws();
        if (s[i] === '&' && s[i + 1] !== '&') { i++; v = v & shift(); }
        else if (s[i] === '|' && s[i + 1] !== '|') { i++; v = v | shift(); }
        else if (s[i] === '^') { i++; v = v ^ shift(); }
        else return v;
      }
    }
    const v = expr();
    ws();
    if (i < s.length) throw new AsmError('trailing junk "' + s.slice(i) + '" in expression', line);
    return v | 0;
  }

  /* =========================================================================
   *  Modified immediate: an 8-bit value rotated right by an even amount.
   *  This is the rule behind "invalid constant" errors, and it matters in
   *  loops (loop bounds, strides, masks).
   * ====================================================================== */
  function encodeModifiedImm(v) {
    v = u32(v);
    for (let r = 0; r < 32; r += 2) {
      const rot = u32((v << r) | (v >>> ((32 - r) & 31)));
      if (rot <= 0xff) return { imm8: rot, rot: r };
    }
    return null;
  }
  function nearestValidImm(v) {
    // helper used for friendly error messages
    for (let d = 1; d < 4096; d++) {
      if (encodeModifiedImm(u32(v - d))) return u32(v - d);
      if (encodeModifiedImm(u32(v + d))) return u32(v + d);
    }
    return null;
  }

  /* =========================================================================
   *  Instruction tables
   * ====================================================================== */
  const DP3 = ['and', 'eor', 'sub', 'rsb', 'add', 'adc', 'sbc', 'rsc', 'orr', 'bic'];
  const DP2 = ['mov', 'mvn'];          // rd, op2
  const DPT = ['tst', 'teq', 'cmp', 'cmn']; // rn, op2  (always set flags)
  const SHIFTS = ['lsl', 'lsr', 'asr', 'ror', 'rrx'];
  const MEM_OPS = ['ldr', 'str', 'ldrb', 'strb', 'ldrh', 'strh', 'ldrsb', 'ldrsh', 'ldrd', 'strd'];
  const EXT_OPS = ['uxtb', 'sxtb', 'uxth', 'sxth', 'uxtb16', 'clz', 'rbit', 'rev', 'rev16', 'revsh'];
  const MUL_OPS = ['mul', 'mla', 'mls', 'umull', 'umlal', 'smull', 'smlal', 'smulbb', 'smlabb'];
  const NEON_BIN = ['vadd', 'vsub', 'vmul', 'vand', 'vorr', 'veor', 'vmax', 'vmin', 'vmla', 'vmls', 'vabd', 'vshl', 'vshr', 'vhadd', 'vqadd', 'vqsub', 'vpadd'];

  /* =========================================================================
   *  Assembler
   * ====================================================================== */
  function assemble(source, opts) {
    opts = opts || {};
    LENIENT = !!opts.lenient;
    const lines = String(source).replace(/\r\n?/g, '\n').split('\n');
    const syms = Object.create(null);
    const numLabels = Object.create(null);
    const regAlias = Object.create(null);
    const items = [];            // {kind:'insn'|'data', addr, size, ...}
    const litpool = [];          // pending LDR =imm
    let section = 'text';
    let addr = { text: MAP.TEXT_BASE, data: MAP.DATA_BASE };
    const dataBytes = [];        // {addr, bytes:[]}
    const errors = [];
    const warnings = [];

    function cur() { return addr[section]; }
    function bump(n) { addr[section] += n; }
    // Padding inside .text must be executable, so emit NOPs rather than a hole.
    function emitPad(a, ln) {
      if (!a || a < 1) return;
      let pad = (a - (cur() % a)) % a;
      if (!pad) return;
      if (section === 'text') {
        while (pad >= 4) { work.push({ kind: 'insn', text: 'nop', addr: cur(), ln: ln || 0, section }); bump(4); pad -= 4; }
      }
      if (pad) { work.push({ kind: 'data', addr: cur(), bytes: new Array(pad).fill(0), ln: ln || 0, section }); bump(pad); }
    }

    /* ---------- pass 0: strip comments, collect labels, size everything --- */
    const parsed = [];
    for (let ln = 0; ln < lines.length; ln++) {
      let text = lines[ln];
      // strip comments: @  ;  //   (but not inside a string literal)
      let out = '', inStr = false, strCh = '';
      for (let k = 0; k < text.length; k++) {
        const c = text[k];
        if (inStr) { out += c; if (c === '\\') { out += text[++k] || ''; } else if (c === strCh) inStr = false; continue; }
        if (c === '"' || c === "'") { inStr = true; strCh = c; out += c; continue; }
        if (c === '@' || c === ';') break;
        if (c === '/' && text[k + 1] === '/') break;
        out += c;
      }
      parsed.push({ raw: lines[ln], text: out.trim(), ln: ln + 1 });
    }

    // helper for .equ before use: do a quick scan for .equ/.set
    for (const p of parsed) {
      const m = /^\.(equ|set)\s+([A-Za-z_.$][\w.$]*)\s*,\s*(.+)$/i.exec(p.text);
      if (m) { try { syms[m[2]] = evalExpr(m[3], syms, p.ln, 0); } catch (e) { /* retry later */ } }
      const r = /^([A-Za-z_][\w]*)\s+\.req\s+(\w+)$/i.exec(p.text);
      if (r) regAlias[r[1].toLowerCase()] = r[2].toLowerCase();
    }

    const work = [];
    for (const p of parsed) {
      let t = p.text;
      if (!t) continue;
      // labels (possibly several, possibly followed by an instruction)
      for (;;) {
        const m = /^(\d+|[A-Za-z_.$][\w.$]*)\s*:\s*/.exec(t);
        if (!m) break;
        const name = m[1];
        if (/^\d+$/.test(name)) {
          // GNU-as numeric local label: 1:  referenced as 1b / 1f
          (numLabels[name] || (numLabels[name] = [])).push(cur());
        } else {
          if (Object.prototype.hasOwnProperty.call(syms, name) && !name.startsWith('.L'))
            warnings.push({ line: p.ln, msg: 'label "' + name + '" defined more than once' });
          syms[name] = cur();
        }
        work.push({ kind: 'label', name, addr: cur(), ln: p.ln });
        t = t.slice(m[0].length);
      }
      t = t.trim();
      if (!t) continue;

      if (/^\.{2,}$/.test(t)) continue;          // "..." in a listing: treat as a comment
      if (t[0] === '.') {
        const dm = /^\.([A-Za-z_0-9]+)\s*(.*)$/.exec(t);
        if (!dm) { warnings.push({ line: p.ln, msg: 'ignoring "' + t + '"' }); continue; }
        const d = dm[1].toLowerCase(), rest = (dm[2] || '').trim();
        switch (d) {
          case 'text': section = 'text'; break;
          case 'data': case 'bss': section = 'data'; break;
          case 'section': section = /data|bss/i.test(rest) ? 'data' : 'text'; break;
          case 'global': case 'globl': case 'type': case 'size': case 'syntax':
          case 'arch': case 'cpu': case 'fpu': case 'thumb': case 'arm':
          case 'end': case 'ltorg': case 'func': case 'endfunc': case 'eabi_attribute':
            break;
          case 'equ': case 'set': {
            const m2 = /^([A-Za-z_.$][\w.$]*)\s*,\s*(.+)$/.exec(rest);
            if (!m2) { errors.push(new AsmError('.equ needs NAME, value', p.ln)); break; }
            try { syms[m2[1]] = evalExpr(m2[2], syms, p.ln, cur()); } catch (e) { errors.push(e); }
            break;
          }
          case 'req': break;
          case 'align': case 'p2align': {
            const n = rest ? (evalExpr(rest, syms, p.ln, cur()) | 0) : 2;
            emitPad((1 << n));
            break;
          }
          case 'balign': {
            emitPad(rest ? (evalExpr(rest, syms, p.ln, cur()) | 0) : 4);
            break;
          }
          case 'org': { const v = evalExpr(rest, syms, p.ln, cur()); addr[section] = u32(v); break; }
          case 'space': case 'skip': case 'zero': {
            const parts = splitTop(rest);
            const n = evalExpr(parts[0], syms, p.ln, cur());
            const fill = parts[1] ? evalExpr(parts[1], syms, p.ln, cur()) & 0xff : 0;
            work.push({ kind: 'data', addr: cur(), bytes: new Array(n).fill(fill), ln: p.ln, section });
            bump(n);
            break;
          }
          case 'word': case 'int': case '4byte': case 'long': {
            const parts = splitTop(rest);
            const bytes = [];
            for (const pt of parts) { const v = safeEval(pt, syms, p.ln, cur(), errors); bytes.push(v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff); }
            work.push({ kind: 'data', addr: cur(), bytes, ln: p.ln, section, reloc: parts.map((x, k) => ({ expr: x, off: k * 4, size: 4 })) });
            bump(bytes.length);
            break;
          }
          case 'hword': case 'short': case '2byte': {
            const parts = splitTop(rest); const bytes = [];
            for (const pt of parts) { const v = safeEval(pt, syms, p.ln, cur(), errors); bytes.push(v & 0xff, (v >>> 8) & 0xff); }
            work.push({ kind: 'data', addr: cur(), bytes, ln: p.ln, section, reloc: parts.map((x, k) => ({ expr: x, off: k * 2, size: 2 })) });
            bump(bytes.length);
            break;
          }
          case 'byte': case '1byte': {
            const parts = splitTop(rest); const bytes = [];
            for (const pt of parts) { const v = safeEval(pt, syms, p.ln, cur(), errors); bytes.push(v & 0xff); }
            work.push({ kind: 'data', addr: cur(), bytes, ln: p.ln, section, reloc: parts.map((x, k) => ({ expr: x, off: k, size: 1 })) });
            bump(bytes.length);
            break;
          }
          case 'ascii': case 'asciz': case 'string': {
            const parts = splitTop(rest); const bytes = [];
            for (const pt of parts) {
              const sm = /^"((?:[^"\\]|\\.)*)"$/.exec(pt.trim());
              if (!sm) { errors.push(new AsmError('expected a quoted string', p.ln)); continue; }
              const str = sm[1].replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\r/g, '\r').replace(/\\0/g, '\0').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
              for (let k = 0; k < str.length; k++) bytes.push(str.charCodeAt(k) & 0xff);
              if (d !== 'ascii') bytes.push(0);
            }
            work.push({ kind: 'data', addr: cur(), bytes, ln: p.ln, section });
            bump(bytes.length);
            break;
          }
          default:
            warnings.push({ line: p.ln, msg: 'ignoring unsupported directive .' + d });
        }
        continue;
      }

      // instruction
      work.push({ kind: 'insn', text: t, addr: cur(), ln: p.ln, section });
      bump(4);
    }

    // literal pool goes at the end of .text
    const poolBase = ((addr.text + 3) & ~3) >>> 0;

    /* ---------- pass 1: decode instructions ------------------------------ */
    const code = new Map();   // addr -> ir
    const pool = [];          // {addr, value}
    const poolIndex = new Map();

    function poolAlloc(value) {
      const key = u32(value);
      if (poolIndex.has(key)) return poolIndex.get(key);
      const a = u32(poolBase + pool.length * 4);
      pool.push({ addr: a, value: key });
      poolIndex.set(key, a);
      return a;
    }

    function resolveLocal(text, here) {
      return text.replace(/(^|[^\w.$])(\d+)([bf])(?![\w.$])/g, (m, pre, num, dir) => {
        const list = numLabels[num];
        if (!list) return m;
        if (dir === 'b') {
          let best = null;
          for (const a of list) if (a <= here) best = a;
          return best === null ? m : pre + '0x' + best.toString(16);
        }
        for (const a of list) if (a > here) return pre + '0x' + a.toString(16);
        return m;
      });
    }

    for (const w of work) {
      if (w.kind !== 'insn') continue;
      try {
        const ir = decodeLine(resolveLocal(w.text, w.addr), w.addr, syms, w.ln, regAlias, poolAlloc);
        ir.ln = w.ln;
        ir.addr = w.addr;
        ir.src = w.text;
        code.set(w.addr, ir);
      } catch (e) {
        if (e.isAsm) { e.line = e.line || w.ln; errors.push(e); }
        else errors.push(new AsmError(e.message, w.ln));
      }
    }

    /* ---------- pass 2: lay bytes down ----------------------------------- */
    const image = [];   // {addr, bytes}
    for (const w of work) {
      if (w.kind !== 'data') continue;
      let bytes = w.bytes;
      if (w.reloc) {
        bytes = bytes.slice();
        for (const r of w.reloc) {
          const v = safeEval(r.expr, syms, w.ln, w.addr, errors);
          for (let k = 0; k < r.size; k++) bytes[r.off + k] = (v >>> (8 * k)) & 0xff;
        }
      }
      image.push({ addr: w.addr, bytes });
    }
    for (const p of pool) image.push({ addr: p.addr, bytes: [p.value & 0xff, (p.value >>> 8) & 0xff, (p.value >>> 16) & 0xff, (p.value >>> 24) & 0xff] });

    LENIENT = false;
    return {
      code, image, syms, errors, warnings,
      textEnd: u32(poolBase + pool.length * 4),
      entry: (syms._start !== undefined ? syms._start : (syms.main !== undefined ? syms.main : MAP.TEXT_BASE)),
      lineOf: (a) => (code.get(a) ? code.get(a).ln : null)
    };
  }

  function safeEval(expr, syms, ln, pc, errors) {
    try { return evalExpr(expr, syms, ln, pc); }
    catch (e) { errors.push(e.isAsm ? e : new AsmError(e.message, ln)); return 0; }
  }

  // split on commas that are not inside brackets/braces/quotes
  function splitTop(s) {
    const out = []; let depth = 0, cur = '', inStr = false, q = '';
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (inStr) { cur += c; if (c === '\\') { cur += s[++i] || ''; } else if (c === q) inStr = false; continue; }
      if (c === '"' || c === "'") { inStr = true; q = c; cur += c; continue; }
      if (c === '[' || c === '{' || c === '(') depth++;
      if (c === ']' || c === '}' || c === ')') depth--;
      if (c === ',' && depth === 0) { out.push(cur.trim()); cur = ''; continue; }
      cur += c;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }

  function parseReg(tok, ln, alias) {
    let t = String(tok).trim().toLowerCase();
    if (alias && alias[t]) t = alias[t];
    let m = /^r(\d{1,2})$/.exec(t);
    if (m) { const n = +m[1]; if (n > 15) throw new AsmError('no such register ' + tok, ln); return n; }
    if (t in REGNAME) return REGNAME[t];
    throw new AsmError('expected a register, got "' + tok + '"', ln);
  }
  function parseVReg(tok, ln) {
    const t = String(tok).trim().toLowerCase();
    let m = /^([sdq])(\d{1,2})$/.exec(t);
    if (!m) throw new AsmError('expected an s/d/q register, got "' + tok + '"', ln);
    const n = +m[2];
    const lim = m[1] === 's' ? 31 : (m[1] === 'd' ? 31 : 15);
    if (n > lim) throw new AsmError('no such register ' + tok, ln);
    return { kind: m[1], n };
  }

  function parseOperand2(toks, syms, ln, pc, alias) {
    // toks: array of remaining comma-separated tokens
    const first = toks[0].trim();
    if (first.startsWith('#')) {
      const v = evalExpr(first.slice(1), syms, ln, pc);
      const enc = encodeModifiedImm(v);
      if (!enc) {
        const near = nearestValidImm(v);
        throw new AsmError(
          'immediate #' + v + ' (0x' + u32(v).toString(16) + ') cannot be encoded. ARM immediates are an 8-bit value ' +
          'rotated right by an even amount' + (near !== null ? '; 0x' + near.toString(16) + ' would work, or use  LDR rX, =' + u32(v) : ''), ln);
      }
      return { type: 'imm', value: u32(v), enc };
    }
    const rm = parseReg(first, ln, alias);
    if (toks.length === 1) return { type: 'reg', rm, shift: null };
    const sh = toks[1].trim().toLowerCase();
    const sm = /^(lsl|lsr|asr|ror|rrx)\s*(.*)$/.exec(sh);
    if (!sm) throw new AsmError('expected a shift (LSL/LSR/ASR/ROR/RRX) after the register', ln);
    const kind = sm[1];
    if (kind === 'rrx') return { type: 'reg', rm, shift: { kind: 'rrx' } };
    const arg = sm[2].trim();
    if (!arg) throw new AsmError(kind.toUpperCase() + ' needs an amount', ln);
    if (arg.startsWith('#')) {
      let n = evalExpr(arg.slice(1), syms, ln, pc);
      if (kind === 'lsl' && (n < 0 || n > 31)) throw new AsmError('LSL amount must be 0..31', ln);
      if ((kind === 'lsr' || kind === 'asr') && (n < 1 || n > 32)) throw new AsmError(kind.toUpperCase() + ' amount must be 1..32', ln);
      if (kind === 'ror' && (n < 1 || n > 31)) throw new AsmError('ROR amount must be 1..31', ln);
      return { type: 'reg', rm, shift: { kind, imm: n } };
    }
    return { type: 'reg', rm, shift: { kind, rs: parseReg(arg, ln, alias) } };
  }

  function parseMem(str, syms, ln, pc, alias) {
    // returns {rn, offset, index:'offset'|'pre'|'post', sub, label?}
    const s = str.trim();
    if (!s.startsWith('[')) {
      // PC-relative label form:  LDR r0, mylabel
      const v = evalExpr(s, syms, ln, pc);
      return { pcrel: true, target: u32(v) };
    }
    const close = s.indexOf(']');
    if (close < 0) throw new AsmError('missing ]', ln);
    const inner = s.slice(1, close).trim();
    let after = s.slice(close + 1).trim();
    const parts = splitTop(inner);
    const rn = parseReg(parts[0], ln, alias);
    let index = 'offset', writeback = false;
    if (after.startsWith('!')) { index = 'pre'; writeback = true; after = after.slice(1).trim(); }
    let off = null;
    if (parts.length > 1) {
      off = parseOffset(parts.slice(1), syms, ln, pc, alias);
    }
    if (after.startsWith(',')) {
      if (off) throw new AsmError('cannot combine [Rn, off] with post-index', ln);
      index = 'post'; writeback = true;
      off = parseOffset(splitTop(after.slice(1)), syms, ln, pc, alias);
    } else if (after) {
      throw new AsmError('unexpected "' + after + '" after ]', ln);
    }
    return { rn, off: off || { type: 'imm', value: 0, sub: false }, index, writeback };
  }
  function parseOffset(toks, syms, ln, pc, alias) {
    let first = toks[0].trim(), sub = false;
    if (first.startsWith('#')) {
      const v = evalExpr(first.slice(1), syms, ln, pc);
      return { type: 'imm', value: Math.abs(v), sub: v < 0 };
    }
    if (first.startsWith('-')) { sub = true; first = first.slice(1).trim(); }
    else if (first.startsWith('+')) { first = first.slice(1).trim(); }
    const rm = parseReg(first, ln, alias);
    let shift = null;
    if (toks.length > 1) {
      const sm = /^(lsl|lsr|asr|ror|rrx)\s*(.*)$/i.exec(toks[1].trim());
      if (!sm) throw new AsmError('expected a shift in the memory operand', ln);
      const kind = sm[1].toLowerCase();
      if (kind === 'rrx') shift = { kind: 'rrx' };
      else {
        const a = sm[2].trim();
        if (!a.startsWith('#')) throw new AsmError('shift amount in a memory operand must be an immediate', ln);
        shift = { kind, imm: evalExpr(a.slice(1), syms, ln, pc) };
      }
    }
    return { type: 'reg', rm, sub, shift };
  }

  function parseRegList(str, ln, alias) {
    const s = str.trim();
    if (!s.startsWith('{') || !s.endsWith('}')) throw new AsmError('expected a register list in { }', ln);
    const inner = s.slice(1, -1);
    let mask = 0;
    for (const part of inner.split(',')) {
      const p = part.trim();
      if (!p) continue;
      const rm = /^(\w+)\s*-\s*(\w+)$/.exec(p);
      if (rm) {
        const a = parseReg(rm[1], ln, alias), b = parseReg(rm[2], ln, alias);
        if (b < a) throw new AsmError('register range must go low to high', ln);
        for (let k = a; k <= b; k++) mask |= (1 << k);
      } else {
        mask |= 1 << parseReg(p, ln, alias);
      }
    }
    if (!mask) throw new AsmError('empty register list', ln);
    return mask;
  }
  function parseVRegList(str, ln) {
    const s = str.trim();
    if (!s.startsWith('{') || !s.endsWith('}')) throw new AsmError('expected a register list in { }', ln);
    const regs = [];
    for (const part of s.slice(1, -1).split(',')) {
      const p = part.trim();
      if (!p) continue;
      const rm = /^([sdq])(\d+)\s*-\s*([sdq])(\d+)$/i.exec(p);
      if (rm) { for (let k = +rm[2]; k <= +rm[4]; k++) regs.push({ kind: rm[1].toLowerCase(), n: k }); }
      else regs.push(parseVReg(p, ln));
    }
    return regs;
  }

  const ALL_MNEM = []
    .concat(DP3, DP2, DPT, MEM_OPS, EXT_OPS, MUL_OPS, SHIFTS,
      ['b', 'bl', 'bx', 'blx', 'cbz', 'cbnz', 'nop', 'push', 'pop', 'svc', 'swi', 'mrs', 'msr', 'pld', 'pli', 'dmb', 'dsb', 'isb',
        'ldm', 'stm', 'ldmia', 'ldmib', 'ldmda', 'ldmdb', 'stmia', 'stmib', 'stmda', 'stmdb', 'ldmfd', 'stmfd', 'ldmea', 'stmea',
        'ldmfa', 'stmfa', 'ldmed', 'stmed',
        'movw', 'movt', 'sdiv', 'udiv', 'ubfx', 'sbfx', 'bfc', 'bfi', 'ssat', 'usat', 'adr', 'wfi', 'wfe', 'yield', 'sev',
        'cps', 'cpsid', 'cpsie', 'mrc', 'mcr', 'mrrc', 'mcrr', 'clrex', 'setend'])
    .sort((a, b) => b.length - a.length);
  const LDM_SUFFIX = /^(ia|ib|da|db|fd|fa|ed|ea)$/;

  function splitMnemonic(word, ln) {
    let w = word.toLowerCase();
    const ALL = ALL_MNEM;
    for (const base of ALL) {
      if (!w.startsWith(base)) continue;
      let rest = w.slice(base.length);
      let cond = 'al', setFlags = false;
      // order can be  <base><cond><S>  or  <base>S<cond>
      for (let pass = 0; pass < 2; pass++) {
        if (rest.length >= 2) {
          const c2 = rest.slice(0, 2);
          const cc = COND_ALIAS[c2] || (COND.indexOf(c2) >= 0 ? c2 : null);
          if (cc && cond === 'al') { cond = cc; rest = rest.slice(2); continue; }
        }
        if (rest[0] === 's' && !setFlags && (DP3.indexOf(base) >= 0 || DP2.indexOf(base) >= 0 || SHIFTS.indexOf(base) >= 0 || ['mul', 'mla', 'mls', 'umull', 'smull', 'umlal', 'smlal'].indexOf(base) >= 0)) {
          setFlags = true; rest = rest.slice(1); continue;
        }
        break;
      }
      if (rest === '') return { base, cond, setFlags };
      // LDMNEIA-style: condition before the addressing mode
      if ((base === 'ldm' || base === 'stm') && LDM_SUFFIX.test(rest)) return { base: base + rest, cond, setFlags };
    }
    return null;
  }

  function decodeLine(text, addr, syms, ln, alias, poolAlloc) {
    const m = /^(\S+)\s*(.*)$/.exec(text);
    const word = m[1];
    const argStr = (m[2] || '').trim();
    const pcVal = u32(addr + 8);       // ARM: reading PC gives current + 8

    if (/^v/i.test(word)) return decodeVector(word, argStr, syms, ln, alias, pcVal);
    // Thumb-2 IT blocks: accepted and ignored. In this emulator every instruction can
    // carry its own condition, which is exactly what the IT block expresses.
    if (/^it[et]{0,3}$/i.test(word)) return { op: 'nop', cond: 'al', cycles: 0, hint: 'it' };

    const sp = splitMnemonic(word, ln);
    if (!sp) throw new AsmError('unknown instruction "' + word + '"', ln);
    const { base, cond, setFlags } = sp;
    const a = splitTop(argStr);

    const need = (n, what) => { if (a.length < n) throw new AsmError(base.toUpperCase() + ' needs ' + what, ln); };

    if (base === 'nop' || base === 'wfi' || base === 'wfe' || base === 'yield' || base === 'sev' ||
      base === 'dmb' || base === 'dsb' || base === 'isb' || base === 'pld' || base === 'pli') {
      return { op: 'nop', cond, cycles: 1, hint: base };
    }
    if (base === 'b' || base === 'bl') {
      need(1, 'a label');
      const t = evalExpr(a[0], syms, ln, pcVal);
      const delta = s32(u32(t) - pcVal);
      if (delta < -33554432 || delta > 33554428)
        throw new AsmError('branch target is ' + delta + ' bytes away; B/BL reach +/-32 MB', ln);
      return { op: base, cond, target: u32(t), cycles: 3 };
    }
    if (base === 'bx' || base === 'blx') {
      need(1, 'a register');
      if (/^[a-zA-Z_.$]/.test(a[0]) && !/^(r\d|sp|lr|pc|ip|fp|sl|sb)$/i.test(a[0].trim())) {
        const t = evalExpr(a[0], syms, ln, pcVal);
        return { op: base === 'bx' ? 'b' : 'bl', cond, target: u32(t), cycles: 3 };
      }
      return { op: base, cond, rm: parseReg(a[0], ln, alias), cycles: 3 };
    }
    if (base === 'cbz' || base === 'cbnz') {
      need(2, 'a register and a label');
      const t = evalExpr(a[1], syms, ln, pcVal);
      const delta = s32(u32(t) - u32(addr + 4));
      if (delta < 0 || delta > 126)
        throw new AsmError('CBZ/CBNZ can only jump FORWARD 0..126 bytes (this is ' + delta + '). It is a Thumb-only instruction.', ln);
      return { op: base, cond: 'al', rn: parseReg(a[0], ln, alias), target: u32(t), cycles: 2, thumbOnly: true };
    }
    if (base === 'adr') {
      need(2, 'a register and a label');
      const t = evalExpr(a[1], syms, ln, pcVal);
      return { op: 'mov', cond, setFlags: false, rd: parseReg(a[0], ln, alias), op2: { type: 'imm', value: u32(t) }, cycles: 1, pseudo: 'adr' };
    }
    if (base === 'svc' || base === 'swi') {
      const v = a.length ? evalExpr(a[0].replace(/^#/, ''), syms, ln, pcVal) : 0;
      return { op: 'svc', cond, imm: u32(v), cycles: 1 };
    }
    if (base === 'push' || base === 'pop') {
      need(1, 'a register list');
      return { op: base === 'push' ? 'stm' : 'ldm', cond, rn: 13, writeback: true,
        mode: base === 'push' ? 'db' : 'ia', mask: parseRegList(a[0], ln, alias), cycles: 2, pseudo: base };
    }
    if (/^(ldm|stm)/.test(base)) {
      need(2, 'a base register and a register list');
      let mode = base.slice(3) || 'ia';
      const isLoad = base.startsWith('ldm');
      const stackAlias = { fd: isLoad ? 'ia' : 'db', ea: isLoad ? 'db' : 'ia', fa: isLoad ? 'da' : 'ib', ed: isLoad ? 'ib' : 'da' };
      if (stackAlias[mode]) mode = stackAlias[mode];
      if (!mode) mode = 'ia';
      let rnTok = a[0].trim(), wb = false;
      if (rnTok.endsWith('!')) { wb = true; rnTok = rnTok.slice(0, -1); }
      return { op: isLoad ? 'ldm' : 'stm', cond, rn: parseReg(rnTok, ln, alias), writeback: wb, mode, mask: parseRegList(a[1], ln, alias), cycles: 2 };
    }
    if (MEM_OPS.indexOf(base) >= 0) {
      need(2, 'a register and an address');
      const rd = parseReg(a[0], ln, alias);
      let rest = a.slice(1).join(', ');
      let rd2 = null;
      if (base === 'ldrd' || base === 'strd') {
        if (/^\[/.test(a[1].trim())) { rd2 = rd + 1; }
        else { rd2 = parseReg(a[1], ln, alias); rest = a.slice(2).join(', '); }
        if (rd % 2 !== 0) throw new AsmError('LDRD/STRD needs an EVEN first register (r0, r2, r4 ...)', ln);
      }
      // LDR rX, =value
      const eq = /^=\s*(.+)$/.exec(rest.trim());
      if (eq) {
        if (base !== 'ldr') throw new AsmError('only LDR supports the =value form', ln);
        const v = evalExpr(eq[1], syms, ln, pcVal);
        const enc = encodeModifiedImm(v);
        if (enc) return { op: 'mov', cond, setFlags: false, rd, op2: { type: 'imm', value: u32(v) }, cycles: 1, pseudo: 'ldr=' };
        const pa = poolAlloc(v);
        return { op: 'load', cond, rd, mem: { pcrel: true, target: pa }, size: 4, signed: false, cycles: 3, pseudo: 'ldr=', mnem: 'ldr' };
      }
      const mem = parseMem(rest, syms, ln, pcVal, alias);
      const sizeOf = { ldr: 4, str: 4, ldrb: 1, strb: 1, ldrh: 2, strh: 2, ldrsb: 1, ldrsh: 2, ldrd: 8, strd: 8 };
      return {
        op: base.startsWith('ldr') ? 'load' : 'store',
        cond, rd, rd2, mem, size: sizeOf[base], signed: /^ldrs/.test(base),
        cycles: base.startsWith('ldr') ? 3 : 1, mnem: base
      };
    }
    if (base === 'movw' || base === 'movt') {
      need(2, 'a register and a 16-bit immediate');
      const v = evalExpr(a[1].replace(/^#/, ''), syms, ln, pcVal);
      if (v < 0 || v > 0xffff) throw new AsmError(base.toUpperCase() + ' takes a 16-bit value (0..65535)', ln);
      return { op: base, cond, rd: parseReg(a[0], ln, alias), imm: v, cycles: 1 };
    }
    if (base === 'sdiv' || base === 'udiv') {
      need(3, 'three registers');
      return { op: base, cond, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias), rm: parseReg(a[2], ln, alias), cycles: 12 };
    }
    if (EXT_OPS.indexOf(base) >= 0) {
      need(2, 'two registers');
      let rot = 0;
      if (a.length > 2) { const rm2 = /^ror\s*#?(\d+)$/i.exec(a[2].trim()); if (rm2) rot = +rm2[1]; }
      return { op: base, cond, rd: parseReg(a[0], ln, alias), rm: parseReg(a[1], ln, alias), rot, cycles: 1 };
    }
    if (base === 'ssat' || base === 'usat') {
      need(3, 'rd, #bits, rm');
      const bits = evalExpr(a[1].replace(/^#/, ''), syms, ln, pcVal);
      let shift = null;
      if (a.length > 3) {
        const sm = /^(lsl|asr)\s*#?(\d+)$/i.exec(a[3].trim());
        if (sm) shift = { kind: sm[1].toLowerCase(), imm: +sm[2] };
      }
      return { op: base, cond, rd: parseReg(a[0], ln, alias), rm: parseReg(a[2], ln, alias), bits, shift, cycles: 1 };
    }
    if (base === 'bfi') {
      need(4, 'rd, rn, #lsb, #width');
      return { op: 'bfi', cond, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias),
        lsb: evalExpr(a[2].replace(/^#/, ''), syms, ln, pcVal), width: evalExpr(a[3].replace(/^#/, ''), syms, ln, pcVal), cycles: 1 };
    }
    if (base === 'bfc') {
      need(3, 'rd, #lsb, #width');
      return { op: 'bfc', cond, rd: parseReg(a[0], ln, alias),
        lsb: evalExpr(a[1].replace(/^#/, ''), syms, ln, pcVal), width: evalExpr(a[2].replace(/^#/, ''), syms, ln, pcVal), cycles: 1 };
    }
    if (base === 'ubfx' || base === 'sbfx') {
      need(4, 'rd, rn, #lsb, #width');
      return { op: base, cond, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias),
        lsb: evalExpr(a[2].replace(/^#/, ''), syms, ln, pcVal), width: evalExpr(a[3].replace(/^#/, ''), syms, ln, pcVal), cycles: 1 };
    }
    if (MUL_OPS.indexOf(base) >= 0) {
      if (base === 'mul') { need(3, 'rd, rn, rm'); return { op: 'mul', cond, setFlags, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias), rm: parseReg(a[2], ln, alias), cycles: 3 }; }
      if (base === 'mla' || base === 'mls') { need(4, 'rd, rn, rm, ra'); return { op: base, cond, setFlags, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias), rm: parseReg(a[2], ln, alias), ra: parseReg(a[3], ln, alias), cycles: 3 }; }
      if (base === 'smulbb') { need(3, 'rd, rn, rm'); return { op: 'smulbb', cond, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias), rm: parseReg(a[2], ln, alias), cycles: 2 }; }
      if (base === 'smlabb') { need(4, 'rd, rn, rm, ra'); return { op: 'smlabb', cond, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias), rm: parseReg(a[2], ln, alias), ra: parseReg(a[3], ln, alias), cycles: 2 }; }
      need(4, 'rdlo, rdhi, rn, rm');
      return { op: base, cond, setFlags, rdlo: parseReg(a[0], ln, alias), rdhi: parseReg(a[1], ln, alias), rn: parseReg(a[2], ln, alias), rm: parseReg(a[3], ln, alias), cycles: 4 };
    }
    if (DPT.indexOf(base) >= 0) {
      need(2, 'a register and an operand');
      return { op: base, cond, setFlags: true, rn: parseReg(a[0], ln, alias), op2: parseOperand2(a.slice(1), syms, ln, pcVal, alias), cycles: 1 };
    }
    if (DP2.indexOf(base) >= 0) {
      need(2, 'a destination register and an operand');
      return { op: base, cond, setFlags, rd: parseReg(a[0], ln, alias), op2: parseOperand2(a.slice(1), syms, ln, pcVal, alias), cycles: 1 };
    }
    if (DP3.indexOf(base) >= 0) {
      if (a.length === 2) a.splice(1, 0, a[0]);   // ADD r0, #1  ==  ADD r0, r0, #1
      need(3, 'rd, rn and an operand');
      return { op: base, cond, setFlags, rd: parseReg(a[0], ln, alias), rn: parseReg(a[1], ln, alias), op2: parseOperand2(a.slice(2), syms, ln, pcVal, alias), cycles: 1 };
    }
    if (SHIFTS.indexOf(base) >= 0) {
      need(2, 'rd and a source');
      return { op: 'mov', cond, setFlags, rd: parseReg(a[0], ln, alias),
        op2: parseOperand2([a[1], base + ' ' + (a[2] || '')], syms, ln, pcVal, alias), cycles: 1 };
    }
    if (base === 'mrs' || base === 'msr') return { op: 'nop', cond, cycles: 1 };
    // CPSID i / CPSIE if / SETEND / CLREX: state changes the emulator has no state for.
    if (base === 'cps' || base === 'cpsid' || base === 'cpsie' || base === 'setend' || base === 'clrex')
      return { op: 'nop', cond, cycles: 1, hint: base };
    // Coprocessor moves. MRC/MRRC read; on this machine CP15 c9/c14 give the cycle counter.
    if (base === 'mrc' || base === 'mrrc') {
      const dst = [];
      for (let i = 2; i < a.length && dst.length < (base === 'mrrc' ? 2 : 1); i++) {
        if (/^c\d+$/i.test(a[i].trim())) break;
        dst.push(parseReg(a[i], ln, alias));
      }
      if (!dst.length) throw new AsmError('MRC/MRRC needs a destination register', ln);
      return { op: 'cpread', cond, rd: dst[0], rd2: dst.length > 1 ? dst[1] : -1, cycles: 2 };
    }
    if (base === 'mcr' || base === 'mcrr') return { op: 'nop', cond, cycles: 2, hint: base };
    throw new AsmError('unknown instruction "' + word + '"', ln);
  }

  /* ------------------------------- VFP / NEON -------------------------- */
  const V_BASES = ['vldr', 'vstr', 'vld1', 'vst1', 'vld1r', 'vmov', 'vdup', 'vcvt', 'vcmpe', 'vcmp', 'vmrs',
    'vsqrt', 'vneg', 'vabs', 'vpush', 'vpop', 'vdiv'].concat(NEON_BIN).sort((a, b) => b.length - a.length);

  function decodeVector(word, argStr, syms, ln, alias, pcVal) {
    let w = word.toLowerCase(), dt = '';
    const dot = w.indexOf('.');
    if (dot >= 0) { dt = w.slice(dot + 1); w = w.slice(0, dot); }
    let base = null, cond = 'al';
    for (const b of V_BASES) {
      if (!w.startsWith(b)) continue;
      const rest = w.slice(b.length);
      if (rest === '') { base = b; break; }
      const cc = COND_ALIAS[rest] || (COND.indexOf(rest) >= 0 ? rest : null);
      if (cc) { base = b; cond = cc; break; }
    }
    if (!base) throw new AsmError('unsupported vector instruction "' + word + '"', ln);
    const a = splitTop(argStr);

    if (base === 'vldr' || base === 'vstr') {
      const vd = parseVReg(a[0], ln);
      const mem = parseMem(a.slice(1).join(', '), syms, ln, pcVal, alias);
      return { op: base, cond, vd, mem, cycles: 3 };
    }
    if (base === 'vld1' || base === 'vst1' || base === 'vld1r') {
      const regs = parseVRegList(a[0], ln);
      const mem = parseMem(a.slice(1).join(', '), syms, ln, pcVal, alias);
      return { op: base === 'vst1' ? 'vst1' : 'vld1', cond, regs, mem, dt: dt || '8', cycles: 2 };
    }
    if (base === 'vmov') {
      // vmov sX, rY | vmov rY, sX | vmov sX, sY | vmov.f32 sX, #imm | vmov.i32 qX, #imm | vmov dX, rA, rB
      const isVec = (t) => /^[sdq]\d+$/i.test(t.trim());
      if (a.length === 3 && isVec(a[0]) && !isVec(a[1])) return { op: 'vmov_d_rr', cond, vd: parseVReg(a[0], ln), rn: parseReg(a[1], ln, alias), rm: parseReg(a[2], ln, alias), cycles: 2 };
      if (a.length === 3 && !isVec(a[0]) && isVec(a[2])) return { op: 'vmov_rr_d', cond, rd: parseReg(a[0], ln, alias), rd2: parseReg(a[1], ln, alias), vm: parseVReg(a[2], ln), cycles: 2 };
      if (a[1].trim().startsWith('#')) {
        const v = a[1].trim().slice(1);
        const isF = /f/.test(dt);
        return { op: 'vmov_imm', cond, vd: parseVReg(a[0], ln), dt: dt || 'i32', imm: isF ? parseFloat(v) : evalExpr(v, syms, ln, pcVal), cycles: 1 };
      }
      if (isVec(a[0]) && isVec(a[1])) return { op: 'vmov_vv', cond, vd: parseVReg(a[0], ln), vm: parseVReg(a[1], ln), cycles: 1 };
      if (isVec(a[0])) return { op: 'vmov_s_r', cond, vd: parseVReg(a[0], ln), rm: parseReg(a[1], ln, alias), cycles: 1 };
      return { op: 'vmov_r_s', cond, rd: parseReg(a[0], ln, alias), vm: parseVReg(a[1], ln), cycles: 1 };
    }
    if (base === 'vdup') return { op: 'vdup', cond, vd: parseVReg(a[0], ln), rm: parseReg(a[1], ln, alias), dt: dt || '32', cycles: 1 };
    if (base === 'vcvt') {
      return { op: 'vcvt', cond, vd: parseVReg(a[0], ln), vm: parseVReg(a[1], ln), dt, cycles: 2 };
    }
    if (base === 'vcmp' || base === 'vcmpe') {
      return { op: 'vcmp', cond, vd: parseVReg(a[0], ln), vm: a[1].trim().startsWith('#') ? null : parseVReg(a[1], ln), cycles: 2 };
    }
    if (base === 'vmrs') return { op: 'vmrs', cond, cycles: 2 };
    if (base === 'vsqrt' || base === 'vneg' || base === 'vabs') {
      return { op: base, cond, dt: dt || 'f32', vd: parseVReg(a[0], ln), vm: parseVReg(a[1], ln), cycles: 4 };
    }
    if (base === 'vpush' || base === 'vpop') return { op: 'nop', cond, cycles: 2 };
    if (NEON_BIN.indexOf(base) >= 0 || base === 'vdiv') {
      if (a.length === 2) a.splice(1, 0, a[0]);
      return { op: base, cond, dt: dt || 'i32', vd: parseVReg(a[0], ln), vn: parseVReg(a[1], ln),
        vm: a[2].trim().startsWith('#') ? { imm: evalExpr(a[2].trim().slice(1), syms, ln, pcVal) } : parseVReg(a[2], ln),
        cycles: base === 'vdiv' ? 14 : 2 };
    }
    throw new AsmError('unsupported vector instruction "' + word + '"', ln);
  }

  /* =========================================================================
   *  CPU
   * ====================================================================== */
  class CPU {
    constructor() {
      this.mem = new Uint8Array(MAP.STACK_BASE + MAP.STACK_SIZE);
      this.fb = new Uint8Array(MAP.FB_SIZE);
      this.tpage = new Uint8Array(MAP.TPAGE_SIZE);
      this.vbytes = new Uint8Array(256);          // s0-s31 / d0-d31 / q0-q15
      this.vdv = new DataView(this.vbytes.buffer);
      this.reset();
    }
    reset() {
      this.r = new Int32Array(16);
      this.r[13] = MAP.SP_INIT | 0;
      this.r[14] = 0;
      this.N = this.Z = this.C = this.V = false;
      this.cycles = 0;
      this.insnCount = 0;
      this.halted = false;
      this.error = null;
      this.console = '';
      this.gpioToggles = [];
      this.rngState = 0x2a6d365b;
      this.mem.fill(0);
      this.fb.fill(0);
      this.tpage.fill(0x20);
      this.vbytes.fill(0);
      this.memWrites = 0; this.memReads = 0; this.branches = 0; this.taken = 0;
      this.trace = [];
      this.traceLimit = 0;
    }
    load(asm) {
      this.reset();
      this.code = asm.code;
      this.syms = asm.syms;
      for (const blk of asm.image) {
        for (let k = 0; k < blk.bytes.length; k++) this.write8(u32(blk.addr + k), blk.bytes[k], true);
      }
      this.r[15] = asm.entry | 0;
      this.pc = u32(asm.entry);
      this.entry = u32(asm.entry);
    }
    /* ------------------------------------------------------ memory access */
    inRam(a) { return a < this.mem.length; }
    read8(a) {
      a = u32(a);
      if (a < this.mem.length) return this.mem[a];
      if (a >= MAP.FB && a < MAP.FB + MAP.FB_SIZE) return this.fb[a - MAP.FB];
      if (a >= MAP.TPAGE && a < MAP.TPAGE + MAP.TPAGE_SIZE) return this.tpage[a - MAP.TPAGE];
      if (a >= MAP.MMIO && a < MAP.MMIO + 0x100) return this.mmioRead(a) & 0xff;
      this.fault('read from unmapped address 0x' + a.toString(16));
      return 0;
    }
    write8(a, v, quiet) {
      a = u32(a); v &= 0xff;
      if (a < this.mem.length) { this.mem[a] = v; return; }
      if (a >= MAP.FB && a < MAP.FB + MAP.FB_SIZE) { this.fb[a - MAP.FB] = v; this.dirtyFB = true; return; }
      if (a >= MAP.TPAGE && a < MAP.TPAGE + MAP.TPAGE_SIZE) { this.tpage[a - MAP.TPAGE] = v; this.dirtyText = true; return; }
      if (a >= MAP.MMIO && a < MAP.MMIO + 0x100) { this.mmioWrite(a, v); return; }
      if (!quiet) this.fault('write to unmapped address 0x' + a.toString(16));
    }
    mmioRead(a) {
      switch (u32(a & ~3)) {
        case MAP.GPIO: this.gpioToggles.push(this.cycles); return 0;
        case MAP.CYCLES: return this.cycles >>> 0;
        case MAP.KEY: return this.key || 0;
        case MAP.RANDOM: {
          let x = this.rngState; x ^= x << 13; x ^= x >>> 17; x ^= x << 5; this.rngState = x | 0;
          return x >>> 0;
        }
        default: return 0;
      }
    }
    mmioWrite(a, v) {
      switch (u32(a & ~3)) {
        case MAP.GPIO: this.gpioToggles.push(this.cycles); break;
        case MAP.UART: this.console += String.fromCharCode(v & 0x7f); break;
        case MAP.HALT: this.halted = true; break;
        case MAP.KEY: this.key = 0; break;
      }
    }
    read32(a) {
      a = u32(a);
      if (a & 3) { this.fault('unaligned 32-bit access at 0x' + a.toString(16) + ' (LDR needs a 4-byte-aligned address)'); return 0; }
      this.memReads++;
      if (a + 3 < this.mem.length) {
        return u32(this.mem[a] | (this.mem[a + 1] << 8) | (this.mem[a + 2] << 16) | (this.mem[a + 3] << 24));
      }
      if (a >= MAP.MMIO && a < MAP.MMIO + 0x100) return u32(this.mmioRead(a));
      return u32(this.read8(a) | (this.read8(a + 1) << 8) | (this.read8(a + 2) << 16) | (this.read8(a + 3) << 24));
    }
    write32(a, v) {
      a = u32(a);
      if (a & 3) { this.fault('unaligned 32-bit access at 0x' + a.toString(16) + ' (STR needs a 4-byte-aligned address)'); return; }
      this.memWrites++;
      if (a + 3 < this.mem.length) {
        this.mem[a] = v & 0xff; this.mem[a + 1] = (v >>> 8) & 0xff; this.mem[a + 2] = (v >>> 16) & 0xff; this.mem[a + 3] = (v >>> 24) & 0xff;
        return;
      }
      if (a >= MAP.MMIO && a < MAP.MMIO + 0x100) { this.mmioWrite(a, v); return; }
      this.write8(a, v); this.write8(a + 1, v >>> 8); this.write8(a + 2, v >>> 16); this.write8(a + 3, v >>> 24);
    }
    read16(a) { if (a & 1) { this.fault('unaligned 16-bit access at 0x' + u32(a).toString(16)); return 0; } this.memReads++; return u32(this.read8(a) | (this.read8(a + 1) << 8)); }
    write16(a, v) { if (a & 1) { this.fault('unaligned 16-bit access at 0x' + u32(a).toString(16)); return; } this.memWrites++; this.write8(a, v); this.write8(a + 1, v >>> 8); }

    fault(msg) { this.error = msg; this.halted = true; }

    /* ------------------------------------------------------------- helpers */
    getReg(n) { return n === 15 ? u32(this.pc + 8) : u32(this.r[n]); }
    setReg(n, v) { if (n === 15) { this.pc = u32(v); this.branched = true; } else this.r[n] = v | 0; }

    condTrue(c) {
      switch (c) {
        case 'al': return true;
        case 'eq': return this.Z; case 'ne': return !this.Z;
        case 'cs': return this.C; case 'cc': return !this.C;
        case 'mi': return this.N; case 'pl': return !this.N;
        case 'vs': return this.V; case 'vc': return !this.V;
        case 'hi': return this.C && !this.Z; case 'ls': return !this.C || this.Z;
        case 'ge': return this.N === this.V; case 'lt': return this.N !== this.V;
        case 'gt': return !this.Z && (this.N === this.V); case 'le': return this.Z || (this.N !== this.V);
        default: return true;
      }
    }
    shiftOp2(op2) {
      if (op2.type === 'imm') {
        // an immediate with a non-zero rotation also produces a carry-out
        const c = (op2.enc && op2.enc.rot !== 0) ? ((op2.value >>> 31) & 1) === 1 : this.C;
        return { value: u32(op2.value), carry: c };
      }
      let v = this.getReg(op2.rm);
      if (!op2.shift) return { value: v, carry: this.C };
      const k = op2.shift.kind;
      let n = op2.shift.rs !== undefined ? (this.getReg(op2.shift.rs) & 0xff) : op2.shift.imm;
      if (k === 'rrx') {
        const c = v & 1;
        return { value: u32((v >>> 1) | (this.C ? 0x80000000 : 0)), carry: c === 1 };
      }
      if (n === 0) return { value: v, carry: this.C };
      switch (k) {
        case 'lsl':
          if (n >= 32) return { value: 0, carry: n === 32 ? (v & 1) === 1 : false };
          return { value: u32(v << n), carry: ((v >>> (32 - n)) & 1) === 1 };
        case 'lsr':
          if (n >= 32) return { value: 0, carry: n === 32 ? ((v >>> 31) & 1) === 1 : false };
          return { value: u32(v >>> n), carry: ((v >>> (n - 1)) & 1) === 1 };
        case 'asr':
          if (n >= 32) { const s = (v >>> 31) & 1; return { value: s ? 0xffffffff : 0, carry: s === 1 }; }
          return { value: u32(s32(v) >> n), carry: ((v >>> (n - 1)) & 1) === 1 };
        case 'ror': {
          const m = n & 31;
          if (m === 0) return { value: v, carry: ((v >>> 31) & 1) === 1 };
          return { value: u32((v >>> m) | (v << (32 - m))), carry: ((v >>> (m - 1)) & 1) === 1 };
        }
      }
      return { value: v, carry: this.C };
    }
    setNZ(res) { this.N = ((res >>> 31) & 1) === 1; this.Z = u32(res) === 0; }
    addWithCarry(a, b, cin) {
      const ua = u32(a), ub = u32(b), c = cin ? 1 : 0;
      const usum = ua + ub + c;
      const res = u32(usum);
      const sa = s32(a), sb = s32(b);
      const ssum = sa + sb + c;
      return { res, carry: usum > 0xffffffff, overflow: ssum !== s32(res) };
    }

    /* --------------------------------------------------------------- step */
    step() {
      if (this.halted) return false;
      const ir = this.code.get(u32(this.pc));
      if (!ir) {
        this.fault('no instruction at 0x' + u32(this.pc).toString(16) + ' — did the loop fall off the end of the code? (add a halt)');
        return false;
      }
      this.branched = false;
      this.lastIR = ir;
      this.r[15] = this.pc | 0;
      const exec = this.condTrue(ir.cond);
      this.insnCount++;
      if (ir.cond !== 'al') { this.branches += 0; }
      if (!exec) {
        this.cycles += 1;                       // a failed condition still costs a slot
        this.pc = u32(this.pc + 4);
        this.skipped = true;
        return true;
      }
      this.skipped = false;
      this.cycles += ir.cycles || 1;
      try { this.exec(ir); } catch (e) { this.fault(e.message); return false; }
      if (!this.branched) this.pc = u32(this.pc + 4);
      if (this.traceLimit && this.trace.length < this.traceLimit) this.trace.push({ pc: ir.addr, ln: ir.ln });
      return !this.halted;
    }

    exec(ir) {
      const R = (n) => this.getReg(n);
      switch (ir.op) {
        case 'nop': break;
        case 'cpread':
          this.setReg(ir.rd, this.cycles >>> 0);
          if (ir.rd2 >= 0) this.setReg(ir.rd2, 0);
          break;
        case 'b': this.branches++; this.taken++; this.pc = ir.target; this.branched = true; break;
        case 'bl': this.branches++; this.taken++; this.r[14] = u32(this.pc + 4) | 0; this.pc = ir.target; this.branched = true; break;
        case 'bx': case 'blx': {
          if (ir.op === 'blx') this.r[14] = u32(this.pc + 4) | 0;
          const t = R(ir.rm);
          if (ir.rm === 14 && u32(t) === 0) { this.halted = true; break; }
          this.pc = u32(t & ~1); this.branched = true; this.branches++; this.taken++;
          break;
        }
        case 'cbz': case 'cbnz': {
          const z = R(ir.rn) === 0;
          this.branches++;
          if ((ir.op === 'cbz') === z) { this.pc = ir.target; this.branched = true; this.taken++; }
          break;
        }
        case 'svc': {
          if (ir.imm === 1) { this.console += String.fromCharCode(R(0) & 0x7f); }
          else this.halted = true;
          break;
        }
        case 'mov': case 'mvn': {
          const o = this.shiftOp2(ir.op2);
          let v = ir.op === 'mvn' ? u32(~o.value) : o.value;
          this.setReg(ir.rd, v);
          if (ir.setFlags) { this.setNZ(v); this.C = o.carry; }
          break;
        }
        case 'and': case 'orr': case 'eor': case 'bic': {
          const o = this.shiftOp2(ir.op2);
          const a = R(ir.rn), b = o.value;
          let v = ir.op === 'and' ? (a & b) : ir.op === 'orr' ? (a | b) : ir.op === 'eor' ? (a ^ b) : (a & ~b);
          v = u32(v);
          this.setReg(ir.rd, v);
          if (ir.setFlags) { this.setNZ(v); this.C = o.carry; }
          break;
        }
        case 'add': case 'adc': case 'sub': case 'sbc': case 'rsb': case 'rsc': {
          const o = this.shiftOp2(ir.op2);
          const a = R(ir.rn), b = o.value;
          let r;
          if (ir.op === 'add') r = this.addWithCarry(a, b, false);
          else if (ir.op === 'adc') r = this.addWithCarry(a, b, this.C);
          else if (ir.op === 'sub') r = this.addWithCarry(a, u32(~b), true);
          else if (ir.op === 'sbc') r = this.addWithCarry(a, u32(~b), this.C);
          else if (ir.op === 'rsb') r = this.addWithCarry(b, u32(~a), true);
          else r = this.addWithCarry(b, u32(~a), this.C);
          this.setReg(ir.rd, r.res);
          if (ir.setFlags) { this.setNZ(r.res); this.C = r.carry; this.V = r.overflow; }
          break;
        }
        case 'cmp': case 'cmn': case 'tst': case 'teq': {
          const o = this.shiftOp2(ir.op2);
          const a = R(ir.rn), b = o.value;
          if (ir.op === 'cmp') { const r = this.addWithCarry(a, u32(~b), true); this.setNZ(r.res); this.C = r.carry; this.V = r.overflow; }
          else if (ir.op === 'cmn') { const r = this.addWithCarry(a, b, false); this.setNZ(r.res); this.C = r.carry; this.V = r.overflow; }
          else if (ir.op === 'tst') { const v = u32(a & b); this.setNZ(v); this.C = o.carry; }
          else { const v = u32(a ^ b); this.setNZ(v); this.C = o.carry; }
          break;
        }
        case 'mul': { const v = u32(Math.imul(R(ir.rn), R(ir.rm))); this.setReg(ir.rd, v); if (ir.setFlags) this.setNZ(v); break; }
        case 'mla': { const v = u32(Math.imul(R(ir.rn), R(ir.rm)) + s32(R(ir.ra))); this.setReg(ir.rd, v); if (ir.setFlags) this.setNZ(v); break; }
        case 'mls': { const v = u32(s32(R(ir.ra)) - Math.imul(R(ir.rn), R(ir.rm))); this.setReg(ir.rd, v); break; }
        case 'smulbb': { const v = u32(Math.imul((R(ir.rn) << 16) >> 16, (R(ir.rm) << 16) >> 16)); this.setReg(ir.rd, v); break; }
        case 'smlabb': { const v = u32(Math.imul((R(ir.rn) << 16) >> 16, (R(ir.rm) << 16) >> 16) + s32(R(ir.ra))); this.setReg(ir.rd, v); break; }
        case 'umull': case 'umlal': case 'smull': case 'smlal': {
          const signed = ir.op[0] === 's';
          let a = BigInt(signed ? s32(R(ir.rn)) : u32(R(ir.rn)));
          let b = BigInt(signed ? s32(R(ir.rm)) : u32(R(ir.rm)));
          let p = a * b;
          if (ir.op === 'umlal' || ir.op === 'smlal') {
            const lo = BigInt(u32(R(ir.rdlo))), hi = BigInt(signed ? s32(R(ir.rdhi)) : u32(R(ir.rdhi)));
            p += (hi << 32n) + lo;
          }
          const mask = (1n << 64n) - 1n;
          const pm = p & mask;
          this.setReg(ir.rdlo, Number(pm & 0xffffffffn) >>> 0);
          this.setReg(ir.rdhi, Number((pm >> 32n) & 0xffffffffn) >>> 0);
          if (ir.setFlags) { this.Z = pm === 0n; this.N = ((pm >> 63n) & 1n) === 1n; }
          break;
        }
        case 'sdiv': { const d = s32(R(ir.rm)); this.setReg(ir.rd, d === 0 ? 0 : u32((s32(R(ir.rn)) / d) | 0)); break; }
        case 'udiv': { const d = u32(R(ir.rm)); this.setReg(ir.rd, d === 0 ? 0 : u32(Math.floor(u32(R(ir.rn)) / d))); break; }
        case 'clz': { const v = u32(R(ir.rm)); this.setReg(ir.rd, v === 0 ? 32 : Math.clz32(v)); break; }
        case 'rbit': { let v = u32(R(ir.rm)), o = 0; for (let k = 0; k < 32; k++) { o = (o << 1) | (v & 1); v >>>= 1; } this.setReg(ir.rd, u32(o)); break; }
        case 'rev': { const v = u32(R(ir.rm)); this.setReg(ir.rd, u32(((v & 0xff) << 24) | ((v & 0xff00) << 8) | ((v >>> 8) & 0xff00) | (v >>> 24))); break; }
        case 'rev16': { const v = u32(R(ir.rm)); this.setReg(ir.rd, u32(((v & 0xff) << 8) | ((v >>> 8) & 0xff) | ((v & 0xff0000) << 8) | ((v >>> 8) & 0xff0000))); break; }
        case 'uxtb': { this.setReg(ir.rd, u32(rorN(R(ir.rm), ir.rot) & 0xff)); break; }
        case 'sxtb': { this.setReg(ir.rd, u32((rorN(R(ir.rm), ir.rot) << 24) >> 24)); break; }
        case 'uxth': { this.setReg(ir.rd, u32(rorN(R(ir.rm), ir.rot) & 0xffff)); break; }
        case 'sxth': { this.setReg(ir.rd, u32((rorN(R(ir.rm), ir.rot) << 16) >> 16)); break; }
        case 'ubfx': { this.setReg(ir.rd, u32((R(ir.rn) >>> ir.lsb) & ((ir.width >= 32) ? 0xffffffff : ((1 << ir.width) - 1)))); break; }
        case 'sbfx': { const sh = 32 - ir.width; this.setReg(ir.rd, u32(((R(ir.rn) >>> ir.lsb) << sh) >> sh)); break; }
        case 'ssat': {
          let v = s32(R(ir.rm));
          if (ir.shift) v = ir.shift.kind === 'lsl' ? (v << ir.shift.imm) : (v >> ir.shift.imm);
          const lim = Math.pow(2, ir.bits - 1);
          if (v > lim - 1) v = lim - 1; else if (v < -lim) v = -lim;
          this.setReg(ir.rd, u32(v));
          break;
        }
        case 'usat': {
          let v = s32(R(ir.rm));
          if (ir.shift) v = ir.shift.kind === 'lsl' ? (v << ir.shift.imm) : (v >> ir.shift.imm);
          const lim = Math.pow(2, ir.bits) - 1;
          if (v > lim) v = lim; else if (v < 0) v = 0;
          this.setReg(ir.rd, u32(v));
          break;
        }
        case 'bfi': {
          const mask = ir.width >= 32 ? 0xffffffff : u32(((1 << ir.width) - 1) << ir.lsb);
          const src = u32((R(ir.rn) << ir.lsb)) & mask;
          this.setReg(ir.rd, u32((R(ir.rd) & ~mask) | src));
          break;
        }
        case 'bfc': {
          const mask = ir.width >= 32 ? 0xffffffff : u32(((1 << ir.width) - 1) << ir.lsb);
          this.setReg(ir.rd, u32(R(ir.rd) & ~mask));
          break;
        }
        case 'movw': this.setReg(ir.rd, u32(ir.imm)); break;
        case 'movt': this.setReg(ir.rd, u32((R(ir.rd) & 0xffff) | (ir.imm << 16))); break;
        case 'load': case 'store': this.execMem(ir); break;
        case 'ldm': case 'stm': this.execBlock(ir); break;
        default:
          if (ir.op.startsWith('v')) { this.execVector(ir); break; }
          throw new Error('unimplemented instruction: ' + ir.op);
      }
    }

    memAddress(ir) {
      const m = ir.mem;
      if (m.pcrel) return { addr: m.target, wbAddr: null };
      let base = this.getReg(m.rn);
      let off = 0;
      if (m.off.type === 'imm') off = m.off.value;
      else {
        const o = this.shiftOp2({ type: 'reg', rm: m.off.rm, shift: m.off.shift });
        off = o.value;
      }
      if (m.off.sub) off = u32(-off);
      const applied = u32(base + off);
      if (m.index === 'post') return { addr: base, wb: m.writeback ? applied : null };
      return { addr: applied, wb: m.writeback ? applied : null };
    }

    execMem(ir) {
      const { addr, wb } = this.memAddress(ir);
      if (ir.op === 'load') {
        let v;
        if (ir.size === 4) v = this.read32(addr);
        else if (ir.size === 2) { v = this.read16(addr); if (ir.signed) v = u32((v << 16) >> 16); }
        else if (ir.size === 1) { v = this.read8(addr); this.memReads++; if (ir.signed) v = u32((v << 24) >> 24); }
        else { // ldrd
          this.setReg(ir.rd, this.read32(addr)); this.setReg(ir.rd2, this.read32(u32(addr + 4)));
          if (wb !== null && wb !== undefined) this.setReg(ir.mem.rn, wb);
          return;
        }
        this.setReg(ir.rd, v);
      } else {
        const v = this.getReg(ir.rd);
        if (ir.size === 4) this.write32(addr, v);
        else if (ir.size === 2) this.write16(addr, v & 0xffff);
        else if (ir.size === 1) { this.write8(addr, v & 0xff); this.memWrites++; }
        else { this.write32(addr, v); this.write32(u32(addr + 4), this.getReg(ir.rd2)); }
      }
      if (wb !== null && wb !== undefined) this.setReg(ir.mem.rn, wb);
    }

    execBlock(ir) {
      const regs = [];
      for (let k = 0; k < 16; k++) if (ir.mask & (1 << k)) regs.push(k);
      const n = regs.length;
      this.cycles += n;                     // one extra cycle per register, roughly
      let base = this.getReg(ir.rn);
      let start;
      switch (ir.mode) {
        case 'ia': start = base; break;
        case 'ib': start = u32(base + 4); break;
        case 'da': start = u32(base - 4 * n + 4); break;
        case 'db': start = u32(base - 4 * n); break;
        default: start = base;
      }
      if (ir.op === 'ldm') {
        for (let k = 0; k < n; k++) {
          const v = this.read32(u32(start + 4 * k));
          if (regs[k] === 15) { if (v === 0) { this.halted = true; } else { this.pc = u32(v & ~1); this.branched = true; } }
          else this.r[regs[k]] = v | 0;
        }
      } else {
        for (let k = 0; k < n; k++) this.write32(u32(start + 4 * k), this.getReg(regs[k]));
      }
      if (ir.writeback) {
        const delta = (ir.mode === 'ia' || ir.mode === 'ib') ? 4 * n : -4 * n;
        this.setReg(ir.rn, u32(base + delta));
      }
    }

    /* ------------------------------------------------------------ vectors */
    vOff(v) { return v.kind === 's' ? v.n * 4 : v.kind === 'd' ? v.n * 8 : v.n * 16; }
    vSize(v) { return v.kind === 's' ? 4 : v.kind === 'd' ? 8 : 16; }
    getF32(v) { return this.vdv.getFloat32(this.vOff(v), true); }
    setF32(v, x) { this.vdv.setFloat32(this.vOff(v), x, true); }
    elemSize(dt) { const m = /(\d+)/.exec(dt || '32'); return m ? (+m[1]) / 8 : 4; }
    isFloat(dt) { return /f/.test(dt || ''); }

    execVector(ir) {
      const dv = this.vdv;
      switch (ir.op) {
        case 'vldr': { const { addr } = this.memAddress(ir); const bytes = this.vSize(ir.vd); for (let k = 0; k < bytes; k += 4) dv.setUint32(this.vOff(ir.vd) + k, this.read32(u32(addr + k)), true); break; }
        case 'vstr': { const { addr } = this.memAddress(ir); const bytes = this.vSize(ir.vd); for (let k = 0; k < bytes; k += 4) this.write32(u32(addr + k), dv.getUint32(this.vOff(ir.vd) + k, true)); break; }
        case 'vld1': case 'vst1': {
          const { addr, wb } = this.memAddress(ir);
          let a = addr;
          for (const reg of ir.regs) {
            const off = this.vOff(reg), sz = this.vSize(reg);
            for (let k = 0; k < sz; k++) {
              if (ir.op === 'vld1') this.vbytes[off + k] = this.read8(u32(a + k));
              else this.write8(u32(a + k), this.vbytes[off + k]);
            }
            a = u32(a + sz);
          }
          this.cycles += ir.regs.length;
          if (ir.mem.writeback) {
            let total = 0; for (const reg of ir.regs) total += this.vSize(reg);
            if (ir.mem.off.type === 'imm' && ir.mem.off.value === 0) this.setReg(ir.mem.rn, u32(this.getReg(ir.mem.rn) + total));
            else if (wb !== null && wb !== undefined) this.setReg(ir.mem.rn, wb);
          }
          break;
        }
        case 'vmov_s_r': dv.setUint32(this.vOff(ir.vd), this.getReg(ir.rm), true); break;
        case 'vmov_r_s': this.setReg(ir.rd, dv.getUint32(this.vOff(ir.vm), true)); break;
        case 'vmov_vv': { const n = this.vSize(ir.vd); for (let k = 0; k < n; k++) this.vbytes[this.vOff(ir.vd) + k] = this.vbytes[this.vOff(ir.vm) + k]; break; }
        case 'vmov_d_rr': dv.setUint32(this.vOff(ir.vd), this.getReg(ir.rn), true), dv.setUint32(this.vOff(ir.vd) + 4, this.getReg(ir.rm), true); break;
        case 'vmov_rr_d': this.setReg(ir.rd, dv.getUint32(this.vOff(ir.vm), true)), this.setReg(ir.rd2, dv.getUint32(this.vOff(ir.vm) + 4, true)); break;
        case 'vmov_imm': {
          const es = this.elemSize(ir.dt), n = this.vSize(ir.vd);
          for (let k = 0; k < n; k += es) this.putElem(this.vOff(ir.vd) + k, es, this.isFloat(ir.dt), ir.imm);
          break;
        }
        case 'vdup': {
          const es = this.elemSize(ir.dt), n = this.vSize(ir.vd), val = this.getReg(ir.rm);
          for (let k = 0; k < n; k += es) this.putElem(this.vOff(ir.vd) + k, es, false, val);
          break;
        }
        case 'vcvt': {
          const toF = /f\d+\.[su]/.test(ir.dt || '');
          const v = toF ? (ir.dt.indexOf('.s') >= 0 ? dv.getInt32(this.vOff(ir.vm), true) : dv.getUint32(this.vOff(ir.vm), true))
            : dv.getFloat32(this.vOff(ir.vm), true);
          if (toF) dv.setFloat32(this.vOff(ir.vd), v, true);
          else dv.setInt32(this.vOff(ir.vd), Math.trunc(v) | 0, true);
          break;
        }
        case 'vcmp': {
          const a = this.getF32(ir.vd), b = ir.vm ? this.getF32(ir.vm) : 0;
          this.fpN = a < b; this.fpZ = a === b; this.fpC = a >= b || isNaN(a) || isNaN(b); this.fpV = isNaN(a) || isNaN(b);
          break;
        }
        case 'vmrs': this.N = !!this.fpN; this.Z = !!this.fpZ; this.C = !!this.fpC; this.V = !!this.fpV; break;
        case 'vsqrt': this.setF32(ir.vd, Math.sqrt(this.getF32(ir.vm))); break;
        case 'vneg': this.setF32(ir.vd, -this.getF32(ir.vm)); break;
        case 'vabs': this.setF32(ir.vd, Math.abs(this.getF32(ir.vm))); break;
        case 'vdiv': this.setF32(ir.vd, this.getF32(ir.vn) / this.getF32(ir.vm)); break;
        default: this.execNeonBin(ir); break;
      }
    }
    putElem(off, es, isF, val) {
      const dv = this.vdv;
      if (isF) { dv.setFloat32(off, val, true); return; }
      if (es === 1) dv.setUint8(off, val & 0xff);
      else if (es === 2) dv.setUint16(off, val & 0xffff, true);
      else if (es === 8) { dv.setUint32(off, val >>> 0, true); dv.setUint32(off + 4, val < 0 ? 0xffffffff : 0, true); }
      else dv.setUint32(off, val >>> 0, true);
    }
    getElem(off, es, isF, signed) {
      const dv = this.vdv;
      if (isF) return dv.getFloat32(off, true);
      if (es === 1) return signed ? dv.getInt8(off) : dv.getUint8(off);
      if (es === 2) return signed ? dv.getInt16(off, true) : dv.getUint16(off, true);
      return signed ? dv.getInt32(off, true) : dv.getUint32(off, true);
    }
    execNeonBin(ir) {
      const dt = ir.dt || 'i32';
      const isF = this.isFloat(dt);
      const signed = /s/.test(dt) || isF;
      const es = this.elemSize(dt);
      const n = this.vSize(ir.vd);
      const od = this.vOff(ir.vd), on = this.vOff(ir.vn);
      const imm = (ir.vm && ir.vm.imm !== undefined) ? ir.vm.imm : null;
      const om = imm === null ? this.vOff(ir.vm) : 0;
      const op = ir.op;
      this.cycles += Math.max(0, (n / 8) - 1);
      for (let k = 0; k < n; k += es) {
        const a = this.getElem(on + k, es, isF, signed);
        const b = imm !== null ? imm : this.getElem(om + k, es, isF, signed);
        let r;
        switch (op) {
          case 'vadd': r = a + b; break;
          case 'vsub': r = a - b; break;
          case 'vmul': r = isF ? a * b : Math.imul(a, b); break;
          case 'vmla': r = (isF ? this.getElem(od + k, es, true, true) + a * b : this.getElem(od + k, es, false, signed) + Math.imul(a, b)); break;
          case 'vmls': r = (isF ? this.getElem(od + k, es, true, true) - a * b : this.getElem(od + k, es, false, signed) - Math.imul(a, b)); break;
          case 'vand': r = a & b; break;
          case 'vorr': r = a | b; break;
          case 'veor': r = a ^ b; break;
          case 'vmax': r = a > b ? a : b; break;
          case 'vmin': r = a < b ? a : b; break;
          case 'vabd': r = Math.abs(a - b); break;
          case 'vshl': r = a << b; break;
          case 'vshr': r = signed ? (a >> b) : (a >>> b); break;
          case 'vhadd': r = (a + b) >> 1; break;
          case 'vqadd': { const lim = es === 1 ? 255 : es === 2 ? 65535 : 0xffffffff; r = Math.min(a + b, lim); break; }
          case 'vqsub': r = Math.max(0, a - b); break;
          case 'vpadd': r = a + b; break;
          default: throw new Error('unimplemented vector op ' + op);
        }
        this.putElem(od + k, es, isF, r);
      }
    }

    /* --------------------------------------------------------------- run */
    run(maxInsn) {
      const lim = maxInsn || 2000000;
      let n = 0;
      while (!this.halted && n < lim) { if (!this.step()) break; n++; }
      if (n >= lim && !this.halted) {
        this.fault('ran for ' + lim.toLocaleString() + ' instructions without stopping — the loop probably never exits. ' +
          'Check that the counter really reaches the value your branch tests for.');
      }
      return n;
    }
    snapshot() {
      return { r: Array.from(this.r), pc: this.pc, N: this.N, Z: this.Z, C: this.C, V: this.V, cycles: this.cycles };
    }
  }
  function rorN(v, n) { n = (n || 0) & 31; return n === 0 ? u32(v) : u32((v >>> n) | (v << (32 - n))); }

  /* =========================================================================
   *  Framebuffer geometry: linear, row-major, 1 bit per pixel.
   *    row  y  starts at  y * FB_STRIDE
   *    pixel x is bit (7 - (x & 7)) of byte (x >> 3)
   *  The stride is 40 bytes, which is not a power of two -- exactly like a
   *  real panel whose line length is not the visible width -- so a row table
   *  still earns its place.
   * ====================================================================== */
  function fbRowOffset(y) { return y * MAP.FB_STRIDE; }

  function renderFB(bytes, ctx, opts) {
    opts = opts || {};
    const W = MAP.FB_W, H = MAP.FB_H, STRIDE = MAP.FB_STRIDE;
    const img = ctx.createImageData(W, H);
    const on = opts.on || [126, 255, 160], off = opts.off || [10, 12, 16];
    for (let y = 0; y < H; y++) {
      const base = y * STRIDE;
      for (let bx = 0; bx < STRIDE; bx++) {
        const b = bytes[base + bx] || 0;
        for (let bit = 0; bit < 8; bit++) {
          const px = bx * 8 + bit;
          if (px >= W) break;
          const set = (b >> (7 - bit)) & 1;
          const i = (y * W + px) * 4;
          img.data[i] = set ? on[0] : off[0];
          img.data[i + 1] = set ? on[1] : off[1];
          img.data[i + 2] = set ? on[2] : off[2];
          img.data[i + 3] = 255;
        }
      }
    }
    return img;
  }

  global.ARM = { assemble, CPU, MAP, encodeModifiedImm, fbRowOffset, renderFB, AsmError, evalExpr };
})(typeof window !== 'undefined' ? window : globalThis);
