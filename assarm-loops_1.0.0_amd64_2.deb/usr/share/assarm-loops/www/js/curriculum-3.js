/* AssArm: Loops — curriculum part 3 : Unit 7 */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u7', n: 7, title: 'Making Loops Fast', icon: '⚡', color: '#f7768e',
    blurb: 'Hoisting, strength reduction, unrolling, alignment and preload — the five things that actually move the needle.',
    lessons: [

/* ------------------------------------------------------------------ 7.1 */
{
  id: 'u7l1', title: 'What a loop costs', goal: 'Count the cost of a loop body and know where the time goes.',
  teach: [
    { t: 'p', x: 'Before optimising anything, count. A loop\'s cost is <b>(cost of one body) × (number of iterations)</b> plus a small fixed setup. Both factors are worth attacking, and it is usually obvious which one.' },
    { t: 'table', head: ['Operation', 'Rough cost on a Cortex-A7', 'Notes'], rows: [
      ['Data processing (<code>ADD</code>, <code>MOV</code>, shifts)', '1 cycle', 'Often dual-issued with a neighbour'],
      ['<code>MUL</code>', '2–3 cycles', 'Result not available immediately'],
      ['<code>SDIV</code> / <code>UDIV</code>', '4–20 cycles', 'Data dependent. Avoid in loops.'],
      ['<code>LDR</code> (L1 hit)', '~3 cycles latency, 1/cycle throughput', 'The stall only shows if you use it immediately'],
      ['<code>LDR</code> (L2 hit)', '~10–20 cycles', ''],
      ['<code>LDR</code> (DRAM)', '~100+ cycles', 'This is what dominates big loops'],
      ['Predicted branch', '~1 cycle', ''],
      ['Mispredicted branch', '~8 cycles', 'Pipeline refill'],
      ['<code>LDM</code>/<code>STM</code> of n registers', '~n + 2 cycles', 'Much better than n separate loads']
    ] },
    { t: 'note', x: 'These are order-of-magnitude figures for one particular in-order core, offered so you have a mental model. The emulator in this app reports an approximate cycle count built on the same model — use it to compare two versions of your own loop, not to predict real hardware exactly.' },
    { t: 'h', x: 'Where the time actually goes' },
    { t: 'p', x: 'In almost every real loop, one of three things dominates: <b>memory</b> (you are waiting for data), <b>a dependency chain</b> (each instruction needs the previous one\'s result), or <b>branches</b> (unpredictable ones). Instruction count matters least of the four, which is why "make it shorter" is often the wrong instinct.' },
    { t: 'h', x: 'Measure, then change' },
    { t: 'code', cap: 'The same sum, two ways — run both and compare cycles', x: '@ version A: index arithmetic\n    ldr  r1, =a\n    mov  r2, #0\n    mov  r0, #0\n1:  ldr  r3, [r1, r2, lsl #2]\n    add  r0, r0, r3\n    add  r2, r2, #1\n    cmp  r2, #8\n    blo  1b' }
  ],
  real: {
    title: 'Profiling before optimising',
    text: 'The single most common optimisation mistake is speeding up a loop that was not the problem. On ARM, <code>perf stat</code> on Linux and the DWT cycle counter on Cortex-M both give you real numbers. A loop that is 2% of runtime cannot be made to matter no matter how clever you are.',
    code: '@ Cortex-M: read the cycle counter before and after\n    ldr  r4, =0xE0001004    @ DWT_CYCCNT\n    ldr  r5, [r4]\n    bl   the_loop\n    ldr  r6, [r4]\n    sub  r0, r6, r5         @ cycles consumed'
  },
  deep: {
    kind: 'cores',
    title: 'Static cycle counts only work on some cores',
    text: 'A Cortex-A7 is in-order and dual-issue with a short pipeline, so adding up per-instruction costs by hand is at least approximately right, which is what the table above is quietly assuming. A Cortex-A9 or Cortex-A15 is out-of-order — instructions can complete ahead of earlier ones and a stalled load can be hidden behind unrelated work — so no paper count will match what actually happens. Cortex-M3 and M4 sit at the other extreme: their pipelines are simple enough that the technical reference manual publishes an exact cycle count for every instruction, no measurement required. Where arithmetic cannot be trusted, ask the core directly.',
    code: '@ Cortex-A7/A9/A15: read the free-running PMU cycle counter\n    mrc  p15, 0, r0, c9, c13, 0   @ r0 = PMCCNTR, cycles since it was last enabled',
    note: 'Reading it is one instruction; enabling it first takes two more privileged <code>MCR</code> writes to the same coprocessor, which is why most codebases wrap this pair in a small helper instead of inlining it at every call site.'
  },
  refs: [
    { src: 'ARM Cortex-A7 MPCore Technical Reference Manual, Instruction cycle timings', cite: 'Per-instruction issue and result latencies are documented per core; they differ between Cortex-A implementations.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Optimizing code', cite: 'Memory access and branch behaviour dominate the cost of most loops; instruction count alone is a poor predictor of performance.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which of these usually dominates the cost of a large loop?', opts: ['Instruction count', 'Waiting for memory', 'Register allocation', 'Code size'], a: 1, why: 'A DRAM access can cost more than a hundred arithmetic instructions. That is why cache behaviour beats instruction count.' },
    { k: 'mcq', q: 'You shorten a loop body from 6 instructions to 5 but it runs no faster. Most likely reason?', opts: ['The measurement is wrong', 'The loop was limited by memory or a dependency chain, not by instruction issue', 'Five is an unlucky number', 'The compiler undid it'], a: 1, why: 'Removing an instruction from a loop that is stalled on a load changes nothing — you removed work that was happening during the stall.' },
    { k: 'code', q: 'Write the pointer-walk version of this sum and make it fit in 40 executed instructions. (The index version needs more.)', start: '    ldr  r1, =a\n    mov  r2, #0\n    mov  r0, #0\n1:  ldr  r3, [r1, r2, lsl #2]\n    add  r0, r0, r3\n    add  r2, r2, #1\n    cmp  r2, #8\n    blo  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', check: [{ reg: 'r0', eq: 36 }, { maxInsn: 40 }], solution: '    ldr  r1, =a\n    add  r2, r1, #32\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    blo  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', hints: ['Post-index the load and compare the pointer against a precomputed end.', 'That removes one instruction from every iteration.'], why: 'Four instructions per iteration instead of five — 32 executed instead of 40 in the body.' },
    { k: 'mcq', q: 'Roughly how many cycles does a mispredicted branch cost on a typical Cortex-A core?', opts: ['0', '1', '~8', '~100'], a: 2, why: 'It is the pipeline refill. Deep out-of-order cores pay more; Cortex-M cores pay less.' },
    { k: 'mcq', q: 'Why does <code>LDM</code> of 8 registers beat 8 separate <code>LDR</code>s?', opts: ['It moves less data', 'It pays the fetch, decode and address-generation cost once instead of eight times', 'It is cached differently', 'It is not faster'], a: 1, why: 'The data transfer is the same; everything around it is eliminated.' }
  ]
},

/* ------------------------------------------------------------------ 7.2 */
{
  id: 'u7l2', title: 'Hoisting', goal: 'Move everything that does not change out of the loop.',
  teach: [
    { t: 'p', x: 'Anything computed inside a loop whose value never changes is being computed n times for no reason. Moving it out is called <b>hoisting</b>, and it is the highest-value, lowest-risk optimisation there is.' },
    { t: 'code', cap: 'Before: the address is recomputed every iteration', x: '1:  ldr  r4, =base       @ the same value, every time\n    ldr  r5, [r4, r2, lsl #2]\n    add  r0, r0, r5\n    add  r2, r2, #1\n    cmp  r2, #100\n    blo  1b' },
    { t: 'code', cap: 'After', x: '    ldr  r4, =base       @ once\n1:  ldr  r5, [r4, r2, lsl #2]\n    add  r0, r0, r5\n    add  r2, r2, #1\n    cmp  r2, #100\n    blo  1b' },
    { t: 'h', x: 'What to look for' },
    { t: 'table', head: ['Hoistable', 'Example'], rows: [
      ['Constant addresses', '<code>ldr rX, =label</code>'],
      ['Loop bounds', 'the end pointer, the limit'],
      ['Masks and shifted constants', 'a replicated fill byte'],
      ['Values loaded from memory that the loop does not write', 'a struct field read every iteration'],
      ['The result of a call that returns the same thing', '<code>strlen</code> inside the condition']
    ] },
    { t: 'note', x: 'The last one is the famous "Schlemiel the Painter" bug: <code>for (i = 0; i &lt; strlen(s); i++)</code> calls strlen on every iteration, turning a linear loop into a quadratic one. In assembly it is more obvious, because you can see the <code>BL</code>.' },
    { t: 'h', x: 'What stops you hoisting' },
    { t: 'p', x: 'A load can only be hoisted if the loop cannot write to that address. In C the compiler often cannot prove this — two pointers might alias — which is why <code>restrict</code> exists and why hand-written assembly can be faster: <i>you</i> know the buffers are separate.' }
  ],
  real: {
    title: 'The aliasing problem, concretely',
    text: 'A compiler seeing <code>for (i=0;i&lt;n;i++) dst[i] = src[i] + hdr-&gt;scale;</code> must reload <code>hdr-&gt;scale</code> every iteration, because a write to <code>dst[i]</code> might land on <code>hdr</code>. In assembly you simply load it once, because you know it cannot. That one hoist can double the loop\'s speed.',
    code: '    ldr  r6, [r5, #SCALE]   @ hoisted: we know dst does not alias hdr\n1:  ldr  r3, [r1], #4\n    add  r3, r3, r6\n    str  r3, [r0], #4\n    subs r2, r2, #1\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'Restrict turns a reload into a hoist',
    text: 'Given plain pointers, the compiler cannot hoist the load of <code>*k</code> above the loop, because a write to <code>dst[i]</code> might alias <code>*k</code> on some later iteration and it has no way to rule that out. Mark all three pointers <code>restrict</code> and that possibility is gone by promise rather than proof, so gcc hoists the load exactly as if you had written the assembly by hand.',
    a: { lab: 'C, with restrict', lang: 'c', code: 'void addk(int *restrict dst, const int *restrict src,\n          const int *restrict k, int n) {\n    for (int i = 0; i < n; i++)\n        dst[i] = src[i] + *k;\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: '    ldr  r4, [r2]            @ *k loaded once, hoisted above the loop\n1:  ldr  r5, [r1], #4\n    add  r5, r5, r4\n    str  r5, [r0], #4\n    subs r3, r3, #1\n    bne  1b' },
    note: 'Delete <code>restrict</code> from any one of the three pointers and the load of <code>*k</code> moves back inside the loop, because now a write to <code>dst[i]</code> might be a write to <code>*k</code>. The generated code is otherwise identical — one keyword is the entire difference between a hoist and a reload on every iteration.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop-invariant code motion', cite: 'Computations whose operands do not change within the loop should be performed once before the loop is entered.' },
    { src: 'ISO/IEC 9899, 6.7.3 — restrict', cite: 'The restrict qualifier lets a compiler assume that accesses through one pointer do not alias accesses through another, enabling loads to be hoisted out of loops.' }
  ],
  ex: [
    { k: 'code', q: 'Hoist everything hoistable out of this loop and get the instruction count under 45.', start: '    mov  r2, #0\n    mov  r0, #0\n1:  ldr  r4, =a\n    mov  r6, #3\n    ldr  r5, [r4, r2, lsl #2]\n    mul  r5, r5, r6\n    add  r0, r0, r5\n    add  r2, r2, #1\n    cmp  r2, #8\n    blo  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', check: [{ reg: 'r0', eq: 108 }, { maxInsn: 60 }], solution: '    ldr  r4, =a\n    mov  r6, #3\n    mov  r2, #0\n    mov  r0, #0\n1:  ldr  r5, [r4, r2, lsl #2]\n    mul  r5, r5, r6\n    add  r0, r0, r5\n    add  r2, r2, #1\n    cmp  r2, #8\n    blo  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', hints: ['Both <code>ldr r4, =a</code> and <code>mov r6, #3</code> are the same on every iteration.', 'Move them above the label.'], why: '3 × 36 = 108. Two instructions moved out of a loop that runs eight times is sixteen instructions saved.' },
    { k: 'mcq', q: 'Why can a C compiler often not hoist a load out of a loop that writes to memory?', opts: ['Loads are too slow to hoist', 'It cannot prove the store does not write to the same address — the pointers might alias', 'Hoisting changes the flags', 'It always can'], a: 1, why: 'This is the single biggest reason hand-written assembly beats compiled code in copy-and-transform loops.' },
    { k: 'mcq', q: 'What is wrong with <code>for (i = 0; i &lt; strlen(s); i++)</code>?', opts: ['Nothing', 'strlen is called on every iteration, making a linear loop quadratic', 'i should be unsigned', 'strlen returns the wrong type'], a: 1, why: 'The loop bound is loop-invariant. Compute it once above the loop.' },
    { k: 'code', q: 'This loop adds a constant scale factor from memory. Hoist the load and keep the answer at 70.', start: '    ldr  r1, =a\n    ldr  r5, =scale\n    mov  r2, #5\n    mov  r0, #0\n1:  ldr  r6, [r5]\n    ldr  r3, [r1], #4\n    add  r3, r3, r6\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 1,2,3,4,5\nscale: .word 11\n', check: [{ reg: 'r0', eq: 70 }, { maxInsn: 32 }], solution: '    ldr  r1, =a\n    ldr  r5, =scale\n    ldr  r6, [r5]\n    mov  r2, #5\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r3, r3, r6\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 1,2,3,4,5\nscale: .word 11\n', hints: ['<code>ldr r6, [r5]</code> is the same every iteration.'], why: '15 + 5×11 = 70. You just did by hand what a compiler needs <code>restrict</code> to do.' },
    { k: 'mcq', q: 'Which of these is NOT normally hoistable?', opts: ['A constant address', 'The loop bound', 'A load from an address the loop itself writes to', 'A shifted constant mask'], a: 2, why: 'If the loop writes it, its value genuinely changes — hoisting would be wrong, not just unhelpful.' }
  ]
},

/* ------------------------------------------------------------------ 7.3 */
{
  id: 'u7l3', title: 'Strength reduction', goal: 'Replace expensive operations with cheap ones that give the same answer.',
  teach: [
    { t: 'p', x: 'Strength reduction means swapping an expensive operation for a cheaper one with the same result. In loops the classic case is replacing a multiply by a running add.' },
    { t: 'code', cap: 'Multiply becomes add', x: '@ before: a multiply every iteration\n1:  mul  r3, r2, r6      @ offset = i * stride\n    ldr  r4, [r1, r3]\n    add  r2, r2, #1\n    cmp  r2, #100\n    blo  1b\n\n@ after: the offset is maintained incrementally\n    mov  r3, #0\n1:  ldr  r4, [r1, r3]\n    add  r3, r3, r6      @ one add replaces the multiply\n    add  r2, r2, #1\n    cmp  r2, #100\n    blo  1b' },
    { t: 'h', x: 'The catalogue' },
    { t: 'table', head: ['Expensive', 'Cheap equivalent', 'Condition'], rows: [
      ['<code>x * 2ⁿ</code>', '<code>LSL x, #n</code>', 'always'],
      ['<code>x / 2ⁿ</code> (unsigned)', '<code>LSR x, #n</code>', 'always'],
      ['<code>x / 2ⁿ</code> (signed)', '<code>ASR</code> plus a rounding fix', 'ASR alone rounds towards −∞'],
      ['<code>x % 2ⁿ</code>', '<code>AND x, #(2ⁿ−1)</code>', 'unsigned only'],
      ['<code>x * 10</code>', '<code>ADD x, x, x, LSL #2</code> then <code>LSL #1</code>', 'any small constant'],
      ['<code>i * stride</code> in a loop', 'a running offset', 'stride is constant']
    ] },
    { t: 'code', cap: 'Multiply by a constant with the barrel shifter', x: '@ r0 = r1 * 10\n    add  r0, r1, r1, lsl #2   @ r1 + 4*r1 = 5*r1\n    lsl  r0, r0, #1           @ 10*r1\n\n@ r0 = r1 * 7\n    rsb  r0, r1, r1, lsl #3   @ 8*r1 - r1' },
    { t: 'note', x: 'Signed division by a power of two is <b>not</b> a plain <code>ASR</code>. <code>ASR</code> rounds towards negative infinity; C division rounds towards zero. −7 / 2 is −3 in C but <code>asr #1</code> gives −4. Compilers emit an extra add to correct it — so if you write <code>ASR</code> yourself, know which rounding you are choosing.' },
    { t: 'h', x: 'Division is the one to hunt for' },
    { t: 'p', x: 'Not every ARMv7 core even has <code>SDIV</code> — it is optional in ARMv7-A and absent on Cortex-A8. Where it exists it costs a dozen cycles or more. A division inside a loop is almost always worth restructuring away.' }
  ],
  real: {
    title: 'Walking a 2D array without multiplying',
    text: 'Row-major image code needs <code>base + y*stride + x</code>. Computed naively that is a multiply per pixel. Maintained incrementally — add <code>stride</code> at the end of each row — it is one add per row and nothing at all per pixel.',
    code: '@ walk an image without a single multiply\n    mov  r7, r0          @ row pointer\n1:  mov  r8, r7          @ pixel pointer for this row\n    mov  r3, r9          @ width\n2:  ldrb r4, [r8], #1\n    @ ... process ...\n    subs r3, r3, #1\n    bne  2b\n    add  r7, r7, r10     @ next row: one add, once per row\n    subs r6, r6, #1\n    bne  1b'
  },
  deep: {
    kind: 'cores',
    title: 'MUL and SDIV cost different amounts on different cores',
    text: 'On a Cortex-A7 a 32-bit <code>MUL</code> takes about 3 cycles before the result is ready, so code that consumes it immediately stalls exactly like it would after a load. A Cortex-M4 computes a 32×32-bit multiply-accumulate in a single cycle, so the same multiply that is worth avoiding on A7 barely registers there. Cortex-A8 removes the choice entirely: <code>SDIV</code>/<code>UDIV</code> were optional in ARMv7-A and A8 does not implement them, so a division compiles to a library call no matter how the source is written. Replacing the multiply with a running add sidesteps all three differences at once.',
    a: { lab: 'MUL every iteration — 3-cycle latency on Cortex-A7', code: '1:  mul  r4, r2, r6      @ r4 = i * stride\n    ldr  r5, [r1, r4]\n    add  r0, r0, r5\n    add  r2, r2, #1\n    cmp  r2, #50\n    blo  1b' },
    b: { lab: 'Running add — the same one cycle on A7, A15 or M4', code: '    mov  r4, #0\n1:  ldr  r5, [r1, r4]\n    add  r0, r0, r5\n    add  r4, r4, r6\n    add  r2, r2, #1\n    cmp  r2, #50\n    blo  1b' },
    note: 'The saving is largest on an in-order Cortex-A7 and smallest on a Cortex-M4, whose single-cycle MAC makes the original MUL nearly free already. It says nothing about division, though — a stray SDIV still needs restructuring away entirely on a Cortex-A8, which has no divider to fall back on.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A4 — Shifted register operands', cite: 'A register operand may be shifted by a constant amount as part of a data-processing instruction, at no additional cost.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A4 — Integer divide', cite: 'SDIV and UDIV are optional in ARMv7-A and required in ARMv7-R and ARMv7-M.' }
  ],
  ex: [
    { k: 'code', q: 'Compute r0 = r1 × 40 using only shifts and adds, no MUL. r1 = 7.', start: '    mov  r1, #7\n', check: [{ reg: 'r0', eq: 280 }, { notContains: 'mul' }], solution: '    mov  r1, #7\n    add  r0, r1, r1, lsl #2\n    lsl  r0, r0, #3\n', hints: ['40 = 5 × 8, and 5×r1 is <code>add r0, r1, r1, lsl #2</code>.'], why: '7 × 40 = 280, in two instructions with no multiplier involved.' },
    { k: 'code', q: 'Replace the multiply in this loop with a running offset. Answer must stay 84.', start: '    ldr  r1, =a\n    mov  r6, #4\n    mov  r2, #0\n    mov  r0, #0\n1:  mul  r3, r2, r6\n    ldr  r4, [r1, r3]\n    add  r0, r0, r4\n    add  r2, r2, #1\n    cmp  r2, #6\n    blo  1b\n\n.data\na: .word 4,8,12,16,20,24\n', check: [{ reg: 'r0', eq: 84 }, { notContains: 'mul' }], solution: '    ldr  r1, =a\n    mov  r3, #0\n    mov  r2, #0\n    mov  r0, #0\n1:  ldr  r4, [r1, r3]\n    add  r3, r3, #4\n    add  r0, r0, r4\n    add  r2, r2, #1\n    cmp  r2, #6\n    blo  1b\n\n.data\na: .word 4,8,12,16,20,24\n', hints: ['Keep the byte offset in r3 and add 4 each time.'], why: 'The multiply disappears entirely, replaced by an add that was nearly free.' },
    { k: 'mcq', q: 'Why is <code>asr r0, r0, #1</code> not the same as signed division by 2 in C?', opts: ['It is the same', 'ASR rounds towards negative infinity; C rounds towards zero, so −7/2 differs', 'ASR does not work on negatives', 'ASR is unsigned'], a: 1, why: 'ASR gives −4 where C gives −3. Compilers add a correction; if you hand-write ASR, you are choosing the other rounding.' },
    { k: 'mcq', q: 'Which is the cheapest way to compute <code>x % 8</code> for unsigned x?', opts: ['<code>udiv</code> then <code>mls</code>', '<code>and r0, r0, #7</code>', '<code>sub</code> in a loop', '<code>lsr</code> then <code>lsl</code>'], a: 1, why: 'Modulo a power of two is a mask. One instruction, one cycle.' },
    { k: 'code', q: 'Compute r0 = r1 × 7 in one instruction using RSB and the barrel shifter. r1 = 9.', start: '    mov  r1, #9\n', check: [{ reg: 'r0', eq: 63 }, { maxInsn: 5 }], solution: '    mov  r1, #9\n    rsb  r0, r1, r1, lsl #3\n', hints: ['7 = 8 − 1, and RSB computes (second operand) − (first operand).'], why: '8×9 − 9 = 63, in a single instruction.' }
  ]
},

/* ------------------------------------------------------------------ 7.4 */
{
  id: 'u7l4', title: 'Unrolling', goal: 'Trade code size for fewer loop-control instructions — and know when to stop.',
  teach: [
    { t: 'p', x: 'Unrolling means doing several iterations\' worth of work per trip round the loop, so the loop control is paid less often.' },
    { t: 'code', cap: 'Rolled: 2 of every 4 instructions are overhead', x: '1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1      @ overhead\n    bne  1b              @ overhead' },
    { t: 'code', cap: 'Unrolled 4×: 2 of every 10', x: '1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    ldr  r3, [r1], #4\n    add  r0, r0, r3\n    ldr  r3, [r1], #4\n    add  r0, r0, r3\n    ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #4\n    bne  1b' },
    { t: 'code', cap: 'Better: unroll with LDM and independent accumulators', x: '1:  ldmia r1!, {r3-r6}   @ four loads, one instruction\n    add  r0, r0, r3\n    add  r7, r7, r4      @ separate accumulators break the\n    add  r8, r8, r5      @ dependency chain so the adds can\n    add  r9, r9, r6      @ issue in parallel\n    subs r2, r2, #4\n    bne  1b\n    add  r0, r0, r7      @ combine at the end\n    add  r8, r8, r9\n    add  r0, r0, r8' },
    { t: 'note', x: 'The second win is bigger than the first. Four adds into <i>one</i> accumulator form a dependency chain — each must wait for the previous. Four separate accumulators can execute in any order. Breaking dependency chains is often what unrolling is really for.' },
    { t: 'table', head: ['Unroll factor', 'Overhead share', 'Cost'], rows: [
      ['1×', '50%', 'smallest code'],
      ['2×', '33%', ''],
      ['4×', '20%', 'usually the sweet spot'],
      ['8×', '11%', 'watch your instruction cache'],
      ['16×+', '6%', 'almost always counterproductive']
    ] },
    { t: 'h', x: 'The costs' },
    { t: 'p', x: 'Unrolling multiplies code size, and code that does not fit the instruction cache is slower, not faster. It also needs a remainder path for counts that are not a multiple of the factor — which is Unit 5\'s tail problem all over again. And on an out-of-order core with a good branch predictor, the loop overhead you removed may have been free anyway.' }
  ],
  real: {
    title: 'Why compilers unroll less than you expect',
    text: 'GCC and Clang unroll conservatively at -O2 and more aggressively at -O3, and they often get it wrong in both directions. Hand-unrolling a genuinely hot loop still pays — but only after measuring, and usually by 4, with independent accumulators, not by heroic factors.',
    code: '@ 4x unrolled sum with 4 accumulators — the standard shape\n    mov  r0, #0\n    mov  r7, #0\n    mov  r8, #0\n    mov  r9, #0\n1:  ldmia r1!, {r3-r6}\n    add  r0, r0, r3\n    add  r7, r7, r4\n    add  r8, r8, r5\n    add  r9, r9, r6\n    subs r2, r2, #4\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'Unrolling is off by default at -O2',
    text: 'At <code>-O2</code>, gcc leaves a simple accumulation loop exactly as rolled as you wrote it — the code-size and instruction-cache cost of unrolling is judged not worth paying automatically at that level, so it stays gated behind <code>-O3</code> or the explicit <code>-funroll-loops</code> flag. Ask for either of those and the body is duplicated with several independent accumulators, the same shape this lesson builds by hand. Either way, a trip count that is not a compile-time multiple of the unroll factor still needs a scalar remainder loop afterwards — the compiler cannot make that requirement disappear any more than you can.',
    a: { lab: 'C', lang: 'c', code: 'int sum(const int *a, int n) {\n    int s = 0;\n    for (int i = 0; i < n; i++)\n        s += a[i];\n    return s;\n}' },
    b: { lab: 'gcc -O2, ARMv7 (rolled)', code: 'sum:\n    mov   r2, #0\n    cmp   r1, #0\n    ble   2f\n    mov   r3, #0\n1:  ldr   r12, [r0, r3, lsl #2]\n    add   r2, r2, r12\n    add   r3, r3, #1\n    cmp   r3, r1\n    blt   1b\n2:  mov   r0, r2\n    bx    lr' },
    note: 'Check the compiler\'s own output before hand-unrolling a loop like this one — if <code>-O3</code> already produces four accumulators and a tidy remainder loop, this lesson has nothing left to add.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop unrolling', cite: 'Unrolling reduces loop overhead and exposes more independent instructions for scheduling, at the cost of increased code size and instruction-cache pressure.' }
  ],
  ex: [
    { k: 'code', q: 'Unroll this sum by 4 using LDM, and get the executed instruction count under 30.', start: '    ldr  r1, =a\n    mov  r2, #16\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\n', check: [{ reg: 'r0', eq: 136 }, { maxInsn: 36 }], solution: '    ldr  r1, =a\n    mov  r2, #16\n    mov  r0, #0\n1:  ldmia r1!, {r3-r6}\n    add  r0, r0, r3\n    add  r0, r0, r4\n    add  r0, r0, r5\n    add  r0, r0, r6\n    subs r2, r2, #4\n    bne  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\n', hints: ['Load four words with one <code>ldmia r1!, {r3-r6}</code>.', 'Subtract 4 from the counter instead of 1.'], why: 'Sum 1..16 = 136. Four iterations of a seven-instruction body instead of sixteen of a four-instruction one.' },
    { k: 'mcq', q: 'Why use four separate accumulators rather than one?', opts: ['To use more registers', 'One accumulator creates a dependency chain — each add waits for the previous; four independent chains can issue in parallel', 'It makes the code shorter', 'It avoids overflow'], a: 1, why: 'On a dual-issue or out-of-order core this is often a bigger win than the reduced loop overhead.' },
    { k: 'mcq', q: 'What is the usual sweet spot for an unroll factor?', opts: ['2', '4', '16', '64'], a: 1, why: 'Beyond 4 the returns shrink fast while the code-size and remainder costs keep growing.' },
    { k: 'code', q: 'Unroll with four independent accumulators, then combine. Sum must be 136.', start: '    ldr  r1, =a\n    mov  r2, #16\n    mov  r0, #0\n    mov  r7, #0\n    mov  r8, #0\n    mov  r9, #0\n1:\n\n.data\na: .word 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\n', check: [{ reg: 'r0', eq: 136 }, { maxInsn: 42 }], solution: '    ldr  r1, =a\n    mov  r2, #16\n    mov  r0, #0\n    mov  r7, #0\n    mov  r8, #0\n    mov  r9, #0\n1:  ldmia r1!, {r3-r6}\n    add  r0, r0, r3\n    add  r7, r7, r4\n    add  r8, r8, r5\n    add  r9, r9, r6\n    subs r2, r2, #4\n    bne  1b\n    add  r0, r0, r7\n    add  r8, r8, r9\n    add  r0, r0, r8\n\n.data\na: .word 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\n', hints: ['Each of the four loaded words goes into its own accumulator.', 'Combine the four accumulators after the loop.'], why: 'Same answer, four independent dependency chains instead of one.' },
    { k: 'mcq', q: 'What extra problem does unrolling by 4 create?', opts: ['Register pressure only', 'Counts that are not a multiple of 4 need a remainder path', 'The flags stop working', 'It prevents hoisting'], a: 1, why: 'The tail problem from Unit 5 returns, and it is why an unrolled loop is always longer than it first looks.' }
  ]
},

/* ------------------------------------------------------------------ 7.5 */
{
  id: 'u7l5', title: 'Scheduling and load latency', goal: 'Arrange instructions so the core is never waiting on a result it just asked for.',
  teach: [
    { t: 'p', x: 'A load does not deliver its value on the next cycle. On a Cortex-A7 the result is available roughly three cycles later. If the very next instruction uses it, the core stalls.' },
    { t: 'code', cap: 'Stalling: the ADD needs r3 immediately', x: '1:  ldr  r3, [r1], #4\n    add  r0, r0, r3      @ stalls waiting for the load\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'code', cap: 'Scheduled: do something else while the load lands', x: '1:  ldr  r3, [r1], #4\n    subs r2, r2, #1      @ independent work fills the gap\n    add  r0, r0, r3      @ by now r3 has arrived\n    bne  1b              @ the flags from SUBS are still valid!' },
    { t: 'note', x: 'That last version is only legal because <b>loads and stores never change the flags</b>. The <code>SUBS</code> sets them, the <code>ADD</code> does not disturb them, and the <code>BNE</code> still reads the right ones. This is the single most useful consequence of ARM\'s "loads do not set flags" rule.' },
    { t: 'h', x: 'Software pipelining' },
    { t: 'p', x: 'The general version: load the data for iteration <i>n+1</i> while processing iteration <i>n</i>. The loop then always has a load in flight and never waits.' },
    { t: 'code', cap: 'One iteration ahead', x: '    ldr  r3, [r1], #4    @ prologue: load the first element\n1:  ldr  r4, [r1], #4    @ load the NEXT one\n    add  r0, r0, r3      @ process the current one\n    mov  r3, r4\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'p', x: 'Real pipelined loops alternate registers rather than copying, and unroll by two so the copy disappears. The principle stays: keep a load in flight at all times.' },
    { t: 'h', x: 'Dual issue' },
    { t: 'p', x: 'Cortex-A7, A8 and A9 can issue two instructions per cycle when they are independent and of compatible types. Alternating a load with an arithmetic instruction, rather than grouping all the loads together, is what lets that happen.' }
  ],
  real: {
    title: 'Why optimised library loops look scrambled',
    text: 'Open ARM\'s optimised memcpy or a NEON DSP kernel and the instructions appear to be in a strange order — loads far from their uses, counters decremented in odd places. That is scheduling. The code is arranged so that no instruction waits for its neighbour.',
    code: '@ scheduled: the SUBS fills the load-use gap and the flags survive\n1:  ldr   r3, [r1], #4\n    subs  r2, r2, #1\n    add   r0, r0, r3\n    bne   1b'
  },
  deep: {
    kind: 'pitfall',
    title: 'A software-pipelined loop that forgets its last value',
    text: 'Priming the pipeline with one load up front and fetching "the next one" inside the loop is only half the trick — the value loaded on the loop\'s final trip has no later iteration left to add it in. Get the bookkeeping wrong and the loop exits having loaded every element but added only the ones before the last, silently: no crash, no warning, just a wrong answer.',
    a: { lab: 'Buggy — the last element is loaded but never added', code: '    ldr  r1, =a\n    mov  r0, #0\n    mov  r2, #3           @ three more elements after the prologue load\n    ldr  r3, [r1], #4     @ prologue: load element 0\n1:  ldr  r4, [r1], #4     @ load the next element\n    add  r0, r0, r3       @ process the current one\n    mov  r3, r4\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 10,20,30,40' },
    b: { lab: 'Fixed — an epilogue adds the value still in flight', code: '    ldr  r1, =a\n    mov  r0, #0\n    mov  r2, #3\n    ldr  r3, [r1], #4\n1:  ldr  r4, [r1], #4\n    add  r0, r0, r3\n    mov  r3, r4\n    subs r2, r2, #1\n    bne  1b\n    add  r0, r0, r3       @ epilogue: the final load is still waiting\n\n.data\na: .word 10,20,30,40' },
    note: 'The <code>mov r3, r4</code> shuffle is also why real pipelined code alternates between two registers across iterations instead of copying — the copy is one more instruction sitting in the same dependency chain the pipelining was meant to shorten. Dropped epilogues are the more common bug, though: count how many values you loaded against how many you actually used.'
  },
  refs: [
    { src: 'ARM Cortex-A7 MPCore Technical Reference Manual, Load/store pipeline', cite: 'The result of a load is not available to a dependent instruction for several cycles; independent instructions placed between them avoid the stall.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR', cite: 'Load instructions do not update the condition flags.' }
  ],
  ex: [
    { k: 'mcq', q: 'Why can <code>SUBS</code> be placed between a load and the instruction that uses it?', opts: ['SUBS is very fast', 'Loads do not change the flags, so the SUBS result is still valid for the branch — and the SUBS fills the load-use gap', 'The assembler reorders it anyway', 'It cannot be'], a: 1, why: 'This is why "loads never set flags" is a useful rule rather than an annoyance.' },
    { k: 'code', q: 'Reschedule this loop so the SUBS sits between the load and its use. Sum must stay 36.', start: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', check: [{ reg: 'r0', eq: 36 }, { regex: 'subs[^\\n]*\\n\\s*add\\s+r0', desc: 'The <code>subs</code> must sit between the load and the <code>add</code> that uses it.' }], solution: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    subs r2, r2, #1\n    add  r0, r0, r3\n    bne  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', hints: ['Swap the <code>add</code> and the <code>subs</code>.', 'The <code>bne</code> still works because <code>add</code> has no S.'], why: 'Same instructions, same count, fewer stalls — the free kind of optimisation.' },
    { k: 'mcq', q: 'What is software pipelining?', opts: ['Running two loops at once', 'Loading the data for the next iteration while processing the current one', 'Using LDM', 'Unrolling by 2'], a: 1, why: 'It keeps a memory request permanently in flight so the core never waits.' },
    { k: 'bug', q: 'This rescheduling broke the loop. Why?', code: '1:  ldr  r3, [r1], #4\n    adds r2, r2, #-1\n    add  r0, r0, r3\n    bne  1b', opts: ['<code>adds r2, r2, #-1</code> is not a valid instruction', 'Nothing is wrong', 'The branch is backwards', '<code>ldr</code> cannot be post-indexed'], a: 0, why: 'ARM immediates are unsigned; most assemblers will rewrite this as <code>SUBS r2, r2, #1</code>, but writing what you mean is safer — and if the assembler does not, it is an error.' },
    { k: 'mcq', q: 'On a dual-issue in-order core, which instruction pairing is most likely to issue together?', opts: ['Two loads', 'A load and an independent ALU operation', 'Two branches', 'A load and the ADD that uses it'], a: 1, why: 'Different execution units and no dependency is the recipe for dual issue.' }
  ]
},

/* ------------------------------------------------------------------ 7.6 */
{
  id: 'u7l6', title: 'Cache, alignment and PLD', goal: 'Make the memory system work with your loop instead of against it.',
  teach: [
    { t: 'p', x: 'A loop that walks memory does not read bytes — it reads <b>cache lines</b>, typically 32 or 64 bytes at a time. Everything about loop performance over large data follows from that.' },
    { t: 'table', head: ['Access pattern', 'Cache behaviour'], rows: [
      ['Sequential forwards', 'Best. The hardware prefetcher recognises it and fetches ahead.'],
      ['Sequential backwards', 'Usually fine, sometimes not prefetched.'],
      ['Fixed large stride', 'Bad. One useful word per line fetched.'],
      ['Random', 'Worst. Every access a potential miss.'],
      ['Two streams', 'Fine. Prefetchers track several streams.']
    ] },
    { t: 'h', x: 'PLD: asking for data early' },
    { t: 'code', cap: 'Preload several lines ahead', x: '1:  pld   [r1, #128]     @ start fetching 128 bytes ahead\n    ldmia r1!, {r3-r10}\n    stmia r0!, {r3-r10}\n    subs  r2, r2, #32\n    bhs   1b' },
    { t: 'p', x: '<code>PLD</code> has no architectural effect at all — it cannot fault, it changes no register, and on a core without preload support it is a no-op. Its only job is to start a cache line fetch early enough that the real load finds the data already there.' },
    { t: 'note', x: 'The distance matters. Too close and the data has not arrived; too far and you evict what you are still using. A common starting point is 2–4 cache lines ahead, then measure.' },
    { t: 'h', x: 'Loop alignment' },
    { t: 'p', x: 'A loop whose top is aligned to a cache line or to an 8-byte boundary fetches more efficiently. <code>.balign 16</code> before the loop label costs a few padding bytes and occasionally buys a measurable improvement on in-order cores.' },
    { t: 'code', cap: 'Aligning the loop head', x: '    .balign 16\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'h', x: 'The thing that beats all of this' },
    { t: 'p', x: 'Changing your data layout. A loop over an array of structs touching one field wastes most of every cache line. Splitting into separate arrays — "struct of arrays" — can be worth more than every other optimisation in this unit put together.' }
  ],
  real: {
    title: 'Struct of arrays in a particle system',
    text: 'Ten thousand particles with position, velocity, colour and lifetime as one struct means an update loop that touches position drags colour and lifetime through the cache with it. Four separate arrays mean the position loop reads nothing but positions — often a 3–4× speedup with no change to the instructions at all.',
    code: '@ array of structs: 32-byte stride, 8 useful bytes per line\n1:  ldr  r3, [r1], #32\n    @ ...\n\n@ struct of arrays: every byte of every line is used\n1:  ldmia r1!, {r3-r10}\n    @ ...'
  },
  deep: {
    kind: 'pitfall',
    title: 'LDM does not forgive misalignment the way LDR does',
    text: 'Most ARMv7 cores let a plain <code>LDR</code> or <code>STR</code> quietly handle an address that is not a multiple of 4, splitting it into extra bus cycles instead of faulting — until <code>SCTLR.A</code>, the alignment-check bit, is set, at which point the same code takes a data abort instead. <code>LDM</code>, <code>STM</code>, <code>LDRD</code> and <code>STRD</code> never get that leniency: they require natural alignment unconditionally, <code>SCTLR.A</code> or not, which is easy to forget right after turning a byte loop into the word-at-a-time <code>LDM</code> form from the unrolling lesson.',
    a: { lab: 'Buggy — LDM on a pointer that is not guaranteed word-aligned', code: '    add   r1, r1, #1        @ r1 is now one byte off a word boundary\n1:  ldmia r1!, {r3-r6}      @ faults once SCTLR.A enables alignment checking\n    subs  r2, r2, #4\n    bne   1b' },
    b: { lab: 'Fixed — check alignment before switching to LDM', code: '    tst   r1, #3            @ low two bits clear means word-aligned\n    bne   2f\n1:  ldmia r1!, {r3-r6}      @ fast path: known aligned\n    subs  r2, r2, #4\n    bne   1b\n2:  nop                     @ unaligned: fall back to byte-at-a-time here' },
    note: 'Cache line size sneaks back in here too: a misaligned access that does not fault can still straddle two lines instead of one, which costs proportionally more on a Cortex-A15\'s 64-byte lines than an A8 or A9\'s 32-byte ones. None of this touches a Cortex-M core without a preload engine, where <code>PLD</code> was already a no-op and alignment trapping is controlled a different way entirely.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — PLD', cite: 'PLD signals that a memory access is likely; it has no effect on the architectural state and cannot generate an abort.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Cache and prefetch', cite: 'Sequential access patterns are detected by hardware prefetchers; strided and random patterns benefit from explicit preload.' }
  ],
  ex: [
    { k: 'mcq', q: 'What does <code>PLD</code> change architecturally?', opts: ['It loads a register', 'Nothing — it is a hint with no architectural effect', 'It sets the flags', 'It flushes the cache'], a: 1, why: 'That is exactly why it is safe to sprinkle into loops: it cannot fault and cannot be wrong, only useless.' },
    { k: 'mcq', q: 'Which access pattern is worst for a data cache?', opts: ['Sequential forwards', 'Sequential backwards', 'A large fixed stride', 'Two sequential streams'], a: 2, why: 'A large stride fetches a whole line to use one word of it, wasting most of the bandwidth.' },
    { k: 'mcq', q: 'Why can "struct of arrays" beat every instruction-level optimisation?', opts: ['It uses fewer registers', 'It makes every byte of every fetched cache line useful, which attacks the dominant cost', 'It shortens the code', 'It avoids branches'], a: 1, why: 'Memory is the bottleneck; layout decides how much of each fetch you actually use.' },
    { k: 'code', q: 'Add a <code>.balign 16</code> before the loop and a <code>pld</code> that looks 64 bytes ahead. The sum must stay 36.', start: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', check: [{ reg: 'r0', eq: 36 }, { contains: 'pld' }, { contains: 'balign' }], solution: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n    .balign 16\n1:  pld  [r1, #64]\n    ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', hints: ['<code>.balign 16</code> goes just before the loop label.', '<code>pld [r1, #64]</code> as the first instruction of the body.'], why: 'On this tiny array neither helps, which is the lesson: these are tools for loops over data far larger than the cache.' },
    { k: 'mcq', q: 'Why might you deliberately align a hot lookup table to a cache-line boundary?', opts: ['To save memory', 'So a lookup crosses into a fresh, not-yet-fetched line as rarely as possible', 'Because ARMv7 refuses unaligned loads', 'For readability'], a: 1, why: 'Same instinct as aligning the loop head earlier in this lesson: fewer cache-line boundaries crossed means fewer avoidable misses.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
