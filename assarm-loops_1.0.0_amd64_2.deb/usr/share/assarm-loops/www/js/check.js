/* AssArm: Loops — exercise runner and checker (shared by the app and the build-time validator) */
(function (G) {
  'use strict';
  const ARM = G.ARM;

  const HALT_TAIL = '\n.text\n__assarm_done:\n    ldr r12, =0x20020014\n    str r12, [r12]\n';

  function stripComments(src) {
    return String(src).split('\n').map(l => l.replace(/[@;].*$/, '').replace(/\/\/.*$/, '')).join('\n');
  }

  /* Run a user program. Returns {ok, cpu, asm, errors, ranOut} */
  function runProgram(src, opts) {
    opts = opts || {};
    const asm = ARM.assemble(src + HALT_TAIL);
    if (asm.errors.length) return { ok: false, asm, errors: asm.errors };
    const cpu = new ARM.CPU();
    cpu.load(asm);
    const budget = opts.budget || 400000;
    cpu.run(budget);
    return { ok: true, asm, cpu, errors: [] };
  }

  function symAddr(asm, name) {
    const v = asm.syms[name];
    return v === undefined ? null : (v >>> 0);
  }

  function fmt(v) {
    const n = v >>> 0;
    return n + (n > 9 ? ' (0x' + n.toString(16).toUpperCase() + ')' : '');
  }

  /* Evaluate a list of check clauses against a finished run.
     Returns {pass:bool, fails:[string], notes:[string]} */
  function evaluate(src, checks, res) {
    const fails = [], notes = [];
    const cpu = res.cpu, asm = res.asm;
    const clean = stripComments(src).toLowerCase();
    const wantsInfinite = (checks || []).some(x => x.infinite);

    for (const c of (checks || [])) {
      if (c.notContains !== undefined) {
        if (clean.indexOf(String(c.notContains).toLowerCase()) >= 0)
          fails.push('Your code still uses <code>' + c.notContains + '</code> — this exercise asks you to do without it.');
        continue;
      }
      if (c.contains !== undefined) {
        if (clean.indexOf(String(c.contains).toLowerCase()) < 0)
          fails.push('Your code needs to use <code>' + c.contains + '</code>.');
        continue;
      }
      if (c.regex !== undefined) {
        if (!new RegExp(c.regex, c.flags || 'i').test(clean))
          fails.push(c.desc || 'Your code does not have the shape this exercise is asking for.');
        continue;
      }
      if (c.notRegex !== undefined) {
        if (new RegExp(c.notRegex, c.flags || 'i').test(clean))
          fails.push(c.desc || 'Your code still has a shape this exercise asks you to remove.');
        continue;
      }
      if (c.infinite) {
        if (!(cpu.error && /without stopping/.test(cpu.error)))
          fails.push('This loop was supposed to run for ever, but it stopped on its own.');
        continue;
      }
      // everything below needs a clean run
      if (cpu.error && wantsInfinite && /without stopping/.test(cpu.error)) {
        // expected: the program was supposed to loop for ever
      } else if (cpu.error && !c.allowError) {
        fails.push(cpu.error);
        break;
      }
      if (c.reg !== undefined) {
        const n = /^r(\d+)$/.exec(c.reg) ? +/^r(\d+)$/.exec(c.reg)[1] : ({ sp: 13, lr: 14, pc: 15 })[c.reg];
        const got = cpu.r[n] >>> 0, want = c.eq >>> 0;
        if (got !== want) fails.push(c.reg + ' should be ' + fmt(want) + ' but it is ' + fmt(got) + '.');
        else notes.push(c.reg + ' = ' + fmt(got) + ' ✓');
        continue;
      }
      if (c.flag !== undefined) {
        const got = !!cpu[c.flag];
        if (got !== !!c.eq) fails.push('Flag ' + c.flag + ' should be ' + (c.eq ? 'set' : 'clear') + '.');
        continue;
      }
      if (c.memLabel !== undefined) {
        const base = symAddr(asm, c.memLabel);
        if (base === null) { fails.push('There is no label called <code>' + c.memLabel + '</code> in your program — keep the <code>.data</code> block.'); continue; }
        if (c.words) {
          for (let i = 0; i < c.words.length; i++) {
            const got = cpu.read32(base + i * 4) >>> 0, want = c.words[i] >>> 0;
            if (got !== want) { fails.push(c.memLabel + '[' + i + '] should be ' + fmt(want) + ' but it is ' + fmt(got) + '.'); break; }
          }
        }
        if (c.bytes) {
          for (let i = 0; i < c.bytes.length; i++) {
            const got = cpu.read8(base + i), want = c.bytes[i] & 0xff;
            if (got !== want) { fails.push(c.memLabel + '[' + i + '] should be ' + want + ' but it is ' + got + '.'); break; }
          }
        }
        continue;
      }
      if (c.mem !== undefined) {
        const got = cpu.read32(c.mem) >>> 0;
        if (got !== (c.eq >>> 0)) fails.push('The word at 0x' + (c.mem >>> 0).toString(16) + ' should be ' + fmt(c.eq) + ' but it is ' + fmt(got) + '.');
        continue;
      }
      if (c.maxInsn !== undefined) {
        if (cpu.insnCount > c.maxInsn) fails.push('Too many instructions executed: ' + cpu.insnCount + ', the budget is ' + c.maxInsn + '.');
        else notes.push(cpu.insnCount + ' instructions (budget ' + c.maxInsn + ') ✓');
        continue;
      }
      if (c.maxCycles !== undefined) {
        if (cpu.cycles > c.maxCycles) fails.push('Too many cycles: ' + cpu.cycles + ', the budget is ' + c.maxCycles + '.');
        else notes.push(cpu.cycles + ' cycles (budget ' + c.maxCycles + ') ✓');
        continue;
      }
      if (c.minCycles !== undefined) {
        if (cpu.cycles < c.minCycles) fails.push('That finished in ' + cpu.cycles + ' cycles — too few. Expected at least ' + c.minCycles + '.');
        continue;
      }
      if (c.console !== undefined) {
        if (cpu.console !== c.console) fails.push('Output should be "' + c.console + '" but it was "' + cpu.console + '".');
        continue;
      }
      if (c.gpio !== undefined) {
        const n = cpu.gpioToggles.length;
        if (n !== c.gpio) fails.push('The buzzer pin should have been toggled ' + c.gpio + ' times, but it was toggled ' + n + ' times.');
        continue;
      }
      if (c.gpioAtLeast !== undefined) {
        if (cpu.gpioToggles.length < c.gpioAtLeast) fails.push('The pin was toggled only ' + cpu.gpioToggles.length + ' times; at least ' + c.gpioAtLeast + ' were expected.');
        continue;
      }
      if (c.fbBytes !== undefined) {
        let n = 0; for (let i = 0; i < cpu.fb.length; i++) if (cpu.fb[i] !== 0) n++;
        if (n !== c.fbBytes) fails.push('Expected ' + c.fbBytes + ' non-zero bytes in the framebuffer, found ' + n + '.');
        continue;
      }
      if (c.fbAtLeast !== undefined) {
        let n = 0; for (let i = 0; i < cpu.fb.length; i++) if (cpu.fb[i] !== 0) n++;
        if (n < c.fbAtLeast) fails.push('Only ' + n + ' bytes of the framebuffer were written; expected at least ' + c.fbAtLeast + '.');
        continue;
      }
      if (c.fbPixel !== undefined) {
        const [x, y] = c.fbPixel;
        const b = cpu.fb[ARM.fbRowOffset(y) + (x >> 3)];
        const on = (b >> (7 - (x & 7))) & 1;
        if (!on !== !c.eq) fails.push('Pixel (' + x + ',' + y + ') should be ' + (c.eq ? 'lit' : 'dark') + '.');
        continue;
      }
      if (c.textAt !== undefined) {
        const s = String.fromCharCode.apply(null, Array.from(cpu.tpage.slice(c.textAt, c.textAt + c.eq.length)));
        if (s !== c.eq) fails.push('The text page should read "' + c.eq + '" at offset ' + c.textAt + ' but it reads "' + s + '".');
        continue;
      }
    }
    return { pass: fails.length === 0, fails, notes };
  }

  function checkExercise(src, checks, opts) {
    const res = runProgram(src, opts);
    if (!res.ok) {
      return {
        pass: false,
        fails: res.errors.map(e => 'Line ' + e.line + ': ' + e.message),
        notes: [], asmError: true
      };
    }
    const ev = evaluate(src, checks, res);
    ev.cpu = res.cpu;
    ev.asm = res.asm;
    return ev;
  }

  G.LoopCheck = { runProgram, checkExercise, evaluate, HALT_TAIL, stripComments };
})(typeof window !== 'undefined' ? window : globalThis);
