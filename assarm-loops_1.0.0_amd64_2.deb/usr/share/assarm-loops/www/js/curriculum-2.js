/* AssArm: Loops — curriculum part 2 : Units 4-6 */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u4', n: 4, title: 'Loop Control', icon: '⤴', color: '#e06c9f',
    blurb: 'Break, continue, nesting, and the register discipline that stops nested loops from eating each other.',
    lessons: [

/* ------------------------------------------------------------------ 4.1 */
{
  id: 'u4l1', title: 'Break: leaving early', goal: 'Exit a loop from the middle without corrupting state.',
  teach: [
    { t: 'p', x: 'A <code>break</code> in C is a forward branch to the instruction after the loop. There is nothing else to it — but where you put it changes what the loop costs.' },
    { t: 'code', cap: 'Search with an early exit', x: '@ find the first element of a[] equal to r5; index -> r0, or -1 if absent\n    ldr  r1, =a\n    mov  r2, #8          @ how many\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    cmp  r3, r5\n    beq  found           @ the "break"\n    add  r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n    mvn  r0, #0          @ not found: r0 = -1\nfound:' },
    { t: 'h', x: 'Two exits means two answers' },
    { t: 'p', x: 'A loop with a break has two ways out, and each one leaves the registers in a different state. The instruction after the loop must cope with both — which is why the "not found" case here sets r0 to −1 <i>before</i> falling into the shared exit label.' },
    { t: 'note', x: 'Get into the habit of writing down, in a comment, what each register holds at <b>each</b> exit. Most break-related bugs are really "I forgot this path existed".' },
    { t: 'h', x: 'Breaking out of the middle of a body' },
    { t: 'p', x: 'If the break condition is discovered halfway through the body, you can branch straight out — you do not have to finish the iteration. But anything the rest of the body would have done (advancing a second pointer, closing a resource) now does not happen. That asymmetry is the whole difficulty.' },
    { t: 'code', cap: 'Careful: the second pointer does not advance', x: '1:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    beq  2f              @ break here and r4 was NOT advanced\n    strb r3, [r4], #1\n    subs r2, r2, #1\n    bne  1b\n2:' }
  ],
  real: {
    title: 'The first-match scan in a hash table',
    text: 'Open-addressing hash tables probe a sequence of slots and break on the first match or the first empty slot. The loop has three exits — found, empty, table full — and every one of them must leave a well-defined answer. This is where real bugs live.',
    code: 'probe:\n    ldr  r3, [r1, r0, lsl #2]\n    cmp  r3, r5\n    beq  hit\n    cmp  r3, #0\n    beq  miss            @ empty slot: the key is not here\n    add  r0, r0, #1\n    and  r0, r0, r6      @ wrap (mask = size-1)\n    subs r2, r2, #1\n    bne  probe\n    b    table_full'
  },
  deep: {
    kind: 'cores',
    title: 'A predictor guesses; Cortex-M0 cannot',
    text: 'Whether <code>beq found</code> is taken depends on the data, not the code, so this is exactly the branch a hardware predictor exists for. Cortex-A7 and Cortex-A9 keep a table of recently seen branches and their outcomes, and a correct guess lets the fetch unit keep running down the taken path with no bubble at all. Cortex-M0\'s three-stage pipeline has nothing of the kind: every taken branch flushes whatever was already fetched behind it and costs the same fixed handful of cycles regardless of the data.',
    code: '@ whichever way "beq found" goes this iteration is a guess worth making\n1:  ldr  r3, [r1], #4\n    cmp  r3, r5\n    beq  found            @ data-dependent: a predictor guesses, Cortex-M0 cannot\n    add  r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\nfound:',
    note: 'A search loop that always breaks near the start looks equally fast on both cores. One where the match position is random shows the difference: the A-profile core is right about as often as the data lets it be, and the M0 pays the flush every single time.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — B', cite: 'A conditional branch out of a loop body is an ordinary B<cond>; the architecture has no dedicated loop-exit instruction.' },
    { src: 'Cortex-M0 Technical Reference Manual (DDI 0432C), Pipeline', cite: 'The Cortex-M0 uses a simple 3-stage pipeline with no branch prediction; a taken branch is always refetched from its target.' }
  ],
  ex: [
    { k: 'code', q: 'Find the index of the first element of <code>a</code> equal to 7. Put it in r0, or −1 (0xFFFFFFFF) if it is not there.', start: '    ldr  r1, =a\n    mov  r2, #6\n    mov  r0, #0\n1:\n\n.data\na: .word 3, 9, 7, 1, 7, 2\n', check: [{ reg: 'r0', eq: 2 }], solution: '    ldr  r1, =a\n    mov  r2, #6\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    cmp  r3, #7\n    beq  2f\n    add  r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n    mvn  r0, #0\n2:\n\n.data\na: .word 3, 9, 7, 1, 7, 2\n', hints: ['Compare each loaded value against 7 and branch forwards when equal.', 'After the loop falls through, set r0 to −1 with <code>mvn r0, #0</code>.'], why: 'The first 7 is at index 2. The <code>mvn</code> only runs on the fall-through path.' },
    { k: 'mcq', q: 'A loop has a break in the middle of its body. What is the main hazard?', opts: ['The flags are lost', 'Work that the rest of the body would have done — pointer updates, counters — is skipped', 'The branch will be out of range', 'The loop cannot be unrolled'], a: 1, why: 'The state after a mid-body break differs from the state after a normal exit, and the code afterwards has to handle both.' },
    { k: 'bug', q: 'This search returns the wrong index when the value <i>is</i> found. Why?', code: '    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, #1\n    cmp  r3, r5\n    beq  2f\n    subs r2, r2, #1\n    bne  1b\n2:', opts: ['<code>ldr</code> should be <code>ldrb</code>', 'The index is incremented before the comparison, so a match reports index+1', 'r2 is never initialised', '<code>beq</code> should be <code>bne</code>'], a: 1, why: 'Increment after the test, or subtract 1 on the found path. Off-by-one on the break path is the classic version of this bug.' },
    { k: 'order', q: 'Order a search loop that breaks on a match and sets r0 = −1 otherwise.', lines: ['    mvn r0, #0', '    beq 2f', '2:', '1:  ldr r3, [r1], #4', '    cmp r3, r5', '    subs r2, r2, #1\n    bne 1b'], a: [3, 4, 1, 5, 0, 2], why: 'Load, compare, break, loop control, then the not-found result, then the shared exit label.' },
    { k: 'mcq', q: 'How many exits does the hash-table probe loop in this lesson have?', opts: ['One', 'Two', 'Three', 'Four'], a: 2, why: 'Found, empty slot, and the loop running out — three, and each one has to leave a defined answer.' }
  ]
},

/* ------------------------------------------------------------------ 4.2 */
{
  id: 'u4l2', title: 'Continue: skipping an iteration', goal: 'Skip the rest of a body without skipping the loop control.',
  teach: [
    { t: 'p', x: 'A <code>continue</code> jumps to the loop\'s update-and-test, not to the top. Get that wrong and you skip the decrement, and the loop never ends.' },
    { t: 'code', cap: 'Sum only the even elements', x: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    tst  r3, #1\n    bne  2f              @ odd: "continue"\n    add  r0, r0, r3\n2:  subs r2, r2, #1      @ <- the continue lands HERE, not at 1:\n    bne  1b' },
    { t: 'note', x: 'The continue target label goes <b>between</b> the body and the loop control. If you branch back to <code>1b</code> instead, the counter is never decremented on the skipped iterations.' },
    { t: 'h', x: 'Or skip the branch entirely' },
    { t: 'p', x: 'On ARM, a one-instruction body that you were going to skip is usually better written with a condition on the instruction itself — no branch at all:' },
    { t: 'code', cap: 'The same loop, branchless', x: '1:  ldr  r3, [r1], #4\n    tst  r3, #1\n    addeq r0, r0, r3     @ add only when the low bit is clear\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'p', x: 'Five instructions instead of six, and — far more importantly — one branch per iteration instead of two, with no chance of a mispredict. Unit 6 is entirely about this technique.' }
  ],
  real: {
    title: 'Filtering a packet stream',
    text: 'A ring-buffer consumer walks every entry and processes only those matching a filter. The filtered-out case is usually the common one, so making it cheap — a conditional instruction rather than a branch — is where the performance is.',
    code: '1:  ldr  r3, [r1], #4\n    and  r4, r3, r6      @ mask off the type field\n    cmp  r4, r7\n    blne handle_packet   @ call only when it matches\n    subs r2, r2, #1\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: '-O2 will not unroll this for you',
    text: 'Loop unrolling is one of the classic optimisations gcc keeps out of <code>-O2</code> entirely, gated behind its own flag rather than folded into a level. At <code>-O2</code> this eight-element sum-the-evens loop compiles to exactly the loop you wrote, predicated add and all; add <code>-funroll-loops</code> to the same command line and the body is duplicated several times over so the loop control is paid for less often.',
    a: { lab: 'C', lang: 'c', code: 'int sum_even(int *a, int n) {\n    int s = 0;\n    for (int i = 0; i < n; i++)\n        if ((a[i] & 1) == 0)\n            s += a[i];\n    return s;\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: 'sum_even:\n    mov   r2, #0\n    cmp   r1, #0\n    ble   3f\n    mov   r3, #0\n1:  ldr   r12, [r0, r3, lsl #2]\n    tst   r12, #1\n    addeq r2, r2, r12\n    add   r3, r3, #1\n    cmp   r3, r1\n    blt   1b\n3:  mov   r0, r2\n    bx    lr' },
    note: 'The loop body here is one predicated add either way, so unrolling would spend code size to remove a branch that already predicts well. <code>-funroll-loops</code> is opt-in precisely because that trade is not always a good one.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — Conditional execution', cite: 'Most A32 instructions carry a 4-bit condition field, allowing short conditional sequences to be written without branches.' }
  ],
  ex: [
    { k: 'mcq', q: 'Where must a <code>continue</code> branch land?', opts: ['At the top of the loop', 'At the update-and-test, after the body', 'After the loop', 'At the first instruction of the body'], a: 1, why: 'Branching to the top skips the counter update, and the loop never terminates.' },
    { k: 'code', q: 'Sum only the elements of <code>a</code> that are greater than 10. Answer in r0.', start: '    ldr  r1, =a\n    mov  r2, #7\n    mov  r0, #0\n1:\n\n.data\na: .word 4, 25, 10, 11, 3, 40, 9\n', check: [{ reg: 'r0', eq: 76 }], solution: '    ldr  r1, =a\n    mov  r2, #7\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    cmp  r3, #10\n    addhi r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 4, 25, 10, 11, 3, 40, 9\n', hints: ['You can do it with a branch, or with one conditional add.', '<code>cmp r3, #10</code> then <code>addhi r0, r0, r3</code>.'], why: '25 + 11 + 40 = 76. Note that 10 itself is not greater than 10.' },
    { k: 'bug', q: 'This loop hangs. Why?', code: '    mov  r2, #5\n1:  ldr  r3, [r1], #4\n    tst  r3, #1\n    bne  1b            @ "continue"\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b', opts: ['<code>tst</code> should be <code>cmp</code>', 'The continue branches to the top, so odd elements never decrement r2', 'r1 runs off the end', '<code>subs</code> needs no S'], a: 1, why: 'It also walks r1 off the end of the array. The continue must land after the body, before the loop control.' },
    { k: 'code', q: 'Count how many of the 8 bytes at <code>b</code> are NOT zero, using a conditional instruction and no branch inside the body.', start: '    ldr  r1, =b\n    mov  r2, #8\n    mov  r0, #0\n1:\n\n.data\nb: .byte 0,5,0,7,7,0,1,0\n', check: [{ reg: 'r0', eq: 4 }, { maxInsn: 45 }], solution: '    ldr  r1, =b\n    mov  r2, #8\n    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    addne r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n\n.data\nb: .byte 0,5,0,7,7,0,1,0\n', hints: ['<code>cmp r3, #0</code> then <code>addne</code>.'], why: '5, 7, 7 and 1 are non-zero — four of them.' },
    { k: 'mcq', q: 'Why is a conditional instruction often better than a continue branch?', opts: ['It uses fewer registers', 'It removes a branch, which removes a possible mispredict, and shortens the loop', 'Conditional instructions are always faster', 'It allows the loop to be nested'], a: 1, why: 'When the body is one or two instructions, predication wins. When it is long, the branch wins — see Unit 6.' }
  ]
},

/* ------------------------------------------------------------------ 4.3 */
{
  id: 'u4l3', title: 'Nested loops', goal: 'Nest loops without the inner one destroying the outer one\'s state.',
  teach: [
    { t: 'p', x: 'Nesting is easy to write and easy to get wrong. The rule is simple: <b>the inner loop must not touch any register the outer loop depends on</b>, and the inner counter must be re-initialised on every outer iteration.' },
    { t: 'code', cap: 'A 3 × 4 nest', x: '    mov  r0, #0          @ total\n    mov  r1, #3          @ outer counter\nouter:\n    mov  r2, #4          @ INNER COUNTER RESET — inside the outer loop\ninner:\n    add  r0, r0, #1\n    subs r2, r2, #1\n    bne  inner\n    subs r1, r1, #1\n    bne  outer\n@ r0 = 12' },
    { t: 'note', x: 'If <code>mov r2, #4</code> were above <code>outer:</code>, the inner loop would run 4 times on the first outer pass and 0 times… meaning 2³² times… on every pass after that. Resetting the inner counter is not optional.' },
    { t: 'h', x: 'Register budget' },
    { t: 'table', head: ['Depth', 'Registers needed just for control'], rows: [
      ['1 loop', '1 counter'],
      ['2 loops', '2 counters + often 2 pointers'],
      ['3 loops', '3 counters + 3 pointers = half your register file']
    ] },
    { t: 'p', x: 'This is why deeply nested assembly loops are rare. Past two levels, it is usually better to flatten — compute one combined counter — or to call a subroutine for the inner loop and let the calling convention manage the registers.' },
    { t: 'h', x: 'Flattening' },
    { t: 'code', cap: 'Two loops become one', x: '@ instead of for(y=0;y<H;y++) for(x=0;x<W;x++)\n@ do:          for(i=0;i<W*H;i++)\n    mov  r2, #(4*6)      @ W*H\n1:  @ body works on a flat index\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'p', x: 'Flattening works whenever the body does not need x and y separately. If it does — as in the screen loops of Unit 9 — the nest has to stay.' }
  ],
  real: {
    title: 'Matrix multiply, three deep',
    text: 'The classic triple nest is i, j, k. Hand-written ARM versions keep the innermost loop free of everything except the accumulate, and push all the address arithmetic outwards, because the inner loop runs n³ times and the outer one only n.',
    code: '@ innermost loop of a matrix multiply: keep it tiny\n1:  ldr  r4, [r1], #4\n    ldr  r5, [r2], r6    @ r6 = row stride\n    mla  r7, r4, r5, r7\n    subs r3, r3, #1\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'Hoisting is automatic; unrolling is not',
    text: 'Loop-invariant code motion is a routine part of <code>-O2</code>: anything that does not change across an iteration gets computed once and carried forward, whether you wrote it that way or not. Here the compiler notices that <code>r*cols+c</code> only ever walks forward through memory and replaces the multiply with a pointer that is simply carried from one row into the next — the flattening this lesson teaches by hand, done for you. What <code>-O2</code> will not do on its own is unroll either loop; that still needs <code>-funroll-loops</code>.',
    a: { lab: 'C', lang: 'c', code: 'int total(int *a, int rows, int cols) {\n    int s = 0;\n    for (int r = 0; r < rows; r++)\n        for (int c = 0; c < cols; c++)\n            s += a[r * cols + c];\n    return s;\n}' },
    b: { lab: 'gcc -O2, ARMv7 (rows and cols unknown until run time)', code: 'total:\n    mov   r3, #0\n    cmp   r1, #0\n    ble   4f\n1:  mov   r4, #0\n    cmp   r2, #0\n    ble   3f\n2:  ldr   r5, [r0], #4\n    add   r3, r3, r5\n    add   r4, r4, #1\n    cmp   r4, r2\n    blt   2b\n3:  subs  r1, r1, #1\n    bne   1b\n4:  mov   r0, r3\n    bx    lr' },
    note: 'There is no <code>MUL</code> anywhere in the output, even though the source multiplies <code>r</code> by <code>cols</code> in plain sight. Do not read the absence of an instruction as the absence of the operation — the compiler moved the work into a pointer increment instead of removing it.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop nesting', cite: 'Address computation and loop-invariant values should be hoisted to the outermost loop in which they remain constant.' },
    { src: 'GCC documentation, Options That Control Optimization', cite: '-funroll-loops is not enabled by -O2 or -O3; it must be requested explicitly, or enabled by feedback-directed options such as -fprofile-use.' }
  ],
  ex: [
    { k: 'code', q: 'Write a 5 × 6 nest that leaves 30 in r0.', start: '    mov  r0, #0\n    mov  r1, #5\n1:\n', check: [{ reg: 'r0', eq: 30 }], solution: '    mov  r0, #0\n    mov  r1, #5\n1:  mov  r2, #6\n2:  add  r0, r0, #1\n    subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n', hints: ['Reset the inner counter at the top of the outer body.', 'Use <code>2:</code> / <code>2b</code> for the inner loop.'], why: 'Five outer passes, six inner each.' },
    { k: 'bug', q: 'This should print a 4 × 4 grid but the inner loop runs a very long time on the second pass. Why?', code: '    mov  r2, #4\n    mov  r1, #4\n1:\n2:  add  r0, r0, #1\n    subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b', opts: ['r1 and r2 are swapped', 'The inner counter is initialised outside the outer loop, so it is already 0 on the second pass', '<code>bne 2b</code> should be <code>bne 1b</code>', 'r0 is never initialised'], a: 1, why: 'On the second outer pass r2 is 0; <code>subs</code> makes it 0xFFFFFFFF and the inner loop runs about four billion times.' },
    { k: 'mcq', q: 'Where should loop-invariant address arithmetic go?', opts: ['In the innermost loop', 'In the outermost loop in which it stays constant', 'Anywhere', 'In a subroutine'], a: 1, why: 'Work in the inner loop is paid n times more often. Hoisting is the single biggest win in nested code.' },
    { k: 'code', q: 'Fill the 12 bytes at <code>grid</code> with the value of the outer counter: rows of 4, three rows, values 3, 2, 1.', start: '    ldr  r0, =grid\n    mov  r1, #3\n1:\n\n.data\ngrid: .space 12\n', check: [{ memLabel: 'grid', bytes: [3, 3, 3, 3, 2, 2, 2, 2, 1, 1, 1, 1] }], solution: '    ldr  r0, =grid\n    mov  r1, #3\n1:  mov  r2, #4\n2:  strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  2b\n    subs r1, r1, #1\n    bne  1b\n\n.data\ngrid: .space 12\n', hints: ['The value to store is the outer counter r1.', 'Reset r2 to 4 inside the outer loop.'], why: 'The outer counter counts down 3, 2, 1 — and is also the data.' },
    { k: 'mcq', q: 'When can you flatten a two-level nest into one loop?', opts: ['Always', 'When the body does not need the two indices separately', 'When both counts are powers of two', 'Never'], a: 1, why: 'If the body needs x and y — as a screen plot does — the nest carries information the flat index would have to reconstruct.' }
  ]
},

/* ------------------------------------------------------------------ 4.4 */
{
  id: 'u4l4', title: 'Counters that are not counters', goal: 'Use pointer comparison and sentinel values instead of a separate counter.',
  teach: [
    { t: 'p', x: 'A counter is one more register to keep and one more instruction to execute. Often the loop already contains something that tells you when to stop.' },
    { t: 'code', cap: 'Compare the pointer against the end', x: '    ldr  r1, =a\n    add  r2, r1, #32     @ end address, computed once\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    blo  1b' },
    { t: 'p', x: 'No counter at all. The pointer, which you needed anyway, is doing double duty. On a loop over 8 words that is one register and eight instructions saved.' },
    { t: 'h', x: 'Count down on the pointer' },
    { t: 'code', cap: 'The two-instruction array loop', x: '    ldr  r1, =a\n    add  r1, r1, #32     @ start at the end\n1:  ldr  r3, [r1, #-4]!  @ pre-decrement\n    adds r0, r0, r3\n    cmp  r1, r4          @ r4 = base\n    bhi  1b' },
    { t: 'h', x: 'Negative-offset indexing: the real trick' },
    { t: 'p', x: 'Point the base at the <i>end</i> of the array and use a negative index that counts up to zero. Now the loop control is a single <code>ADDS</code>/<code>BNE</code> and the index is free:' },
    { t: 'code', cap: 'Index counts up to zero', x: '    ldr  r1, =a\n    add  r1, r1, #32     @ one past the end\n    mvn  r2, #31         @ NOT(31) = -32\n1:  ldr  r3, [r1, r2]    @ a[8 + (r2/4)]\n    add  r0, r0, r3\n    adds r2, r2, #4      @ climbs towards 0, sets Z at the end\n    bne  1b' },
    { t: 'note', x: 'This shape shows up constantly in optimised library code and in compiler output, and the first time you meet it in a disassembly it is baffling. Now it will not be.' }
  ],
  real: {
    title: 'How Clang writes array loops',
    text: 'At -O2, LLVM very often converts a count-up index loop into exactly the negative-offset form above, because it turns the loop control into one flag-setting add. Recognising it is a big part of being able to read optimised ARM output.',
    code: '@ clang -O2 for: for (i=0;i<n;i++) s+=a[i];\n    add  r0, r0, r1, lsl #2\n    rsb  r1, r1, #0\n    lsl  r1, r1, #2\n.LBB0:\n    ldr  r3, [r0, r1]\n    add  r2, r2, r3\n    adds r1, r1, #4\n    bne  .LBB0'
  },
  deep: {
    kind: 'pitfall',
    title: 'A pointer compared with a signed condition',
    text: 'Addresses are unsigned, so a loop that walks a pointer up to an end value must compare with an unsigned condition — <code>BLO</code>, <code>BHI</code>, <code>BLS</code>, <code>BHS</code> — never a signed one. <code>BLT</code>/<code>BGT</code> happen to give the same answer for ordinary stack and heap addresses, which is exactly what lets the bug survive testing: it only shows up once a pointer lands at or above 0x80000000, where the signed comparison flips.',
    a: { lab: 'Wrong: signed comparison', code: '    ldr  r1, =a\n    add  r2, r1, #32     @ end address\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    blt  1b              @ signed: wrong once addresses reach 0x80000000' },
    b: { lab: 'Right: unsigned comparison', code: '    ldr  r1, =a\n    add  r2, r1, #32     @ end address\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    blo  1b              @ unsigned: correct for every address' },
    note: 'This is why the instruction set gives you two complete families of comparison — LO/LS/HI/HS for unsigned quantities like addresses and sizes, LT/LE/GT/GE for signed ones like counts and coordinates. Choose the family by what the bits mean, never by habit.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop termination', cite: 'Comparing the induction variable against a precomputed limit avoids maintaining a separate loop counter.' }
  ],
  ex: [
    { k: 'code', q: 'Sum the 6 words at <code>a</code> using a pointer comparison — no counter register.', start: '    ldr  r1, =a\n    mov  r0, #0\n\n.data\na: .word 1,2,3,4,5,6\n', check: [{ reg: 'r0', eq: 21 }, { notContains: 'subs' }], solution: '    ldr  r1, =a\n    mov  r0, #0\n    add  r2, r1, #24\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    blo  1b\n\n.data\na: .word 1,2,3,4,5,6\n', hints: ['Compute the end address once: base + 24.', 'Compare the walking pointer against it with <code>blo</code>.'], why: 'The pointer is the counter. One fewer register in play.' },
    { k: 'mcq', q: 'In the negative-index form, why does the loop end?', opts: ['The pointer reaches the end address', 'The index climbs to zero and <code>ADDS</code> sets Z', 'A sentinel value is found', 'The counter underflows'], a: 1, why: 'That is the whole trick: reaching zero from below gives you the flag test for free.' },
    { k: 'code', q: 'Sum the 4 words at <code>a</code> using the negative-index form: base points one past the end, index starts at −16 and climbs to 0.', start: '    ldr  r1, =a\n    add  r1, r1, #16\n    mov  r0, #0\n\n.data\na: .word 10,20,30,40\n', check: [{ reg: 'r0', eq: 100 }, { contains: 'adds' }], solution: '    ldr  r1, =a\n    add  r1, r1, #16\n    mov  r0, #0\n    mvn  r2, #15\n1:  ldr  r3, [r1, r2]\n    add  r0, r0, r3\n    adds r2, r2, #4\n    bne  1b\n\n.data\na: .word 10,20,30,40\n', hints: ['<code>mvn r2, #15</code> gives −16 directly — NOT(15) is 0xFFFFFFF0.', 'The load is <code>ldr r3, [r1, r2]</code> with r1 one past the end.'], why: 'r2 goes −16, −12, −8, −4, 0. The last <code>adds</code> sets Z and the loop ends.' },
    { k: 'mcq', q: 'What does <code>mvn r2, #15</code> put in r2?', opts: ['15', '−15', '−16', '0xFFFFFFF0'], a: 2, why: 'MVN computes NOT(15) = 0xFFFFFFF0, which as a signed number is −16. Option 4 is the same bits but the question asked for the value.' },
    { k: 'bug', q: 'This pointer-compare loop processes one element too few. Why?', code: '    ldr  r1, =a\n    add  r2, r1, #24\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    bcc  1b\n    @ 6 words expected', opts: ['<code>bcc</code> should be <code>bls</code>', 'It does not — <code>add r2, r1, #24</code> is correct for 6 words, and BCC is BLO', 'The end address should be +20', '<code>ldr</code> should be pre-indexed'], a: 1, why: 'A trick question: this loop is correct. BCC and BLO are the same condition, and 6 words is 24 bytes. Learning to recognise <i>correct</i> code matters too.' }
  ]
},

/* ------------------------------------------------------------------ 4.5 */
{
  id: 'u4l5', title: 'Loops that call functions', goal: 'Protect loop state across BL, and know what the calling convention guarantees.',
  teach: [
    { t: 'p', x: '<code>BL</code> puts the return address in <b>LR</b> and branches. If your loop calls a function, two things are now at risk: LR itself, and every call-clobbered register.' },
    { t: 'table', head: ['Register', 'Survives a BL?'], rows: [
      ['r0–r3', 'No — arguments and return values'],
      ['r12 (IP)', 'No — scratch'],
      ['r4–r11', 'Yes, if the callee obeys the AAPCS'],
      ['LR (r14)', '<b>No</b> — the BL overwrites it'],
      ['SP (r13)', 'Yes — must be restored by the callee']
    ] },
    { t: 'note', x: 'A loop inside a function that calls another function <b>must</b> save LR, or the outer function can never return. <code>push {r4, lr}</code> at the top and <code>pop {r4, pc}</code> at the bottom is the standard idiom.' },
    { t: 'code', cap: 'A loop that calls out, done correctly', x: 'process_all:\n    push {r4, r5, lr}    @ save LR and the callee-saved regs we use\n    mov  r4, r0          @ pointer -> a register that survives calls\n    mov  r5, r1          @ count   -> likewise\n1:  ldr  r0, [r4], #4\n    bl   process_one     @ clobbers r0-r3, r12 and LR\n    subs r5, r5, #1\n    bne  1b\n    pop  {r4, r5, pc}    @ restore and return in one instruction' },
    { t: 'h', x: 'Why the counter moved to r5' },
    { t: 'p', x: 'If the counter had stayed in r1, <code>process_one</code> would be free to destroy it. Moving loop state into r4–r11 before the loop starts costs two instructions once, and makes the loop correct for ever.' },
    { t: 'h', x: 'POP into PC' },
    { t: 'p', x: '<code>pop {r4, r5, pc}</code> loads the saved LR straight into PC, which returns. It saves an instruction over <code>pop {r4, r5, lr}</code> + <code>bx lr</code>, and it is what every ARM compiler emits.' }
  ],
  real: {
    title: 'Callbacks and iterators',
    text: 'Any loop that takes a function pointer — a qsort comparator, an event dispatcher, a tree walker — pays this cost. The loop\'s own state must live in callee-saved registers, and the loop must push LR. Forgetting is not a subtle bug: the program returns to a random address.',
    code: 'for_each:\n    push {r4-r6, lr}\n    mov  r4, r0\n    mov  r5, r1\n    mov  r6, r2          @ the callback\n1:  ldr  r0, [r4], #4\n    blx  r6\n    subs r5, r5, #1\n    bne  1b\n    pop  {r4-r6, pc}'
  },
  deep: {
    kind: 'cores',
    title: 'A push costs about a cycle per register',
    text: 'PUSH and POP are STM/LDM under the alias, so saving eight registers is one instruction to fetch and decode — but the data still has to move. On a Cortex-A7 or Cortex-A9 the transfer itself costs roughly one cycle per register once the pipeline is filled, so <code>push {r4-r11, lr}</code> spends about nine cycles moving data on top of its single decode. That is still far cheaper than nine separate single-register pushes, which would pay the fetch-and-decode overhead nine times over as well.',
    code: '@ one instruction, nine registers -- roughly nine cycles of transfer, not one\nprocess_all:\n    push {r4-r11, lr}\n1:  ldr  r0, [r4], #4\n    bl   process_one\n    subs r5, r5, #1\n    bne  1b\n    pop  {r4-r11, pc}',
    note: 'This is why buying registers in this lesson is a real trade, not a free lunch: every register added to the list is another cycle at entry and exit, paid once per call, against a saving that only shows up if the loop runs enough iterations to need it.'
  },
  refs: [
    { src: 'Procedure Call Standard for the ARM Architecture (IHI 0042)', cite: 'A subroutine may freely modify r0–r3, r12, LR and the condition flags; r4–r11 and SP must be preserved.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — BL, BLX', cite: 'BL sets LR to the address of the instruction following the branch.' }
  ],
  ex: [
    { k: 'mcq', q: 'Your loop keeps a counter in r1 and calls a function each iteration. What happens?', opts: ['Nothing, r1 is preserved', 'The callee may destroy r1 — move the counter to r4–r11 first', 'The counter is saved automatically', 'BL refuses to assemble'], a: 1, why: 'r0–r3 are argument/scratch registers. Only r4–r11 are guaranteed across a call.' },
    { k: 'mcq', q: 'Why must a function containing a <code>BL</code> save LR?', opts: ['To keep the stack aligned', 'Because BL overwrites LR with the new return address, destroying its own', 'Because the callee reads it', 'It does not have to'], a: 1, why: 'Without saving it, the function has no way back to its own caller.' },
    { k: 'code', q: 'Complete this loop so it correctly calls <code>dbl</code> four times and leaves 240 in r5. (<code>dbl</code> doubles r0 and clobbers r1.)', start: '    mov  r5, #15\n    mov  r6, #4\n1:  mov  r0, r5\n    @ call dbl, keep the result\n    subs r6, r6, #1\n    bne  1b\n    b    end\n\ndbl:\n    mov  r1, #99\n    lsl  r0, r0, #1\n    bx   lr\nend:\n', check: [{ reg: 'r5', eq: 240 }], solution: '    mov  r5, #15\n    mov  r6, #4\n1:  mov  r0, r5\n    bl   dbl\n    mov  r5, r0\n    subs r6, r6, #1\n    bne  1b\n    b    end\n\ndbl:\n    mov  r1, #99\n    lsl  r0, r0, #1\n    bx   lr\nend:\n', hints: ['<code>bl dbl</code>, then copy r0 back into r5.', 'r5 is callee-saved, which is why the counter and the accumulator are safe there.'], why: '15 → 30 → 60 → 120 → 240. Note the loop state lives in r5 and r6, both safe across the call.' },
    { k: 'mcq', q: 'What does <code>pop {r4, pc}</code> do?', opts: ['Pops r4 and returns', 'Pops r4 and branches to the popped value — i.e. returns', 'Pops two values into r4', 'Is illegal'], a: 1, why: 'The saved LR goes straight into PC. It is the standard one-instruction epilogue.' },
    { k: 'bug', q: 'This function crashes when it returns. What is missing?', code: 'work:\n    mov  r4, r0\n    mov  r5, r1\n1:  ldr  r0, [r4], #4\n    bl   helper\n    subs r5, r5, #1\n    bne  1b\n    bx   lr', opts: ['<code>subs</code> should be <code>sub</code>', 'It never saved LR, which <code>bl helper</code> overwrote — and it clobbers r4/r5 without saving them', 'r0 is the wrong argument register', '<code>bx lr</code> should be <code>b lr</code>'], a: 1, why: 'Two bugs at once, both fixed by <code>push {r4, r5, lr}</code> at the top and <code>pop {r4, r5, pc}</code> at the bottom.' }
  ]
},

/* ------------------------------------------------------------------ 4.6 */
{
  id: 'u4l6', title: 'Two loops in one', goal: 'Merge loops, split loops, and know which way is faster.',
  teach: [
    { t: 'p', x: 'Two loops over the same data can often be merged into one. Sometimes that is faster; sometimes the opposite — splitting one loop into two — is faster. The deciding factor is usually cache and register pressure, not instruction count.' },
    { t: 'code', cap: 'Two passes', x: '@ pass 1: sum\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n@ pass 2: find the maximum\n2:  ldr  r3, [r4], #4\n    cmp  r3, r5\n    movhi r5, r3\n    subs r6, r6, #1\n    bne  2b' },
    { t: 'code', cap: 'One fused pass', x: '1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r3, r5\n    movhi r5, r3\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'table', head: ['', 'Two loops', 'One fused loop'], rows: [
      ['Loop overhead', 'paid twice', 'paid once'],
      ['Memory traffic', 'data read twice', 'read once'],
      ['Registers live', 'fewer', 'more'],
      ['Good when…', 'each body is register-hungry, or the data fits in cache anyway', 'the data is large and does not fit in cache']
    ] },
    { t: 'note', x: 'Rule of thumb: if the array is bigger than the cache, fuse — the second pass would have to re-read everything from RAM. If it comfortably fits, the second pass is nearly free and splitting can win by freeing registers.' },
    { t: 'h', x: 'Loop splitting (fission)' },
    { t: 'p', x: 'The opposite move. A body doing two unrelated things may run out of registers and spill to the stack every iteration. Splitting it into two simpler loops can remove all the spills — and spills are memory accesses in the innermost loop, the most expensive place to have them.' }
  ],
  real: {
    title: 'Image processing pipelines',
    text: 'Converting to greyscale and then blurring is two passes over a megapixel buffer — four megabytes read twice. Fusing them into a single pass halves the memory traffic, and on a memory-bound ARM SoC that is close to halving the runtime. Almost every image library has a fused fast path for exactly this.',
    code: '@ fused: convert and accumulate in one pass\n1:  ldrb r3, [r1], #1\n    ldrb r4, [r1], #1\n    ldrb r5, [r1], #1\n    add  r6, r3, r4\n    add  r6, r6, r5      @ cheap grey approximation\n    strb r6, [r7], #1\n    add  r8, r8, r6      @ and the histogram sum, same pass\n    subs r2, r2, #1\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'Two passes over the array stay two passes',
    text: 'Loop fusion — merging separate passes over the same array into one — is a source-level transformation gcc will not perform for you at <code>-O2</code>, even when the two loops sit right next to each other and are obviously safe to merge. Each one is compiled exactly as written, complete with its own loop control and its own pass over memory; the fused version from this lesson exists only because someone wrote it by hand.',
    a: { lab: 'C — two adjacent loops', lang: 'c', code: 'int sum = 0, best = 0;\nfor (int i = 0; i < n; i++)\n    sum += a[i];\nfor (int i = 0; i < n; i++)\n    if (a[i] > best) best = a[i];' },
    b: { lab: 'gcc -O2, ARMv7 — still two loops', code: '    mov   r2, #0\n    mov   r4, #0\n1:  ldr   r5, [r0, r4, lsl #2]\n    add   r2, r2, r5\n    add   r4, r4, #1\n    cmp   r4, r1\n    blt   1b\n\n    mov   r3, #0\n    mov   r4, #0\n2:  ldr   r5, [r0, r4, lsl #2]\n    cmp   r5, r3\n    movgt r3, r5\n    add   r4, r4, #1\n    cmp   r4, r1\n    blt   2b' },
    note: 'The array is read in full, twice. Fusing the two loops needs proof that the bodies cannot interfere with each other across iterations, and gcc\'s -O2 pipeline does not attempt that proof even when, as here, it is obviously safe.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Cache-friendly coding', cite: 'Reusing data while it is still in cache is generally more effective than reducing instruction count.' }
  ],
  ex: [
    { k: 'code', q: 'In a single pass over the 6 words at <code>a</code>, put the sum in r0 and the largest value in r5.', start: '    ldr  r1, =a\n    mov  r2, #6\n    mov  r0, #0\n    mov  r5, #0\n1:\n\n.data\na: .word 4, 19, 7, 2, 31, 8\n', check: [{ reg: 'r0', eq: 71 }, { reg: 'r5', eq: 31 }], solution: '    ldr  r1, =a\n    mov  r2, #6\n    mov  r0, #0\n    mov  r5, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r3, r5\n    movhi r5, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 4, 19, 7, 2, 31, 8\n', hints: ['Do both jobs between the load and the loop control.', '<code>cmp r3, r5</code> then <code>movhi r5, r3</code>.'], why: 'Sum 71, max 31, one pass, one read of the data.' },
    { k: 'mcq', q: 'The array is 64 MB and the cache is 1 MB. Fuse or split?', opts: ['Split — simpler loops', 'Fuse — a second pass would re-read all 64 MB from RAM', 'Either, no difference', 'Split, then fuse'], a: 1, why: 'When the data does not fit in cache, memory traffic dominates and halving it is the whole game.' },
    { k: 'mcq', q: 'What is loop fission for?', opts: ['Making loops shorter', 'Relieving register pressure so the body stops spilling to the stack every iteration', 'Improving branch prediction', 'Reducing code size'], a: 1, why: 'A spill in an inner loop is a memory access in the hottest place in your program.' },
    { k: 'mcq', q: 'Why does XOR-drawing let one loop do two jobs?', opts: ['XOR is faster than MOV', 'Applying the same pattern twice restores the original, so one operation both draws and erases', 'XOR sets the flags', 'It does not'], a: 1, why: 'a XOR b XOR b = a. It was the standard sprite technique on machines with no spare cycles.' },
    { k: 'code', q: 'XOR the 4 words at <code>src</code> into <code>dst</code> in place, so that running the same loop twice restores <code>dst</code>. Run it TWICE in your program and check dst is unchanged.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #4\n1:\n\n.data\nsrc: .word 0xFF00FF00, 0x12345678, 1, 2\ndst: .word 0xAAAAAAAA, 0x55555555, 3, 4\n', check: [{ memLabel: 'dst', words: [0xAAAAAAAA, 0x55555555, 3, 4] }, { contains: 'eor' }], solution: '    mov  r6, #2\n3:  ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #4\n1:  ldr  r3, [r1], #4\n    ldr  r4, [r0]\n    eor  r4, r4, r3\n    str  r4, [r0], #4\n    subs r2, r2, #1\n    bne  1b\n    subs r6, r6, #1\n    bne  3b\n\n.data\nsrc: .word 0xFF00FF00, 0x12345678, 1, 2\ndst: .word 0xAAAAAAAA, 0x55555555, 3, 4\n', hints: ['Wrap the whole thing in an outer loop that runs twice.', 'Reset both pointers at the top of each outer pass.'], why: 'The second pass undoes the first exactly — which is why XOR sprites need no saved background.' }
  ]
}
    ]
  });

  U.push({
    id: 'u5', n: 5, title: 'Block Moves', icon: '▤', color: '#9d7cd8',
    blurb: 'LDM and STM move up to sixteen registers in one instruction. This is where ARM loops get fast.',
    lessons: [

/* ------------------------------------------------------------------ 5.1 */
{
  id: 'u5l1', title: 'LDM and STM', goal: 'Move many registers with one instruction.',
  teach: [
    { t: 'p', x: '<code>LDM</code> — Load Multiple — reads consecutive words from memory into a list of registers. <code>STM</code> writes them back. One instruction can move up to sixteen words.' },
    { t: 'code', cap: 'Eight words, two instructions', x: '    ldmia r1!, {r4-r11}   @ load 32 bytes, advance r1 by 32\n    stmia r0!, {r4-r11}   @ store them, advance r0 by 32' },
    { t: 'p', x: 'The register list is a bitmask in the encoding, so the registers are always transferred in <b>numerical order, lowest register to lowest address</b> — no matter what order you write them in. <code>{r4, r1}</code> and <code>{r1, r4}</code> assemble to exactly the same instruction.' },
    { t: 'note', x: 'Write your register lists in ascending order. Some assemblers warn if you do not, and a reader who thinks the order matters will be misled.' },
    { t: 'h', x: 'The bulk copy loop' },
    { t: 'code', cap: '32 bytes per iteration', x: '@ r0 = dst, r1 = src, r2 = byte count (multiple of 32)\n1:  ldmia r1!, {r3-r10}\n    stmia r0!, {r3-r10}\n    subs  r2, r2, #32\n    bne   1b' },
    { t: 'p', x: 'Four instructions move 32 bytes. The byte-at-a-time loop needed four instructions to move <i>one</i> byte. That is the factor of 32 that makes <code>memcpy</code> fast.' },
    { t: 'h', x: 'What it costs' },
    { t: 'p', x: 'An <code>LDM</code> of n registers takes roughly n cycles of data transfer — you are not getting the memory for free. What you save is the instruction fetch, the decode, the address arithmetic and the loop overhead. On a Cortex-A7 an 8-register LDM/STM pair moves 32 bytes in about 16–18 cycles; the byte loop needs about 128.' }
  ],
  real: {
    title: 'Context switching',
    text: 'When an operating system switches tasks it saves every register of the outgoing task and loads every register of the incoming one. That is two instructions: one STM and one LDM. The whole of a task switch\'s register handling is two lines of assembly.',
    code: 'switch:\n    stmia r0, {r0-r14}    @ save the outgoing context\n    ldmia r1, {r0-r14}    @ load the incoming one\n    ldr   pc, [r1, #60]   @ and jump to its saved PC'
  },
  deep: {
    kind: 'pitfall',
    title: 'LDM on an unaligned address',
    text: 'ARMv7-A permits an unaligned <code>LDR</code> or <code>STR</code> when <code>SCTLR.A</code> is clear, which is the usual reset state — real silicon quietly does the extra bus work and returns the right answer. <code>LDM</code> and <code>STM</code> get no such tolerance on any configuration: an unaligned base address for a block transfer is architecturally <b>UNPREDICTABLE</b>. This teaching machine is stricter still and faults on any unaligned word access at all, which is at least as safe a target to code against as real hardware.',
    a: { lab: 'Unpredictable: LDM straight after an odd-length head', code: '@ r0 was advanced by 1..3 bytes copying a header, then straight into a block load\n    ldmia r0!, {r4-r7}    @ UNPREDICTABLE on real hardware if r0 is not a multiple of 4' },
    b: { lab: 'Correct: align first, exactly like the memcpy in this unit', code: '1:  ands r3, r0, #3\n    beq  2f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    b    1b\n2:  ldmia r1!, {r4-r7}\n    stmia r0!, {r4-r7}' },
    note: 'The alignment habit from the memcpy lesson is not a style preference — it is the only thing standing between a block loop and an instruction whose behaviour on misalignment is not defined at all.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDM/LDMIA, STM/STMIA', cite: 'The registers are loaded or stored in order of increasing register number, with the lowest-numbered register at the lowest address.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Alignment', cite: 'LDM and STM require word-aligned addresses.' }
  ],
  ex: [
    { k: 'mcq', q: 'In <code>stmia r0!, {r7, r2, r5}</code>, which register is written to the lowest address?', opts: ['r7', 'r2', 'r5', 'Whichever you wrote first'], a: 1, why: 'Always lowest register number to lowest address, regardless of the order in the source.' },
    { k: 'code', q: 'Copy the 8 words at <code>src</code> to <code>dst</code> using LDM/STM, in one pass with no loop.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8\ndst: .space 32\n', check: [{ memLabel: 'dst', words: [1, 2, 3, 4, 5, 6, 7, 8] }, { maxInsn: 6 }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    ldmia r1, {r4-r11}\n    stmia r0, {r4-r11}\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8\ndst: .space 32\n', hints: ['One LDM of eight registers, one STM.', 'You do not need the <code>!</code> here — nothing else uses the pointers.'], why: 'Two instructions move 32 bytes. This is the core of every fast memcpy.' },
    { k: 'code', q: 'Copy 64 bytes from <code>src</code> to <code>dst</code> with a loop that moves 32 bytes per pass.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #64\n1:\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\ndst: .space 64\n', check: [{ memLabel: 'dst', words: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16] }, { maxInsn: 14 }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #64\n1:  ldmia r1!, {r3-r10}\n    stmia r0!, {r3-r10}\n    subs  r2, r2, #32\n    bne   1b\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\ndst: .space 64\n', hints: ['Use the <code>!</code> so the pointers advance by 32 automatically.', 'Subtract 32 from the byte count each pass.'], why: 'Two passes, four instructions each. Compare that with 64 iterations of a byte loop.' },
    { k: 'mcq', q: 'Why does an 8-register LDM not take 1 cycle?', opts: ['It does', 'The data still has to move — roughly one cycle per register — but the fetch, decode and loop overhead are paid once', 'LDM is microcoded and slow', 'It depends on the condition code'], a: 1, why: 'You save the overhead, not the memory bandwidth. That is still a large win.' },
    { k: 'mcq', q: 'What must be true of the address used by LDM?', opts: ['It must be in .data', 'It must be word-aligned', 'It must be even', 'Nothing'], a: 1, why: 'LDM and STM always fault on unaligned addresses, with no configurable tolerance.' }
  ]
},

/* ------------------------------------------------------------------ 5.2 */
{
  id: 'u5l2', title: 'IA, IB, DA, DB', goal: 'Choose the right block addressing mode, and understand the stack aliases.',
  teach: [
    { t: 'p', x: 'Block transfers come in four addressing modes. The two letters say <b>direction</b> (Increment or Decrement) and <b>when</b> (After or Before the first transfer).' },
    { t: 'table', head: ['Mode', 'First address', 'Registers go', 'After writeback rN is'], rows: [
      ['<code>IA</code>', 'rN', 'upwards', 'rN + 4n'],
      ['<code>IB</code>', 'rN + 4', 'upwards', 'rN + 4n'],
      ['<code>DA</code>', 'rN − 4n + 4', 'upwards', 'rN − 4n'],
      ['<code>DB</code>', 'rN − 4n', 'upwards', 'rN − 4n']
    ] },
    { t: 'note', x: 'Registers always end up in ascending order in memory. The mode only decides <i>where the block starts</i>, never the order within it.' },
    { t: 'h', x: 'The stack aliases' },
    { t: 'p', x: 'The same four modes have a second set of names, describing the stack they implement. ARM\'s standard stack is <b>Full Descending</b>: SP points at the last item pushed, and the stack grows downwards.' },
    { t: 'table', head: ['Stack name', 'Means', 'On a store (push)', 'On a load (pop)'], rows: [
      ['<code>FD</code>', 'Full Descending', '<code>STMDB</code>', '<code>LDMIA</code>'],
      ['<code>ED</code>', 'Empty Descending', '<code>STMDA</code>', '<code>LDMIB</code>'],
      ['<code>FA</code>', 'Full Ascending', '<code>STMIB</code>', '<code>LDMDA</code>'],
      ['<code>EA</code>', 'Empty Ascending', '<code>STMIA</code>', '<code>LDMDB</code>']
    ] },
    { t: 'code', cap: 'Four spellings of the same instruction', x: '    stmdb sp!, {r4-r6}   @ what you write when thinking about addresses\n    stmfd sp!, {r4-r6}   @ what you write when thinking about a stack\n    push  {r4-r6}        @ what you actually write\n@ all three assemble to identical bytes' },
    { t: 'h', x: 'Which one for a loop?' },
    { t: 'p', x: 'For walking forwards through memory: <code>IA</code> with writeback. For walking backwards — a backwards copy, say — <code>DB</code> with writeback, which mirrors it exactly.' }
  ],
  real: {
    title: 'A backwards block copy for overlapping moves',
    text: 'memmove\'s backwards path is the DB mirror of its forward path. Both pointers start at the end and every LDMDB/STMDB pair steps down 32 bytes.',
    code: '@ overlapping copy, top down\n    add  r0, r0, r2\n    add  r1, r1, r2\n1:  ldmdb r1!, {r3-r10}\n    stmdb r0!, {r3-r10}\n    subs  r2, r2, #32\n    bne   1b'
  },
  deep: {
    kind: 'compiler',
    title: 'The register list is sorted, not written',
    text: 'A C function that touches a couple of callee-saved registers gets one <code>PUSH</code> and one <code>POP</code> from the compiler, exactly as this lesson recommends by hand. The register list in the machine encoding is a 16-bit mask, one bit per register, so the transfer order is fixed by register number — gcc\'s output lists them in ascending order regardless of the order the source happens to use them in, because there is no other order the hardware can express.',
    a: { lab: 'C', lang: 'c', code: 'int total;\nint accumulate(int *p, int n) {\n    int t = 0, i;\n    for (i = 0; i < n; i++)\n        t += p[i];\n    total = t;\n    return i;\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: 'accumulate:\n    push  {r4, r5, lr}\n    mov   r4, #0\n    mov   r5, #0\n    cmp   r1, #0\n    ble   2f\n1:  ldr   r3, [r0, r5, lsl #2]\n    add   r4, r4, r3\n    add   r5, r5, #1\n    cmp   r5, r1\n    blt   1b\n2:  ldr   r3, =total\n    str   r4, [r3]\n    mov   r0, r5\n    pop   {r4, r5, pc}' },
    note: 'Write the push list by hand as {lr, r5, r4} and the assembler still emits the identical bytes as {r4, r5, lr} — the mnemonic\'s register list is decorative, and a bitmask has no order of its own.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDM/STM addressing modes', cite: 'The addressing mode suffixes IA, IB, DA and DB select the base address of the transfer; the stack-oriented aliases FD, ED, FA and EA map onto them depending on whether the instruction loads or stores.' },
    { src: 'AAPCS (IHI 0042)', cite: 'The stack is full descending and SP must be 8-byte aligned at any public interface.' }
  ],
  ex: [
    { k: 'mcq', q: '<code>push {r0-r3}</code> is exactly which instruction?', opts: ['<code>stmia sp!, {r0-r3}</code>', '<code>stmdb sp!, {r0-r3}</code>', '<code>stmda sp!, {r0-r3}</code>', '<code>stmib sp!, {r0-r3}</code>'], a: 1, why: 'Full descending stack: decrement before the store.' },
    { k: 'match', q: 'Match the stack alias to the real addressing mode, for a STORE.', pairs: [['STMFD', 'STMDB'], ['STMEA', 'STMIA'], ['STMFA', 'STMIB'], ['STMED', 'STMDA']], why: 'Full means SP points at data; Descending means the stack grows down.' },
    { k: 'code', q: 'Copy the 8 words at <code>src</code> to <code>dst</code> backwards, using LDMDB/STMDB.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    add  r1, r1, #32\n    add  r0, r0, #32\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8\ndst: .space 32\n', check: [{ memLabel: 'dst', words: [1, 2, 3, 4, 5, 6, 7, 8] }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    add  r1, r1, #32\n    add  r0, r0, #32\n    ldmdb r1!, {r4-r11}\n    stmdb r0!, {r4-r11}\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8\ndst: .space 32\n', hints: ['Both pointers already point one past the end.', 'DB subtracts first, so the block lands in the right place.'], why: 'The data comes out in the same order — DB only changes where the block starts, not the order inside it.' },
    { k: 'predict', q: 'r1 = 0x18000 and the words at 0x18000 are 10, 20, 30. What is r5 after <code>ldmia r1, {r4-r6}</code>?', code: '    ldr  r1, =d\n    ldmia r1, {r4-r6}\n    mov  r0, r5\n\n.data\nd: .word 10,20,30\n', ask: 'r0', a: 20, why: 'r4 gets the lowest address, r5 the next — 20.' },
    { k: 'mcq', q: 'After <code>ldmdb r1!, {r4-r7}</code> with r1 = 0x1020, what is r1?', opts: ['0x1020', '0x1030', '0x1010', '0x1000'], a: 2, why: 'Four registers is 16 bytes; DB subtracts them all first, so r1 becomes 0x1010, and r4 was loaded from 0x1010.' }
  ]
},

/* ------------------------------------------------------------------ 5.3 */
{
  id: 'u5l3', title: 'A real memcpy', goal: 'Build the head/bulk/tail structure that every fast copy uses.',
  teach: [
    { t: 'p', x: 'You now have every piece. A production copy routine is: align the destination, move big blocks, then mop up. Here it is in full.' },
    { t: 'code', cap: 'memcpy, the whole thing', x: '@ r0 = dst, r1 = src, r2 = count.  Returns dst in r0.\nmemcpy:\n    push {r0, r4-r10, lr}\n    cmp  r2, #32\n    blo  4f                @ tiny: skip straight to the byte loop\n\n@ --- head: byte copy until dst is word aligned ---\n1:  ands r3, r0, #3\n    beq  2f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    sub  r2, r2, #1\n    b    1b\n\n@ --- bulk: 32 bytes at a time ---\n2:  cmp  r2, #32\n    blo  3f\n    ldmia r1!, {r4-r10, r12}\n    stmia r0!, {r4-r10, r12}\n    sub  r2, r2, #32\n    b    2b\n\n@ --- mid: 4 bytes at a time ---\n3:  cmp  r2, #4\n    blo  4f\n    ldr  r3, [r1], #4\n    str  r3, [r0], #4\n    sub  r2, r2, #4\n    b    3b\n\n@ --- tail: the last 0-3 bytes ---\n4:  cmp  r2, #0\n    beq  5f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n5:  pop  {r0, r4-r10, pc}' },
    { t: 'note', x: 'Notice that only the <b>destination</b> is aligned. If the source is misaligned relative to the destination, a real library would fall back to a shift-and-merge loop; here the mid loop\'s <code>LDR</code> handles it, because ARMv7-A permits unaligned word loads.' },
    { t: 'h', x: 'Why three loops and not one' },
    { t: 'p', x: 'Each loop has a different step size, so each needs its own test. The alternative — one loop with a size check inside — puts a branch in the hot path for a condition that is nearly always the same. Three loops is faster and, once you know the pattern, no harder to read.' },
    { t: 'h', x: 'Why r12 is in the register list' },
    { t: 'p', x: 'r12 is call-clobbered, so it does not need saving — a free eighth register for the block transfer. Using r4–r10 plus r12 gives eight registers while only pushing seven.' }
  ],
  real: {
    title: 'What the real one adds',
    text: 'ARM\'s optimised-routines memcpy adds: a NEON path for large copies, PLD preloads several cache lines ahead, special handling for misaligned source, and a size threshold below which it uses a completely different unrolled byte path. The skeleton above is genuinely the skeleton — the extras are refinements on it.',
    code: '@ the preload that a production version adds\n2:  pld  [r1, #128]        @ tell the cache what we will want next\n    ldmia r1!, {r4-r10, r12}\n    stmia r0!, {r4-r10, r12}\n    subs r2, r2, #32\n    bhs  2b'
  },
  deep: {
    kind: 'pitfall',
    title: 'A forward copy that overtakes itself',
    text: 'A forward LDM/STM copy reads a block, then writes it, then moves on — and if the destination overlaps the source ahead of the read position, that write clobbers bytes the read has not reached yet. <code>memcpy</code>\'s contract explicitly excludes this case; <code>memmove</code> exists purely to detect the overlap and, when the destination is ahead of the source, copy from the top down instead, so nothing is overwritten before it has been read.',
    a: { lab: 'Wrong: forward copy, dst overlapping ahead of src', code: '@ shift an 11-word block up by one word -- forward copy corrupts itself\n    add  r0, r1, #4      @ dst = src + 4: overlapping, dst AHEAD of src\n    mov  r2, #11\n1:  ldr  r3, [r1], #4\n    str  r3, [r0], #4    @ overwrites src[1..] before it has been read\n    subs r2, r2, #1\n    bne  1b' },
    b: { lab: 'Right: copy from the top down when dst is ahead of src', code: '@ same shift, copying backwards\n    add  r1, r1, #44      @ one past the last source word\n    add  r0, r1, #4\n    mov  r2, #11\n1:  ldr  r3, [r1, #-4]!\n    str  r3, [r0, #-4]!\n    subs r2, r2, #1\n    bne  1b' },
    note: 'This is exactly the DB addressing mode from the earlier lesson on block addressing, stepping down from the top — it exists for this reason, not as an alternative style.'
  },
  refs: [
    { src: 'ARM optimised-routines, string/arm/memcpy.S', cite: 'The reference ARM memcpy aligns the destination, then copies in blocks using LDM/STM with preloading, and finishes with word and byte tails.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — PLD', cite: 'PLD is a memory hint; it has no architectural effect other than to signal a likely future access.' }
  ],
  ex: [
    { k: 'code', q: 'Copy 20 bytes from <code>src</code> to <code>dst</code> using a 4-byte loop plus a byte tail. (20 = 5 words exactly, so your tail should run zero times — prove your tail handles that.)', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #20\n\n.data\nsrc: .byte 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20\n.align 2\ndst: .space 20\n', check: [{ memLabel: 'dst', bytes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #20\n3:  cmp  r2, #4\n    blo  4f\n    ldr  r3, [r1], #4\n    str  r3, [r0], #4\n    sub  r2, r2, #4\n    b    3b\n4:  cmp  r2, #0\n    beq  5f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n5:\n\n.data\nsrc: .byte 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20\n.align 2\ndst: .space 20\n', hints: ['Word loop first, guarded by <code>cmp r2, #4</code> / <code>blo</code>.', 'Then a byte loop guarded by <code>cmp r2, #0</code> / <code>beq</code>.'], why: 'The guards are what make the structure safe for any length, including zero.' },
    { k: 'code', q: 'Now copy 22 bytes — 5 words plus a 2-byte tail. Same structure.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #22\n\n.data\nsrc: .byte 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22\n.align 2\ndst: .space 22\n', check: [{ memLabel: 'dst', bytes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22] }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #22\n3:  cmp  r2, #4\n    blo  4f\n    ldr  r3, [r1], #4\n    str  r3, [r0], #4\n    sub  r2, r2, #4\n    b    3b\n4:  cmp  r2, #0\n    beq  5f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  4b\n5:\n\n.data\nsrc: .byte 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22\n.align 2\ndst: .space 22\n', hints: ['The same code as the previous exercise works unchanged — that is the point.'], why: 'A correct head/bulk/tail structure does not care about the length. That is why it is worth writing carefully once.' },
    { k: 'mcq', q: 'Why is r12 a good extra register for the block transfer?', opts: ['It is faster', 'It is call-clobbered, so it needs no saving — a free register', 'It is the only one LDM accepts', 'It is aligned'], a: 1, why: 'Seven pushes buy you eight registers in the list.' },
    { k: 'mcq', q: 'What does <code>PLD [r1, #128]</code> actually do?', opts: ['Loads a word into r1', 'Hints to the cache that data 128 bytes ahead will be needed soon', 'Aligns the pointer', 'Nothing, it is removed by the assembler'], a: 1, why: 'It is architecturally a no-op with a microarchitectural effect: it starts the cache line fetch early so the LDM does not stall.' },
    { k: 'mcq', q: 'Why does the copy align the destination rather than the source?', opts: ['Stores are more sensitive to misalignment than loads on most cores, and the STM demands alignment', 'The source cannot be aligned', 'It is arbitrary', 'To save a register'], a: 0, why: 'The STM is the instruction with the hard alignment requirement, so the destination is the pointer that must be fixed.' }
  ]
},

/* ------------------------------------------------------------------ 5.4 */
{
  id: 'u5l4', title: 'memset and the fill loop', goal: 'Fill memory as fast as the bus allows.',
  teach: [
    { t: 'p', x: 'Filling is easier than copying: there is only one pointer, and the value can be prepared once outside the loop.' },
    { t: 'code', cap: 'Prepare, then blast', x: '@ r0 = dst, r1 = byte value, r2 = count\n    and  r1, r1, #0xFF\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16   @ r1 now holds four copies of the byte\n    mov  r3, r1\n    mov  r4, r1\n    mov  r5, r1                @ four registers, all the same\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #16\n    bne   1b' },
    { t: 'p', x: 'Sixteen bytes per iteration from a two-instruction loop body. The preparation — five instructions — is paid once, however long the fill is.' },
    { t: 'h', x: 'How many registers should you use?' },
    { t: 'table', head: ['Registers in the STM', 'Bytes per iteration', 'Note'], rows: [
      ['2', '8', 'barely worth the setup'],
      ['4', '16', 'a good default'],
      ['8', '32', 'matches a 32-byte cache line on many cores'],
      ['More', '—', 'diminishing returns; you are bus-limited now']
    ] },
    { t: 'note', x: 'Matching the cache line size is the sweet spot: a full-line write can often skip fetching the old line from memory at all, roughly doubling fill throughput. Beyond that, you are limited by how fast memory can accept data, and more registers do not help.' },
    { t: 'h', x: 'Zeroing is a special case' },
    { t: 'p', x: 'Zeroing has no byte to replicate, so the setup collapses to <code>mov r1, #0</code> repeated. Boot code zeroing the BSS section is exactly this loop, and it is often the very first loop a system executes.' }
  ],
  real: {
    title: 'Zeroing the BSS at boot',
    text: 'Before <code>main()</code> runs, the C runtime must set every uninitialised global to zero. On a bare-metal ARM system that is a loop from <code>__bss_start__</code> to <code>__bss_end__</code>, and it runs before there is a stack, a heap or a C library. It is as close to the first thing the machine does as makes no difference.',
    code: 'zero_bss:\n    ldr  r0, =__bss_start__\n    ldr  r1, =__bss_end__\n    mov  r2, #0\n    mov  r3, #0\n1:  cmp  r0, r1\n    bhs  2f\n    stmia r0!, {r2, r3}\n    b    1b\n2:'
  },
  deep: {
    kind: 'cores',
    title: 'A device-mapped framebuffer has no line to fill',
    text: 'The cache-line argument for wide STMs only applies to normal cacheable memory. This app\'s framebuffer is a flat 9600-byte region at <code>0x20000000</code> with no cache behind it at all, which is how small displays are very often wired up in practice — every store is its own bus transaction, whether it is a lone <code>STRB</code> or one lane of an 8-register <code>STM</code>. The saving from a wide STM there is pure instruction count: fewer fetches and less loop overhead for the same bytes moved, not a cache trick.',
    code: '@ filling the framebuffer: no cache line to complete, just fewer instructions\n    ldr  r0, =0x20000000\n    mov  r1, #0\n    mov  r3, #0\n    mov  r4, #0\n    mov  r5, #0\n    mov  r2, #600        @ 9600 bytes / 16\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #1\n    bne   1b',
    note: 'Real systems mix both cases: an SoC\'s own DRAM is cached and rewards full-line stores, while the small SPI or parallel display it drives -- an e-paper panel, a character LCD, a handheld console\'s screen -- is normally mapped uncached, exactly like this framebuffer, and rewards nothing but fewer instructions.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Cache behaviour on writes', cite: 'Writing a complete cache line can avoid the read-for-ownership of that line, improving store throughput.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — STM', cite: 'STM stores the listed registers to consecutive words beginning at the address determined by the addressing mode.' }
  ],
  ex: [
    { k: 'code', q: 'Fill the 32 bytes at <code>buf</code> with 0xCD, using an STM of four registers.', start: '    ldr  r0, =buf\n    mov  r1, #0xCD\n    mov  r2, #32\n\n.data\nbuf: .space 32\n', check: [{ memLabel: 'buf', words: [0xCDCDCDCD, 0xCDCDCDCD, 0xCDCDCDCD, 0xCDCDCDCD, 0xCDCDCDCD, 0xCDCDCDCD, 0xCDCDCDCD, 0xCDCDCDCD] }, { maxInsn: 20 }], solution: '    ldr  r0, =buf\n    mov  r1, #0xCD\n    mov  r2, #32\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16\n    mov  r3, r1\n    mov  r4, r1\n    mov  r5, r1\n1:  stmia r0!, {r1, r3, r4, r5}\n    subs  r2, r2, #16\n    bne   1b\n\n.data\nbuf: .space 32\n', hints: ['Replicate the byte into all four lanes first.', 'Copy that word into three more registers, then STM all four.'], why: 'Two iterations of a two-instruction loop fill 32 bytes.' },
    { k: 'mcq', q: 'Why prepare the replicated word outside the loop?', opts: ['Because ORR cannot be used inside a loop', 'Because it is loop-invariant — the same every iteration, so computing it once saves work proportional to the length', 'To save registers', 'It has to be in .data'], a: 1, why: 'Hoisting loop-invariant work is the single most reliable optimisation there is.' },
    { k: 'mcq', q: 'What is the advantage of an STM that writes a full cache line?', opts: ['Fewer instructions only', 'The core may skip reading the old line from memory, since every byte is being overwritten', 'It is the only aligned form', 'None'], a: 1, why: 'A partial write has to merge with the existing line; a full-line write does not.' },
    { k: 'code', q: 'Zero the 24 bytes at <code>buf</code> using a pointer-compare loop and an STM of two registers.', start: '    ldr  r0, =buf\n    ldr  r1, =bufend\n\n.data\nbuf: .word 1,2,3,4,5,6\nbufend:\n', check: [{ memLabel: 'buf', words: [0, 0, 0, 0, 0, 0] }], solution: '    ldr  r0, =buf\n    ldr  r1, =bufend\n    mov  r2, #0\n    mov  r3, #0\n1:  cmp  r0, r1\n    bhs  2f\n    stmia r0!, {r2, r3}\n    b    1b\n2:\n\n.data\nbuf: .word 1,2,3,4,5,6\nbufend:\n', hints: ['A label placed after the data gives you the end address.', 'Compare r0 against r1 with <code>bhs</code> to leave.'], why: 'This is exactly the BSS-zeroing loop that runs before <code>main()</code>.' },
    { k: 'mcq', q: 'This app\'s framebuffer is mapped as plain uncached memory rather than normal cacheable memory. What follows for a wide STM filling it?', opts: ['Nothing changes', 'The cache-line argument for full-line stores does not apply, but fewer instructions still means less loop overhead', 'STM cannot target uncached memory', 'The fill becomes faster than on cacheable memory'], a: 1, why: 'Small displays are very often wired up exactly like this -- no cache, so the whole saving from a wide STM is in instruction count.' }
  ]
},

/* ------------------------------------------------------------------ 5.5 */
{
  id: 'u5l5', title: 'The remainder problem', goal: 'Handle counts that are not a multiple of your block size.',
  teach: [
    { t: 'p', x: 'A loop that moves 32 bytes at a time can only handle counts that are multiples of 32. Everything else needs a plan for the remainder, and there are three standard ones.' },
    { t: 'h', x: 'Plan 1: a tail loop' },
    { t: 'p', x: 'What you have already seen. Simple, obviously correct, and the remainder costs up to 31 iterations of a slow loop. Fine when the total is large.' },
    { t: 'h', x: 'Plan 2: a jump table of partial blocks' },
    { t: 'code', cap: 'Dispatch straight into the middle of an unrolled block', x: '@ r2 = 0..7 words remaining\n    ands r3, r2, #7\n    beq  2f\n    rsb  r3, r3, #8\n    add  pc, pc, r3, lsl #2   @ jump into the ladder\n    nop\n    ldr  r4, [r1], #4\n    str  r4, [r0], #4\n    ldr  r4, [r1], #4\n    str  r4, [r0], #4\n    @ ... seven pairs ...\n2:' },
    { t: 'p', x: 'This is a cousin of "Duff\'s device" from C. It is fast and it is genuinely used in optimised libraries — but writing to PC is a big hammer, and on modern cores it defeats the return-stack predictor. Know it; reach for it rarely.' },
    { t: 'h', x: 'Plan 3: overlap the last block' },
    { t: 'code', cap: 'Copy the final block from the end, accepting an overlap', x: '@ copy the last 32 bytes by backing up, even if some bytes get copied twice\n    add  r1, r1, r2\n    add  r0, r0, r2\n    ldmdb r1, {r4-r11}\n    stmdb r0, {r4-r11}' },
    { t: 'p', x: 'If the count is at least one block, you can always finish by copying the <i>last</i> block from the end of the buffer, even if it overlaps bytes you already copied. Copying a byte twice is harmless for a copy — and this removes the tail loop entirely.' },
    { t: 'note', x: 'The overlap trick is only valid when re-writing a byte is harmless. It is perfect for copy and fill. It is wrong for anything with side effects — a checksum, a device FIFO, an accumulating sum.' }
  ],
  real: {
    title: 'How modern memcpy avoids tails',
    text: 'Contemporary optimised memcpy implementations lean heavily on the overlap trick, precisely because branch-heavy tail handling dominates the cost of small copies. A copy of 40 bytes becomes two 32-byte block moves that overlap by 24 bytes — two instructions, no loop, no branches.',
    code: '@ 33..64 bytes: two overlapping 32-byte blocks, no loop at all\n    ldmia r1, {r4-r11}\n    stmia r0, {r4-r11}\n    add   r1, r1, r2\n    add   r0, r0, r2\n    ldmdb r1, {r4-r11}\n    stmdb r0, {r4-r11}'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler will not write you a Duff\'s device',
    text: 'When a copy\'s length is a compile-time constant, gcc simply unrolls the whole thing into straight-line loads and stores, with nothing left over to call a remainder — a 20-byte constant copy becomes a handful of word transfers worked out entirely at compile time. The moment the length becomes a run-time variable, gcc gives up on inlining altogether and emits a call to the library <code>memcpy</code>, which is the hand-written routine from an earlier lesson. The computed jump-table dispatch from this lesson is not something either path produces; it only ever appears in hand-tuned code.',
    a: { lab: 'C -- length is a compile-time constant', lang: 'c', code: 'void copy20(char *d, const char *s) {\n    __builtin_memcpy(d, s, 20);\n}' },
    b: { lab: 'gcc -O2, ARMv7 -- no loop, nothing left over', code: 'copy20:\n    ldr   r2, [r1]\n    ldr   r3, [r1, #4]\n    ldr   r12, [r1, #8]\n    str   r2, [r0]\n    str   r3, [r0, #4]\n    str   r12, [r0, #8]\n    ldr   r2, [r1, #12]\n    ldr   r3, [r1, #16]\n    str   r2, [r0, #12]\n    str   r3, [r0, #16]\n    bx    lr' },
    note: 'Ask for a length gcc cannot see at compile time and all of this disappears, replaced by one <code>BL memcpy</code> -- the whole head/bulk/tail structure from this unit lives inside that call, not at the call site.'
  },
  refs: [
    { src: 'ARM optimised-routines, memcpy', cite: 'Small copies are handled with overlapping fixed-size transfers rather than byte loops, to avoid the branch cost of tail handling.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — ADD (register) with PC as destination', cite: 'Writing to PC causes a branch; the value written must be suitably aligned for the current instruction set state.' }
  ],
  ex: [
    { k: 'mcq', q: 'When is the "overlap the last block" trick NOT safe?', opts: ['When the count is large', 'When re-processing a byte has a side effect — a checksum, an accumulating sum, a device FIFO', 'When the pointers are aligned', 'It is always safe'], a: 1, why: 'Writing the same byte twice is harmless. Adding the same byte to a sum twice is not.' },
    { k: 'code', q: 'Copy 12 words from <code>src</code> to <code>dst</code> using an 8-word block plus an overlapping second 8-word block from the end.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8,9,10,11,12\ndst: .space 48\n', check: [{ memLabel: 'dst', words: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] }, { maxInsn: 12 }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    ldmia r1, {r4-r11}\n    stmia r0, {r4-r11}\n    add  r1, r1, #48\n    add  r0, r0, #48\n    ldmdb r1, {r4-r11}\n    stmdb r0, {r4-r11}\n\n.data\nsrc: .word 1,2,3,4,5,6,7,8,9,10,11,12\ndst: .space 48\n', hints: ['First block copies words 0–7.', 'Then point both pointers one past the end and use DB to copy words 4–11.'], why: 'Words 4–7 are copied twice, which costs nothing and removes the tail loop entirely.' },
    { k: 'mcq', q: 'What is the ARM equivalent of Duff\'s device?', opts: ['A tail loop', 'Adding a scaled remainder to PC to jump into the middle of an unrolled ladder', 'Using LDRD', 'Using NEON'], a: 1, why: 'Computed dispatch into a partially-unrolled block — the same idea as the C switch-inside-a-loop.' },
    { k: 'mcq', q: 'A copy of 40 bytes with a 32-byte block loop leaves what remainder?', opts: ['0', '4', '8', '32'], a: 2, why: '40 − 32 = 8. Either a tail loop, or one overlapping block from the end.' },
    { k: 'code', q: 'Copy 10 bytes from <code>src</code> to <code>dst</code> with a word loop and a byte tail. (10 = 2 words + 2 bytes.)', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #10\n\n.data\nsrc: .byte 1,2,3,4,5,6,7,8,9,10\n.align 2\ndst: .space 10\n', check: [{ memLabel: 'dst', bytes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #10\n1:  cmp  r2, #4\n    blo  2f\n    ldr  r3, [r1], #4\n    str  r3, [r0], #4\n    sub  r2, r2, #4\n    b    1b\n2:  cmp  r2, #0\n    beq  3f\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  2b\n3:\n\n.data\nsrc: .byte 1,2,3,4,5,6,7,8,9,10\n.align 2\ndst: .space 10\n', hints: ['The word loop runs twice, then the byte loop runs twice.'], why: 'The structure is identical to the memcpy in the last lesson — it scales down as well as up.' }
  ]
},

/* ------------------------------------------------------------------ 5.6 */
{
  id: 'u5l6', title: 'Register discipline in a block loop', goal: 'Use the whole register file without breaking the calling convention.',
  teach: [
    { t: 'p', x: 'A block-transfer loop wants as many registers as it can get. The calling convention says which ones you may take and what you owe for them.' },
    { t: 'table', head: ['Register', 'Free to use?', 'Cost'], rows: [
      ['r0–r3', 'Yes, immediately', 'You lose the arguments they held'],
      ['r12', 'Yes, immediately', 'None — it is scratch'],
      ['r4–r11', 'Yes, if you save them', 'One push and one pop'],
      ['r13 (SP)', 'No', '—'],
      ['r14 (LR)', 'Only if saved', 'You cannot return without it'],
      ['r15 (PC)', 'No (except deliberately)', '—']
    ] },
    { t: 'p', x: 'So a leaf routine gets five registers free (r0–r3, r12) and can buy up to eight more for the price of one <code>PUSH</code> and one <code>POP</code>. That is thirteen registers for a block loop — enough for a 12-register LDM plus a pointer.' },
    { t: 'code', cap: 'Buying registers', x: 'bigcopy:\n    push {r4-r11, lr}     @ one instruction buys eight registers\n1:  ldmia r1!, {r3-r10}\n    stmia r0!, {r3-r10}\n    subs r2, r2, #32\n    bne  1b\n    pop  {r4-r11, pc}     @ and gives them back, and returns' },
    { t: 'note', x: 'Because <code>PUSH</code> and <code>POP</code> are themselves <code>STM</code>/<code>LDM</code>, saving eight registers costs one instruction, not eight. This is a large part of why ARM function prologues are so short.' },
    { t: 'h', x: 'r11 and frame pointers' },
    { t: 'p', x: 'Some build configurations reserve r11 as a frame pointer. If you are writing assembly that will be linked with such code you may use r11 freely inside your function as long as you restore it — but a debugger will not be able to unwind through your loop. For hot inner loops that is usually an acceptable trade.' },
    { t: 'h', x: 'Stack alignment' },
    { t: 'p', x: 'The AAPCS requires SP to be 8-byte aligned whenever you call another function. <code>push {r4-r11, lr}</code> pushes nine registers — 36 bytes — which breaks alignment. Push an even number, or add a dummy register, if your loop calls out.' }
  ],
  real: {
    title: 'Why hand-written assembly still wins here',
    text: 'A C compiler will not use twelve registers in a copy loop, because it has to respect the abstract machine and cannot always prove the aliasing is safe. Hand-written block loops routinely use the whole register file, and that is why hand-written memcpy is still faster than compiled memcpy on 32-bit ARM.',
    code: '@ twelve registers in flight, one instruction each way\n    push {r4-r11, lr}\n1:  ldmia r1!, {r3-r12}\n    stmia r0!, {r3-r12}\n    subs r2, r2, #40\n    bne  1b\n    pop  {r4-r11, pc}'
  },
  deep: {
    kind: 'cores',
    title: 'M-profile automates half of this in hardware',
    text: 'Everything in this lesson is about the software cost of saving registers before a loop calls out. Cortex-M cores do something similar automatically whenever an exception fires: on entry, the hardware itself pushes r0-r3, r12, LR, the return address and the status register onto the stack before the handler\'s first instruction runs, with no <code>PUSH</code> anywhere in the handler\'s own code. Software still has to save r4-r11 if the handler uses them -- the automatic part covers exactly the call-clobbered set, the same registers an ordinary function call already leaves free to use.',
    code: '@ the software half: entering a loop that calls out\nmyloop:\n    push {r4-r7, lr}\n1:  bl   helper\n    subs r5, r5, #1\n    bne  1b\n    pop  {r4-r7, pc}',
    note: 'That automatic stacking is also why M-profile interrupt latency is so predictable: the hardware sequence takes the same fixed number of cycles every time, the exact discipline this course has been asking you to apply by hand to ordinary function calls.'
  },
  refs: [
    { src: 'AAPCS (IHI 0042), Core registers', cite: 'r4–r11 are callee-saved; r0–r3 and r12 may be corrupted by a called function; SP must be 8-byte aligned at public interfaces.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — PUSH, POP', cite: 'PUSH and POP are aliases of STMDB and LDMIA on SP with writeback.' }
  ],
  ex: [
    { k: 'mcq', q: 'How many instructions does it take to save eight callee-saved registers?', opts: ['8', '4', '2', '1'], a: 3, why: 'One PUSH — which is an STMDB — saves all eight.' },
    { k: 'mcq', q: 'Which registers can a leaf function use with no saving at all?', opts: ['r0–r3 and r12', 'r0–r11', 'r4–r11', 'Only r0'], a: 0, why: 'Five free registers, plus SP and PC which have jobs.' },
    { k: 'code', q: 'Write a routine <code>sum32</code> that sums 8 words using one LDM, saving and restoring whatever it needs. Call it and leave the answer in r0.', start: '    ldr  r1, =a\n    bl   sum32\n    b    end\n\nsum32:\n    @ your code — must not corrupt r4-r11 as seen by the caller\n\nend:\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', check: [{ reg: 'r0', eq: 36 }], solution: '    ldr  r4, =0x1234\n    ldr  r1, =a\n    bl   sum32\n    ldr  r5, =0x1234\n    cmp  r4, r5\n    bne  bad\n    b    end\nbad:\n    mov  r0, #0\n    b    end\n\nsum32:\n    push {r4-r11, lr}\n    ldmia r1, {r4-r11}\n    add  r0, r4, r5\n    add  r0, r0, r6\n    add  r0, r0, r7\n    add  r0, r0, r8\n    add  r0, r0, r9\n    add  r0, r0, r10\n    add  r0, r0, r11\n    pop  {r4-r11, pc}\n\nend:\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', hints: ['<code>push {r4-r11, lr}</code> then <code>ldmia r1, {r4-r11}</code>.', 'Return with <code>pop {r4-r11, pc}</code>.'], why: 'The reference solution also checks that r4 really survived the call — which is the whole point of the convention.' },
    { k: 'mcq', q: 'Why does <code>push {r4-r11, lr}</code> break the 8-byte stack alignment rule?', opts: ['It does not', 'It pushes nine registers — 36 bytes — which is not a multiple of 8', 'LR cannot be pushed', 'PUSH always misaligns'], a: 1, why: 'Push an even number of registers when your function calls out. Adding r12 to the list is the usual fix.' },
    { k: 'mcq', q: 'Why is hand-written assembly still competitive for memcpy on 32-bit ARM?', opts: ['Compilers cannot emit LDM', 'A human can commit the whole register file to the loop and knows the buffers do not alias; the compiler must be conservative', 'Assembly runs at a higher clock', 'It is not'], a: 1, why: 'Register budget and aliasing knowledge, not instruction selection, are where the hand-written version wins.' }
  ]
}
    ]
  });

  U.push({
    id: 'u6', n: 6, title: 'Branchless Loops', icon: '⋔', color: '#4fb6c9',
    blurb: 'ARM lets almost every instruction carry a condition. Used well, that turns branchy loop bodies into straight lines.',
    lessons: [

/* ------------------------------------------------------------------ 6.1 */
{
  id: 'u6l1', title: 'Conditional execution', goal: 'Attach a condition to any instruction and know what it costs.',
  teach: [
    { t: 'p', x: 'In the A32 instruction set, <b>every</b> instruction has a 4-bit condition field. <code>ADDEQ</code>, <code>LDRNE</code>, <code>MOVGT</code>, <code>BLLT</code> — all real instructions. When the condition is false, the instruction is fetched, decoded, and then does nothing.' },
    { t: 'code', cap: 'if (a > b) max = a; else max = b;', x: '    cmp   r0, r1\n    movgt r2, r0\n    movle r2, r1' },
    { t: 'p', x: 'No branches. Three instructions, always three cycles, completely predictable. The branching version is two or three instructions but includes a branch that the processor may mispredict, costing perhaps a dozen cycles when it does.' },
    { t: 'h', x: 'The rule of thumb' },
    { t: 'table', head: ['Conditional body length', 'Better approach'], rows: [
      ['1–3 instructions', 'Conditional execution — almost always'],
      ['4–8 instructions', 'Depends. Measure.'],
      ['More than 8', 'Branch — you do not want to fetch and discard that much'],
      ['Contains a load that might fault', 'Conditional execution is fine — a false condition suppresses the access entirely']
    ] },
    { t: 'note', x: 'A conditional instruction whose condition is false still occupies a cycle. Predication trades <i>guaranteed</i> small cost for <i>possible</i> large cost. In a loop whose condition alternates unpredictably, that is an excellent trade.' },
    { t: 'h', x: 'Only the S form changes flags' },
    { t: 'p', x: '<code>ADDEQ r0, r0, #1</code> does not touch the flags, so a run of conditional instructions can all test the same comparison. <code>ADDEQS</code> would change them and break the chain. Write <code>ADDEQ</code>, not <code>ADDSEQ</code>, unless you really mean it.' }
  ],
  real: {
    title: 'Branchless absolute value and clamping in a pixel loop',
    text: 'Image and audio loops are full of tiny conditionals — clamp, abs, select — applied to data that is essentially random. Every one of those as a branch is a coin flip the branch predictor loses half the time. As conditional instructions they are free of that risk entirely.',
    code: '@ r0 = abs(r0), branchless\n    cmp   r0, #0\n    rsblt r0, r0, #0\n\n@ r0 = clamp(r0, 0, 255)\n    cmp   r0, #255\n    movgt r0, #255\n    cmp   r0, #0\n    movlt r0, #0'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler reaches for this on its own',
    text: 'This is not only a hand-tuning trick: gcc and clang emit exactly this pattern from a plain C conditional whenever both branches are small and free of side effects. Ask for the larger of two values and <code>-O2</code> gives back a compare and a single conditional move, with no branch anywhere, on an ordinary ARMv7-A target.',
    a: { lab: 'C', lang: 'c', code: 'int max(int a, int b) {\n    if (a > b) return a;\n    return b;\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: 'max:\n    cmp   r0, r1\n    movle r0, r1\n    bx    lr' },
    note: 'The compiler only reaches for this when it is confident the discarded branch has no side effects -- call a function on one side of the <code>if</code> and it reverts to a real branch immediately, because it cannot execute that call speculatively for free.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — Conditional execution', cite: 'If the condition of an instruction is not met, the instruction has no effect on the registers, memory or flags, but still takes an instruction slot.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Conditional execution', cite: 'Conditional execution avoids the pipeline penalty of a mispredicted branch, at the cost of always issuing the instruction.' }
  ],
  ex: [
    { k: 'code', q: 'Put the larger of r0 and r1 into r2, without any branch.', start: '    mov  r0, #17\n    mov  r1, #42\n', check: [{ reg: 'r2', eq: 42 }, { notContains: 'b ' }], solution: '    mov  r0, #17\n    mov  r1, #42\n    cmp   r0, r1\n    movgt r2, r0\n    movle r2, r1\n', hints: ['One <code>cmp</code>, two conditional <code>mov</code>s with opposite conditions.'], why: 'The two conditions must be exhaustive, or r2 is left undefined on some inputs.' },
    { k: 'code', q: 'Compute the absolute value of r0 (start it at −25) without a branch.', start: '    mvn  r0, #24     @ r0 = -25\n', check: [{ reg: 'r0', eq: 25 }, { notContains: 'b ' }], solution: '    mvn  r0, #24\n    cmp   r0, #0\n    rsblt r0, r0, #0\n', hints: ['<code>rsb r0, r0, #0</code> computes 0 − r0.', 'Make it conditional on <code>lt</code>.'], why: 'RSB — reverse subtract — exists precisely so that 0 minus a register is one instruction.' },
    { k: 'mcq', q: 'A conditional instruction whose condition is false costs…', opts: ['Nothing at all', 'One instruction slot', 'The same as a mispredicted branch', 'Two cycles'], a: 1, why: 'It is fetched and decoded and then does nothing. Predictable, and cheap — but not free.' },
    { k: 'mcq', q: 'When is a branch better than conditional execution?', opts: ['Never', 'When the conditional body is long, so that executing it uselessly wastes many slots', 'When the condition is EQ', 'When the loop is nested'], a: 1, why: 'Past roughly eight instructions, fetching and discarding costs more than a well-predicted branch.' },
    { k: 'code', q: 'Count how many of the 8 words at <code>a</code> are negative, using no branch inside the loop body.', start: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n1:\n\n.data\na: .word 5, -3, 0, -9, 2, -1, 7, -4\n', check: [{ reg: 'r0', eq: 4 }], solution: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    cmp  r3, #0\n    addlt r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word 5, -3, 0, -9, 2, -1, 7, -4\n', hints: ['<code>cmp r3, #0</code> then <code>addlt</code>.', 'Use <code>lt</code>, not <code>lo</code> — these are signed values.'], why: '−3, −9, −1 and −4 — four of them. The only branch is the loop\'s own, which predicts perfectly.' }
  ]
},

/* ------------------------------------------------------------------ 6.2 */
{
  id: 'u6l2', title: 'Branchless min, max and select', goal: 'Build the small branchless primitives loops are made of.',
  teach: [
    { t: 'p', x: 'Four patterns cover most of what a loop body needs to decide. Learn them as units.' },
    { t: 'code', cap: 'max', x: '    cmp   r0, r1\n    movlt r0, r1         @ r0 = max(r0, r1)' },
    { t: 'code', cap: 'min', x: '    cmp   r0, r1\n    movgt r0, r1         @ r0 = min(r0, r1)' },
    { t: 'code', cap: 'select: r0 = cond ? a : b', x: '    cmp   r4, #0\n    movne r0, r1\n    moveq r0, r2' },
    { t: 'code', cap: 'saturating add to 255', x: '    add   r0, r0, r1\n    cmp   r0, #255\n    movhi r0, #255' },
    { t: 'h', x: 'Running max in a loop' },
    { t: 'code', cap: 'One compare, one conditional move, per element', x: '    ldr  r1, =a\n    mov  r2, #8\n    mvn  r0, #0x80000000 @ smallest possible signed value... see the note\n1:  ldr  r3, [r1], #4\n    cmp  r3, r0\n    movgt r0, r3\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'note', x: 'Initialising a running maximum is its own small trap. Starting at 0 is wrong if every element is negative. The safe move is to load the first element as the initial maximum and loop over the remaining n−1 — which also removes the need for a magic constant.' },
    { t: 'h', x: 'The bit-twiddling alternative' },
    { t: 'p', x: 'Classic branchless tricks like <code>min = b ^ ((a ^ b) &amp; -(a &lt; b))</code> exist because most architectures have no conditional move. ARM does, so on ARM the straightforward version is both clearer and faster. Recognise the trick when you read portable C; do not write it in ARM assembly.' }
  ],
  real: {
    title: 'Saturating pixel blending',
    text: 'Adding two 8-bit colour channels can exceed 255. Every blend loop in every 2D renderer therefore contains a saturating add. Done with branches it is unpredictable; done with a conditional move it is two extra cycles, always.',
    code: '@ blend one channel with saturation\n    ldrb  r3, [r1], #1\n    ldrb  r4, [r2], #1\n    add   r3, r3, r4\n    cmp   r3, #255\n    movhi r3, #255\n    strb  r3, [r0], #1'
  },
  deep: {
    kind: 'pitfall',
    title: 'A pixel plotted off the edge',
    text: 'Nothing about <code>STRB</code> checks that the address it is given is still inside the framebuffer. A coordinate that drifts outside 0-319 or 0-239 turns into a byte offset outside the buffer\'s 9600 bytes, and the store goes wherever that computed address happens to land -- on this machine that might be the unmapped gap just past the framebuffer, which halts the program with a fault, or it might be one of the other peripherals mapped a little further up. Neither is the pixel you meant to draw, and on real hardware the equivalent write very often lands on ordinary memory with no fault at all. The fix is the branchless clamp from this lesson, applied to the coordinate before it is ever turned into an address.',
    a: { lab: 'Wrong: no bound on y', code: '@ r6 = y, can be negative or >= 240 from earlier arithmetic\n    mov  r7, #40\n    mul  r8, r6, r7      @ row offset -- garbage in, garbage out\n    ldr  r9, =0x20000000\n    add  r9, r9, r8\n    strb r5, [r9]        @ lands outside the framebuffer if r6 was out of range' },
    b: { lab: 'Right: clamp before computing the address', code: '@ r6 = y, clamp to 0..239 first -- branchless\n    cmp  r6, #239\n    movgt r6, #239\n    cmp  r6, #0\n    movlt r6, #0\n    mov  r7, #40\n    mul  r8, r6, r7\n    ldr  r9, =0x20000000\n    add  r9, r9, r8\n    strb r5, [r9]' },
    note: 'A framebuffer store that goes out of range is not guaranteed to fault -- it depends entirely on where the bad address lands, and on most real hardware the answer is "some other piece of memory, silently." That unpredictability, not a crash you can rely on, is what lets this bug survive testing until the one input that finally walks off the edge.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — MOV (register)', cite: 'A conditional MOV writes the destination only if the condition holds; otherwise the register is unchanged.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — USAT, SSAT', cite: 'USAT and SSAT saturate a value to a given bit width in a single instruction.' }
  ],
  ex: [
    { k: 'code', q: 'Find the largest of the 8 signed words at <code>a</code>. Initialise the running maximum from the first element, not a constant.', start: '    ldr  r1, =a\n    mov  r2, #7\n\n.data\na: .word -5, -3, -20, -9, -2, -11, -7, -4\n', check: [{ reg: 'r0', eq: 4294967294 }], solution: '    ldr  r1, =a\n    mov  r2, #7\n    ldr  r0, [r1], #4\n1:  ldr  r3, [r1], #4\n    cmp  r3, r0\n    movgt r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\na: .word -5, -3, -20, -9, -2, -11, -7, -4\n', hints: ['Load the first element into r0 before the loop, then loop over the other seven.', 'The answer is −2, which as unsigned bits is 4294967294.'], why: 'Every element is negative, so a maximum initialised to 0 would have given the wrong answer.' },
    { k: 'code', q: 'Add r1 into r0 with saturation at 255. Start r0 = 200, r1 = 100.', start: '    mov  r0, #200\n    mov  r1, #100\n', check: [{ reg: 'r0', eq: 255 }, { notContains: 'b ' }], solution: '    mov  r0, #200\n    mov  r1, #100\n    add   r0, r0, r1\n    cmp   r0, #255\n    movhi r0, #255\n', hints: ['Add first, then clamp with a conditional move.'], why: '300 clamps to 255. This is the core of every alpha-blend loop.' },
    { k: 'mcq', q: 'Why is the XOR-and-mask branchless min trick a bad idea on ARM?', opts: ['It gives wrong answers', 'ARM has conditional moves, so the direct version is shorter, clearer and faster', 'It does not assemble', 'It needs NEON'], a: 1, why: 'That trick exists for architectures without predication. ARM is not one of them.' },
    { k: 'mcq', q: 'What is wrong with initialising a running maximum to 0?', opts: ['Nothing', 'If every element is negative, the answer comes out as 0, which is not in the array', '0 is not a valid register value', 'It is slower'], a: 1, why: 'Initialise from the first element instead — correct for every input, and one instruction shorter.' },
    { k: 'code', q: 'Compute r0 = (r4 != 0) ? r1 : r2, branchless. r4 = 0, r1 = 11, r2 = 22.', start: '    mov  r4, #0\n    mov  r1, #11\n    mov  r2, #22\n', check: [{ reg: 'r0', eq: 22 }, { notContains: 'b ' }], solution: '    mov  r4, #0\n    mov  r1, #11\n    mov  r2, #22\n    cmp   r4, #0\n    movne r0, r1\n    moveq r0, r2\n', hints: ['<code>cmp r4, #0</code> then two opposite conditional moves.'], why: 'r4 is zero, so the EQ move wins and r0 gets 22.' }
  ]
},

/* ------------------------------------------------------------------ 6.3 */
{
  id: 'u6l3', title: 'IT blocks in Thumb-2', goal: 'Read and write conditional Thumb code.',
  teach: [
    { t: 'p', x: 'Thumb-2 instructions do not each carry a condition field — there is no room. Instead, an <code>IT</code> instruction declares that the next one to four instructions are conditional.' },
    { t: 'code', cap: 'IT, and its suffix letters', x: '    cmp   r0, r1\n    ite   gt             @ If-Then-Else on GT\n    movgt r2, r0         @   T: runs when GT\n    movle r2, r1         @   E: runs when the opposite, LE' },
    { t: 'table', head: ['Written', 'Covers', 'Pattern'], rows: [
      ['<code>IT</code>', '1 instruction', 'T'],
      ['<code>ITT</code>', '2', 'both on the condition'],
      ['<code>ITE</code>', '2', 'one on, one on the inverse'],
      ['<code>ITTE</code>', '3', 'on, on, inverse'],
      ['<code>ITTEE</code>', '4', 'on, on, inverse, inverse']
    ] },
    { t: 'note', x: 'The assembler will usually generate the <code>IT</code> for you if you write the conditional instructions, and it will complain if your suffixes do not match what you declared. Writing IT blocks by hand is mostly an exercise in getting the T/E letters to agree with the instructions that follow.' },
    { t: 'h', x: 'Rules that bite' },
    { t: 'p', x: 'Inside an IT block: at most four instructions; the conditions must alternate exactly as declared; you may not branch into the middle; and the last instruction may be a branch but nothing may follow it. An instruction that sets flags inside an IT block is legal but changes the condition for the instructions after the block, not within it.' },
    { t: 'h', x: 'Why this matters for loops' },
    { t: 'p', x: 'Most 32-bit ARM code shipped today is Thumb-2, because it is roughly 30% smaller and therefore fits the instruction cache better. Your branchless loop body, written for A32, becomes an IT block in Thumb — and IT blocks are capped at four instructions, so long predicated sequences have to be broken up or branched.' }
  ],
  real: {
    title: 'Cortex-M is Thumb-only',
    text: 'Every Cortex-M processor — the M0, M3, M4, M7 in microcontrollers everywhere — executes Thumb and nothing else. If you write a conditional loop body for an M4, it is an IT block by definition. On Cortex-M0 there is no IT at all, and every conditional is a branch.',
    code: '@ Cortex-M4: clamp inside an IT block\n    cmp   r0, #255\n    it    hi\n    movhi r0, #255'
  },
  deep: {
    kind: 'pitfall',
    title: 'Flags set inside the block do not rewind it',
    text: 'The condition for every instruction inside an <code>IT</code> block is fixed the moment <code>IT</code> executes, from whatever the flags were then -- it is not re-evaluated instruction by instruction. An instruction inside the block that updates the flags changes what they are for whatever comes <i>after</i> the block, but it does nothing to the predicates already assigned to the instructions still inside it.',
    a: { lab: 'Confusing: expecting CMPGT to steer the next line', code: '    cmp   r0, r1\n    itte  gt\n    cmpgt r2, r3        @ this DOES update the flags\n    movgt r4, r2        @ still tests the ORIGINAL r0-vs-r1 result, not this cmp\n    movle r4, r3' },
    b: { lab: 'Clear: close the block, then test the new flags', code: '    cmp   r0, r1\n    ite   gt\n    movgt r4, r2\n    movle r4, r3\n    cmp   r2, r3        @ a fresh IT block would see THESE flags\n    it    gt\n    movgt r5, r2' },
    note: 'If a second comparison needs to steer anything, it has to sit in a block of its own, opened after the first one closes -- a real trap when porting hand-written A32 predicated code into Thumb-2, where there is no such block boundary to trip over.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — IT', cite: 'IT makes up to four following instructions conditional; the condition for each is specified by the T and E letters in the instruction mnemonic.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A6 — The Thumb instruction set', cite: 'Thumb instructions are 16 or 32 bits; most do not include a condition field, so conditional execution is provided by the IT instruction.' }
  ],
  ex: [
    { k: 'mcq', q: 'How many instructions can one IT block cover?', opts: ['1', '2', '4', '8'], a: 2, why: 'Up to four, described by the T and E letters after IT.' },
    { k: 'mcq', q: 'What does <code>ITE GT</code> declare?', opts: ['Two instructions, both on GT', 'Two instructions: the first on GT, the second on LE', 'Three instructions on GT', 'One instruction on GT'], a: 1, why: 'T then E: the condition, then its inverse.' },
    { k: 'mcq', q: 'Cortex-M0 has no IT instruction. What must a conditional body use instead?', opts: ['NEON', 'A branch', 'LDM', 'Nothing — it is impossible'], a: 1, why: 'M0 implements a small Thumb subset with no IT, so every conditional is a branch.' },
    { k: 'code', q: 'Write the max-of-two using an explicit ITE block. (This emulator accepts IT and checks your suffixes are consistent.)', start: '    mov  r0, #9\n    mov  r1, #4\n', check: [{ reg: 'r2', eq: 9 }, { contains: 'ite' }], solution: '    mov  r0, #9\n    mov  r1, #4\n    cmp   r0, r1\n    ite   gt\n    movgt r2, r0\n    movle r2, r1\n', hints: ['<code>ite gt</code>, then <code>movgt</code>, then <code>movle</code>.'], why: 'The T instruction takes the declared condition, the E instruction its inverse.' },
    { k: 'mcq', q: 'Why is most shipped 32-bit ARM code Thumb-2?', opts: ['It is a newer architecture', 'It is about 30% smaller, which means better instruction-cache behaviour', 'It has more registers', 'It runs at a higher clock'], a: 1, why: 'Density. On small caches, smaller code is faster code.' }
  ]
},

/* ------------------------------------------------------------------ 6.4 */
{
  id: 'u6l4', title: 'When predication loses', goal: 'Know the cases where a branch is genuinely better.',
  teach: [
    { t: 'p', x: 'Conditional execution is not free and it is not always right. Three situations where a branch wins:' },
    { t: 'h', x: '1. The body is long' },
    { t: 'p', x: 'Ten predicated instructions cost ten slots every iteration whether or not they do anything. A correctly predicted branch costs one or two. If the body is long, branch.' },
    { t: 'h', x: '2. The condition is highly predictable' },
    { t: 'p', x: 'A branch that goes the same way 99% of the time is predicted correctly 99% of the time and is essentially free. Predication throws away that advantage: it pays the full cost every single iteration, including the 99% where the answer was obvious.' },
    { t: 'h', x: '3. The skipped work is expensive' },
    { t: 'code', cap: 'A predicated division is still a division you nearly executed', x: '@ predicated: the SDIV slot is consumed every iteration\n    cmp   r3, #0\n    sdivne r0, r1, r3\n\n@ branched: the division is genuinely skipped\n    cmp  r3, #0\n    beq  1f\n    sdiv r0, r1, r3\n1:' },
    { t: 'note', x: 'On modern out-of-order ARM cores the balance has shifted further towards branches, because branch predictors have become extremely good and because predicated instructions create false dependencies that limit reordering. ARMv8 removed most conditional execution from A64 for exactly this reason — it kept only conditional select, compare and branch.' },
    { t: 'h', x: 'The honest summary' },
    { t: 'table', head: ['Situation', 'Use'], rows: [
      ['Short body, unpredictable condition', 'Predication'],
      ['Short body, predictable condition', 'Either — measure'],
      ['Long body', 'Branch'],
      ['Body contains something expensive', 'Branch'],
      ['In-order core (Cortex-A7, A53 aarch32, Cortex-M)', 'Predication more often'],
      ['Out-of-order core (Cortex-A15, A7x)', 'Branch more often']
    ] }
  ],
  real: {
    title: 'Why A64 dropped conditional execution',
    text: 'ARMv8\'s 64-bit instruction set kept only CSEL, CSINC, CCMP and the like. The architects concluded that with good branch prediction and out-of-order execution, general predication cost more in encoding space and scheduling freedom than it earned. If you write 32-bit ARM today, predication is still a real tool — but it is a tool whose era is closing.',
    code: '@ A64 keeps only the select form:\n@   cmp  w0, w1\n@   csel w2, w0, w1, gt\n@ which is the max idiom, and nothing more general'
  },
  deep: {
    kind: 'cores',
    title: 'Predication is a data hazard in disguise',
    text: 'A conditional instruction that might not execute has to be treated as though it reads its own destination, because the result is either the new value or whatever was already there, and nothing knows which until the condition resolves. That is a real input dependency a plain, unconditional instruction never has, and an out-of-order core\'s scheduler has to track it. On an in-order core such as the Cortex-A7 this barely matters, since everything issues in program order regardless. On an out-of-order core, a chain of conditional writes to the same register serialises exactly where a correctly predicted branch would not have.',
    code: '@ MOVGT and MOVLE both target r2, so each one depends on\n@ whatever r2 already held -- a dependency neither would have alone\n    cmp   r0, r1\n    movgt r2, r0\n    movle r2, r1',
    note: 'This false-dependency effect is part of why ARMv8\'s A64 kept only <code>CSEL</code> and its relatives rather than general predication: a conditional select reads both candidate values as ordinary inputs and carries no hidden dependency on its own destination.'
  },
  refs: [
    { src: 'ARM ARM for ARMv8-A (DDI 0487), A64 instruction set overview', cite: 'A64 does not provide general conditional execution; conditional behaviour is provided by conditional select, conditional compare and conditional branch instructions.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Branch prediction', cite: 'A mispredicted branch incurs a penalty of several cycles corresponding to the pipeline depth.' }
  ],
  ex: [
    { k: 'mcq', q: 'Your loop body has a 12-instruction conditional section that runs about 1% of the time. Predicate or branch?', opts: ['Predicate', 'Branch — 12 wasted slots every iteration against a branch that predicts correctly 99% of the time', 'Either', 'Use NEON'], a: 1, why: 'Long body plus predictable condition is the clearest case for a branch.' },
    { k: 'mcq', q: 'Why did ARMv8\'s A64 drop general conditional execution?', opts: ['It was too slow to decode', 'Good branch prediction and out-of-order execution made it a poor trade for encoding space and scheduling freedom', 'It was never used', 'To save power'], a: 1, why: 'A64 kept CSEL and friends — the cases that still pay — and dropped the rest.' },
    { k: 'mcq', q: 'On which kind of core does predication pay off most?', opts: ['Large out-of-order application cores', 'Simple in-order cores such as Cortex-M and Cortex-A7', 'Cores with large caches', 'It is identical everywhere'], a: 1, why: 'In-order cores have weaker prediction and no reordering to lose, so avoiding a branch is a clearer win.' },
    { k: 'mcq', q: 'A predicated <code>SDIV</code> whose condition is false costs…', opts: ['Nothing', 'A slot — the instruction is still issued even though it does no work', 'A full division', 'A mispredict penalty'], a: 1, why: 'It does not perform the division, but it does occupy its place in the stream — which is why skipping expensive work is a job for a branch.' },
    { k: 'mcq', q: 'What makes a Cortex-M0\'s timing analysable in a way a Cortex-A15\'s is not?', opts: ['It runs at a lower clock speed', 'No pipeline flush to model, no cache, no branch prediction — every instruction has a fixed, documented cycle count', 'It has fewer registers', 'It only supports Thumb'], a: 1, why: 'Determinism, not speed. It is why hard-real-time firmware so often favours an in-order microcontroller core over a speculative application core.' }
  ]
},

/* ------------------------------------------------------------------ 6.5 */
{
  id: 'u6l5', title: 'Table lookup instead of deciding', goal: 'Replace a chain of comparisons with one load.',
  teach: [
    { t: 'p', x: 'The oldest optimisation in computing: if a loop keeps asking the same question, answer it once in advance and keep the answers in a table. One load replaces a whole chain of compares and branches.' },
    { t: 'code', cap: 'Classify each byte with one load', x: '@ instead of: if (c>=48 && c<=57) digit; else if (c>=65 && c<=90) upper; ...\n    ldr  r5, =ctype\n1:  ldrb r3, [r1], #1\n    ldrb r4, [r5, r3]    @ one load gives the whole answer\n    tst  r4, #DIGIT\n    ...' },
    { t: 'h', x: 'The economics' },
    { t: 'table', head: ['', 'Compare chain', 'Table lookup'], rows: [
      ['Instructions per element', '4–12, data-dependent', '1'],
      ['Branches per element', '2–6, unpredictable', '0'],
      ['Memory used', 'none', 'table size'],
      ['Cache behaviour', 'code is hot', 'table must stay hot too']
    ] },
    { t: 'note', x: 'A 256-byte table is 4 cache lines and will stay resident in any loop that touches it repeatedly. A 64 KB table will not, and a table lookup that misses the cache every time is far slower than the compares it replaced. Table size is the whole decision.' },
    { t: 'h', x: 'Building a table at run time' },
    { t: 'code', cap: 'A squares table, built by a loop, used by a loop', x: '@ build: 16 entries\n    ldr  r0, =sq\n    mov  r1, #0\n1:  mul  r2, r1, r1\n    str  r2, [r0, r1, lsl #2]\n    add  r1, r1, #1\n    cmp  r1, #16\n    blo  1b\n\n@ use: no multiply in the hot loop at all\n    ldr  r2, [r0, r3, lsl #2]' },
    { t: 'p', x: 'Building the table is itself a loop — a cheap one that runs once. Everything after it is a load.' }
  ],
  real: {
    title: 'CRC32 is a table lookup in a loop',
    text: 'Computing CRC32 bit by bit takes 8 shift-and-conditional-XOR steps per byte. With a 1 KB table of 256 precomputed words it takes one XOR, one shift and one load per byte — about eight times faster. Practically every CRC implementation in the world is this loop.',
    code: '@ CRC32, table-driven: one byte per iteration\n1:  ldrb r3, [r1], #1\n    eor  r3, r3, r0\n    and  r3, r3, #0xFF\n    ldr  r3, [r4, r3, lsl #2]\n    eor  r0, r3, r0, lsr #8\n    subs r2, r2, #1\n    bne  1b'
  },
  deep: {
    kind: 'pitfall',
    title: 'Rebuilding the table you already built',
    text: 'A lookup table only pays for itself if it is built once and reused. The classic way to get this wrong is a routine that builds its table on every call, above the loop that uses it, so a 256-entry byte popcount table meant to turn a per-byte loop into a single load instead spends 256 loop trips rebuilding itself before it does one useful lookup — every single time the function runs.',
    a: { lab: 'Wrong: the table is rebuilt on every call', code: 'count_set_bits:              @ called once per buffer\n    push {r4-r6, lr}\n    ldr  r4, =popcnt_tbl\n    mov  r5, #0\n1:  mov  r6, r5              @ stands in for popcnt(r5) -- rebuilding all 256 entries, every single call\n    strb r6, [r4, r5]\n    add  r5, r5, #1\n    cmp  r5, #256\n    blo  1b\n2:  ldrb r6, [r1], #1\n    ldrb r6, [r4, r6]\n    add  r0, r0, r6\n    subs r2, r2, #1\n    bne  2b\n    pop  {r4-r6, pc}' },
    b: { lab: 'Right: build once, call many times', code: 'build_popcnt_tbl:            @ called ONCE, before the first use\n    ldr  r4, =popcnt_tbl\n    mov  r5, #0\n1:  mov  r6, r5              @ stands in for popcnt(r5)\n    strb r6, [r4, r5]\n    add  r5, r5, #1\n    cmp  r5, #256\n    blo  1b\n    bx   lr\n\ncount_set_bits:              @ every later call: the table already exists\n    push {r4, lr}\n    ldr  r4, =popcnt_tbl\n2:  ldrb r6, [r1], #1\n    ldrb r6, [r4, r6]\n    add  r0, r0, r6\n    subs r2, r2, #1\n    bne  2b\n    pop  {r4, pc}' },
    note: 'The table build is itself a loop worth hoisting — the same loop-invariant reasoning from Unit 4, applied across calls instead of across iterations. A table amortised over one call is barely faster than the arithmetic it replaced; amortised over a million calls it is nearly free.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Data caches', cite: 'Lookup tables are effective when the table remains resident in cache; large tables can cost more in cache misses than the computation they replace.' },
    { src: 'Hacker\'s Delight (Warren, 2nd ed.), Chapter 5 -- Counting bits', cite: 'A precomputed table of one-byte population counts turns counting the bits of a word into four table lookups and three additions.' }
  ],
  ex: [
    { k: 'code', q: 'Build a table of the first 8 squares at <code>sq</code>, then use it to put 5² in r0 with a single load.', start: '    ldr  r6, =sq\n    mov  r1, #0\n1:\n\n.data\nsq: .space 32\n', check: [{ reg: 'r0', eq: 25 }, { memLabel: 'sq', words: [0, 1, 4, 9, 16, 25, 36, 49] }], solution: '    ldr  r6, =sq\n    mov  r1, #0\n1:  mul  r2, r1, r1\n    str  r2, [r6, r1, lsl #2]\n    add  r1, r1, #1\n    cmp  r1, #8\n    blo  1b\n    mov  r3, #5\n    ldr  r0, [r6, r3, lsl #2]\n\n.data\nsq: .space 32\n', hints: ['Build with <code>mul</code> and a scaled store.', 'Then read entry 5 with <code>ldr r0, [r6, r3, lsl #2]</code>.'], why: 'The build loop runs 8 times; every later square costs one load.' },
    { k: 'mcq', q: 'When is a lookup table the wrong choice?', opts: ['When the table is small', 'When the table is too large to stay in cache, so every lookup is a memory miss', 'When the loop is short', 'When the values are constant'], a: 1, why: 'A cache-missing lookup can easily be slower than the arithmetic it replaced.' },
    { k: 'code', q: 'Use the 8-entry table at <code>t</code> to translate the 6 bytes at <code>src</code> into <code>dst</code>.', start: '    ldr  r6, =t\n    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #6\n1:\n\n.data\nt:   .byte 100,101,102,103,104,105,106,107\nsrc: .byte 0,3,1,7,2,5\ndst: .space 6\n', check: [{ memLabel: 'dst', bytes: [100, 103, 101, 107, 102, 105] }], solution: '    ldr  r6, =t\n    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #6\n1:  ldrb r3, [r1], #1\n    ldrb r4, [r6, r3]\n    strb r4, [r0], #1\n    subs r2, r2, #1\n    bne  1b\n\n.data\nt:   .byte 100,101,102,103,104,105,106,107\nsrc: .byte 0,3,1,7,2,5\ndst: .space 6\n', hints: ['Load the index, use it as an offset into the table, store the result.', 'Bytes need no shift: <code>ldrb r4, [r6, r3]</code>.'], why: 'This is a translate loop — the same shape as character-set conversion and colour palette mapping.' },
    { k: 'mcq', q: 'How much faster is table-driven CRC32 than the bit-by-bit version, roughly?', opts: ['Twice', 'About eight times — one table step replaces eight bit steps', 'A hundred times', 'No faster'], a: 1, why: 'Each table entry encodes the result of processing eight bits at once.' },
    { k: 'mcq', q: 'Counting the set bits of a byte one bit at a time costs up to eight compare-and-branch steps. What does a 256-entry popcount table reduce that to?', opts: ['Still eight, but without branches', 'One load', 'Zero instructions', 'It depends on the byte'], a: 1, why: 'The table has already done the counting for every possible byte value; using it is one indexed load, the same trade as the CRC32 example earlier in this lesson.' }
  ]
},

/* ------------------------------------------------------------------ 6.6 */
{
  id: 'u6l6', title: 'Counting without looping', goal: 'Use CLZ, RBIT and bit tricks to finish in one instruction what a loop would grind through.',
  teach: [
    { t: 'p', x: 'The fastest loop is the one you do not run. ARMv7 has a handful of instructions that replace whole loops.' },
    { t: 'table', head: ['Instruction', 'Does', 'Replaces'], rows: [
      ['<code>CLZ</code>', 'Count leading zeros', 'a shift-and-test loop, up to 32 iterations'],
      ['<code>RBIT</code>', 'Reverse all 32 bits', 'a 32-iteration shift loop'],
      ['<code>REV</code>', 'Byte-swap a word', 'four shifts and three ORs'],
      ['<code>UBFX</code>', 'Extract a bit-field', 'a shift and a mask'],
      ['<code>SSAT</code>/<code>USAT</code>', 'Saturate to n bits', 'two compares and two moves']
    ] },
    { t: 'code', cap: 'Find the lowest set bit — no loop', x: '    rbit r1, r0          @ reverse: lowest bit becomes highest\n    clz  r1, r1          @ count leading zeros = index of the lowest set bit\n@ r1 = 32 if r0 was zero' },
    { t: 'h', x: 'Isolating and clearing the lowest set bit' },
    { t: 'code', cap: 'The two classic two-instruction tricks', x: '    rsb  r1, r0, #0      @ r1 = -r0\n    and  r1, r1, r0      @ r1 = lowest set bit of r0, on its own\n\n    sub  r1, r0, #1\n    and  r0, r0, r1      @ r0 = r0 with its lowest set bit cleared' },
    { t: 'p', x: 'That second one turns a "loop over all 32 bits" into a "loop over the set bits only". If a word has three bits set, the loop runs three times instead of thirty-two.' },
    { t: 'code', cap: 'Population count, the fast way', x: '    mov  r2, #0\n1:  cmp  r0, #0\n    beq  2f\n    sub  r1, r0, #1\n    and  r0, r0, r1      @ clear the lowest set bit\n    add  r2, r2, #1\n    b    1b\n2:' },
    { t: 'note', x: 'This is known as Kernighan\'s algorithm. For a sparse word it is dramatically faster than testing every bit; for a dense word it is about the same. NEON has a true one-instruction population count — <code>VCNT</code> — which Unit 11 uses.' }
  ],
  real: {
    title: 'Finding the highest-priority pending interrupt',
    text: 'An interrupt controller presents pending interrupts as a bitmask. <code>CLZ</code> turns "which is the highest-priority one set" into a single instruction, and the whole dispatch becomes a load, a CLZ and an indexed branch. No loop at all.',
    code: '    ldr  r0, [r4, #PENDING]\n    cmp  r0, #0\n    beq  none\n    clz  r1, r0          @ 0 = bit 31 is set\n    rsb  r1, r1, #31     @ r1 = index of the highest set bit\n    ldr  pc, [r5, r1, lsl #2]   @ jump straight to its handler'
  },
  deep: {
    kind: 'cores',
    title: 'Cortex-M0 does not have this instruction',
    text: 'CLZ exists in every ARM profile from ARMv5 onward except the very smallest: ARMv6-M, the architecture behind Cortex-M0 and M0+, drops both CLZ and RBIT entirely. Firmware written for those parts falls back to precisely the shift-and-test loop this lesson replaces, up to 32 iterations of it, because the one-cycle instruction that would do the job on any Cortex-A part or a Cortex-M3/M4/M7 simply is not part of the instruction set there.',
    code: '@ the ARMv6-M fallback for count-leading-zeros: no CLZ, so shift and test\n    mov  r1, #0          @ count\n    mov  r2, r0\n    mov  r3, #32\n1:  cmp   r3, #0\n    beq   2f\n    tst   r2, #0x80000000\n    bne   2f\n    lsl   r2, r2, #1\n    add   r1, r1, #1\n    subs  r3, r3, #1\n    b     1b\n2:',
    note: 'This app models one generic ARMv7 core, so <code>CLZ</code> and <code>RBIT</code> are always available here -- the fallback loop above is what the same problem costs on the one common ARM part where they are not.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — CLZ', cite: 'CLZ returns the number of binary zero bits before the first binary one bit in the value, returning 32 if the operand is zero.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — RBIT, REV, REV16', cite: 'RBIT reverses the bit order of a 32-bit register; REV reverses the byte order.' }
  ],
  ex: [
    { k: 'code', q: 'Find the index of the lowest set bit of 0x00000A00 using RBIT and CLZ. Answer in r1.', start: '    ldr  r0, =0x00000A00\n', check: [{ reg: 'r1', eq: 9 }, { notContains: 'bne' }], solution: '    ldr  r0, =0x00000A00\n    rbit r1, r0\n    clz  r1, r1\n', hints: ['RBIT then CLZ, both into r1.'], why: '0xA00 = bits 9 and 11. The lowest is bit 9 — found in two instructions instead of a nine-iteration loop.' },
    { k: 'code', q: 'Count the set bits of 0xF0F0F0F0 using Kernighan\'s algorithm. Answer in r2.', start: '    ldr  r0, =0xF0F0F0F0\n    mov  r2, #0\n', check: [{ reg: 'r2', eq: 16 }, { maxInsn: 110 }], solution: '    ldr  r0, =0xF0F0F0F0\n    mov  r2, #0\n1:  cmp  r0, #0\n    beq  2f\n    sub  r1, r0, #1\n    and  r0, r0, r1\n    add  r2, r2, #1\n    b    1b\n2:\n', hints: ['<code>sub r1, r0, #1</code> then <code>and r0, r0, r1</code> clears the lowest set bit.', 'Loop until r0 is zero, counting the trips.'], why: '16 set bits, so 16 iterations instead of 32.' },
    { k: 'mcq', q: 'What does <code>and r1, r0, -r0</code> (as two instructions: RSB then AND) give you?', opts: ['r0 with the lowest bit cleared', 'The lowest set bit of r0, isolated', 'The highest set bit', 'Zero'], a: 1, why: 'Two\'s complement negation flips everything above the lowest set bit, so ANDing leaves exactly that bit.' },
    { k: 'mcq', q: '<code>CLZ</code> on a register containing zero returns…', opts: ['0', '31', '32', 'undefined'], a: 2, why: 'All 32 bits are zero, so there are 32 leading zeros. That well-defined answer is what makes CLZ safe to use without a guard.' },
    { k: 'code', q: 'Byte-swap 0x11223344 into 0x44332211 using one instruction. Answer in r0.', start: '    ldr  r0, =0x11223344\n', check: [{ reg: 'r0', eq: 0x44332211 }, { maxInsn: 4 }], solution: '    ldr  r0, =0x11223344\n    rev  r0, r0\n', hints: ['<code>rev</code>.'], why: 'One instruction replaces four shifts and three ORs — and it is what every big-endian network parser uses.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
