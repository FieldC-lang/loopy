/* AssArm: Loops — application */
(function () {
  'use strict';
  const UNITS = window.LOOP_UNITS || [];
  const ARM = window.ARM, LC = window.LoopCheck;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  /* ---- storage: localStorage where it works, an Android bridge where it does not ---- */
  const STORE = (function () {
    try {
      if (window.AssArmStore && typeof window.AssArmStore.get === 'function') {
        return {
          getItem: k => { const v = window.AssArmStore.get(k); return (v === null || v === '') ? null : v; },
          setItem: (k, v) => window.AssArmStore.set(k, v)
        };
      }
    } catch (e) { }
    try {
      localStorage.setItem('__assarm_probe', '1');
      localStorage.removeItem('__assarm_probe');
      return localStorage;
    } catch (e) { }
    const mem = Object.create(null);
    return { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); } };
  })();

  /* ============================================================ progress */
  const KEY = 'assarm.loops.v1';
  const DEF = {
    xp: 0, streak: 0, lastDay: null, hearts: 5, heartTs: 0,
    lessons: {}, badges: [], correct: 0, attempts: 0, todayXp: 0, days: 0,
    settings: { unlimited: false, sound: true, bigtext: false }
  };
  let P = load();
  function load() {
    try {
      const raw = STORE.getItem(KEY);
      if (!raw) return JSON.parse(JSON.stringify(DEF));
      const o = JSON.parse(raw);
      return Object.assign(JSON.parse(JSON.stringify(DEF)), o,
        { settings: Object.assign({}, DEF.settings, o.settings || {}) });
    } catch (e) { return JSON.parse(JSON.stringify(DEF)); }
  }
  function save() { try { STORE.setItem(KEY, JSON.stringify(P)); } catch (e) { } }
  function today() { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  function touchDay() {
    const t = today();
    if (P.lastDay === t) return;
    const y = new Date(Date.now() - 864e5);
    const yk = y.getFullYear() + '-' + (y.getMonth() + 1) + '-' + y.getDate();
    P.streak = (P.lastDay === yk) ? P.streak + 1 : 1;
    P.lastDay = t; P.todayXp = 0; P.days++;
    save();
  }
  const HEART_MS = 9 * 60 * 1000;
  function hearts() {
    if (P.settings.unlimited) return 99;
    if (P.hearts >= 5) { P.heartTs = Date.now(); return 5; }
    const gained = Math.floor((Date.now() - (P.heartTs || 0)) / HEART_MS);
    if (gained > 0) { P.hearts = Math.min(5, P.hearts + gained); P.heartTs = Date.now(); save(); }
    return P.hearts;
  }
  function loseHeart() {
    if (P.settings.unlimited) return;
    if (P.hearts === 5) P.heartTs = Date.now();
    P.hearts = Math.max(0, P.hearts - 1); save();
  }
  function addXp(n) { P.xp += n; P.todayXp += n; save(); }

  const ALL_LESSONS = [];
  UNITS.forEach(u => u.lessons.forEach(l => ALL_LESSONS.push({ u, l })));
  const lessonById = id => ALL_LESSONS.find(x => x.l.id === id);
  const crowns = id => (P.lessons[id] && P.lessons[id].crowns) || 0;
  const doneCount = () => ALL_LESSONS.filter(x => crowns(x.l.id) > 0).length;

  /* ============================================================== badges */
  const BADGES = [
    { id: 'first', e: '🥾', n: 'First Steps', d: 'Finish your first lesson', test: () => doneCount() >= 1 },
    { id: 'u1', e: '↻', n: 'Loop Shape', d: 'Finish Unit 1', test: () => unitDone('u1') },
    { id: 'flags', e: '⚑', n: 'Flag Bearer', d: 'Finish Unit 2', test: () => unitDone('u2') },
    { id: 'mem', e: '⇥', n: 'Pointer Walker', d: 'Finish Unit 3', test: () => unitDone('u3') },
    { id: 'blk', e: '▤', n: 'Block Mover', d: 'Finish Unit 5', test: () => unitDone('u5') },
    { id: 'fast', e: '⚡', n: 'Optimiser', d: 'Finish Unit 7', test: () => unitDone('u7') },
    { id: 'beep', e: '🔊', n: 'Bit-Banger', d: 'Finish Unit 8', test: () => unitDone('u8') },
    { id: 'pix', e: '▦', n: 'Pixel Pusher', d: 'Finish Unit 9', test: () => unitDone('u9') },
    { id: 'neon', e: '⟦⟧', n: 'Vectorised', d: 'Finish Unit 11', test: () => unitDone('u11') },
    { id: 'all', e: '★', n: 'Loop Master', d: 'Finish every lesson', test: () => doneCount() === ALL_LESSONS.length },
    { id: 'streak3', e: '🔥', n: 'Three Days', d: 'A 3-day streak', test: () => P.streak >= 3 },
    { id: 'streak7', e: '🔥', n: 'Full Week', d: 'A 7-day streak', test: () => P.streak >= 7 },
    { id: 'xp500', e: '💎', n: '500 XP', d: 'Earn 500 XP', test: () => P.xp >= 500 },
    { id: 'xp2000', e: '👑', n: '2000 XP', d: 'Earn 2000 XP', test: () => P.xp >= 2000 },
    { id: 'gold', e: '🏆', n: 'Gold Crown', d: 'Get 3 crowns on any lesson', test: () => ALL_LESSONS.some(x => crowns(x.l.id) >= 3) }
  ];
  function unitDone(uid) {
    const u = UNITS.find(x => x.id === uid);
    return !!u && u.lessons.every(l => crowns(l.id) > 0);
  }
  function checkBadges() {
    let got = null;
    BADGES.forEach(b => {
      if (P.badges.indexOf(b.id) < 0 && b.test()) { P.badges.push(b.id); got = b; }
    });
    if (got) { save(); toast(got.e + '  Badge unlocked: ' + got.n); }
  }

  /* =============================================================== chrome */
  let toastT = null;
  function toast(msg) {
    const el = $('#toast'); el.textContent = msg; el.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('on'), 2600);
  }
  function renderTop() {
    $('#s-xp').textContent = P.xp;
    $('#s-streak').textContent = P.streak;
    const h = hearts();
    $('#s-hearts').textContent = P.settings.unlimited ? '∞' : h;
  }
  function show(view) {
    $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + view));
    $$('.nav button').forEach(b => b.classList.toggle('on', b.dataset.v === view));
    window.scrollTo(0, 0);
    renderTop();
    if (view === 'home') renderHome();
    if (view === 'profile') renderProfile();
    if (view === 'machine') renderFreeMachine();
    if (view === 'ref') renderRef();
  }

  /* ================================================================= home */
  function renderHome() {
    const total = ALL_LESSONS.length, done = doneCount();
    const pct = Math.round(done / total * 100);
    const goal = 50, gp = Math.min(100, Math.round(P.todayXp / goal * 100));
    let h = '<div class="hero"><h1>' + (done === 0 ? 'Start with the backwards branch' : 'Keep going') + '</h1>' +
      '<p>' + (done === 0
        ? 'Twelve units, ' + total + ' lessons, a real ARMv7 emulator and a framebuffer to draw on.'
        : done + ' of ' + total + ' lessons complete · ' + pct + '%') + '</p>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
      '<div class="barlab"><span>Course progress</span><span>' + done + '/' + total + '</span></div>' +
      '<div class="bar" style="margin-top:10px"><i style="width:' + gp + '%;background:linear-gradient(90deg,#e0af68,#ff9e64)"></i></div>' +
      '<div class="barlab"><span>Daily goal</span><span>' + P.todayXp + '/' + goal + ' XP</span></div></div>';

    const nextId = (ALL_LESSONS.find(x => crowns(x.l.id) === 0) || ALL_LESSONS[0]).l.id;
    UNITS.forEach(u => {
      const uDone = u.lessons.filter(l => crowns(l.id) > 0).length;
      const open = u.lessons.some(l => l.id === nextId) || uDone > 0;
      h += '<div class="unit' + (open ? ' open' : '') + '" style="--uc:' + u.color + '" data-u="' + u.id + '">' +
        '<div class="uh" data-toggle="' + u.id + '">' +
        '<div class="badge">' + u.icon + '</div>' +
        '<div class="t"><b>Unit ' + u.n + ' · ' + esc(u.title) + '</b><span>' + uDone + ' of ' + u.lessons.length + ' lessons</span></div>' +
        '<div class="cw">' + (uDone === u.lessons.length ? '✓' : '') + '</div>' +
        '<div class="chev">›</div></div>' +
        '<div class="ub">' + esc(u.blurb) + '</div><div class="ul">';
      u.lessons.forEach((l, i) => {
        const c = crowns(l.id);
        const cls = c > 0 ? 'done' : (l.id === nextId ? 'next' : '');
        h += '<button class="lrow ' + cls + '" data-l="' + l.id + '">' +
          '<div class="dot">' + (c > 0 ? '✓' : (i + 1)) + '</div>' +
          '<div class="lt"><b>' + esc(l.title) + '</b><span>' + esc(l.goal) + '</span></div>' +
          '<div class="crowns">' + [0, 1, 2].map(k => '<span class="' + (k < c ? '' : 'off') + '">♛</span>').join('') + '</div>' +
          '</button>';
      });
      h += '</div></div>';
    });
    $('#v-home').innerHTML = h;
    $$('#v-home .uh').forEach(e => e.onclick = () => e.parentElement.classList.toggle('open'));
    $$('#v-home .lrow').forEach(e => e.onclick = () => openLesson(e.dataset.l));
  }

  /* ============================================================ highlight */
  const MNEM = /^(adcs?|adds?|ands?|adr|asrs?|bics?|bl|blx|bx|b|cbn?z|clz|cmn|cmp|eors?|it[et]{0,3}|ldm[a-z]*|ldr[bhsd]*|lsls?|lsrs?|mla|mls|mov[wt]?|movs|mrs|msr|muls?|mvns?|nop|orrs?|pld|pli|pop|push|rbit|rev1?6?|rors?|rrx|rsbs?|rscs?|sbcs?|sbfx|sdiv|smlabb|smlal|smull|smulbb|ssat|stm[a-z]*|str[bhd]*|subs?|svc|swi|sxt[bh]|teq|tst|ubfx|udiv|umlal|umull|usat|uxt[bh]|wfe|wfi|yield|sev|dmb|dsb|isb|v[a-z0-9]+)$/i;
  function hl(src) {
    return String(src).split('\n').map(line => {
      let out = '', i = 0;
      const cm = line.search(/[@;]|\/\//);
      let code = cm >= 0 ? line.slice(0, cm) : line, com = cm >= 0 ? line.slice(cm) : '';
      const re = /("(?:[^"\\]|\\.)*"|\.[A-Za-z_][\w.]*|[A-Za-z_.$][\w.$]*:|#?-?(?:0[xXbB])?[0-9][\w]*|[rR](?:1[0-5]|[0-9])\b|\b(?:sp|lr|pc|ip|fp)\b|[sdq][0-9]+\b|[A-Za-z_.$][\w.$]*|\s+|.)/g;
      let m;
      while ((m = re.exec(code)) !== null) {
        const t = m[0];
        if (/^\s+$/.test(t)) { out += t; continue; }
        if (/^"/.test(t)) { out += '<span class="k-l">' + esc(t) + '</span>'; continue; }
        if (/^\./.test(t)) { out += '<span class="k-d">' + esc(t) + '</span>'; continue; }
        if (/:$/.test(t)) { out += '<span class="k-l">' + esc(t) + '</span>'; continue; }
        if (/^#/.test(t) || /^-?\d/.test(t)) { out += '<span class="k-n">' + esc(t) + '</span>'; continue; }
        if (/^([rR](1[0-5]|[0-9])|sp|lr|pc|ip|fp|[sdq]\d+)$/.test(t)) { out += '<span class="k-r">' + esc(t) + '</span>'; continue; }
        if (MNEM.test(t)) { out += '<span class="k-i">' + esc(t) + '</span>'; continue; }
        out += esc(t);
      }
      if (com) out += '<span class="k-c">' + esc(com) + '</span>';
      return out;
    }).join('\n');
  }
  const C_KW = /^(auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|restrict|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while|uint8_t|uint16_t|uint32_t|int8_t|int16_t|int32_t|size_t|bool)$/;
  function hlC(src) {
    return String(src).split('\n').map(line => {
      let code = line, com = '';
      const i = line.indexOf('//');
      if (i >= 0) { code = line.slice(0, i); com = line.slice(i); }
      let out = '';
      const re = /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|0[xX][0-9a-fA-F]+|\d+|[A-Za-z_]\w*|\s+|.)/g;
      let m;
      while ((m = re.exec(code)) !== null) {
        const t = m[0];
        if (/^\s+$/.test(t)) { out += t; continue; }
        if (/^["']/.test(t)) { out += '<span class="k-l">' + esc(t) + '</span>'; continue; }
        if (/^\d|^0[xX]/.test(t)) { out += '<span class="k-n">' + esc(t) + '</span>'; continue; }
        if (C_KW.test(t)) { out += '<span class="k-i">' + esc(t) + '</span>'; continue; }
        out += esc(t);
      }
      if (com) out += '<span class="k-c">' + esc(com) + '</span>';
      return out;
    }).join('\n');
  }
  function codeBlock(src, cap, lang) {
    const body = lang === 'c' ? hlC(src) : hl(src);
    return '<pre>' + (cap ? '<span class="cap">' + esc(cap) + '</span>' : '') + body + '</pre>';
  }

  /* =============================================================== lesson */
  let S = null;   // active lesson session
  function openLesson(id) {
    const rec = lessonById(id);
    if (!rec) return;
    touchDay();
    S = { u: rec.u, l: rec.l, stage: 'teach', idx: 0, right: 0, wrong: 0, gained: 0, order: rec.l.ex.map((_, i) => i) };
    show('lesson'); renderTeach();
  }
  function lessonHead(progress) {
    return '<div class="lhead"><button class="x" id="bk">✕</button>' +
      '<div class="pb"><div class="bar"><i style="width:' + progress + '%"></i></div></div>' +
      '<div class="hrt">' + (P.settings.unlimited ? '∞' : '♥ ' + hearts()) + '</div></div>';
  }
  function bindBack() { const b = $('#bk'); if (b) b.onclick = () => { if (confirm('Leave this lesson? Progress in it is not saved.')) show('home'); }; }

  function renderTeach() {
    const l = S.l, u = S.u;
    let h = lessonHead(0);
    h += '<div class="card"><h2>' + esc(l.title) + '</h2><div class="goal">' + esc(l.goal) + '</div><div class="teach">';
    l.teach.forEach(b => {
      if (b.t === 'p') h += '<p>' + b.x + '</p>';
      else if (b.t === 'h') h += '<h3>' + esc(b.x) + '</h3>';
      else if (b.t === 'note') h += '<div class="note">' + b.x + '</div>';
      else if (b.t === 'code') h += codeBlock(b.x, b.cap);
      else if (b.t === 'table') {
        h += '<table class="t"><thead><tr>' + b.head.map(x => '<th>' + x + '</th>').join('') + '</tr></thead><tbody>' +
          b.rows.map(r => '<tr>' + r.map(c => '<td>' + c + '</td>').join('') + '</tr>').join('') + '</tbody></table>';
      }
    });
    h += '</div></div>';
    if (l.real) {
      h += '<div class="panelbox pb-real"><div class="ph">▶ Real-world use · ' + esc(l.real.title) + '</div><div class="pc"><p>' +
        l.real.text + '</p>' + (l.real.code ? codeBlock(l.real.code) : '') + '</div></div>';
    }
    if (l.deep) {
      const HEAD = {
        compiler: ['pb-comp', '{ } What the compiler does'],
        cores: ['pb-core', '⌁ On real cores'],
        pitfall: ['pb-pit', '⚠ The classic mistake']
      }[l.deep.kind] || ['pb-comp', '{ } Under the hood'];
      h += '<div class="panelbox ' + HEAD[0] + '"><div class="ph">' + HEAD[1] + ' · ' + esc(l.deep.title) +
        '</div><div class="pc"><p>' + l.deep.text + '</p>';
      if (l.deep.a || l.deep.b) {
        h += '<div class="twin">' +
          (l.deep.a ? '<div><div class="lab">' + esc(l.deep.a.lab) + '</div>' + codeBlock(l.deep.a.code, null, l.deep.a.lang) + '</div>' : '') +
          (l.deep.b ? '<div><div class="lab">' + esc(l.deep.b.lab) + '</div>' + codeBlock(l.deep.b.code, null, l.deep.b.lang) + '</div>' : '') +
          '</div>';
      }
      if (l.deep.code) h += codeBlock(l.deep.code, null, l.deep.lang);
      if (l.deep.note) h += '<p style="margin-top:2px">' + l.deep.note + '</p>';
      h += '</div></div>';
    }
    if (l.refs && l.refs.length) {
      h += '<div class="panelbox pb-ref"><div class="ph">📖 References</div><div class="pc">' +
        l.refs.map(r => '<div class="r"><b>' + esc(r.src) + '</b>' + esc(r.cite) + '</div>').join('') + '</div></div>';
    }
    h += '<button class="btn p" id="go">Start the ' + l.ex.length + ' exercises</button>';
    $('#v-lesson').innerHTML = h;
    bindBack();
    $('#go').onclick = () => {
      if (hearts() <= 0) { toast('Out of hearts — they refill over time, or switch on unlimited in Profile.'); return; }
      S.stage = 'ex'; S.idx = 0; renderEx();
    };
  }

  /* ============================================================ exercises */
  function renderEx() {
    const l = S.l, e = l.ex[S.idx];
    const prog = Math.round(S.idx / l.ex.length * 100);
    let h = lessonHead(prog);
    h += '<div class="card exwrap"><div class="q">' + e.q + '</div><div id="body"></div>' +
      '<div class="verdict" id="vd"></div></div><div id="acts"></div>';
    $('#v-lesson').innerHTML = h;
    bindBack();
    const body = $('#body'), acts = $('#acts');
    S.answered = false; S.firstTry = true;
    ({ mcq: exChoice, bug: exChoice, fill: exFill, order: exOrder, match: exMatch, predict: exPredict, code: exCode })[e.k](e, body, acts);
  }

  function verdict(ok, title, extra) {
    const vd = $('#vd');
    vd.className = 'verdict on ' + (ok ? 'ok' : 'no');
    vd.innerHTML = '<b>' + title + '</b>' + (extra || '');
    vd.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  function settle(ok, why) {
    if (S.answered) return;
    S.answered = true;
    P.attempts++; if (ok) P.correct++;
    if (ok) {
      const n = S.firstTry ? 10 : 4;
      S.gained += n; S.right++; addXp(n);
      verdict(true, 'Correct  +' + n + ' XP', why ? '<div style="margin-top:5px">' + why + '</div>' : '');
    } else {
      S.wrong++; loseHeart();
      verdict(false, 'Not quite', why ? '<div style="margin-top:5px">' + why + '</div>' : '');
    }
    renderTop();
    const b = $('#nextb');
    if (b) { b.textContent = S.idx === S.l.ex.length - 1 ? 'Finish' : 'Continue'; b.disabled = false; b.className = 'btn ' + (ok ? 'p' : 'd'); }
    if (!ok && hearts() <= 0 && !P.settings.unlimited) {
      setTimeout(() => toast('No hearts left. They come back over time — or turn on unlimited hearts in Profile.'), 400);
    }
  }
  function nextBtn(acts, checkFn) {
    acts.innerHTML = '<div class="btnrow"><button class="btn s" id="checkb">Check</button>' +
      '<button class="btn p" id="nextb" disabled>Continue</button></div>';
    $('#checkb').onclick = checkFn;
    $('#nextb').onclick = advance;
  }
  function advance() {
    if (S.idx < S.l.ex.length - 1) { S.idx++; renderEx(); }
    else finishLesson();
  }

  /* -- multiple choice / find-the-bug -- */
  function exChoice(e, body, acts) {
    let h = '';
    if (e.code) h += codeBlock(e.code);
    h += e.opts.map((o, i) => '<button class="opt" data-i="' + i + '">' + o + '</button>').join('');
    body.innerHTML = h;
    let sel = -1;
    $$('.opt', body).forEach(b => b.onclick = () => {
      if (S.answered) return;
      sel = +b.dataset.i;
      $$('.opt', body).forEach(x => x.classList.toggle('sel', x === b));
    });
    nextBtn(acts, () => {
      if (sel < 0 || S.answered) return;
      const ok = sel === e.a;
      $$('.opt', body).forEach((x, i) => {
        x.classList.remove('sel');
        if (i === e.a) x.classList.add('ok');
        else if (i === sel) x.classList.add('no');
        else x.classList.add('dim');
      });
      settle(ok, e.why);
    });
  }

  /* -- fill in the blank -- */
  function exFill(e, body, acts) {
    body.innerHTML = codeBlock(e.pre) +
      '<div class="fillbox"><input class="fill" id="fi" placeholder="type the missing line" autocapitalize="off" autocorrect="off" spellcheck="false"></div>' +
      (e.hint ? '<div class="hintbox">Hint: ' + e.hint + '</div>' : '');
    const inp = $('#fi'); setTimeout(() => inp.focus(), 60);
    const norm = s => String(s).toLowerCase().replace(/[\s,]+/g, ' ').replace(/\s*,\s*/g, ',').trim().replace(/\s+/g, '');
    inp.onkeydown = ev => { if (ev.key === 'Enter') $('#checkb').click(); };
    nextBtn(acts, () => {
      if (S.answered) return;
      const got = norm(inp.value);
      const ok = e.a.some(a => norm(a) === got);
      settle(ok, (ok ? '' : 'Expected: <code>' + esc(e.a[0]) + '</code>. ') + (e.why || ''));
    });
  }

  /* -- order the lines -- */
  function exOrder(e, body, acts) {
    let cur = e.lines.map((_, i) => i);
    // shuffle deterministically so it is never already correct
    cur = cur.slice().reverse();
    if (cur.join() === e.a.join()) cur.push(cur.shift());
    function draw() {
      body.innerHTML = '<div class="ordlist">' + cur.map((li, pos) =>
        '<div class="oi"><div class="n">' + (pos + 1) + '</div><div>' + esc(e.lines[li]) + '</div>' +
        '<div class="mv"><button data-d="-1" data-p="' + pos + '">▲</button><button data-d="1" data-p="' + pos + '">▼</button></div></div>'
      ).join('') + '</div>';
      $$('.mv button', body).forEach(b => b.onclick = () => {
        if (S.answered) return;
        const p = +b.dataset.p, d = +b.dataset.d, q = p + d;
        if (q < 0 || q >= cur.length) return;
        const t = cur[p]; cur[p] = cur[q]; cur[q] = t; draw();
      });
    }
    draw();
    nextBtn(acts, () => {
      if (S.answered) return;
      const ok = cur.join() === e.a.join();
      settle(ok, (ok ? '' : 'The right order is:<ul>' + e.a.map(i => '<li><code>' + esc(e.lines[i].trim()) + '</code></li>').join('') + '</ul>') + (e.why || ''));
    });
  }

  /* -- matching pairs -- */
  function exMatch(e, body, acts) {
    const left = e.pairs.map((p, i) => ({ t: p[0], i }));
    const right = e.pairs.map((p, i) => ({ t: p[1], i })).slice().reverse();
    let sel = null, matched = 0;
    body.innerHTML = '<div class="pairs"><div class="pcol" id="pl">' +
      left.map(o => '<button data-i="' + o.i + '">' + o.t + '</button>').join('') + '</div><div class="pcol" id="pr">' +
      right.map(o => '<button data-i="' + o.i + '">' + o.t + '</button>').join('') + '</div></div>';
    function click(side, b) {
      if (S.answered || b.classList.contains('ok')) return;
      if (!sel) { sel = { side, b }; b.classList.add('sel'); return; }
      if (sel.side === side) { sel.b.classList.remove('sel'); sel = { side, b }; b.classList.add('sel'); return; }
      const ok = sel.b.dataset.i === b.dataset.i;
      sel.b.classList.remove('sel');
      if (ok) {
        sel.b.classList.add('ok'); b.classList.add('ok'); matched++;
        if (matched === e.pairs.length) settle(true, e.why);
      } else { S.firstTry = false; toast('Not a pair — try again'); }
      sel = null;
    }
    $$('#pl button', body).forEach(b => b.onclick = () => click('l', b));
    $$('#pr button', body).forEach(b => b.onclick = () => click('r', b));
    acts.innerHTML = '<div class="btnrow"><button class="btn p" id="nextb" disabled>Continue</button></div>';
    $('#nextb').onclick = advance;
  }

  /* -- predict the register -- */
  function exPredict(e, body, acts) {
    body.innerHTML = codeBlock(e.code) +
      '<div class="fillbox"><input class="fill" id="fi" inputmode="numeric" placeholder="value of ' + esc(e.ask) +
      ' (decimal, or 0x...)" autocapitalize="off" spellcheck="false"></div>' +
      '<div class="muted">You can run it in the Machine tab first if you want to cheat — but try it in your head.</div>';
    const inp = $('#fi'); setTimeout(() => inp.focus(), 60);
    inp.onkeydown = ev => { if (ev.key === 'Enter') $('#checkb').click(); };
    nextBtn(acts, () => {
      if (S.answered) return;
      let v = String(inp.value).trim().replace(/[_,\s]/g, '');
      let n = /^0[xX]/.test(v) ? parseInt(v.slice(2), 16) : parseInt(v, 10);
      const ok = (n >>> 0) === (e.a >>> 0);
      settle(ok, (ok ? '' : 'The answer is <code>' + (e.a >>> 0) + '</code>. ') + (e.why || ''));
    });
  }

  /* -- write code -- */
  function exCode(e, body, acts) {
    body.innerHTML =
      '<textarea class="ed" id="ed" spellcheck="false" autocapitalize="off" autocorrect="off"></textarea>' +
      '<div class="btnrow" style="margin:9px 0 10px">' +
      '<button class="btn s" id="runb" style="padding:9px">▶ Run</button>' +
      '<button class="btn s" id="hintb" style="padding:9px">Hint</button>' +
      '<button class="btn s" id="resetb" style="padding:9px">Reset</button></div>' +
      '<div id="hints"></div><div id="mach"></div>';
    const ed = $('#ed');
    ed.value = e.start || '';
    ed.addEventListener('keydown', ev => {
      if (ev.key === 'Tab') {
        ev.preventDefault();
        const s = ed.selectionStart, t = ed.value;
        ed.value = t.slice(0, s) + '    ' + t.slice(ed.selectionEnd);
        ed.selectionStart = ed.selectionEnd = s + 4;
      }
    });
    let hi = 0;
    $('#hintb').onclick = () => {
      const hs = e.hints || [];
      if (hi >= hs.length) {
        if (confirm('Show the full solution? You will not earn XP for this exercise.')) {
          ed.value = e.solution; S.firstTry = false;
          $('#hints').innerHTML = '<div class="hintbox">Read it, then press Run, then Check. Understanding it counts.</div>';
        }
        return;
      }
      S.firstTry = false;
      $('#hints').innerHTML += '<div class="hintbox">Hint ' + (hi + 1) + ': ' + hs[hi] + '</div>';
      hi++;
    };
    $('#resetb').onclick = () => { ed.value = e.start || ''; $('#mach').innerHTML = ''; };
    $('#runb').onclick = () => runInto(ed.value, $('#mach'));
    nextBtn(acts, () => {
      if (S.answered) return;
      const res = LC.checkExercise(ed.value, e.check, { budget: 600000 });
      runInto(ed.value, $('#mach'), res);
      if (res.pass) settle(true, e.why);
      else {
        S.firstTry = false;
        const list = '<ul>' + res.fails.slice(0, 4).map(f => '<li>' + f + '</li>').join('') + '</ul>';
        const vd = $('#vd');
        vd.className = 'verdict on no';
        vd.innerHTML = '<b>Not yet</b>' + list + '<div class="muted" style="margin-top:6px">Fix it and press Check again — a wrong Check here does not cost a heart.</div>';
        const b = $('#nextb'); if (b) b.disabled = true;
        vd.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    });
  }

  /* ============================================================== machine */
  function runInto(src, host, pre) {
    const res = pre || LC.checkExercise(src, [], { budget: 600000 });
    if (res.asmError) {
      host.innerHTML = '<div class="asmerr">' + res.fails.map(esc).join('<br>') + '</div>';
      return res;
    }
    host.innerHTML = machineHTML(res.cpu, res.asm);
    paintMachine(res.cpu);
    return res;
  }
  function machineHTML(cpu, asm) {
    const names = ['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r11', 'ip', 'sp', 'lr', 'pc'];
    let regs = '';
    for (let i = 0; i < 16; i++) {
      const v = (i === 15 ? cpu.pc : cpu.r[i]) >>> 0;
      regs += '<div class="' + (v !== 0 ? 'chg' : '') + '"><span class="rn">' + names[i] + '</span>' +
        '<span class="rv">' + hex8(v) + '</span></div>';
    }
    const fl = ['N', 'Z', 'C', 'V'].map(f => '<span class="' + (cpu[f] ? 'on' : '') + '">' + f + '</span>').join('');
    let fbUsed = 0; for (let i = 0; i < cpu.fb.length; i++) if (cpu.fb[i]) fbUsed++;
    let textUsed = false; for (let i = 0; i < cpu.tpage.length; i++) if (cpu.tpage[i] !== 0x20) { textUsed = true; break; }
    let h = '<div class="machine wide"><div>';
    h += '<div class="mpanel"><h4>Registers</h4><div class="regs">' + regs + '</div>' +
      '<div class="flags">' + fl + '</div>' +
      '<div class="mstat"><span>insns <b>' + cpu.insnCount.toLocaleString() + '</b></span>' +
      '<span>cycles <b>' + cpu.cycles.toLocaleString() + '</b></span>' +
      '<span>reads <b>' + cpu.memReads + '</b></span><span>writes <b>' + cpu.memWrites + '</b></span>' +
      '<span>branches <b>' + cpu.branches + '</b></span></div>';
    if (cpu.error) h += '<div class="asmerr" style="margin:9px 0 0">' + esc(cpu.error) + '</div>';
    h += '</div>';
    if (cpu.console) h += '<div class="mpanel" style="margin-top:10px"><h4>Console</h4><div class="console">' + esc(cpu.console) + '</div></div>';
    const dv = dataView(cpu, asm);
    if (dv) h += '<div class="mpanel" style="margin-top:10px"><h4>Memory (.data)</h4><div class="memview">' + dv + '</div></div>';
    h += '</div><div>';
    if (fbUsed) h += '<div class="mpanel"><h4>Framebuffer · 320×240 · 1 bpp</h4><canvas class="fbcanvas" id="hcv" width="320" height="240"></canvas></div>';
    if (textUsed) h += '<div class="mpanel" style="margin-top:10px"><h4>Text page · 40×24</h4><div class="tpage" id="tpg"></div></div>';
    if (cpu.gpioToggles.length) h += '<div class="mpanel" style="margin-top:10px"><h4>Buzzer pin · ' + cpu.gpioToggles.length + ' toggles</h4><canvas class="spk" id="scv" width="300" height="46"></canvas>' +
      '<button class="btn s" id="playb" style="margin-top:8px;padding:8px;font-size:13px">🔊 Play it</button></div>';
    h += '</div></div>';
    return h;
  }
  function hex8(v) { return '0x' + (v >>> 0).toString(16).toUpperCase().padStart(8, '0'); }
  function dataView(cpu, asm) {
    if (!asm || !asm.syms) return '';
    const labels = Object.keys(asm.syms).filter(k => {
      const a = asm.syms[k] >>> 0;
      return a >= ARM.MAP.DATA_BASE && a < ARM.MAP.DATA_BASE + 4096 && !/^__assarm/.test(k);
    }).sort((a, b) => asm.syms[a] - asm.syms[b]);
    if (!labels.length) return '';
    let out = '';
    labels.slice(0, 6).forEach(name => {
      const base = asm.syms[name] >>> 0;
      let line = name + ':';
      for (let i = 0; i < 16; i++) {
        if (i % 8 === 0 && i) line += '\n' + ' '.repeat(name.length + 1);
        line += ' ' + cpu.read8(base + i).toString(16).toUpperCase().padStart(2, '0');
      }
      out += esc(line) + '\n';
    });
    return out.trimEnd();
  }
  function paintMachine(cpu) {
    const cv = $('#hcv');
    if (cv) {
      const ctx = cv.getContext('2d');
      ctx.putImageData(ARM.renderFB(cpu.fb, ctx), 0, 0);
    }
    const tp = $('#tpg');
    if (tp) {
      let s = '';
      for (let y = 0; y < 24; y++) {
        for (let x = 0; x < 40; x++) {
          const b = cpu.tpage[y * 40 + x];
          s += (b >= 32 && b < 127) ? String.fromCharCode(b) : '.';
        }
        s += '\n';
      }
      tp.textContent = s.trimEnd();
    }
    const sc = $('#scv');
    if (sc) {
      const ctx = sc.getContext('2d'), W = sc.width, H = sc.height;
      ctx.clearRect(0, 0, W, H);
      const t = cpu.gpioToggles, last = t[t.length - 1] || 1;
      ctx.strokeStyle = '#ff9e64'; ctx.lineWidth = 1.5; ctx.beginPath();
      let up = false, px = 0; ctx.moveTo(0, H - 8);
      for (let i = 0; i < t.length; i++) {
        const x = Math.round(t[i] / last * (W - 4)) + 2;
        ctx.lineTo(x, up ? 8 : H - 8);
        up = !up;
        ctx.lineTo(x, up ? 8 : H - 8);
        px = x;
      }
      ctx.lineTo(W - 2, up ? 8 : H - 8);
      ctx.stroke();
    }
    const pb = $('#playb');
    if (pb) pb.onclick = () => playSpeaker(cpu.gpioToggles);
  }
  let actx = null;
  function playSpeaker(toggles) {
    if (!toggles.length) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      const span = toggles[toggles.length - 1] - toggles[0] || 1;
      const dur = Math.min(1.5, Math.max(0.25, span / 1000000 * 1.023e6 / 1.023e6 * 2));
      const rate = actx.sampleRate, n = Math.floor(rate * dur);
      const buf = actx.createBuffer(1, n, rate);
      const d = buf.getChannelData(0);
      let ti = 0, level = 0.22;
      for (let i = 0; i < n; i++) {
        const cyc = toggles[0] + (i / n) * span;
        while (ti < toggles.length && toggles[ti] <= cyc) { ti++; level = -level; }
        d[i] = level * (1 - i / n);
      }
      const src = actx.createBufferSource(); src.buffer = buf;
      src.connect(actx.destination); src.start();
    } catch (e) { toast('Audio is not available here'); }
  }

  /* ======================================================== free machine */
  const DEMO = `@ AssArm: Loops — scratch machine.
@ Edit anything, press Run. The whole ARMv7 core is here.

    ldr  r7, =0x20000000      @ framebuffer: 320x240, 1 bpp, 40-byte stride
    ldr  r11, =0x20020000     @ GPIO — any access toggles the buzzer pin

@ --- clear the framebuffer with block stores (Unit 5) ---
    mov  r0, r7
    mov  r1, #0
    mov  r3, #0
    mov  r4, #0
    mov  r5, #0
    mov  r2, #600             @ 9600 bytes / 16 per pass
1:  stmia r0!, {r1, r3, r4, r5}
    subs  r2, r2, #1
    bne   1b

@ --- draw an XOR texture over all 240 rows (Unit 9) ---
    mov  r6, #0               @ y
    mov  r9, #40              @ the stride
2:  mul  r0, r6, r9           @ row base = y * stride
    add  r0, r0, r7
    mov  r8, #0               @ x, counted in bytes
3:  eor  r10, r8, r6          @ the classic XOR pattern
    and  r10, r10, #0xFF
    strb r10, [r0, r8]
    add  r8, r8, #1
    cmp  r8, #40
    blo  3b
    add  r6, r6, #1
    cmp  r6, #240
    blo  2b

@ --- eight buzzer toggles with a delay between them (Unit 8) ---
    mov  r4, #8
4:  ldr  r2, [r11]
    mov  r5, #40
5:  subs r5, r5, #1
    bne  5b
    subs r4, r4, #1
    bne  4b
`;
  function renderFreeMachine() {
    if ($('#med')) return;
    $('#v-machine').innerHTML =
      '<div class="card"><h2>The machine</h2><div class="goal">A full ARMv7 core, a 320×240 1-bpp framebuffer at 0x20000000, a character console at 0x20010000 and a buzzer pin at 0x20020000.</div>' +
      '<textarea class="ed" id="med" spellcheck="false" autocapitalize="off" autocorrect="off" style="min-height:300px"></textarea>' +
      '<div class="btnrow" style="margin-top:9px"><button class="btn p" id="mrun" style="padding:10px">▶ Run</button>' +
      '<button class="btn s" id="mdemo" style="padding:10px">Demo</button>' +
      '<button class="btn s" id="mclr" style="padding:10px">Clear</button></div></div>' +
      '<div id="mout"></div>' +
      '<div class="card"><h4 style="margin:0 0 8px;font-size:11px;letter-spacing:.09em;text-transform:uppercase;color:var(--fg3)">Memory map</h4>' +
      '<table class="t"><tbody>' +
      '<tr><td><code>0x00008000</code></td><td>.text — your code</td></tr>' +
      '<tr><td><code>0x00018000</code></td><td>.data — your data</td></tr>' +
      '<tr><td><code>0x0002C000</code></td><td>initial SP (stack grows down)</td></tr>' +
      '<tr><td><code>0x20000000</code></td><td>framebuffer — 320×240, 1 bpp, 40-byte stride, bit 7 leftmost (9600 bytes)</td></tr>' +
      '<tr><td><code>0x20010000</code></td><td>character console, 40×24 ASCII</td></tr>' +
      '<tr><td><code>0x20020000</code></td><td>GPIO — any access toggles the buzzer pin</td></tr>' +
      '<tr><td><code>0x20020004</code></td><td>cycle counter (read-only)</td></tr>' +
      '<tr><td><code>0x2002000C</code></td><td>console out — write a byte</td></tr>' +
      '<tr><td><code>0x20020010</code></td><td>random word</td></tr>' +
      '<tr><td><code>0x20020014</code></td><td>halt — write anything</td></tr>' +
      '</tbody></table><p class="muted" style="margin:0">Also: <code>svc #1</code> prints the character in r0, <code>svc #0</code> halts. Falling off the end of your code halts too.</p></div>';
    const ed = $('#med');
    ed.value = STORE.getItem('assarm.loops.scratch') || DEMO;
    ed.addEventListener('keydown', ev => {
      if (ev.key === 'Tab') {
        ev.preventDefault();
        const s = ed.selectionStart;
        ed.value = ed.value.slice(0, s) + '    ' + ed.value.slice(ed.selectionEnd);
        ed.selectionStart = ed.selectionEnd = s + 4;
      }
    });
    $('#mrun').onclick = () => {
      try { STORE.setItem('assarm.loops.scratch', ed.value); } catch (e) { }
      runInto(ed.value, $('#mout'));
    };
    $('#mdemo').onclick = () => { ed.value = DEMO; runInto(ed.value, $('#mout')); };
    $('#mclr').onclick = () => { ed.value = ''; $('#mout').innerHTML = ''; };
  }

  /* ================================================================ done */
  function finishLesson() {
    const id = S.l.id;
    const rec = P.lessons[id] || (P.lessons[id] = { crowns: 0, best: 0 });
    const acc = S.right / Math.max(1, S.right + S.wrong);
    const first = rec.crowns === 0;
    if (rec.crowns < 3) rec.crowns++;
    rec.best = Math.max(rec.best, Math.round(acc * 100));
    let bonus = first ? 20 : 8;
    if (S.wrong === 0) bonus += 10;
    addXp(bonus); S.gained += bonus;
    if (S.wrong === 0 && !P.settings.unlimited) { P.hearts = Math.min(5, P.hearts + 1); }
    save(); checkBadges(); renderTop();

    const next = ALL_LESSONS.find(x => crowns(x.l.id) === 0);
    $('#v-lesson').innerHTML =
      '<div class="done-screen"><div class="big">' + (S.wrong === 0 ? '🏆' : '✅') + '</div>' +
      '<h2>' + (S.wrong === 0 ? 'Flawless' : 'Lesson complete') + '</h2>' +
      '<p>' + esc(S.l.title) + '</p>' +
      '<div class="rewards">' +
      '<div class="rw"><b>+' + S.gained + '</b><span>XP</span></div>' +
      '<div class="rw"><b>' + Math.round(acc * 100) + '%</b><span>Accuracy</span></div>' +
      '<div class="rw"><b>' + '♛'.repeat(rec.crowns) + '</b><span>Crowns</span></div>' +
      '</div>' +
      '<button class="btn p" id="hb">' + (next ? 'Next: ' + esc(next.l.title) : 'Back to the course') + '</button>' +
      '<div class="spacer"></div>' +
      '<button class="btn s" id="rb">Repeat this lesson</button>' +
      '<div class="spacer"></div>' +
      '<button class="btn s" id="cb">Course map</button></div>';
    $('#hb').onclick = () => next ? openLesson(next.l.id) : show('home');
    $('#rb').onclick = () => openLesson(S.l.id);
    $('#cb').onclick = () => show('home');
  }

  /* ============================================================= profile */
  function renderProfile() {
    const total = ALL_LESSONS.length;
    const totalEx = ALL_LESSONS.reduce((n, x) => n + x.l.ex.length, 0);
    const acc = P.attempts ? Math.round(P.correct / P.attempts * 100) : 0;
    let h = '<div class="tiles">' +
      '<div class="tile"><b style="color:var(--gold)">' + P.xp + '</b><span>Total XP</span></div>' +
      '<div class="tile"><b style="color:#ff9e64">' + P.streak + '</b><span>Day streak</span></div>' +
      '<div class="tile"><b style="color:var(--acc)">' + doneCount() + '/' + total + '</b><span>Lessons</span></div>' +
      '<div class="tile"><b style="color:var(--info)">' + acc + '%</b><span>Accuracy</span></div></div>';

    h += '<div class="card"><h4 style="margin:0 0 10px;font-size:11px;letter-spacing:.09em;text-transform:uppercase;color:var(--fg3)">Badges</h4><div class="badges">' +
      BADGES.map(b => '<div class="badge2' + (P.badges.indexOf(b.id) >= 0 ? ' got' : '') + '">' +
        '<span class="e">' + b.e + '</span><b>' + b.n + '</b><span>' + b.d + '</span></div>').join('') + '</div></div>';

    h += '<div class="card"><h4 style="margin:0 0 4px;font-size:11px;letter-spacing:.09em;text-transform:uppercase;color:var(--fg3)">Settings</h4>' +
      '<div class="setting"><div class="t"><b>Unlimited hearts</b><span>Practise without ever being blocked. Nothing in this app costs money.</span></div>' +
      '<div class="sw' + (P.settings.unlimited ? ' on' : '') + '" id="sw-unl"></div></div>' +
      '<div class="setting"><div class="t"><b>Larger text</b><span>Bigger body text throughout</span></div>' +
      '<div class="sw' + (P.settings.bigtext ? ' on' : '') + '" id="sw-big"></div></div>' +
      '<div class="setting"><div class="t"><b>Reset all progress</b><span>XP, crowns, streak and badges</span></div>' +
      '<button class="btn d" style="width:auto;padding:8px 14px;font-size:13px" id="reset">Reset</button></div></div>';

    h += '<div class="card"><h4 style="margin:0 0 8px;font-size:11px;letter-spacing:.09em;text-transform:uppercase;color:var(--fg3)">About</h4>' +
      '<p class="muted" style="margin:0 0 8px">AssArm: Loops — ' + UNITS.length + ' units, ' + total + ' lessons, ' + totalEx +
      ' exercises, and a built-in ARMv7 (A32) emulator with a 320×240 framebuffer, a character console and a GPIO buzzer pin.</p>' +
      '<p class="muted" style="margin:0 0 8px">Every code exercise is checked by running your program on that emulator. Cycle counts use an approximate in-order model in the spirit of a Cortex-A7; use them to compare two versions of your own loop, not to predict real silicon.</p>' +
      '<p class="muted" style="margin:0 0 8px">A companion to the AssArm ARMv7 course. Free, offline, and without a single paid feature.</p>' +
      '<p class="muted" style="margin:0">AssArm: Loops 1.0.0 · com.assarm.loops / assarm-loops</p></div>';
    $('#v-profile').innerHTML = h;
    $('#sw-unl').onclick = function () {
      P.settings.unlimited = !P.settings.unlimited; this.classList.toggle('on', P.settings.unlimited);
      save(); renderTop(); toast(P.settings.unlimited ? 'Unlimited hearts on' : 'Hearts back on');
    };
    $('#sw-big').onclick = function () {
      P.settings.bigtext = !P.settings.bigtext; this.classList.toggle('on', P.settings.bigtext);
      applyBig(); save();
    };
    $('#reset').onclick = () => {
      if (confirm('Erase all progress? This cannot be undone.')) {
        P = JSON.parse(JSON.stringify(DEF)); save(); renderTop(); renderProfile(); toast('Progress reset');
      }
    };
  }
  function applyBig() { document.body.style.fontSize = P.settings.bigtext ? '17px' : '15px'; }

  /* ============================================================ reference */
  function renderRef() {
    if ($('#refbody')) return;
    const rows = [
      ['Loop skeleton', 'init · body · update · test — the four parts of every loop'],
      ['<code>subs rX, rX, #1</code> / <code>bne</code>', 'the canonical two-instruction countdown'],
      ['S suffix', 'without it the flags never change and the loop hangs'],
      ['<code>cmp a, b</code>', 'a subtraction whose result is thrown away'],
      ['Signed conditions', 'GT GE LT LE — for values that can be negative'],
      ['Unsigned conditions', 'HI HS LO LS — for lengths, sizes and addresses'],
      ['<code>[rN], #4</code>', 'post-index: use the address, then advance — the array-loop idiom'],
      ['<code>[rN, #4]!</code>', 'pre-index: advance, then use — walking backwards, and PUSH'],
      ['<code>[rN, rM, lsl #2]</code>', 'scaled index — random access into an array of words'],
      ['<code>ldmia rN!, {r4-r11}</code>', '32 bytes in one instruction'],
      ['<code>addeq</code>, <code>movgt</code>, …', 'predication — a short body with no branch'],
      ['Hoisting', 'anything that does not change belongs above the loop'],
      ['Strength reduction', 'replace a multiply with a running add'],
      ['Unrolling', '4× with independent accumulators, then handle the tail'],
      ['<code>pld [rN, #128]</code>', 'a free hint that starts a cache fetch early'],
      ['Framebuffer address', '<code>base + y*stride + (x&gt;&gt;3)</code>, mask <code>0x80 &gt;&gt; (x&amp;7)</code>'],
      ['Zero-byte test', '<code>(x − 0x01010101) &amp; ~x &amp; 0x80808080</code>'],
      ['NEON', '<code>vld1.32 {d0,d1}, [rN]!</code> — 16 bytes, then <code>vadd.i32 q2, q0, q1</code>']
    ];
    $('#v-ref').innerHTML = '<div class="card" id="refbody"><h2>Quick reference</h2>' +
      '<div class="goal">The things worth having at your fingertips.</div>' +
      '<table class="t"><tbody>' + rows.map(r => '<tr><td style="white-space:normal">' + r[0] + '</td><td>' + r[1] + '</td></tr>').join('') +
      '</tbody></table></div>' +
      '<div class="card"><h4 style="margin:0 0 8px;font-size:11px;letter-spacing:.09em;text-transform:uppercase;color:var(--fg3)">Condition codes</h4>' +
      '<table class="t"><thead><tr><th>Code</th><th>Flags</th><th>After <code>cmp a, b</code></th></tr></thead><tbody>' +
      [['EQ', 'Z=1', 'a == b'], ['NE', 'Z=0', 'a != b'], ['CS / HS', 'C=1', 'a ≥ b unsigned'], ['CC / LO', 'C=0', 'a &lt; b unsigned'],
      ['MI', 'N=1', 'result negative'], ['PL', 'N=0', 'result ≥ 0'], ['VS', 'V=1', 'overflow'], ['VC', 'V=0', 'no overflow'],
      ['HI', 'C=1 &amp; Z=0', 'a &gt; b unsigned'], ['LS', 'C=0 or Z=1', 'a ≤ b unsigned'], ['GE', 'N=V', 'a ≥ b signed'],
      ['LT', 'N≠V', 'a &lt; b signed'], ['GT', 'Z=0 &amp; N=V', 'a &gt; b signed'], ['LE', 'Z=1 or N≠V', 'a ≤ b signed']]
        .map(r => '<tr><td><code>' + r[0] + '</code></td><td>' + r[1] + '</td><td>' + r[2] + '</td></tr>').join('') +
      '</tbody></table></div>';
  }

  /* ================================================================ boot */
  function boot() {
    applyBig();
    touchDay();
    $$('.nav button').forEach(b => b.onclick = () => show(b.dataset.v));
    renderTop();
    show('home');
    setInterval(renderTop, 30000);
    window.addEventListener('beforeunload', save);
    document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
  }
  // Android hardware back button: handled here, returns true if we consumed it
  window.assarmBack = function () {
    const lesson = $('#v-lesson');
    if (lesson && lesson.classList.contains('on')) { show('home'); return true; }
    const home = $('#v-home');
    if (home && !home.classList.contains('on')) { show('home'); return true; }
    return false;
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
