/* AssArm: Loops — curriculum part 1 : Units 1-3 */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u1', n: 1, title: 'The Shape of a Loop', icon: '↻', color: '#5bd6a4',
    blurb: 'A loop is one idea: an instruction that sends the processor backwards. Everything else is bookkeeping.',
    lessons: [

/* ------------------------------------------------------------------ 1.1 */
{
  id: 'u1l1', title: 'What a loop actually is', goal: 'Understand that a loop is nothing but a backwards branch.',
  teach: [
    { t: 'p', x: 'In a high-level language a loop is a keyword: <code>for</code>, <code>while</code>, <code>repeat</code>. In assembly there is no keyword. There is only the program counter — register <b>r15</b>, also called <b>PC</b> — and the fact that you are allowed to write a new value into it.' },
    { t: 'p', x: 'Normally the processor adds 4 to PC after every instruction, because every A32 instruction is exactly 4 bytes long. A <b>branch</b> sets PC to something else instead. If that "something else" is an address you have <i>already executed</i>, the processor runs those instructions again. That is a loop. That is the whole trick.' },
    { t: 'code', cap: 'The smallest loop in the world', x: 'forever:\n    b   forever      @ set PC back to "forever"  ->  runs again, and again' },
    { t: 'note', x: 'This loop never ends, and that is not a mistake — it is how almost every piece of embedded firmware on the planet finishes its <code>main()</code>. You will build a useful version of it in Unit 10.' },
    { t: 'h', x: 'Forwards and backwards' },
    { t: 'p', x: 'A branch to a <i>later</i> address skips instructions — that is an <code>if</code>. A branch to an <i>earlier</i> address repeats instructions — that is a loop. Same instruction, opposite direction. The assembler does not know or care which you meant; it just computes the distance.' },
    { t: 'code', cap: 'Both directions, one instruction', x: '    b   skip          @ forwards: the MOV below never runs\n    mov r0, #99\nskip:\n    mov r0, #1\nback:\n    add r0, r0, #1\n    b   back          @ backwards: the ADD runs for ever' },
    { t: 'h', x: 'Why "label" is not a thing that exists' },
    { t: 'p', x: 'Labels like <code>forever:</code> are a convenience for you. They are not stored anywhere in the finished program. The assembler replaces each one with a number — the address — and encodes the <i>difference</i> between that address and the branch. At run time the processor sees only "add this offset to PC".' }
  ],
  real: {
    title: 'The superloop in every microcontroller',
    text: 'Open the firmware for a washing machine, a drone flight controller, a keyboard, or a Cortex-M4 sensor node, and the last thing <code>main()</code> does is branch to itself. Interrupts do the urgent work; the backwards branch is what stops the CPU from wandering off the end of your program into whatever bytes happen to be there.',
    code: 'main:\n    bl   hardware_init\n    bl   start_timers\nsuperloop:\n    bl   poll_sensors\n    bl   update_control\n    bl   refresh_display\n    b    superloop        @ the backwards branch that never lets go'
  },
  deep: {
    kind: 'cores',
    title: 'The cost of a taken branch depends on the core',
    text: 'A Cortex-M0 has a three-stage pipeline and no branch predictor at all, so a taken branch always costs the same fixed handful of cycles to refill the pipeline, loop or no loop. A Cortex-A7 is an in-order dual-issue core with a branch predictor, so a backwards branch taken on every pass but the last — exactly the shape of a loop — is predicted correctly after the first iteration and costs next to nothing until the final pass mispredicts instead.',
    code: '1:  subs r0, r0, #1\n    bne  1b            @ taken every time except the last',
    note: 'Advice such as "branches are expensive" is really advice about one class of core. On a Cortex-M0 it holds for every branch; on a Cortex-A7 it mostly holds only for a branch the predictor has not seen before.'
  },
  refs: [
    { src: 'ARM Architecture Reference Manual, ARMv7-A/R edition (DDI 0406C)', cite: 'Chapter A8, instruction B — the branch offset is a signed 24-bit word offset applied to PC, giving a range of roughly ±32 MB.' },
    { src: 'ARM Cortex-M0 Technical Reference Manual, Pipeline and instruction timing', cite: 'Cortex-M0 has a three-stage pipeline with no branch prediction, so every taken branch pays the same fixed pipeline-refill cost.' }
  ],
  ex: [
    { k: 'mcq', q: 'What makes an instruction sequence a loop?', opts: ['A special LOOP instruction', 'A branch to an address that has already been executed', 'Using the register r14', 'Declaring a label'], a: 1, why: 'There is no loop instruction in ARMv7. A loop exists when a branch sends PC backwards to code that already ran.' },
    { k: 'mcq', q: 'Every A32 instruction is the same size. How many bytes?', opts: ['1', '2', '4', 'It varies'], a: 2, why: 'A32 (the "ARM" instruction set) is fixed at 4 bytes per instruction, which is why PC normally advances by 4. Thumb instructions are 2 or 4 bytes — a different story you will meet in Unit 6.' },
    { k: 'mcq', q: 'Which of these is a forward branch — an <code>if</code> rather than a loop?', opts: ['<code>top: b top</code>', '<code>b later</code> … <code>later:</code>', '<code>b top</code> … with <code>top:</code> above it', 'All of them'], a: 1, why: 'A branch to a label defined <i>later</i> in the file skips over code. Only a branch to an earlier label repeats it.' },
    { k: 'code', q: 'Write a program that puts 7 in r0, then branches backwards to itself for ever. (The checker stops it for you.)', start: 'spin:\n    mov r0, #7\n    @ add the backwards branch here\n', check: [{ reg: 'r0', eq: 7 }, { infinite: true }], solution: 'spin:\n    mov r0, #7\n    b   spin\n', hints: ['The branch instruction is <code>b</code>.', 'Branch to the label <code>spin</code>.'], why: 'Setting a register then branching backwards is the two-line skeleton every loop grows out of.' },
    { k: 'order', q: 'Put these lines in the order that makes a loop which never ends.', lines: ['    b   again', 'again:', '    add r0, r0, #1'], a: [1, 2, 0], why: 'Label first, body next, backwards branch last. The branch must come <i>after</i> the code it is going to repeat.' }
  ]
},

/* ------------------------------------------------------------------ 1.2 */
{
  id: 'u1l2', title: 'Registers: where a loop lives', goal: 'Know the 16 registers and why loop counters belong in them.',
  teach: [
    { t: 'p', x: 'ARMv7 gives you sixteen 32-bit registers, <b>r0</b> through <b>r15</b>. Three of them have jobs by convention or by hardware:' },
    { t: 'table', head: ['Register', 'Also called', 'What it is for'], rows: [
      ['r0–r3', '—', 'Arguments and return values. Free to clobber inside your loop.'],
      ['r4–r11', '—', 'Long-lived values. If you use them you must save and restore them.'],
      ['r12', 'IP', 'Scratch. A function may destroy it at any moment.'],
      ['r13', 'SP', 'Stack pointer.'],
      ['r14', 'LR', 'Link register — the return address left by <code>BL</code>.'],
      ['r15', 'PC', 'Program counter. Writing to it <i>is</i> branching.']
    ] },
    { t: 'h', x: 'Why this matters for loops' },
    { t: 'p', x: 'A loop runs its body thousands or millions of times. Every trip through the body that touches memory costs far more than one that does not. So the first rule of writing a fast loop is: <b>keep the counter, the pointer and the running total in registers</b>, and touch memory only for the data you are actually processing.' },
    { t: 'code', cap: 'Same job, two speeds', x: '@ slow: the counter lives in memory\nslow:\n    ldr r0, [r1]        @ load counter    <- memory\n    sub r0, r0, #1\n    str r0, [r1]        @ store counter   <- memory\n    cmp r0, #0\n    bne slow\n\n@ fast: the counter lives in a register\nfast:\n    subs r0, r0, #1     @ no memory at all\n    bne fast' },
    { t: 'note', x: 'On a Cortex-A7 the slow version costs roughly five times the cycles of the fast one, and it is four instructions longer. Nothing about the <i>logic</i> changed — only where the number was kept.' },
    { t: 'h', x: 'Reading PC is strange' },
    { t: 'p', x: 'If you read r15 in A32, you do not get the address of the current instruction. You get the current address <b>plus 8</b>, a leftover from the original three-stage pipeline of the ARM1. The emulator in this app models that faithfully, so do not be surprised by it.' }
  ],
  real: {
    title: 'Register pressure in a real DSP loop',
    text: 'A biquad audio filter needs five coefficients, two state variables, an input pointer, an output pointer and a counter — ten live values. ARMv7 has fourteen usable registers, so the whole filter fits with room to spare and never spills to the stack. That single fact is why hand-written ARM audio loops beat naive compiler output so often on 32-bit parts.',
    code: '@ everything the inner loop needs is already in a register\n@ r0=in  r1=out  r2=count  r4..r8=coeffs  r9,r10=state\nfilt:\n    ldr  r3, [r0], #4\n    mla  r11, r3, r4, r9\n    ...\n    subs r2, r2, #1\n    bne  filt'
  },
  deep: {
    kind: 'compiler',
    title: 'Register pressure forces a spill',
    text: 'ARMv7 gives you fourteen usable registers. A loop that needs more live values than that at once cannot keep all of them on-chip, so the compiler must choose some to push to the stack and reload later — a <b>spill</b>. Every spilled value turns one register access into a load or a store inside the loop body, exactly the memory traffic this lesson says to avoid.',
    a: { lab: 'C, ten running totals', lang: 'c', code: 'int sums(int *p, int n) {\n    int s0=0,s1=0,s2=0,s3=0,s4=0;\n    int s5=0,s6=0,s7=0,s8=0,s9=0;\n    for (int i = 0; i < n; i += 10) {\n        s0+=p[i]; s1+=p[i+1]; s2+=p[i+2];\n        s3+=p[i+3]; s4+=p[i+4]; s5+=p[i+5];\n        s6+=p[i+6]; s7+=p[i+7]; s8+=p[i+8];\n        s9+=p[i+9];\n    }\n    return s0+s1+s2+s3+s4+s5+s6+s7+s8+s9;\n}' },
    b: { lab: 'gcc -O2, ARMv7 (two of the ten accumulators)', code: '.L3:\n    ldr   r3, [r4], #40\n    ldr   r5, [sp, #8]      @ reload a spilled accumulator\n    add   r5, r5, r3\n    str   r5, [sp, #8]      @ spill it straight back\n    ldr   r3, [r4, #-36]\n    ldr   r6, [sp, #4]\n    add   r6, r6, r3\n    str   r6, [sp, #4]\n    subs  r7, r7, #1\n    bne   .L3' },
    note: 'Thirteen live values — ten accumulators plus the pointer, the limit and the loop counter — is more than fit alongside the registers the calling convention has already spoken for. Fewer, wider accumulators or a restructured loop is the fix; the compiler cannot invent registers that do not exist.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A2 — Application Level Programmers\' Model', cite: 'r0–r15 are the general-purpose registers; r15 is the PC, and reading it in ARM state returns the instruction address plus 8.' },
    { src: 'Procedure Call Standard for the ARM Architecture (AAPCS, IHI 0042)', cite: 'r0–r3 and r12 are call-clobbered; r4–r11 must be preserved by a called function.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which register is the program counter?', opts: ['r13', 'r14', 'r15', 'r12'], a: 2, why: 'r15 is PC. r13 is SP, r14 is LR, r12 is a scratch register.' },
    { k: 'mcq', q: 'You want a loop counter that survives a <code>bl</code> to another function. Which register is the safest choice?', opts: ['r0', 'r3', 'r5', 'r12'], a: 2, why: 'r4–r11 are callee-saved: a well-behaved function must give them back unchanged. r0–r3 and r12 can be destroyed by any call.' },
    { k: 'mcq', q: 'In A32, reading r15 gives you…', opts: ['the address of the current instruction', 'the address of the current instruction + 4', 'the address of the current instruction + 8', 'zero'], a: 2, why: 'Plus 8 — an artefact of the original three-stage pipeline that was written into the architecture and never removed.' },
    { k: 'predict', q: 'What is in r0 when this stops?', code: '    mov r0, #20\n    mov r1, #3\nl:  sub r0, r0, r1\n    subs r1, r1, #1\n    bne l\n', ask: 'r0', a: 14, why: 'The body runs three times, subtracting 3, then 2, then 1 — total 6 — from 20.' },
    { k: 'mcq', q: 'Why is keeping the counter in a register so much faster than keeping it in memory?', opts: ['Registers hold bigger numbers', 'Memory access costs extra instructions and extra cycles on every single iteration', 'Memory cannot hold negative numbers', 'It is not faster, only shorter'], a: 1, why: 'The cost is paid once per iteration, so a loop multiplies it. Two extra memory instructions in a million-iteration loop is two million extra memory accesses.' }
  ]
},

/* ------------------------------------------------------------------ 1.3 */
{
  id: 'u1l3', title: 'Your first countdown loop', goal: 'Write and run the canonical SUBS/BNE loop.',
  teach: [
    { t: 'p', x: 'Here is the loop you will write more often than any other in your life as an ARM programmer. Two instructions. Learn it until you can type it without thinking.' },
    { t: 'code', cap: 'The canonical ARM countdown', x: '    mov  r1, #10       @ init:   ten iterations\nloop:\n    @ ---- body goes here ----\n    subs r1, r1, #1    @ update: one fewer, AND set the flags\n    bne  loop          @ test:   not zero yet? go again' },
    { t: 'h', x: 'Line by line' },
    { t: 'p', x: '<code>mov r1, #10</code> puts the iteration count in a register. <code>subs r1, r1, #1</code> subtracts one <i>and</i> — because of the <b>S</b> — records whether the result was zero. <code>bne loop</code> reads that record and branches back if the result was <i>not</i> zero.' },
    { t: 'p', x: 'When r1 finally reaches 0, the S-suffixed subtract sets the Z (zero) flag, <code>bne</code> declines to branch, and the processor falls through to whatever comes next. The loop has run exactly ten times.' },
    { t: 'h', x: 'Why counting down, not up' },
    { t: 'p', x: 'Counting up needs three instructions: add, compare, branch. Counting down needs two: the subtract produces the comparison for free, because "did we reach zero" is already in the flags. On a loop that runs ten million times, one instruction saved per trip is ten million instructions saved.' },
    { t: 'code', cap: 'Three instructions vs two', x: '@ counting up: ADD, CMP, B  = 3\n    mov  r1, #0\nup: add  r1, r1, #1\n    cmp  r1, #10\n    bne  up\n\n@ counting down: SUBS, B  = 2\n    mov  r1, #10\ndn: subs r1, r1, #1\n    bne  dn' },
    { t: 'note', x: 'Count down whenever the loop does not care about the order it visits things in. Count up when it does — for example when you are walking a string forwards, or when the index itself is part of the answer.' }
  ],
  real: {
    title: 'Clearing a buffer before use',
    text: 'Zeroing memory is the single most common loop in systems code: clearing a network packet buffer, a BSS section at boot, a frame of audio, a struct before filling it in. It is always a countdown.',
    code: '@ zero r2 words starting at r0\n    mov  r1, #0\nzero:\n    str  r1, [r0], #4\n    subs r2, r2, #1\n    bne  zero'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler will count down for you',
    text: 'Given a <code>for</code> loop whose counter is never read again once the loop ends, the compiler is free to run the induction variable any way it likes — and gcc will usually turn it into a countdown against zero, because that costs one instruction fewer per trip than counting up against the limit. The transformation is only legal because nothing outside the loop can observe which direction the counter actually moved.',
    a: { lab: 'C', lang: 'c', code: 'void touch(int n) {\n    for (int i = 0; i < n; i++)\n        do_work();\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: '    cmp  r4, #0\n    ble  .Lret\n.L3:\n    bl   do_work\n    subs r4, r4, #1\n    bne  .L3\n.Lret:' },
    note: 'The moment the body uses the counter for something the caller can see — printing it, storing it, indexing with it directly — the compiler must count up after all, because the direction has become part of the program\'s observable behaviour.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — SUB (immediate)', cite: 'With the S bit set, SUB updates the N, Z, C and V flags according to the result.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop optimisation', cite: 'Decrementing a counter to zero removes the need for a separate compare, since the subtract already sets the condition flags.' }
  ],
  ex: [
    { k: 'fill', q: 'Complete the countdown so it runs exactly 8 times.', pre: '    mov  r1, #8\nloop:\n    add  r0, r0, #2\n    ___\n    bne  loop', a: ['subs r1, r1, #1', 'subs r1,r1,#1'], hint: 'You need a subtract that also sets the flags.', why: 'Without the S the flags never change, and <code>bne</code> would test whatever was left over from before — usually looping for ever.' },
    { k: 'code', q: 'Put the sum 1+2+3+…+10 into r0 using a countdown loop.', start: '    mov  r0, #0\n    mov  r1, #10\nloop:\n    @ your code\n', check: [{ reg: 'r0', eq: 55 }], solution: '    mov  r0, #0\n    mov  r1, #10\nloop:\n    add  r0, r0, r1\n    subs r1, r1, #1\n    bne  loop\n', hints: ['Add r1 into r0 before you decrement it.', 'The two closing lines are <code>subs r1, r1, #1</code> and <code>bne loop</code>.'], why: 'Counting down still lets you use the counter as data — here it is both the loop control and the value being summed.' },
    { k: 'predict', q: 'How many times does the body run?', code: '    mov  r1, #5\nl:  add  r0, r0, #1\n    subs r1, r1, #1\n    bne  l\n', ask: 'r0', a: 5, why: 'r1 goes 5,4,3,2,1,0 — the branch is taken on 4,3,2,1 and declines at 0, so the body ran five times.' },
    { k: 'bug', q: 'This loop is supposed to run 6 times. What is wrong?', code: '    mov  r1, #6\nloop:\n    add  r0, r0, #1\n    sub  r1, r1, #1\n    bne  loop', opts: ['The counter starts too high', '<code>sub</code> has no <b>S</b>, so the flags are never updated', '<code>bne</code> should be <code>beq</code>', 'r1 is the wrong register'], a: 1, why: 'Without S the Z flag keeps whatever value it had before the loop, so <code>bne</code> makes the same decision every time — almost always an infinite loop.' },
    { k: 'mcq', q: 'Why is a countdown usually cheaper than a count-up?', opts: ['SUBS is a faster instruction than ADD', 'The subtract sets the flags, so no separate CMP is needed', 'Registers count down natively', 'Branches backwards are faster than branches forwards'], a: 1, why: 'It saves one instruction per iteration — the CMP — because "reached zero" is exactly what the Z flag already tells you.' },
    { k: 'code', q: 'Count down from 100 in steps of 7. Leave the number of complete steps you took in r0.', start: '    mov  r1, #100\n    mov  r0, #0\nloop:\n    @ subtract 7, count the step, stop when r1 would go below 7\n', check: [{ reg: 'r0', eq: 14 }], solution: '    mov  r1, #100\n    mov  r0, #0\nloop:\n    cmp  r1, #7\n    blt  done\n    sub  r1, r1, #7\n    add  r0, r0, #1\n    b    loop\ndone:\n', hints: ['You cannot rely on hitting exactly zero when the step is 7.', 'Compare against 7 at the top and leave early if r1 is smaller.'], why: '100 = 7×14 + 2, so fourteen whole steps fit. When the step size does not divide the count, "reached zero" stops being the right test and you need an explicit compare.' }
  ]
},

/* ------------------------------------------------------------------ 1.4 */
{
  id: 'u1l4', title: 'The S suffix', goal: 'Understand exactly which instructions update the flags, and when.',
  teach: [
    { t: 'p', x: 'Most ARM data-processing instructions come in two versions. <code>ADD</code> adds. <code>ADDS</code> adds <i>and updates the condition flags</i>. The difference is one bit in the encoding and it is the difference between a loop that works and a loop that hangs.' },
    { t: 'table', head: ['You write', 'It computes', 'It touches the flags?'], rows: [
      ['<code>sub r1, r1, #1</code>', 'r1 = r1 − 1', 'No'],
      ['<code>subs r1, r1, #1</code>', 'r1 = r1 − 1', 'Yes — N, Z, C, V'],
      ['<code>cmp r1, #0</code>', 'nothing is stored', 'Yes — always'],
      ['<code>mov r0, r1</code>', 'r0 = r1', 'No'],
      ['<code>movs r0, r1</code>', 'r0 = r1', 'Yes — N and Z'],
      ['<code>ldr r0, [r1]</code>', 'r0 = memory', 'Never. Loads cannot set flags.']
    ] },
    { t: 'note', x: '<b>This is the single most common beginner bug in ARM assembly.</b> You write <code>sub</code> where you meant <code>subs</code>, the flags keep an old value, and your loop either never runs or never stops. If a loop misbehaves, check your S suffixes first.' },
    { t: 'h', x: 'The comparison instructions always set flags' },
    { t: 'p', x: '<code>CMP</code>, <code>CMN</code>, <code>TST</code> and <code>TEQ</code> exist only to set flags — they throw the result away. They have no non-S form, because a <code>CMP</code> that did not set flags would do nothing at all.' },
    { t: 'h', x: 'Loads and stores never set flags' },
    { t: 'p', x: 'There is no <code>LDRS</code> that means "load and set flags". (<code>LDRSB</code> and <code>LDRSH</code> exist, but that S means <i>signed</i>, not <i>set flags</i> — a genuinely unfortunate collision.) If you want to loop until you load a zero, you must load, then test:' },
    { t: 'code', cap: 'Load, then test', x: 'scan:\n    ldrb r1, [r0], #1   @ load a byte, advance the pointer\n    cmp  r1, #0         @ the test is a separate instruction\n    bne  scan           @ keep going until we load a 0' },
    { t: 'p', x: 'Or, more idiomatically, use <code>TST</code>/<code>CMP</code>\'s cheaper cousin — a <code>MOVS</code> through a register you were going to write anyway. Unit 3 comes back to this.' }
  ],
  real: {
    title: 'Multi-word arithmetic depends on it',
    text: 'Adding two 64-bit numbers on a 32-bit machine needs the carry out of the low half to feed the high half. That only works if the low add sets the flags and the high add reads them — <code>ADDS</code> then <code>ADC</code>. Getting the S wrong here silently produces wrong numbers rather than a hang, which is worse.',
    code: '@ 64-bit add: (r1:r0) = (r1:r0) + (r3:r2)\n    adds r0, r0, r2      @ low half, publish the carry\n    adc  r1, r1, r3      @ high half, consume the carry'
  },
  deep: {
    kind: 'pitfall',
    title: 'Something between SUBS and BNE steals the flags',
    text: '<code>subs</code> and the branch that reads its flags do not have to be adjacent, which is exactly the trap. Any other flag-setting instruction placed between them — another <code>subs</code>, an <code>adds</code>, even a leftover <code>cmp</code> — overwrites the very condition the branch was written to test.',
    a: { lab: 'BNE tests the wrong update', code: '    mov  r1, #5\n    mov  r2, #0\nloop:\n    ldr  r3, [r0], #4\n    adds r2, r2, r3      @ running total: sets flags too\n    subs r1, r1, #1      @ this Z gets overwritten below\n    cmp  r2, #100        @ a later check, or a debug leftover\n    bne  loop             @ tests r2 vs 100, not the loop counter' },
    b: { lab: 'The counter update comes last', code: '    mov  r1, #5\n    mov  r2, #0\nloop:\n    ldr  r3, [r0], #4\n    add  r2, r2, r3       @ no S: this total does not drive the loop\n    subs r1, r1, #1       @ the last flag-setter before the branch\n    bne  loop' },
    note: 'When a loop test misbehaves, trace backwards from the branch to the nearest instruction that actually carries an <b>S</b>, not to the instruction that looks like the counter. They are not always the same one.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A4 — The Instruction Sets', cite: 'The S bit in a data-processing instruction selects whether the APSR condition flags are updated by the result.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — CMP', cite: 'CMP performs a subtraction, sets the condition flags on the result, and discards it.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which of these updates the Z flag?', opts: ['<code>sub r0, r0, #1</code>', '<code>ldr r0, [r1]</code>', '<code>subs r0, r0, #1</code>', '<code>mov r0, #0</code>'], a: 2, why: 'Only the S-suffixed form touches the flags. <code>mov r0, #0</code> puts zero in r0 but leaves Z exactly as it was.' },
    { k: 'mcq', q: 'What does the S in <code>LDRSB</code> mean?', opts: ['Set flags', 'Signed', 'Store', 'Scaled'], a: 1, why: 'Signed byte load — it sign-extends bit 7 into the top 24 bits. Loads never set flags, so the S could not mean that.' },
    { k: 'bug', q: 'Why does this run for ever?', code: '    mov  r0, #0\n    mov  r1, #4\n    cmp  r1, #0\nl:  add  r0, r0, #1\n    sub  r1, r1, #1\n    bne  l', opts: ['<code>cmp</code> is in the wrong place', 'The <code>sub</code> inside the loop has no S, so <code>bne</code> keeps reading the stale result of the <code>cmp</code> before the loop', 'r0 should start at 1', '<code>bne</code> cannot follow <code>sub</code>'], a: 1, why: 'The <code>cmp r1, #0</code> ran once with r1 = 4, leaving Z clear. Nothing else ever touches the flags, so <code>bne</code> branches every single time.' },
    { k: 'fill', q: 'Add two 64-bit values: (r1:r0) += (r3:r2). Fill in the first line.', pre: '    ___\n    adc  r1, r1, r3', a: ['adds r0, r0, r2', 'adds r0,r0,r2'], hint: 'The low half must publish a carry for ADC to consume.', why: '<code>ADC</code> reads the C flag. If the low add is a plain <code>ADD</code>, C holds something unrelated and the top half comes out wrong.' },
    { k: 'predict', q: 'What is in r0?', code: '    mov  r0, #0\n    movs r1, #3\nl:  add  r0, r0, #10\n    subs r1, r1, #1\n    bne  l\n', ask: 'r0', a: 30, why: 'Three iterations, ten each.' }
  ]
},

/* ------------------------------------------------------------------ 1.5 */
{
  id: 'u1l5', title: 'Labels and how far a branch can reach', goal: 'Know the branch range limits and what to do when you exceed them.',
  teach: [
    { t: 'p', x: 'A branch does not store the address it is going to. It stores the <i>distance</i>. In A32 that distance is a signed 24-bit count of words, which after scaling gives a reach of about <b>±32 megabytes</b> from the branch.' },
    { t: 'table', head: ['Instruction', 'State', 'Reach'], rows: [
      ['<code>B</code> / <code>BL</code>', 'A32', '±32 MB'],
      ['<code>B</code> (unconditional, wide)', 'Thumb-2', '±16 MB'],
      ['<code>B&lt;cond&gt;</code> (wide)', 'Thumb-2', '±1 MB'],
      ['<code>B&lt;cond&gt;</code> (narrow)', 'Thumb', '−256…+254 bytes'],
      ['<code>CBZ</code> / <code>CBNZ</code>', 'Thumb only', '<b>forwards only</b>, 0…126 bytes']
    ] },
    { t: 'note', x: 'For loops, these limits are almost never a problem: loop bodies are small and the branch goes backwards a few dozen bytes. The limits bite when you branch <i>out</i> of a loop into far-away error handling.' },
    { t: 'h', x: 'Local labels' },
    { t: 'p', x: 'Naming every loop is tiring, and names collide. GNU as lets you use plain numbers as labels, referenced with <code>b</code> for "the nearest one backwards" and <code>f</code> for "the nearest one forwards". You can reuse the same number as many times as you like.' },
    { t: 'code', cap: 'Numeric local labels', x: '    mov  r2, #4\n1:  subs r2, r2, #1     @ label "1"\n    bne  1b             @ "1b" = the nearest 1: going backwards\n\n    mov  r2, #4\n1:  subs r2, r2, #1     @ a completely different "1"\n    bne  1b' },
    { t: 'h', x: 'When a loop gets too big' },
    { t: 'p', x: 'If a conditional branch cannot reach its target, invert the condition and jump over an unconditional branch:' },
    { t: 'code', cap: 'The long-branch trampoline', x: '@ wanted:  beq  very_far_away      (out of range)\n@ instead:\n    bne  1f\n    b    very_far_away    @ unconditional B reaches much further\n1:' }
  ],
  real: {
    title: 'Linkers insert these for you',
    text: 'When a call in one object file lands more than 32 MB from its target, the linker silently generates a small trampoline — a "veneer" — nearby, and retargets the call to it. Large Android apps with big native libraries hit this constantly. Knowing the mechanism is what lets you read a disassembly and not be confused by functions with names like <code>__strlen_veneer</code>.',
    code: '@ what the linker inserts when BL cannot reach\n__far_veneer:\n    ldr  pc, [pc, #-4]\n    .word target_address'
  },
  deep: {
    kind: 'pitfall',
    title: 'CBZ cannot close a loop',
    text: '<code>CBZ</code> and <code>CBNZ</code> take an unsigned offset and can only jump <b>forwards</b>, up to 126 bytes, so neither can ever be the branch that sends a loop back to its top. Reach for one as a guard that skips the body when a count is already zero and it works perfectly; write one as the closing branch and it simply cannot express the direction you need.',
    code: '    mov  r1, #5\nloop:\n    cbz  r1, done        @ forwards only: fine as a guard\n    bl   process\n    subs r1, r1, #1\n    bne  loop             @ the closing branch needs a signed offset\ndone:',
    note: 'The asymmetry is deliberate: CBZ/CBNZ exist to shrink the one-line "skip if already zero" guard in Thumb code, not to replace BNE. A backwards branch is always B, BEQ, BNE or one of their relatives.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — B, BL', cite: 'The 24-bit signed immediate is shifted left by two and sign-extended, giving a branch range of ±32 MB in the ARM instruction set.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — CBZ, CBNZ', cite: 'CBZ and CBNZ are available only in Thumb, take an unsigned immediate, and can therefore only branch forwards.' },
    { src: 'GNU as manual, Symbols — Local Labels', cite: 'Numeric labels may be reused; a reference of the form Nb refers to the most recent definition and Nf to the next one.' }
  ],
  ex: [
    { k: 'mcq', q: 'Roughly how far can an A32 <code>B</code> reach?', opts: ['±127 bytes', '±1 KB', '±1 MB', '±32 MB'], a: 3, why: 'A signed 24-bit word offset, scaled by 4, gives ±32 MB.' },
    { k: 'mcq', q: 'Which instruction can only ever branch <i>forwards</i>?', opts: ['<code>B</code>', '<code>BL</code>', '<code>CBZ</code>', '<code>BX</code>'], a: 2, why: 'CBZ/CBNZ take an unsigned offset, so they cannot go backwards — which also means they can never be the closing branch of a loop.' },
    { k: 'mcq', q: 'In <code>bne 1b</code>, what does the <code>b</code> mean?', opts: ['branch', 'byte', 'backwards — the nearest preceding label "1"', 'binary'], a: 2, why: 'It is a direction, not an instruction. <code>1f</code> would mean the next label "1" going forwards.' },
    { k: 'code', q: 'Rewrite this using numeric local labels instead of the name <code>again</code>.', start: '    mov  r1, #3\nagain:\n    add  r0, r0, #5\n    subs r1, r1, #1\n    bne  again\n', check: [{ reg: 'r0', eq: 15 }, { notContains: 'again' }], solution: '    mov  r1, #3\n1:\n    add  r0, r0, #5\n    subs r1, r1, #1\n    bne  1b\n', hints: ['Replace the label with <code>1:</code>.', 'Replace the branch target with <code>1b</code>.'], why: 'Numeric labels keep small loops readable and stop you inventing names like loop2b_inner_retry.' },
    { k: 'order', q: 'Arrange the trampoline that branches to <code>far</code> when Z is set, given that <code>beq far</code> is out of range.', lines: ['    b   far', '1:', '    bne 1f'], a: [2, 0, 1], why: 'Invert the condition to skip over an unconditional branch, which has far more reach.' }
  ]
},

/* ------------------------------------------------------------------ 1.6 */
{
  id: 'u1l6', title: 'Anatomy: init, body, update, test', goal: 'Learn the four-part skeleton and recognise it in any loop.',
  teach: [
    { t: 'p', x: 'Every loop ever written has four parts. Once you can see them, unfamiliar assembly stops being intimidating — you just look for the four pieces and read off what the loop does.' },
    { t: 'code', cap: 'The skeleton, labelled', x: '    mov  r2, #0          @ 1. INIT   — set up counters, pointers, accumulators\n    mov  r3, #16\nloop:\n    add  r2, r2, r3      @ 2. BODY   — the actual work\n    sub  r3, r3, #2      @ 3. UPDATE — move towards the exit condition\n    cmp  r3, #0          @ 4. TEST   — are we done?\n    bgt  loop' },
    { t: 'p', x: 'In tight ARM loops the UPDATE and TEST usually merge into one <code>SUBS</code>, which is why the canonical loop looks like it only has three parts. It still has four; two of them are sharing an instruction.' },
    { t: 'h', x: 'Where things go wrong' },
    { t: 'table', head: ['Symptom', 'Which part is broken'], rows: [
      ['Loop never runs', 'TEST — the exit condition was already true'],
      ['Loop never stops', 'UPDATE — nothing moves towards the exit, or the S is missing'],
      ['Runs one time too many/few', 'TEST — an off-by-one in the comparison or the start value'],
      ['Right count, wrong answer', 'BODY, or INIT forgot to zero the accumulator'],
      ['Works once, wrong on the second call', 'INIT — a register kept a value from last time']
    ] },
    { t: 'note', x: 'Writing loops top-down — init, then a placeholder body, then update, then test — and running it after each step catches almost all of these before they become mysteries.' },
    { t: 'h', x: 'Reading someone else\'s loop' },
    { t: 'p', x: 'Find the backwards branch first. The label it targets is the top of the loop. Everything between them is the body plus the update. Whatever set up the registers used in the test is the init, and it is above the label. That is the entire skill.' }
  ],
  real: {
    title: 'Reading compiler output',
    text: 'When you look at <code>-O2</code> output from GCC or Clang for ARMv7, the four parts are still there but rearranged: the compiler hoists the init, rotates the loop so the test lands at the bottom, and often peels the first iteration. Finding the backwards branch and working outwards is how you get your bearings.',
    code: '@ gcc -O2 for:  for (i=0;i<n;i++) s += a[i];\n    cmp   r1, #0\n    ble   .Lret          @ zero-trip guard (the hoisted TEST)\n    mov   r2, #0         @ INIT\n.L3:\n    ldr   r3, [r0], #4   @ BODY\n    subs  r1, r1, #1     @ UPDATE + TEST\n    add   r2, r2, r3\n    bne   .L3'
  },
  deep: {
    kind: 'compiler',
    title: 'What never changes moves before the loop',
    text: 'Anything computed inside the body that does not depend on the loop variable is <b>loop-invariant</b>, and an optimiser proves that once and moves the computation above the loop entirely — back into what this lesson calls the init. The work still happens exactly once either way; hoisting only stops it from happening <i>n</i> times by accident.',
    a: { lab: 'C', lang: 'c', code: 'void bias(int *a, int n, int k) {\n    for (int i = 0; i < n; i++)\n        a[i] = a[i] + (k + 100);\n}' },
    b: { lab: 'gcc -O2, ARMv7', code: '    add  r3, r2, #100      @ (k+100) computed once, hoisted above the loop\n.L3:\n    ldr  r4, [r0]\n    add  r4, r4, r3\n    str  r4, [r0], #4\n    subs r1, r1, #1\n    bne  .L3' },
    note: 'Hand-written assembly gets this for free, because you write the init as a separate step out of habit. The compiler has to prove invariance first, and anything it cannot prove — a value read through a pointer that might alias the array — it leaves inside the loop just to be safe.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D)', cite: 'Loop bodies should be written so that the loop-control update also produces the condition tested by the terminating branch.' }
  ],
  ex: [
    { k: 'mcq', q: 'In the canonical <code>subs</code>/<code>bne</code> loop, which two parts share one instruction?', opts: ['Init and body', 'Body and update', 'Update and test', 'Test and init'], a: 2, why: '<code>SUBS</code> both moves the counter (update) and sets the flags the branch reads (test).' },
    { k: 'mcq', q: 'A loop produces the right answer the first time it is called and garbage the second. Which part is most likely wrong?', opts: ['INIT', 'BODY', 'UPDATE', 'TEST'], a: 0, why: 'An accumulator that is never reset keeps its value from the previous call. Classic init bug.' },
    { k: 'bug', q: 'This should sum the numbers 1..4 into r0 but gives 10 on the first run and 20 on the second. Which line is missing?', code: 'sum4:\n    mov  r1, #4\n1:  add  r0, r0, r1\n    subs r1, r1, #1\n    bne  1b\n    bx   lr', opts: ['<code>mov r0, #0</code> before the loop', '<code>cmp r1, #0</code> after the loop', '<code>push {lr}</code> at the top', '<code>add r1, r1, #1</code> in the body'], a: 0, why: 'The accumulator is never initialised, so each call adds to whatever the last one left behind.' },
    { k: 'order', q: 'Order the four parts as they appear in a bottom-tested loop.', lines: ['TEST (branch back if not done)', 'INIT', 'BODY', 'UPDATE'], a: [1, 2, 3, 0], why: 'Init happens once above the label; body, update and test repeat.' },
    { k: 'code', q: 'Write a loop that counts how many numbers from 1 to 20 are divisible by 3. Leave the count in r0.', start: '    mov  r0, #0\n    mov  r1, #20\n1:\n    @ r1 is the current number, counting down from 20\n', check: [{ reg: 'r0', eq: 6 }], solution: '    mov  r0, #0\n    mov  r1, #20\n1:\n    mov  r2, r1\n2:\n    cmp  r2, #3\n    blt  3f\n    sub  r2, r2, #3\n    b    2b\n3:\n    cmp  r2, #0\n    addeq r0, r0, #1\n    subs r1, r1, #1\n    bne  1b\n', hints: ['ARMv7-A has <code>sdiv</code> but not every core does — you can also subtract 3 repeatedly.', 'An inner loop that reduces a copy of r1 modulo 3 will do.'], why: '3, 6, 9, 12, 15, 18 — six of them. This is your first nested loop; Unit 4 goes into them properly.' }
  ]
}
    ]
  });

  U.push({
    id: 'u2', n: 2, title: 'Flags and Conditions', icon: '⚑', color: '#f0b429',
    blurb: 'Four bits decide whether your loop goes round again. Learn what each one means and the classic bugs stop happening.',
    lessons: [

/* ------------------------------------------------------------------ 2.1 */
{
  id: 'u2l1', title: 'N, Z, C and V', goal: 'Know precisely what each condition flag records.',
  teach: [
    { t: 'p', x: 'The four condition flags live in the top bits of a status register (the APSR). Every S-suffixed instruction and every <code>CMP</code> rewrites them. Every conditional branch reads them.' },
    { t: 'table', head: ['Flag', 'Name', 'Set when…'], rows: [
      ['<b>N</b>', 'Negative', 'bit 31 of the result is 1 — i.e. the result is negative <i>if you read it as signed</i>'],
      ['<b>Z</b>', 'Zero', 'the result is exactly zero — all 32 bits clear'],
      ['<b>C</b>', 'Carry', 'an unsigned addition overflowed past 2³²−1, or a subtraction did <b>not</b> need to borrow'],
      ['<b>V</b>', 'Overflow', 'a signed operation gave a result too big or too small to fit in 32 bits']
    ] },
    { t: 'note', x: '<b>C on subtraction is the one everybody gets backwards.</b> ARM computes <code>a − b</code> as <code>a + NOT(b) + 1</code>, so C is the carry <i>out</i> of that addition. C = 1 means "no borrow was needed", i.e. a ≥ b unsigned. C = 0 means a &lt; b unsigned.' },
    { t: 'h', x: 'Watch them move' },
    { t: 'code', cap: 'Three subtractions, three different flag states', x: '    mov  r0, #5\n    subs r1, r0, #5     @ result 0   -> Z=1 N=0 C=1 V=0\n    subs r1, r0, #3     @ result 2   -> Z=0 N=0 C=1 V=0\n    subs r1, r0, #9     @ result -4  -> Z=0 N=1 C=0 V=0' },
    { t: 'p', x: 'The third one is the interesting case: 5 − 9 is −4, so N is set; and because 5 is less than 9 as unsigned numbers, a borrow was needed, so C is clear.' },
    { t: 'h', x: 'N and V together mean "signed less than"' },
    { t: 'p', x: 'You almost never test V on its own. Its job is to correct N when a signed comparison overflowed. That is why the signed conditions are defined as <code>LT: N ≠ V</code> and <code>GE: N = V</code> rather than simply "N is set".' }
  ],
  real: {
    title: 'Saturating arithmetic in audio',
    text: 'When a DSP loop adds two samples and the result would clip, V tells you it happened so you can clamp to the maximum instead of wrapping around to a huge negative value — which is the difference between a slightly distorted note and a vicious click in someone\'s headphones.',
    code: '@ clamp instead of wrapping\n    adds  r0, r1, r2\n    bvc   1f              @ no overflow: keep it\n    mov   r0, #0x80000000\n    subpl r0, r0, #1      @ +max if the result went negative\n1:'
  },
  deep: {
    kind: 'pitfall',
    title: 'Reading carry as if it were a borrow flag',
    text: 'The mistake is assuming <b>C</b> works like a school-arithmetic borrow bit, set when the subtraction needed to borrow. ARM defines it the other way round: <b>C = 1 means no borrow was needed</b>, so code written on the opposite assumption has its condition backwards, and the bug only shows up on the inputs where a borrow actually happens.',
    a: { lab: 'Treats C as "a borrow happened"', code: '    cmp  r0, r1\n    bcs  smaller        @ wrong: this fires when r0 >= r1' },
    b: { lab: 'C=1 means no borrow, so r0 >= r1', code: '    cmp  r0, r1\n    bcc  smaller        @ C clear: a borrow WAS needed, so r0 < r1' },
    note: 'Say the rule until it sticks: <b>carry clear after a subtract means a borrow happened</b>. Every unsigned <code>LO</code>/<code>CC</code> condition in this course rests on that one sentence.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A2 — The Application Program Status Register', cite: 'N is set to bit 31 of the result; Z is set if the result is zero; C is the carry out of the ALU; V is set on signed overflow.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — SUB', cite: 'SUB is implemented as an addition of the bitwise inverse of the second operand with a carry-in of 1, which defines the sense of the C flag on subtraction.' }
  ],
  ex: [
    { k: 'mcq', q: 'After <code>subs r0, r1, r2</code> with r1 = 3 and r2 = 10, which flags are set?', opts: ['Z only', 'N only', 'N and C', 'N, with C clear'], a: 3, why: '3 − 10 = −7, so N = 1. Because 3 &lt; 10 unsigned, a borrow was needed, so C = 0.' },
    { k: 'mcq', q: 'C = 1 after a subtraction means…', opts: ['the result was negative', 'the result was zero', 'no borrow was needed — the first operand was ≥ the second, unsigned', 'a borrow was needed'], a: 2, why: 'ARM\'s C on subtract is "not borrow". This is why the unsigned ≥ condition is called HS (also spelled CS).' },
    { k: 'predict', q: 'Which flag makes the branch below taken? Give r0 to find out — it is 1 if taken.', code: '    mov  r0, #0\n    mov  r1, #0x80000000\n    subs r2, r1, #1\n    bvs  1f\n    b    2f\n1:  mov  r0, #1\n2:\n', ask: 'r0', a: 1, why: '0x80000000 is the most negative 32-bit number. Subtracting 1 from it cannot be represented, so V is set.' },
    { k: 'mcq', q: 'Why is signed "less than" defined as N ≠ V rather than just N = 1?', opts: ['Because N is unreliable', 'Because a signed comparison can overflow, which flips the sign of the result; V records that so the test can correct for it', 'Because V is faster to test', 'It is an arbitrary choice'], a: 1, why: 'Compare −2147483648 with 1: the subtraction overflows and the result looks positive. V = 1 tells LT that N lied.' },
    { k: 'code', q: 'Set r0 to 1 if r1 is zero, and 0 otherwise — without any branches. (Hint: <code>movs</code>, then two conditional <code>mov</code>s.)', start: '    mov  r1, #0        @ try changing this to test\n', check: [{ reg: 'r0', eq: 1 }], solution: '    mov  r1, #0\n    movs r2, r1\n    moveq r0, #1\n    movne r0, #0\n', hints: ['<code>movs r2, r1</code> sets Z without changing r1.', 'Then <code>moveq</code> and <code>movne</code>.'], why: 'You have just written your first branchless code. Unit 6 is built entirely on this idea.' }
  ]
},

/* ------------------------------------------------------------------ 2.2 */
{
  id: 'u2l2', title: 'CMP is a subtraction you throw away', goal: 'Use CMP, CMN, TST and TEQ correctly in loop tests.',
  teach: [
    { t: 'p', x: '<code>CMP r0, r1</code> computes <code>r0 − r1</code>, sets all four flags from the result, and stores nothing. That is its entire definition. Everything you know about <code>SUBS</code> applies to it.' },
    { t: 'table', head: ['Instruction', 'Computes', 'Use it for'], rows: [
      ['<code>CMP a, b</code>', 'a − b', 'Is a bigger, smaller or equal to b?'],
      ['<code>CMN a, b</code>', 'a + b', 'Compare against a negative, e.g. <code>cmn r0, #1</code> tests r0 == −1'],
      ['<code>TST a, b</code>', 'a AND b', 'Is a particular bit set?'],
      ['<code>TEQ a, b</code>', 'a EOR b', 'Are these exactly equal, without disturbing C or V from a carry?']
    ] },
    { t: 'h', x: 'CMP in a loop test' },
    { t: 'code', cap: 'The count-up loop', x: '    mov  r1, #0\n1:\n    @ body\n    add  r1, r1, #1\n    cmp  r1, #10        @ compare, do not store\n    bne  1b             @ ten iterations: r1 = 1..10' },
    { t: 'h', x: 'TST is how you loop over bits' },
    { t: 'p', x: '<code>TST r0, #1</code> ANDs r0 with 1 and sets Z if the result is zero — that is, Z is set when bit 0 is <i>clear</i>. Shifting r0 right each time gives you a loop over every bit of a word:' },
    { t: 'code', cap: 'Population count, the obvious way', x: '@ count the set bits of r0 into r2\n    mov  r2, #0\n    mov  r3, #32\n1:\n    tst  r0, #1\n    addne r2, r2, #1    @ bit was set\n    lsr  r0, r0, #1\n    subs r3, r3, #1\n    bne  1b' },
    { t: 'note', x: 'There are much faster ways to count bits, and you will build one in Unit 6. But this loop is the one you should be able to write from memory, because the same shape scans flag words, bitmaps, and free-block maps in every allocator ever written.' }
  ],
  real: {
    title: 'Scanning an interrupt status register',
    text: 'A peripheral raises several interrupts at once and reports them as bits in one 32-bit register. The handler loops over the set bits, servicing each. On ARMv7 the usual trick is <code>CLZ</code> to find the highest set bit directly, but the <code>TST</code>-and-shift loop is what you write first and what you fall back to when the bit order matters.',
    code: '@ service every pending interrupt, lowest first\n    ldr  r0, [r4, #IRQ_STATUS]\n1:  cmp  r0, #0\n    beq  2f\n    rbit r1, r0\n    clz  r1, r1          @ index of lowest set bit\n    bl   dispatch_irq\n    mov  r2, #1\n    bic  r0, r0, r2, lsl r1\n    b    1b\n2:'
  },
  deep: {
    kind: 'compiler',
    title: 'A bit test compiles straight to TST',
    text: 'Source code that tests a single, known bit does not need to compute a mask and compare it separately, because <code>ANDS</code>/<code>TST</code> already produces the flag a branch can read directly. A compiler recognises that shape and emits one flag-setting instruction in place of a separate compare, with the mask folded straight into it.',
    a: { lab: 'C', lang: 'c', code: 'if (x & (1 << 4))\n    handle_flag();' },
    b: { lab: 'gcc -O2, ARMv7', code: '    tst  r0, #16\n    beq  1f\n    bl   handle_flag\n1:' },
    note: 'This only fires for a compile-time-constant mask. Test a bit whose position is itself a variable and the compiler must emit a real shift before it can test anything, because an immediate operand cannot depend on a register.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — CMP, CMN, TST, TEQ', cite: 'These instructions perform the corresponding data-processing operation, update the condition flags, and discard the result.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — TST (immediate)', cite: 'TST computes the bitwise AND of its operands and sets N and Z from the result without writing it anywhere, which is exactly what a single-bit test needs.' }
  ],
  ex: [
    { k: 'mcq', q: '<code>cmp r0, r1</code> is equivalent to which instruction with the result discarded?', opts: ['<code>adds</code>', '<code>subs</code>', '<code>ands</code>', '<code>eors</code>'], a: 1, why: 'CMP is SUBS without a destination register.' },
    { k: 'mcq', q: 'You want to branch when bit 4 of r0 is set. Which pair works?', opts: ['<code>cmp r0, #16</code> / <code>beq</code>', '<code>tst r0, #16</code> / <code>bne</code>', '<code>tst r0, #4</code> / <code>bne</code>', '<code>teq r0, #16</code> / <code>beq</code>'], a: 1, why: 'Bit 4 has the value 16. TST ANDs and sets Z if the result is zero, so BNE fires when the bit <i>is</i> set.' },
    { k: 'mcq', q: 'Why use <code>cmn r0, #1</code> instead of <code>cmp r0, #-1</code>?', opts: ['CMN is faster', 'Negative immediates cannot always be encoded, and CMN adds instead of subtracting, which achieves the same test', 'CMP cannot set Z', 'They are not related'], a: 1, why: 'ARM immediates are unsigned 8-bit values with a rotation. Assemblers will often convert <code>cmp r0,#-1</code> to <code>cmn r0,#1</code> for you — it is the same test.' },
    { k: 'code', q: 'Count how many bits are set in 0xB7 (binary 1011 0111) and leave the answer in r2.', start: '    mov  r0, #0xB7\n    mov  r2, #0\n', check: [{ reg: 'r2', eq: 6 }], solution: '    mov  r0, #0xB7\n    mov  r2, #0\n    mov  r3, #8\n1:\n    tst  r0, #1\n    addne r2, r2, #1\n    lsr  r0, r0, #1\n    subs r3, r3, #1\n    bne  1b\n', hints: ['Test bit 0 with <code>tst r0, #1</code>, then shift right.', 'Eight iterations is enough for a byte.'], why: '1011 0111 has six set bits.' },
    { k: 'predict', q: 'What is r0 at the end?', code: '    mov  r0, #0\n    mov  r1, #0xFF\n1:  tst  r1, #0x80\n    addne r0, r0, #1\n    lsls r1, r1, #1\n    bne  1b\n', ask: 'r0', a: 8, why: 'Shifting 0xFF left, the top bit is set for eight iterations before r1 becomes zero.' }
  ]
},

/* ------------------------------------------------------------------ 2.3 */
{
  id: 'u2l3', title: 'Signed vs unsigned: the classic bug', goal: 'Never again pick BLT when you meant BLO.',
  teach: [
    { t: 'p', x: 'ARM has two complete sets of comparison conditions, and choosing the wrong set is the most expensive two-letter mistake in systems programming. It is behind a long line of real security bugs.' },
    { t: 'table', head: ['Meaning', 'Signed', 'Unsigned'], rows: [
      ['equal', '<code>EQ</code>', '<code>EQ</code>'],
      ['not equal', '<code>NE</code>', '<code>NE</code>'],
      ['greater than', '<code>GT</code>', '<code>HI</code>'],
      ['greater or equal', '<code>GE</code>', '<code>HS</code> (= <code>CS</code>)'],
      ['less than', '<code>LT</code>', '<code>LO</code> (= <code>CC</code>)'],
      ['less or equal', '<code>LE</code>', '<code>LS</code>']
    ] },
    { t: 'note', x: 'Memory hook: the <b>signed</b> ones are words — Greater, Less. The <b>unsigned</b> ones are <i>H</i>igher and <i>L</i>ower. If you are comparing addresses, sizes, lengths, or anything that cannot be negative, you want Higher/Lower.' },
    { t: 'h', x: 'Why it bites' },
    { t: 'code', cap: 'The bug', x: '@ r0 = a length that came from outside\n@ r1 = the size of our buffer, 256\n    cmp  r0, r1\n    bgt  too_big        @ WRONG: signed test\n    @ ... copy r0 bytes ...' },
    { t: 'p', x: 'If r0 arrives as 0xFFFFFFF0, that is 4294967280 unsigned — enormously bigger than 256 — but as a <i>signed</i> number it is −16, which is less than 256. <code>BGT</code> does not fire. The copy loop then runs with a count of 4294967280 and overwrites everything it can reach. Replacing <code>BGT</code> with <code>BHI</code> fixes it.' },
    { t: 'h', x: 'A rule that always works' },
    { t: 'p', x: 'Ask: <b>can this value ever legitimately be negative?</b> Array indices in a loop that counts down to zero: yes, if you let them go past zero. Pointers, lengths, counts, sizes, addresses: no. Use unsigned conditions for the "no" cases and you will not be caught out.' }
  ],
  real: {
    title: 'Bounds checks in a real copy loop',
    text: 'Every parser that reads a length from a file or packet and then loops that many times is one signed comparison away from a buffer overflow. The fix is boring and absolute: compare unsigned, and compare before the loop rather than inside it.',
    code: 'copy_checked:\n    cmp  r2, #MAXLEN\n    bhi  reject          @ unsigned: catches huge values\n    cmp  r2, #0\n    beq  done            @ nothing to do\n1:  ldrb r3, [r0], #1\n    strb r3, [r1], #1\n    subs r2, r2, #1\n    bne  1b\ndone:\n    bx   lr'
  },
  deep: {
    kind: 'pitfall',
    title: 'A length that looks negative slips past the check',
    text: 'A signed comparison on a value that is really an unsigned length trusts the sign bit, and a corrupt or hostile input controls that bit. Once the top bit of a 32-bit length is set, it reads as a huge negative number to a signed test and as a huge positive number to an unsigned one, and only one of those two readings is ever true to what the value means.',
    a: { lab: 'Signed: 0xFFFFFF00 looks small', code: '    cmp  r0, #64\n    bgt  reject          @ -256 is not > 64, so this is skipped' },
    b: { lab: 'Unsigned: the true size gets through', code: '    cmp  r0, #64\n    bhi  reject          @ 4294967040 IS > 64, correctly rejected' },
    note: 'The fix is never a special case for negative-looking values. It is noticing that a length was never a signed quantity in the first place, and using the unsigned condition everywhere it is compared.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — Condition codes', cite: 'HS is a synonym for CS and LO is a synonym for CC; the unsigned conditions are defined purely on C and Z, the signed ones on N, V and Z.' },
    { src: 'CWE-195: Signed to Unsigned Conversion Error', cite: 'A negative value used as a length after conversion to an unsigned type becomes very large, defeating a preceding signed bounds check.' }
  ],
  ex: [
    { k: 'mcq', q: 'You are comparing two memory addresses. Which condition means "r0 is before r1"?', opts: ['<code>BLT</code>', '<code>BLO</code>', '<code>BMI</code>', '<code>BNE</code>'], a: 1, why: 'Addresses are unsigned. An address above 0x7FFFFFFF would look negative to a signed test.' },
    { k: 'mcq', q: 'r0 = 0xFFFFFF00. After <code>cmp r0, #1</code>, which branches are taken?', opts: ['<code>BGT</code> and <code>BHI</code>', '<code>BLT</code> and <code>BHI</code>', '<code>BGT</code> and <code>BLO</code>', 'Neither'], a: 1, why: 'As signed, 0xFFFFFF00 is −256, so it is less than 1 → BLT. As unsigned it is 4294967040, far greater than 1 → BHI. Both fire, from the same flags.' },
    { k: 'bug', q: 'This loop should copy at most 64 bytes. What is the security bug?', code: 'copy:\n    cmp  r2, #64\n    bgt  reject\n1:  ldrb r3, [r0], #1\n    strb r3, [r1], #1\n    subs r2, r2, #1\n    bne  1b', opts: ['<code>ldrb</code> should be <code>ldr</code>', '<code>bgt</code> is a signed test; a negative-looking length passes the check and then runs ~4 billion iterations', 'The pointers are not incremented', '<code>subs</code> should be <code>sub</code>'], a: 1, why: 'Use <code>bhi</code>. And add a zero check, because r2 = 0 makes the <code>subs</code>/<code>bne</code> loop run 2³² times before Z is set.' },
    { k: 'match', q: 'Match each signed condition to its unsigned twin.', pairs: [['GT', 'HI'], ['GE', 'HS'], ['LT', 'LO'], ['LE', 'LS']], why: 'Greater/Less are signed; Higher/Lower are unsigned.' },
    { k: 'code', q: 'Loop over the array at <code>vals</code> (6 words) and put the number of entries strictly greater than 100, <b>treating them as unsigned</b>, into r0.', start: '    ldr  r1, =vals\n    mov  r2, #6\n    mov  r0, #0\n1:\n    @ your code\n\n.data\nvals: .word 5, 4294967295, 100, 101, 0, 300\n', check: [{ reg: 'r0', eq: 3 }], solution: '    ldr  r1, =vals\n    mov  r2, #6\n    mov  r0, #0\n1:\n    ldr  r3, [r1], #4\n    cmp  r3, #100\n    addhi r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n\n.data\nvals: .word 5, 4294967295, 100, 101, 0, 300\n', hints: ['Use <code>cmp</code> then a conditional add.', 'The condition you want is <code>hi</code>, not <code>gt</code>.'], why: '4294967295, 101 and 300 are all above 100 unsigned. With <code>gt</code> you would only count two, because 4294967295 reads as −1.' }
  ]
},

/* ------------------------------------------------------------------ 2.4 */
{
  id: 'u2l4', title: 'Counting up, counting down', goal: 'Choose the right loop direction and know what each costs.',
  teach: [
    { t: 'p', x: 'Four loop shapes cover almost everything. Learn to write all four and to recognise which one a piece of code is using.' },
    { t: 'code', cap: '1. Countdown to zero — cheapest', x: '    mov  r1, #N\n1:  @ body (does not know which iteration it is on)\n    subs r1, r1, #1\n    bne  1b' },
    { t: 'code', cap: '2. Count up to a limit — when the index matters', x: '    mov  r1, #0\n1:  @ body uses r1 as the index 0..N-1\n    add  r1, r1, #1\n    cmp  r1, #N\n    blo  1b' },
    { t: 'code', cap: '3. Pointer walk to an end address — best for arrays', x: '    ldr  r1, =array\n    add  r2, r1, #N*4     @ one past the end\n1:  ldr  r3, [r1], #4\n    @ body\n    cmp  r1, r2\n    blo  1b' },
    { t: 'code', cap: '4. Countdown but the index is still available', x: '    mov  r1, #N\n1:  sub  r2, r1, #1       @ r2 = index N-1 .. 0\n    @ body uses r2\n    subs r1, r1, #1\n    bne  1b' },
    { t: 'table', head: ['Shape', 'Instructions per trip', 'Use when'], rows: [
      ['Countdown', '2', 'order does not matter'],
      ['Count up', '3', 'the index is part of the work'],
      ['Pointer walk', '3 (2 if you can count down)', 'walking memory — no index arithmetic at all'],
      ['Countdown + index', '3', 'you want both cheapness and an index']
    ] },
    { t: 'note', x: 'The pointer walk is the one professional ARM code uses most, because it removes the multiply-by-element-size that an index-based loop needs on every access.' }
  ],
  real: {
    title: 'Why memset counts down and strlen counts up',
    text: 'memset knows its length up front and does not care about order, so it counts down and saves an instruction per iteration. strlen does not know the length — it is looking for the terminator — so it walks a pointer forwards and subtracts at the end to get the answer. The shape follows from what the function knows.',
    code: '@ strlen: pointer walk, length computed at the end\nstrlen:\n    mov  r1, r0\n1:  ldrb r2, [r1], #1\n    cmp  r2, #0\n    bne  1b\n    sub  r0, r1, r0\n    sub  r0, r0, #1\n    bx   lr'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler turns your index into a pointer',
    text: 'Write an ordinary summing loop over an array and nothing in the source mentions a pointer at all, but at <code>-O2</code> the index usually disappears completely, replaced by a pointer advanced through post-indexing — exactly the shape this lesson asks you to write by hand. The compiler can only do this once it has proved nothing else writes to the array through some other alias while the loop runs.',
    a: { lab: 'C', lang: 'c', code: 'int sum(int *a, int n) {\n    int s = 0;\n    for (int i = 0; i < n; i++)\n        s += a[i];\n    return s;\n}' },
    b: { lab: 'gcc -O2, ARMv7 — the index is gone', code: '    cmp  r1, #0\n    ble  2f\n    add  r1, r0, r1, lsl #2   @ end pointer, computed once\n    mov  r2, #0\n1:  ldr  r3, [r0], #4\n    add  r2, r2, r3\n    cmp  r0, r1\n    blo  1b\n2:' },
    note: 'This is why hunting through a disassembly for "the index register" is often a dead end. By the time the compiler is finished there usually is no index register left to find.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Writing efficient loops', cite: 'Prefer decrementing loop counters that terminate on zero, and prefer pointer comparison to index arithmetic when walking arrays.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which loop shape avoids multiplying the index by the element size?', opts: ['Countdown to zero', 'Count up to a limit', 'Pointer walk to an end address', 'They all need it'], a: 2, why: 'The pointer is advanced by the element size directly, usually for free in the post-index of the load.' },
    { k: 'code', q: 'Rewrite this index loop as a pointer walk. It must still put the sum in r0.', start: '    ldr  r1, =a\n    mov  r2, #0\n    mov  r0, #0\n1:  ldr  r3, [r1, r2, lsl #2]\n    add  r0, r0, r3\n    add  r2, r2, #1\n    cmp  r2, #5\n    blo  1b\n\n.data\na: .word 3,1,4,1,5\n', check: [{ reg: 'r0', eq: 14 }, { notContains: 'lsl' }], solution: '    ldr  r1, =a\n    add  r2, r1, #20\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    cmp  r1, r2\n    blo  1b\n\n.data\na: .word 3,1,4,1,5\n', hints: ['Compute the end address once: <code>add r2, r1, #20</code>.', 'Use <code>ldr r3, [r1], #4</code> and compare r1 against r2.'], why: 'Five words is 20 bytes. The scaled index disappears entirely.' },
    { k: 'mcq', q: 'You need the loop index inside the body <i>and</i> the cheapest possible loop. Which shape?', opts: ['Shape 1', 'Shape 2', 'Shape 3', 'Shape 4'], a: 3, why: 'Countdown for the cheap flag test, with a derived index for the body.' },
    { k: 'predict', q: 'How many times does the body run?', code: '    mov  r0, #0\n    mov  r1, #0\n1:  add  r0, r0, #1\n    add  r1, r1, #1\n    cmp  r1, #4\n    blo  1b\n', ask: 'r0', a: 4, why: 'r1 becomes 1,2,3,4; the branch is taken while r1 &lt; 4, so four trips.' },
    { k: 'bug', q: 'This pointer walk copies one element too many. Why?', code: '    ldr  r1, =src\n    ldr  r4, =dst\n    add  r2, r1, #16     @ 4 words\n1:  ldr  r3, [r1], #4\n    str  r3, [r4], #4\n    cmp  r1, r2\n    bls  1b', opts: ['<code>add r2, r1, #16</code> should be #12', '<code>bls</code> includes the case where r1 has already reached the end; it should be <code>blo</code>', '<code>str</code> should come first', 'r4 is never initialised'], a: 1, why: 'The end address is <i>one past</i> the last element, so the loop must stop as soon as the pointer equals it. LS keeps going for one more round.' }
  ]
},

/* ------------------------------------------------------------------ 2.5 */
{
  id: 'u2l5', title: 'All fourteen conditions', goal: 'Drill every condition code until the right one comes automatically.',
  teach: [
    { t: 'p', x: 'Here is the whole set. You do not need to memorise the flag formulas — you need to recognise the <i>question</i> each one answers after a <code>CMP a, b</code>.' },
    { t: 'table', head: ['Code', 'Flags', 'After <code>CMP a, b</code> it means'], rows: [
      ['<code>EQ</code>', 'Z = 1', 'a == b'],
      ['<code>NE</code>', 'Z = 0', 'a != b'],
      ['<code>CS</code> / <code>HS</code>', 'C = 1', 'a ≥ b  (unsigned)'],
      ['<code>CC</code> / <code>LO</code>', 'C = 0', 'a &lt; b  (unsigned)'],
      ['<code>MI</code>', 'N = 1', 'a − b is negative'],
      ['<code>PL</code>', 'N = 0', 'a − b is zero or positive'],
      ['<code>VS</code>', 'V = 1', 'the subtraction overflowed'],
      ['<code>VC</code>', 'V = 0', 'it did not'],
      ['<code>HI</code>', 'C = 1 and Z = 0', 'a &gt; b  (unsigned)'],
      ['<code>LS</code>', 'C = 0 or Z = 1', 'a ≤ b  (unsigned)'],
      ['<code>GE</code>', 'N = V', 'a ≥ b  (signed)'],
      ['<code>LT</code>', 'N ≠ V', 'a &lt; b  (signed)'],
      ['<code>GT</code>', 'Z = 0 and N = V', 'a &gt; b  (signed)'],
      ['<code>LE</code>', 'Z = 1 or N ≠ V', 'a ≤ b  (signed)']
    ] },
    { t: 'note', x: 'There is a fifteenth encoding, <code>AL</code> (always), which is what you get when you write no condition at all. The old <code>NV</code> (never) encoding was withdrawn and now means something else entirely — do not use it.' },
    { t: 'h', x: 'MI and PL are not LT and GE' },
    { t: 'p', x: '<code>MI</code> tests N alone. <code>LT</code> tests N against V. They agree except when the comparison overflowed — which is exactly the case that matters. Use <code>MI</code> when you genuinely want "is this number negative", and <code>LT</code> when you want "is a less than b".' }
  ],
  real: {
    title: 'Clamping a value into range without branching',
    text: 'Conditional execution turns a three-branch clamp into three straight-line instructions, which in a pixel or sample loop is worth a great deal because there is no branch for the processor to mispredict.',
    code: '@ r0 = clamp(r0, 0, 255)\n    cmp   r0, #0\n    movlt r0, #0\n    cmp   r0, #255\n    movgt r0, #255'
  },
  deep: {
    kind: 'pitfall',
    title: 'MI answers a different question from LT',
    text: 'Given <code>cmp r0, r1</code>, it is tempting to read <b>MI</b> as "r0 is less than r1", because a negative subtraction result usually does mean that. It stops meaning that the moment the subtraction overflows, because then the result comes out with the wrong sign, N lies, and only <b>LT</b> — which checks N against V — still gives the right answer.',
    a: { lab: 'MI: fooled by overflow', code: '    ldr  r0, =0x80000000   @ the most negative int32\n    mov  r1, #1\n    cmp  r0, r1              @ 0x80000000 - 1 overflows\n    bmi  is_less             @ wrong: N is clear here, so this is not taken' },
    b: { lab: 'LT: correct regardless of overflow', code: '    ldr  r0, =0x80000000\n    mov  r1, #1\n    cmp  r0, r1\n    blt  is_less             @ correct: r0 IS less than r1 as signed values' },
    note: 'r0 here is the most negative number there is, certainly less than 1, yet the subtraction overflows into a positive-looking result, so N comes out 0 and <b>MI</b> gets it backwards. V exists to catch exactly this case.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — Conditional execution', cite: 'Condition code 0b1110 is AL; 0b1111 was previously NV and is now used to encode unconditional instructions.' }
  ],
  ex: [
    { k: 'mcq', q: 'After <code>cmp r0, r1</code>, which condition means "r0 is strictly greater than r1, unsigned"?', opts: ['<code>GT</code>', '<code>HI</code>', '<code>CS</code>', '<code>PL</code>'], a: 1, why: 'HI = C set and Z clear: greater, and not equal.' },
    { k: 'mcq', q: 'Which condition is true when the result of the last flag-setting operation was negative, regardless of overflow?', opts: ['<code>LT</code>', '<code>MI</code>', '<code>LO</code>', '<code>LE</code>'], a: 1, why: 'MI tests N alone. LT tests N against V and is the right choice for comparisons.' },
    { k: 'match', q: 'Match the condition to what it means after <code>CMP a, b</code>.', pairs: [['LS', 'a ≤ b unsigned'], ['GE', 'a ≥ b signed'], ['NE', 'a ≠ b'], ['VS', 'the comparison overflowed']], why: 'L/H are unsigned; G/L are signed; V stands alone.' },
    { k: 'code', q: 'Clamp r0 into the range 10…200 using only conditional MOVs (no branches).', start: '    mov  r0, #250\n', check: [{ reg: 'r0', eq: 200 }, { notContains: 'b ' }], solution: '    mov  r0, #250\n    cmp  r0, #10\n    movlt r0, #10\n    cmp  r0, #200\n    movgt r0, #200\n', hints: ['Two compares, two conditional moves.', '<code>movlt</code> then <code>movgt</code>.'], why: 'This is the shape of every saturating pixel and sample operation.' },
    { k: 'predict', q: 'What is in r0?', code: '    mov  r0, #0\n    mov  r1, #5\n    mov  r2, #5\n    cmp  r1, r2\n    addhi r0, r0, #1\n    addhs r0, r0, #2\n    addeq r0, r0, #4\n', ask: 'r0', a: 6, why: 'Equal, so HI is false (Z is set), HS is true (C is set), EQ is true. 0 + 2 + 4 = 6.' }
  ]
},

/* ------------------------------------------------------------------ 2.6 */
{
  id: 'u2l6', title: 'Test at the top or the bottom', goal: 'Know the difference between while and do-while in assembly, and why it costs a branch.',
  teach: [
    { t: 'p', x: 'A loop can check its condition before the body (a <code>while</code>) or after it (a <code>do…while</code>). In assembly the difference is real and measurable.' },
    { t: 'code', cap: 'Bottom-tested — one branch per trip', x: '@ do { body } while (--n);\n1:  @ body\n    subs r1, r1, #1\n    bne  1b' },
    { t: 'code', cap: 'Top-tested — two branches per trip', x: '@ while (n) { body; --n; }\n1:  cmp  r1, #0\n    beq  2f            @ branch out\n    @ body\n    sub  r1, r1, #1\n    b    1b            @ branch back\n2:' },
    { t: 'p', x: 'The bottom-tested form costs one taken branch per iteration. The top-tested form costs two. Over a million iterations that is a million extra branches. Compilers therefore <b>rotate</b> loops: they move the test to the bottom and put a single guard in front.' },
    { t: 'code', cap: 'Rotated — the best of both', x: '    cmp  r1, #0\n    beq  2f            @ guard: skip the whole loop if n == 0\n1:  @ body\n    subs r1, r1, #1\n    bne  1b\n2:' },
    { t: 'note', x: 'The guard runs once, not once per iteration. This is the shape you should write by default: <b>guard, then a bottom-tested loop</b>.' },
    { t: 'h', x: 'The zero-trip trap' },
    { t: 'p', x: 'A bottom-tested loop always runs at least once. If your count can legitimately be zero — and counts that come from outside your function always can — the loop without a guard will run 2³² times before the counter wraps back to zero. This is not a hang; it is roughly four billion iterations of whatever your body does, to whatever memory it touches.' }
  ],
  real: {
    title: 'The bug that eats your heap',
    text: 'A copy routine called with length 0 and no guard does not copy nothing — it copies 4,294,967,296 bytes. On a device with no MMU it will happily march through the entire address space. Adding three instructions at the top of the function is the whole fix.',
    code: 'memcpy_safe:\n    cmp  r2, #0\n    bxeq lr              @ length 0: return immediately\n1:  ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b\n    bx   lr'
  },
  deep: {
    kind: 'pitfall',
    title: 'A bottom-tested loop assumes it has already run once',
    text: 'A loop written as body, then <code>subs</code>, then <code>bne</code> only checks for zero after the body has executed, so it silently assumes the count is at least 1. Call it with a count of zero and the subtract does not land on zero at all — it wraps from 0 to 0xFFFFFFFF — and the loop runs 4,294,967,296 times before it finds its way back.',
    a: { lab: 'No guard: fine until n is 0', code: 'fill:\n    mov  r3, #0\n1:  strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b\n    bx   lr' },
    b: { lab: 'Guarded: safe for any n, including 0', code: 'fill:\n    cmp  r2, #0\n    bxeq lr\n    mov  r3, #0\n1:  strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b\n    bx   lr' },
    note: 'The guard costs one compare and one branch that is almost always not taken. Leaving it out costs nothing either, until the one call site that legitimately has zero bytes to process.'
  },
  refs: [
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Loop structure', cite: 'Rotating a loop so that the conditional branch is at the end reduces the number of branches executed per iteration.' }
  ],
  ex: [
    { k: 'mcq', q: 'How many taken branches per iteration does a bottom-tested loop cost?', opts: ['0', '1', '2', '3'], a: 1, why: 'Only the backwards branch. A top-tested loop also needs a forward branch out.' },
    { k: 'mcq', q: 'A bottom-tested countdown loop is called with the counter equal to 0. What happens?', opts: ['It runs zero times', 'It runs once', 'It runs 2³² times', 'It faults immediately'], a: 2, why: '0 − 1 = 0xFFFFFFFF, which is not zero, so it keeps going all the way round the 32-bit counter.' },
    { k: 'code', q: 'Add a guard so this loop is safe when r2 is zero. It must leave r0 unchanged in that case.', start: '    mov  r0, #7\n    mov  r2, #0\n1:  add  r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n', check: [{ reg: 'r0', eq: 7 }], solution: '    mov  r0, #7\n    mov  r2, #0\n    cmp  r2, #0\n    beq  2f\n1:  add  r0, r0, #1\n    subs r2, r2, #1\n    bne  1b\n2:\n', hints: ['Put <code>cmp r2, #0</code> and a forward branch before the label.', 'You will need a <code>2:</code> label after the loop.'], why: 'One compare and one branch, executed once, buys you correctness for the whole function.' },
    { k: 'order', q: 'Arrange a rotated loop: guard in front, test at the bottom.', lines: ['1:  @ body', '    beq 2f', '    subs r1, r1, #1', '    cmp r1, #0', '    bne 1b', '2:'], a: [3, 1, 0, 2, 4, 5], why: 'cmp, beq (guard), label, body, subs, bne, end label.' },
    { k: 'mcq', q: 'Why do compilers rotate loops?', opts: ['To make the disassembly shorter', 'To turn two branches per iteration into one, at the cost of one guard executed once', 'Because bottom-tested loops use fewer registers', 'To avoid the S suffix'], a: 1, why: 'The guard is paid once; the saved branch is paid back on every iteration.' }
  ]
},

/* ------------------------------------------------------------------ 2.7 */
{
  id: 'u2l7', title: 'Loops that never end (on purpose)', goal: 'Write deliberate infinite loops and know how to leave them.',
  teach: [
    { t: 'p', x: 'Not every loop should terminate. An operating system\'s idle loop, a firmware superloop, a fault handler and a bootloader\'s "wait for the watchdog" all run for ever by design. The skill is making the intent obvious and leaving a deliberate exit.' },
    { t: 'code', cap: 'The three honest infinite loops', x: '@ 1. burn cycles (a bad idea on battery)\n1:  b   1b\n\n@ 2. sleep until an interrupt (the right way)\n1:  wfi\n    b   1b\n\n@ 3. a superloop with real work in it\nmain_loop:\n    bl  poll\n    bl  update\n    b   main_loop' },
    { t: 'note', x: '<code>WFI</code> — Wait For Interrupt — puts the core into a low-power state until something happens. A polling loop that spins on a flag with no <code>WFI</code> will keep a phone\'s CPU at full clock and is a genuine battery bug.' },
    { t: 'h', x: 'Leaving an "infinite" loop' },
    { t: 'p', x: 'Three legitimate exits: an interrupt that never returns, a conditional branch out of the middle, and writing to PC. The middle one is the common case and it is just an ordinary conditional branch:' },
    { t: 'code', cap: 'Infinite until something changes', x: '1:  ldr  r0, [r4]        @ read a status word\n    tst  r0, #DONE_BIT\n    bne  2f              @ the exit\n    wfi\n    b    1b\n2:' },
    { t: 'h', x: 'Accidental infinite loops' },
    { t: 'p', x: 'The three causes, in order of frequency: a missing <b>S</b> suffix; an update that moves away from the exit condition rather than towards it; and a step size that steps over the exit value — counting down by 3 from 10 gives 7, 4, 1, −2 and never hits 0.' }
  ],
  real: {
    title: 'The idle loop of an operating system',
    text: 'When Linux has nothing to run on a core it enters the idle loop, which on ARM is a WFI in a loop. Everything else — every process, every interrupt — is a departure from and a return to that loop. It is the floor the whole system stands on.',
    code: 'cpu_idle:\n1:  dsb\n    wfi                  @ core clock-gates here\n    b    1b              @ an interrupt lands, we loop back'
  },
  deep: {
    kind: 'cores',
    title: 'WFI means different things on different cores',
    text: 'On every ARMv7 core, <code>WFI</code> is permission to stop: the core may clock-gate itself until an interrupt, a debug event or a reset arrives, and while it is stopped it draws a small fraction of its running power. What differs by core and by system design is how deep that stop goes — a simple Cortex-M part may only gate its own clock, while a Cortex-A part in a phone or a single-board computer can drop its own voltage rail and let the rest of the system follow it down.',
    code: 'idle:\n1:  wfi                  @ the core stops here until something happens\n    b    1b',
    note: 'A spinning poll loop and a WFI loop can be logically identical and still differ by orders of magnitude in power, which is why "does it use WFI" is one of the first things worth checking in firmware that drains a battery too fast.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter B1 — Wait For Interrupt', cite: 'WFI permits the processor to suspend execution and enter a low-power state until an interrupt or other wakeup event occurs.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which instruction lets an idle loop save power?', opts: ['<code>NOP</code>', '<code>WFI</code>', '<code>DMB</code>', '<code>CLZ</code>'], a: 1, why: 'WFI lets the core stop clocking until an interrupt arrives. NOP still executes at full speed.' },
    { k: 'mcq', q: 'Why does <code>mov r1, #10</code> then <code>subs r1, r1, #3</code> / <code>bne</code> never terminate?', opts: ['SUBS does not set flags', '10 is not a multiple of 3, so the counter steps over zero: 7, 4, 1, −2, …', 'BNE cannot follow SUBS', 'r1 is the wrong register'], a: 1, why: 'Exit-on-exactly-zero only works when the step divides the start value. Otherwise compare against a bound instead.' },
    { k: 'code', q: 'Write a loop that spins until r1 reaches 0, decrementing by 3, starting from 9 — and make it terminate. Leave the number of iterations in r0.', start: '    mov  r1, #9\n    mov  r0, #0\n', check: [{ reg: 'r0', eq: 3 }, { reg: 'r1', eq: 0 }], solution: '    mov  r1, #9\n    mov  r0, #0\n1:  subs r1, r1, #3\n    add  r0, r0, #1\n    bne  1b\n', hints: ['9 is a multiple of 3, so exactly hitting zero does work here.', 'Count the trips in r0.'], why: '9, 6, 3, 0 — three subtractions. When the step divides the count, the cheap test is safe.' },
    { k: 'bug', q: 'This polling loop keeps a phone at 100% CPU. What should be added?', code: '1:  ldr  r0, [r4]\n    tst  r0, #1\n    beq  1b', opts: ['A <code>nop</code>', 'A <code>wfi</code> or <code>wfe</code> before the branch back', 'An <code>S</code> suffix', 'A longer delay constant'], a: 1, why: 'Spinning on a memory location at full clock is a battery bug. WFI/WFE parks the core until something actually happens.' },
    { k: 'mcq', q: 'Which of these is NOT a legitimate way to leave an infinite loop?', opts: ['A conditional branch out of the middle', 'An interrupt that does not return', 'Writing a new value to PC', 'Waiting for the counter to overflow back to zero'], a: 3, why: 'It does eventually happen, but after billions of iterations — that is an accident, not a design.' }
  ]
}
    ]
  });

  U.push({
    id: 'u3', n: 3, title: 'Walking Memory', icon: '⇥', color: '#7aa2f7',
    blurb: 'Loops exist to touch a lot of data. This is how a loop moves through memory without wasting a single instruction.',
    lessons: [

/* ------------------------------------------------------------------ 3.1 */
{
  id: 'u3l1', title: 'LDR and STR: the loop\'s hands', goal: 'Load and store the right width, and know what each costs.',
  teach: [
    { t: 'p', x: 'ARM is a load/store architecture: arithmetic happens only between registers. Every value a loop processes must be <i>loaded</i> in and every result <i>stored</i> out. These two instructions are where loops spend most of their time.' },
    { t: 'table', head: ['Instruction', 'Moves', 'Notes'], rows: [
      ['<code>LDR</code> / <code>STR</code>', '32 bits', 'Address must be 4-byte aligned'],
      ['<code>LDRH</code> / <code>STRH</code>', '16 bits', 'Address must be 2-byte aligned; zero-extends on load'],
      ['<code>LDRB</code> / <code>STRB</code>', '8 bits', 'Any address; zero-extends on load'],
      ['<code>LDRSB</code>', '8 bits', 'Sign-extends bit 7 into the top 24 bits'],
      ['<code>LDRSH</code>', '16 bits', 'Sign-extends bit 15'],
      ['<code>LDRD</code> / <code>STRD</code>', '64 bits', 'Needs an even register pair, e.g. r4/r5']
    ] },
    { t: 'note', x: 'There is no <code>STRSB</code>. Sign extension only makes sense when widening on the way <i>in</i>; storing simply truncates.' },
    { t: 'h', x: 'The simplest array loop' },
    { t: 'code', cap: 'Sum five words', x: '    ldr  r1, =data       @ r1 = address of the array\n    mov  r2, #5          @ five elements\n    mov  r0, #0          @ running total\n1:\n    ldr  r3, [r1]        @ load *r1\n    add  r0, r0, r3\n    add  r1, r1, #4      @ advance to the next word\n    subs r2, r2, #1\n    bne  1b\n\n.data\ndata: .word 10, 20, 30, 40, 50' },
    { t: 'p', x: 'That is four instructions of overhead per element. The next lesson removes one of them for free.' },
    { t: 'h', x: 'LDR rX, =value' },
    { t: 'p', x: '<code>ldr r1, =data</code> is not a real instruction — it is an assembler convenience. If the value fits in an ARM immediate, you get a <code>MOV</code>. If it does not, the assembler places the constant in a <i>literal pool</i> near your code and turns the line into a PC-relative load. Either way you get the number you asked for.' }
  ],
  real: {
    title: 'Endianness and network packets',
    text: 'A packet header on the wire is big-endian; your ARM core is almost certainly little-endian. A loop reading 16-bit fields out of a header therefore loads with <code>LDRH</code> and byte-swaps with <code>REV16</code>. Getting the width and the swap right is most of what packet parsing is.',
    code: '@ read a big-endian 16-bit field into r0\n    ldrh r0, [r1], #2\n    rev16 r0, r0'
  },
  deep: {
    kind: 'compiler',
    title: 'The compiler will not guess your alignment',
    text: 'Copying <code>char</code> arrays one byte at a time is correct for any alignment, so unless the compiler can prove both pointers are 4-byte aligned and the length is a multiple of 4, it must keep the loop at byte width. Declare the parameters as <code>int *</code> instead and the guesswork disappears, because an <code>int *</code> is never allowed to point at a misaligned address in the first place.',
    a: { lab: 'C, bytes: alignment unknown', lang: 'c', code: 'void copy(char *dst, char *src, int n) {\n    for (int i = 0; i < n; i++)\n        dst[i] = src[i];\n}' },
    b: { lab: 'gcc -O2, ARMv7: one byte per trip', code: '1:  ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b' },
    note: 'Change both parameters to <code>int *</code> with the same loop body and the generated code switches to <code>LDR</code>/<code>STR</code> automatically — same source shape, four times the data per trip, purely from a type that turned alignment into a guarantee instead of a guess.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR (immediate)', cite: 'The base register plus offset forms the address; the load is of a word, and the address must be word-aligned unless unaligned access support is enabled.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Alignment support', cite: 'LDRD and STRD require doubleword alignment and an even-numbered first register.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which instruction loads one byte and sign-extends it?', opts: ['<code>LDRB</code>', '<code>LDRSB</code>', '<code>LDRH</code>', '<code>STRB</code>'], a: 1, why: 'LDRB zero-extends; LDRSB copies bit 7 into the top 24 bits, so 0xFF becomes −1.' },
    { k: 'mcq', q: 'Why is there no <code>STRSB</code>?', opts: ['It was removed in ARMv7', 'Storing truncates, so sign extension has nothing to do', 'It is spelled <code>STRSBX</code>', 'There is one'], a: 1, why: 'Sign extension widens a value. A store narrows it, so the question never arises.' },
    { k: 'code', q: 'Sum the six bytes at <code>bytes</code> into r0.', start: '    ldr  r1, =bytes\n    mov  r2, #6\n    mov  r0, #0\n1:\n\n.data\nbytes: .byte 4, 8, 15, 16, 23, 42\n', check: [{ reg: 'r0', eq: 108 }], solution: '    ldr  r1, =bytes\n    mov  r2, #6\n    mov  r0, #0\n1:\n    ldrb r3, [r1], #1\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\nbytes: .byte 4, 8, 15, 16, 23, 42\n', hints: ['Bytes need <code>ldrb</code>, and the pointer advances by 1.', '<code>ldrb r3, [r1], #1</code> does both.'], why: '4+8+15+16+23+42 = 108.' },
    { k: 'bug', q: 'This crashes with an alignment fault. Why?', code: '    ldr  r1, =buf\n    add  r1, r1, #1\n    ldr  r0, [r1]\n\n.data\nbuf: .word 0,0', opts: ['<code>buf</code> is too small', 'r1 is now odd, and <code>LDR</code> needs a 4-byte-aligned address', '<code>ldr</code> should be <code>str</code>', 'The literal pool is missing'], a: 1, why: 'Word loads need word-aligned addresses. Use <code>LDRB</code> for unaligned byte access, or load the aligned word and shift.' },
    { k: 'mcq', q: 'What does the assembler do with <code>ldr r0, =0x12345678</code>?', opts: ['Rejects it', 'Emits a MOV with a 32-bit immediate', 'Places the constant in a literal pool and emits a PC-relative load', 'Splits it into four byte loads'], a: 2, why: '0x12345678 cannot be an ARM immediate, so the assembler stores it near the code and loads it relative to PC.' }
  ]
},

/* ------------------------------------------------------------------ 3.2 */
{
  id: 'u3l2', title: 'Offset, pre-index, post-index', goal: 'Fold the pointer bump into the memory instruction itself.',
  teach: [
    { t: 'p', x: 'Every ARM load and store can update its own base register. Three forms, and the punctuation is the whole difference:' },
    { t: 'table', head: ['Written', 'Name', 'Address used', 'Effect on rN'], rows: [
      ['<code>[r1, #4]</code>', 'offset', 'r1 + 4', 'unchanged'],
      ['<code>[r1, #4]!</code>', 'pre-indexed', 'r1 + 4', 'r1 becomes r1 + 4'],
      ['<code>[r1], #4</code>', 'post-indexed', 'r1', 'r1 becomes r1 + 4'],
    ] },
    { t: 'note', x: 'Read it as punctuation: the <b>!</b> means "and write it back". A <b>comma outside the brackets</b> means "use the address first, then add".' },
    { t: 'h', x: 'Post-index is the loop instruction' },
    { t: 'code', cap: 'Four instructions become three', x: '@ before\n1:  ldr  r3, [r1]\n    add  r1, r1, #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n@ after — the ADD disappeared into the LDR\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'p', x: 'The write-back is free: it happens in the address-generation stage, which is idle anyway. You have removed 25% of the loop body and lost nothing.' },
    { t: 'h', x: 'When to use pre-index' },
    { t: 'p', x: 'Pre-index suits loops that walk <i>backwards</i>, and stack frames. <code>str r0, [sp, #-4]!</code> is exactly what <code>push {r0}</code> does: move the pointer down, then store at the new address.' },
    { t: 'code', cap: 'Walking backwards', x: '    add  r1, r1, #40     @ one past the end\n1:  ldr  r3, [r1, #-4]!  @ step back, then load\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b' }
  ],
  real: {
    title: 'Why compilers love post-index',
    text: 'Look at any optimised ARM output from a loop over an array and you will see <code>ldr rX, [rY], #4</code> almost every time. It is the single most effective instruction-count reduction available in array code, and it costs nothing at all.',
    code: '@ gcc -O2, summing an int array\n.L3:\n    ldr  r3, [r0], #4\n    adds r2, r2, r3\n    cmp  r0, r1\n    bne  .L3'
  },
  deep: {
    kind: 'pitfall',
    title: 'Pre-index where you meant post-index',
    text: 'The two forms differ only in where the comma sits, which makes them easy to swap without noticing. <code>[r1, #4]!</code> moves the pointer first and then reads the new address, so a loop written this way silently skips element zero; <code>[r1], #4</code> reads the current address and moves afterwards, which is almost always what a forward scan actually wants.',
    a: { lab: 'Pre-index: element 0 is never read', code: '    ldr  r1, =arr\n    mov  r2, #4\n1:  ldr  r3, [r1, #4]!    @ advances then loads: arr[1], arr[2], arr[3], arr[4]\n    subs r2, r2, #1\n    bne  1b' },
    b: { lab: 'Post-index: the whole array, in order', code: '    ldr  r1, =arr\n    mov  r2, #4\n1:  ldr  r3, [r1], #4      @ loads then advances: arr[0], arr[1], arr[2], arr[3]\n    subs r2, r2, #1\n    bne  1b' },
    note: 'Both forms assemble without complaint and both update the pointer, so nothing catches this at build time. It shows up only as an answer that is subtly wrong at one end of the array or the other.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR (immediate), addressing modes', cite: 'Offset addressing leaves the base register unchanged; pre-indexed addressing writes the computed address back to the base; post-indexed addressing uses the base as the address and then writes back the computed value.' }
  ],
  ex: [
    { k: 'match', q: 'Match the syntax to its behaviour.', pairs: [['[r1, #4]', 'address r1+4, r1 unchanged'], ['[r1, #4]!', 'address r1+4, r1 becomes r1+4'], ['[r1], #4', 'address r1, r1 becomes r1+4']], why: 'The <code>!</code> means write-back; a comma outside the brackets means post-index.' },
    { k: 'mcq', q: 'Which form is right for walking forwards through an array?', opts: ['<code>[r1, #4]</code>', '<code>[r1, #4]!</code>', '<code>[r1], #4</code>', 'None'], a: 2, why: 'Post-index: use the current element, then advance ready for the next iteration.' },
    { k: 'code', q: 'Rewrite this so the pointer update happens inside the load. The sum must still be 100.', start: '    ldr  r1, =d\n    mov  r2, #4\n    mov  r0, #0\n1:  ldr  r3, [r1]\n    add  r1, r1, #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\nd: .word 10,20,30,40\n', check: [{ reg: 'r0', eq: 100 }, { maxInsn: 22 }], solution: '    ldr  r1, =d\n    mov  r2, #4\n    mov  r0, #0\n1:  ldr  r3, [r1], #4\n    add  r0, r0, r3\n    subs r2, r2, #1\n    bne  1b\n\n.data\nd: .word 10,20,30,40\n', hints: ['Delete the <code>add r1, r1, #4</code>.', 'Change the load to <code>ldr r3, [r1], #4</code>.'], why: 'Same result, one fewer instruction per iteration.' },
    { k: 'mcq', q: '<code>push {r0}</code> is exactly equivalent to which store?', opts: ['<code>str r0, [sp], #4</code>', '<code>str r0, [sp, #-4]!</code>', '<code>str r0, [sp, #4]</code>', '<code>str r0, [sp]</code>'], a: 1, why: 'Pre-decrement then store — the full-descending stack convention.' },
    { k: 'predict', q: 'What is in r1 at the end? (The array starts at 0x18000.)', code: '    ldr  r1, =d\n    ldr  r3, [r1], #4\n    ldr  r3, [r1], #4\n    ldr  r3, [r1, #4]\n\n.data\nd: .word 1,2,3,4\n', ask: 'r1', a: 98312, why: '0x18000 + 8 = 0x18008 = 98312. The third load uses offset addressing, so it reads d[3] but leaves r1 alone.' }
  ]
},

/* ------------------------------------------------------------------ 3.3 */
{
  id: 'u3l3', title: 'The scaled index', goal: 'Use [rN, rM, LSL #k] and know when it beats a pointer walk.',
  teach: [
    { t: 'p', x: 'ARM has a barrel shifter in front of the ALU, and memory operands can use it. <code>[r1, r2, LSL #2]</code> means "address = r1 + (r2 × 4)" — computed for free, inside the load.' },
    { t: 'code', cap: 'Random access by index', x: '    ldr  r1, =arr\n    mov  r2, #3\n    ldr  r0, [r1, r2, lsl #2]   @ r0 = arr[3], no multiply instruction' },
    { t: 'table', head: ['Element size', 'Shift'], rows: [['1 byte', 'none — <code>[r1, r2]</code>'], ['2 bytes', '<code>LSL #1</code>'], ['4 bytes', '<code>LSL #2</code>'], ['8 bytes', '<code>LSL #3</code>'], ['16 bytes', '<code>LSL #4</code>']] },
    { t: 'h', x: 'Scaled index vs pointer walk' },
    { t: 'p', x: 'For a simple forward scan, the pointer walk wins — the post-index is free and you avoid keeping an index at all. The scaled index earns its place when you need <b>random access</b>, or when one index drives <b>several</b> arrays at once.' },
    { t: 'code', cap: 'One index, three arrays', x: '@ out[i] = a[i] + b[i]\n1:  ldr  r4, [r1, r0, lsl #2]\n    ldr  r5, [r2, r0, lsl #2]\n    add  r4, r4, r5\n    str  r4, [r3, r0, lsl #2]\n    add  r0, r0, #1\n    cmp  r0, r6\n    blo  1b' },
    { t: 'note', x: 'Three pointer walks would need three separate increments. One scaled index drives all three arrays from a single counter — fewer registers, fewer instructions.' },
    { t: 'h', x: 'Two-dimensional arrays' },
    { t: 'p', x: 'For a row-major array with <code>W</code> columns, element [y][x] is at <code>base + (y×W + x) × size</code>. If W is a power of two the whole thing collapses into shifts; if it is not, you need a multiply — or a lookup table, which is the subject of Unit 9.' }
  ],
  real: {
    title: 'Pixel addressing in a framebuffer',
    text: 'A 32-bit-per-pixel framebuffer 1024 pixels wide gives pixel (x, y) at <code>base + (y &lt;&lt; 12) + (x &lt;&lt; 2)</code>. Both shifts fold into ARM addressing, so plotting a pixel is one <code>STR</code>. Choose a non-power-of-two width and you have just added a multiply to every pixel.',
    code: '@ plot colour r3 at (r1, r2) in a 1024-wide 32bpp buffer\n    add  r0, r0, r2, lsl #12\n    str  r3, [r0, r1, lsl #2]'
  },
  deep: {
    kind: 'compiler',
    title: 'The scaled index only understands powers of two',
    text: 'A load\'s register-offset form can shift the index before adding it — <code>LSL #1</code>, <code>#2</code>, <code>#3</code> — because the barrel shifter only ever multiplies by a power of two. An array of 4-byte ints fits that perfectly; an array of 12-byte structs does not, so indexing it needs a real multiply folded in before the scaled index can do the last part of the job.',
    a: { lab: 'Power-of-two element: one instruction', code: '    ldr  r1, =ints\n    ldr  r0, [r1, r2, lsl #2]   @ ints[r2], element size 4' },
    b: { lab: '12-byte struct: a multiply first', code: '    ldr  r1, =structs\n    add  r3, r2, r2, lsl #1     @ r3 = r2*3\n    ldr  r0, [r1, r3, lsl #2]   @ address = base + r2*3*4 = base + r2*12' },
    note: 'gcc reaches for exactly this shift-and-add trick whenever a struct size allows it, the same idea Unit 7 calls strength reduction. Past a certain size — a large or awkward element size with no cheap shift decomposition — it gives up and emits a plain <code>MUL</code> instead.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDR (register)', cite: 'The register offset may be shifted by an immediate amount using LSL, LSR, ASR or ROR before being added to the base register.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A5 — Addressing Mode 2', cite: 'The register-offset forms of LDR and STR scale the index only through the barrel shifter, so the available scale factors are powers of two.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which addressing mode reads <code>arr[i]</code> for an array of 32-bit ints, with the index in r2?', opts: ['<code>[r1, r2]</code>', '<code>[r1, r2, lsl #1]</code>', '<code>[r1, r2, lsl #2]</code>', '<code>[r1, r2, lsl #4]</code>'], a: 2, why: '4 bytes per element, so shift left by 2.' },
    { k: 'code', q: 'Use a single index to compute <code>out[i] = a[i] * 2</code> for 4 elements.', start: '    ldr  r1, =a\n    ldr  r2, =out\n    mov  r0, #0\n1:\n\n.data\na:   .word 3, 5, 7, 9\nout: .space 16\n', check: [{ memLabel: 'out', words: [6, 10, 14, 18] }], solution: '    ldr  r1, =a\n    ldr  r2, =out\n    mov  r0, #0\n1:\n    ldr  r3, [r1, r0, lsl #2]\n    lsl  r3, r3, #1\n    str  r3, [r2, r0, lsl #2]\n    add  r0, r0, #1\n    cmp  r0, #4\n    blo  1b\n\n.data\na:   .word 3, 5, 7, 9\nout: .space 16\n', hints: ['One counter r0 drives both arrays.', 'Doubling is <code>lsl r3, r3, #1</code>.'], why: 'One index, two arrays, no pointer arithmetic.' },
    { k: 'mcq', q: 'When is a pointer walk better than a scaled index?', opts: ['Always', 'When you walk one array sequentially forwards', 'When you need random access', 'When the element size is 8 bytes'], a: 1, why: 'A sequential walk gets its increment free from post-indexing, and needs no index register at all.' },
    { k: 'mcq', q: 'Why can a scaled index not compute a pixel address in a GPU\'s tiled framebuffer?', opts: ['The shift amount is limited to 3', 'Tiled memory interleaves bits of x and y, so the address is not a linear function of either coordinate', 'LSL cannot be used with LDRB', 'It can'], a: 1, why: 'The address depends on interleaved bits of both x and y, not on a single coordinate times a constant — exactly what a scaled index cannot express.' },
    { k: 'predict', q: 'What is in r0?', code: '    ldr  r1, =t\n    mov  r2, #2\n    ldr  r0, [r1, r2, lsl #2]\n\n.data\nt: .word 100, 200, 300, 400\n', ask: 'r0', a: 300, why: 'Index 2, element size 4, so t[2] = 300.' }
  ]
},

/* ------------------------------------------------------------------ 3.4 */
{
  id: 'u3l4', title: 'Copy loops', goal: 'Move data between two pointers correctly, including overlapping ranges.',
  teach: [
    { t: 'p', x: 'A copy loop needs two pointers and a count. The shape is identical to a sum loop, with the add replaced by a store.' },
    { t: 'code', cap: 'Byte copy', x: '@ r0 = dst, r1 = src, r2 = count\n1:  ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b' },
    { t: 'h', x: 'Copy words when you can' },
    { t: 'p', x: 'A word copy moves four times the data per iteration. It requires both pointers to be word-aligned and the count to be a multiple of four — conditions you check once, before the loop, not inside it.' },
    { t: 'code', cap: 'Word copy', x: '1:  ldr  r3, [r1], #4\n    str  r3, [r0], #4\n    subs r2, r2, #4\n    bne  1b' },
    { t: 'h', x: 'Overlap: the thing that breaks copies' },
    { t: 'p', x: 'If the destination is <i>inside</i> the source range, a forward copy overwrites bytes it has not read yet. The rule:' },
    { t: 'table', head: ['Situation', 'Direction to copy'], rows: [
      ['dst &lt; src', 'forwards — safe'],
      ['dst &gt; src, ranges overlap', '<b>backwards</b> — start at the end'],
      ['no overlap', 'either']
    ] },
    { t: 'note', x: 'This is exactly the difference between C\'s <code>memcpy</code> (undefined behaviour on overlap) and <code>memmove</code> (defined). A scroll routine moves a screen buffer onto itself and therefore always needs the memmove rule.' },
    { t: 'code', cap: 'Backwards copy for overlapping ranges', x: '    add  r0, r0, r2      @ point one past the end\n    add  r1, r1, r2\n1:  ldrb r3, [r1, #-1]!\n    strb r3, [r0, #-1]!\n    subs r2, r2, #1\n    bne  1b' }
  ],
  real: {
    title: 'memmove in every C library',
    text: 'Every libc contains exactly this decision: compare the pointers, pick a direction, then run the fast loop. Bionic, glibc and newlib all do it, and all of them then switch to <code>LDM</code>/<code>STM</code> block transfers for the bulk — which is Unit 5.',
    code: 'memmove:\n    cmp  r0, r1\n    bls  forward_copy    @ dst <= src: forwards is safe\n    add  r3, r1, r2\n    cmp  r0, r3\n    bhs  forward_copy    @ no overlap at all\n    b    backward_copy'
  },
  deep: {
    kind: 'pitfall',
    title: 'Copying forwards into your own source',
    text: 'A forward byte-by-byte copy is only safe when the destination does not overlap bytes the loop has not read yet. Move a block a few bytes later in the same buffer — the ordinary way to open a gap for an insert — and a forward copy overwrites each source byte moments before it would have been read, smearing the first few bytes across the entire remainder.',
    a: { lab: 'Forward copy, dst just above src', code: '@ dst = src + 4: corrupts everything after the first few bytes\n1:  ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b' },
    b: { lab: 'Backward copy: same overlap, correct', code: '@ read everything before overwriting any of it\n    add  r1, r1, r2\n    add  r0, r0, r2\n1:  ldrb r3, [r1, #-1]!\n    strb r3, [r0, #-1]!\n    subs r2, r2, #1\n    bne  1b' },
    note: 'The rule still holds: when the destination is above the source and the ranges overlap, copy from the end backwards. Decide the direction before the loop starts, not by trial and error inside it.'
  },
  refs: [
    { src: 'ISO/IEC 9899 (C standard), 7.24.2.1 and 7.24.2.2', cite: 'memcpy has undefined behaviour if the objects overlap; memmove behaves as if the source were first copied to a temporary buffer.' },
    { src: 'Arm Optimized Routines, arch/arm/memmove.S', cite: 'A production memmove compares the pointers and picks the copy direction once, before the loop begins, never inside it.' }
  ],
  ex: [
    { k: 'mcq', q: 'dst = 0x1004, src = 0x1000, length = 16. Which direction is safe?', opts: ['Forwards', 'Backwards', 'Either', 'Neither'], a: 1, why: 'The destination is above the source and the ranges overlap, so a forward copy would overwrite source bytes before reading them.' },
    { k: 'code', q: 'Copy 6 bytes from <code>src</code> to <code>dst</code>.', start: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #6\n1:\n\n.data\nsrc: .byte 1,2,3,4,5,6\ndst: .space 6\n', check: [{ memLabel: 'dst', bytes: [1, 2, 3, 4, 5, 6] }], solution: '    ldr  r1, =src\n    ldr  r0, =dst\n    mov  r2, #6\n1:\n    ldrb r3, [r1], #1\n    strb r3, [r0], #1\n    subs r2, r2, #1\n    bne  1b\n\n.data\nsrc: .byte 1,2,3,4,5,6\ndst: .space 6\n', hints: ['Load with <code>ldrb</code>, store with <code>strb</code>, both post-indexed.'], why: 'The two-pointer copy is the second loop shape you should be able to write without thinking.' },
    { k: 'code', q: 'Shift the 8 bytes at <code>buf</code> one place to the RIGHT (buf[1..7] = buf[0..6]). The ranges overlap, so pick your direction carefully.', start: '    ldr  r1, =buf\n    mov  r2, #7\n\n.data\nbuf: .byte 1,2,3,4,5,6,7,0\n', check: [{ memLabel: 'buf', bytes: [1, 1, 2, 3, 4, 5, 6, 7] }], solution: '    ldr  r1, =buf\n    mov  r2, #7\n    add  r0, r1, #8      @ dst end\n    add  r3, r1, #7      @ src end\n1:  ldrb r4, [r3, #-1]!\n    strb r4, [r0, #-1]!\n    subs r2, r2, #1\n    bne  1b\n\n.data\nbuf: .byte 1,2,3,4,5,6,7,0\n', hints: ['Destination is above source: copy backwards.', 'Start both pointers one past the end and use <code>[rX, #-1]!</code>.'], why: 'Copying forwards would smear buf[0] across the whole array — try it and see.' },
    { k: 'mcq', q: 'Why does a word copy need an alignment check before the loop rather than inside it?', opts: ['Alignment can change during the loop', 'Checking inside would cost an instruction on every iteration for a fact that cannot change', 'LDR does not fault on unaligned addresses', 'It does need one inside'], a: 1, why: 'If the pointers are word-aligned once and advance by 4, they stay word-aligned. Check once, then never again.' },
    { k: 'bug', q: 'This word copy sometimes copies four bytes too many. Why?', code: '1:  ldr  r3, [r1], #4\n    str  r3, [r0], #4\n    subs r2, r2, #4\n    bne  1b', opts: ['<code>subs</code> should subtract 1', 'If r2 is not a multiple of 4 it steps past zero and never sets Z', 'The pointers should be pre-indexed', 'It needs <code>ldm</code>'], a: 1, why: 'Counting down by 4 only lands exactly on zero when the count is a multiple of 4. Otherwise handle the remainder separately — Unit 5 shows how.' }
  ]
},

/* ------------------------------------------------------------------ 3.5 */
{
  id: 'u3l5', title: 'Sentinel loops', goal: 'Loop until you find a value, not until a counter runs out.',
  teach: [
    { t: 'p', x: 'Sometimes you do not know how many iterations you need. You stop when you find something: a zero terminator, a newline, a matching key, the end of a linked list. These are <b>sentinel loops</b>, and they have a different shape.' },
    { t: 'code', cap: 'Scan to a zero terminator', x: '@ r0 = pointer to a NUL-terminated string; length ends up in r2\n    mov  r1, r0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    bne  1b\n    sub  r2, r1, r0\n    sub  r2, r2, #1      @ do not count the terminator' },
    { t: 'p', x: 'Note the shape: the load, the compare, the branch — and then arithmetic <i>after</i> the loop to turn the final pointer into the answer. That subtraction at the end is characteristic of sentinel loops.' },
    { t: 'h', x: 'Walking a linked list' },
    { t: 'code', cap: 'The sentinel is a null pointer', x: '@ r0 = head; count the nodes into r1\n    mov  r1, #0\n1:  cmp  r0, #0\n    beq  2f\n    add  r1, r1, #1\n    ldr  r0, [r0, #NEXT]\n    b    1b\n2:' },
    { t: 'note', x: 'A sentinel loop with no guard against a missing sentinel will run off the end of memory. Real code almost always carries a maximum as well — "scan until zero, or until 4096 bytes", which is what <code>strnlen</code> is for.' },
    { t: 'h', x: 'Two exits, one loop' },
    { t: 'p', x: 'A loop with both a sentinel and a count has two exit conditions and therefore two branches. Put the cheap one at the bottom and the rare one wherever it reads best:' },
    { t: 'code', cap: 'strnlen', x: '@ r0 = pointer, r1 = maximum\n    mov  r2, r0\n1:  cmp  r1, #0\n    beq  2f              @ hit the limit\n    ldrb r3, [r2], #1\n    sub  r1, r1, #1\n    cmp  r3, #0\n    bne  1b\n    sub  r2, r2, #1      @ back up over the terminator\n2:  sub  r0, r2, r0' }
  ],
  real: {
    title: 'Parsing a line out of a buffer',
    text: 'Every text protocol — HTTP, SMTP, a config file, a CSV — is parsed by a sentinel loop looking for a newline, with a bound so that a malicious input cannot make the loop run for ever. Forgetting the bound is how you get a denial of service out of a one-line parser.',
    code: '@ find the newline, at most r1 bytes away\n1:  subs r1, r1, #1\n    bmi  notfound\n    ldrb r3, [r0], #1\n    cmp  r3, #10\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'A sentinel hides the trip count from the compiler',
    text: 'Unrolling or vectorising a loop both need to know, at compile time or at worst at loop entry, how many times it will run. A loop that stops at a sentinel value found in the data has a trip count that depends on the data itself, so neither optimisation can apply until something else establishes a bound.',
    a: { lab: 'C: trip count is data-dependent', lang: 'c', code: 'int len(const char *s) {\n    const char *p = s;\n    while (*p) p++;\n    return p - s;\n}' },
    b: { lab: 'gcc -O2, ARMv7: one byte per pass', code: '    mov  r1, r0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    bne  1b\n    sub  r0, r1, r0\n    sub  r0, r0, #1' },
    note: 'A version bounded by a known maximum — <code>strnlen</code>, or a loop over a fixed-size buffer — hands the compiler exactly the bound it needs, which is why the bounded and unbounded forms of the same function can end up with such different assembly.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — LDRB (immediate)', cite: 'LDRB zero-extends the loaded byte into the destination register, so a comparison against #0 tests the byte value directly.' },
    { src: 'GCC documentation, -funroll-loops and auto-vectorisation', cite: 'Loop unrolling and vectorisation both require a trip count known at compile time or established by a runtime bound check before the loop.' }
  ],
  ex: [
    { k: 'code', q: 'Find the length of the string at <code>msg</code> (not counting the terminating zero) and put it in r0.', start: '    ldr  r0, =msg\n\n.data\nmsg: .asciz "LOOPS"\n', check: [{ reg: 'r0', eq: 5 }], solution: '    ldr  r0, =msg\n    mov  r1, r0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0\n    bne  1b\n    sub  r0, r1, r0\n    sub  r0, r0, #1\n\n.data\nmsg: .asciz "LOOPS"\n', hints: ['Walk a second pointer forwards until you load a zero.', 'Subtract the original pointer, then subtract 1 for the terminator.'], why: 'This is <code>strlen</code>. You will make it eight times faster in Unit 7.' },
    { k: 'code', q: 'Count how many bytes in the 9-byte block at <code>data</code> come before the first 0xFF. Put it in r0.', start: '    ldr  r1, =data\n    mov  r0, #0\n\n.data\ndata: .byte 3,1,4,1,5,0xFF,9,2,6\n', check: [{ reg: 'r0', eq: 5 }], solution: '    ldr  r1, =data\n    mov  r0, #0\n1:  ldrb r3, [r1], #1\n    cmp  r3, #0xFF\n    beq  2f\n    add  r0, r0, #1\n    b    1b\n2:\n\n.data\ndata: .byte 3,1,4,1,5,0xFF,9,2,6\n', hints: ['Load, compare against 0xFF, leave the loop when equal.'], why: 'Five bytes precede the sentinel.' },
    { k: 'mcq', q: 'Why does a sentinel loop usually do arithmetic after it finishes?', opts: ['To reset the flags', 'Because the pointer has advanced past the item that stopped it, so the answer has to be corrected', 'To save a register', 'It does not'], a: 1, why: 'Post-indexing means the pointer already moved on. The final <code>sub</code> converts "where I stopped" into "how far I went".' },
    { k: 'bug', q: 'What makes this loop dangerous on untrusted input?', code: '1:  ldrb r3, [r0], #1\n    cmp  r3, #0\n    bne  1b', opts: ['<code>ldrb</code> should be <code>ldr</code>', 'If the buffer contains no zero, the loop walks off the end of memory', 'The compare should be <code>teq</code>', 'r0 should be r1'], a: 1, why: 'Always carry a maximum. That is what <code>strnlen</code> is, and why it exists.' },
    { k: 'mcq', q: 'Which condition would you use to leave a loop when a counter goes negative after <code>subs r1, r1, #1</code>?', opts: ['<code>BEQ</code>', '<code>BMI</code>', '<code>BCS</code>', '<code>BVS</code>'], a: 1, why: 'BMI branches when N is set — the counter has gone below zero. This is the standard way to write a loop whose count may legitimately be zero.' }
  ]
},

/* ------------------------------------------------------------------ 3.6 */
{
  id: 'u3l6', title: 'Alignment, width and speed', goal: 'Understand what alignment costs and how loops exploit it.',
  teach: [
    { t: 'p', x: 'Memory is delivered to the core in chunks — typically 4 or 8 bytes at a time, and 32 or 64 bytes from the cache. An access that sits entirely inside one chunk is one transaction. An access that straddles two is two.' },
    { t: 'table', head: ['Access', 'Alignment required (ARMv7-A)', 'If misaligned'], rows: [
      ['<code>LDRB</code>', 'none', '—'],
      ['<code>LDRH</code>', '2 bytes', 'Fault, or slow, depending on SCTLR.A'],
      ['<code>LDR</code>', '4 bytes', 'Fault, or slow'],
      ['<code>LDRD</code>', '8 bytes', 'Always faults'],
      ['<code>LDM</code> / <code>STM</code>', '4 bytes', 'Always faults']
    ] },
    { t: 'note', x: 'ARMv7-A can be configured to allow unaligned <code>LDR</code> and <code>LDRH</code>, and Linux enables that. It still costs extra cycles. <code>LDM</code>, <code>STM</code> and <code>LDRD</code> never tolerate it, which is the practical reason a fast copy loop starts by aligning its pointers.' },
    { t: 'h', x: 'The align-then-bulk pattern' },
    { t: 'p', x: 'Every serious copy or fill routine has three phases: a <b>head</b> that handles bytes until the pointer is aligned, a <b>bulk</b> loop that moves whole words or blocks, and a <b>tail</b> that handles the leftover bytes. The head and tail are small loops; the bulk loop is where all the time goes.' },
    { t: 'code', cap: 'Head, bulk, tail', x: '@ r0 = dst, r2 = count, r1 = byte value\nhead:\n    tst  r0, #3\n    beq  bulk\n    strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  head\nbulk:\n    orr  r1, r1, r1, lsl #8    @ replicate the byte\n    orr  r1, r1, r1, lsl #16   @ into all four lanes\n1:  cmp  r2, #4\n    blo  tail\n    str  r1, [r0], #4\n    sub  r2, r2, #4\n    b    1b\ntail:\n    cmp  r2, #0\n    beq  2f\n    strb r1, [r0], #1\n    subs r2, r2, #1\n    bne  tail\n2:' },
    { t: 'p', x: 'That replication trick — <code>orr r1, r1, r1, lsl #8</code> twice — turns a byte into four copies of itself using the barrel shifter, with no memory access. It is the standard opening move of <code>memset</code>.' }
  ],
  real: {
    title: 'Why memset is not one instruction long',
    text: 'The whole complexity of a real memset is alignment and size handling. The actual storing is trivial. Read the ARM optimised-routines source and you will find perhaps 15 lines doing the work and 60 lines deciding which of several loops to run.',
    code: '@ replicate a byte into all four lanes of a word\n    and  r1, r1, #0xFF\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16'
  },
  deep: {
    kind: 'cores',
    title: 'The same misaligned load costs differently by core',
    text: 'A Cortex-M0 has no cache and a small, simple bus, so an unaligned word access there either is not supported at all or costs a small and predictable number of extra cycles depending on the exact part. A Cortex-A7 has a cache sitting in the way, so an unaligned access that happens to cross a cache-line boundary turns into two separate line fetches instead of one — a bigger and far less predictable penalty than on the simpler core.',
    code: '    ldr  r0, [r1, #1]   @ address not a multiple of 4',
    note: 'This is the practical reason "enable unaligned access and stop worrying about it" is worse advice on a core with a cache than on one without. The cost stops being a small constant and starts depending on exactly where the access lands.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A3 — Alignment support', cite: 'When SCTLR.A is 0, unaligned word and halfword accesses are permitted; LDM, STM, LDRD and STRD always require word or doubleword alignment and generate an alignment fault otherwise.' },
    { src: 'ARM Cortex-A Series Programmer\'s Guide (DEN0013D), Memory access', cite: 'Unaligned accesses that cross a cache-line boundary are broken into multiple transactions and cost additional cycles.' }
  ],
  ex: [
    { k: 'mcq', q: 'Which of these <b>always</b> faults on an unaligned address, regardless of configuration?', opts: ['<code>LDRB</code>', '<code>LDRH</code>', '<code>LDR</code>', '<code>LDM</code>'], a: 3, why: 'LDM, STM, LDRD and STRD have no unaligned support at all.' },
    { k: 'code', q: 'Replicate the byte in r1 into all four byte lanes of r1 using only shifts and ORs.', start: '    mov  r1, #0xAB\n', check: [{ reg: 'r1', eq: 2880154539 }, { notContains: 'ldr' }], solution: '    mov  r1, #0xAB\n    orr  r1, r1, r1, lsl #8\n    orr  r1, r1, r1, lsl #16\n', hints: ['First OR in a copy shifted by 8 — now you have two lanes.', 'Then OR in a copy of <i>that</i> shifted by 16.'], why: '0xABABABAB = 2880154539. Two instructions, no memory, no loop.' },
    { k: 'mcq', q: 'Why does a fast memcpy align its pointers before the bulk loop?', opts: ['To make the code shorter', 'Because <code>LDM</code>/<code>STM</code> — the fastest bulk transfer — require word alignment', 'Because unaligned loads return zero', 'It does not'], a: 1, why: 'The head loop pays a few byte copies once to unlock a much faster bulk loop for the rest.' },
    { k: 'mcq', q: 'A loop copies 4093 bytes with a word loop. What must it also have?', opts: ['A tail loop for the last byte', 'A tail loop for the last 1 byte — 4093 = 1023×4 + 1', 'Nothing, LDR handles it', 'A second pointer'], a: 1, why: 'Any bulk loop whose step does not divide the count needs a tail. That is the other half of the head/bulk/tail pattern.' },
    { k: 'predict', q: 'What is r0?', code: '    ldr  r1, =b\n    add  r1, r1, #2\n    ldrh r0, [r1]\n\n.data\n.align 2\nb: .byte 1,2,3,4\n', ask: 'r0', a: 1027, why: 'Bytes 3 and 4 little-endian: 0x0403 = 1027. The address is even, so LDRH is legal.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
