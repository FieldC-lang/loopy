/* AssArm: Loops — curriculum part 7 : Unit 11, vector loops */
(function (G) {
  'use strict';
  const U = G.LOOP_UNITS || (G.LOOP_UNITS = []);

  U.push({
    id: 'u11', n: 11, title: 'Vector Loops', icon: '⟦⟧', color: '#9ece6a',
    blurb: 'VFP, fixed point and NEON: doing four, eight or sixteen elements per instruction — and dealing with the leftovers.',
    lessons: [

/* ----------------------------------------------------------------- 11.1 */
{
  id: 'u11l1', title: 'Floating point in a loop', goal: 'Use VFP registers and understand the latency they add.',
  teach: [
    { t: 'p', x: 'VFP gives you 32 single-precision registers, <b>s0</b>–<b>s31</b>, which are also addressable as 16 double-precision registers d0–d15. They are a separate register file from r0–r15, with their own load and store instructions.' },
    { t: 'table', head: ['Instruction', 'Does'], rows: [
      ['<code>VLDR s0, [r1]</code>', 'Load one float'],
      ['<code>VSTR s0, [r1]</code>', 'Store one float'],
      ['<code>VADD.F32 s2, s0, s1</code>', 'Add'],
      ['<code>VMUL.F32 s2, s0, s1</code>', 'Multiply'],
      ['<code>VMLA.F32 s2, s0, s1</code>', 'Multiply and accumulate into s2'],
      ['<code>VMOV s0, r0</code>', 'Move the raw bits between files — <b>not</b> a conversion'],
      ['<code>VCVT.F32.S32 s0, s0</code>', 'Convert an integer to a float, in place'],
      ['<code>VCVT.S32.F32 s0, s0</code>', 'Convert a float to an integer']
    ] },
    { t: 'note', x: '<code>VMOV s0, r0</code> copies bits, not values. Moving the integer 1 gives you the float 1.4×10⁻⁴⁵, because that is what the bit pattern 0x00000001 means as a float. Use <code>VCVT</code> when you want the number.' },
    { t: 'code', cap: 'Sum an array of floats', x: '    ldr  r1, =farr\n    mov  r2, #4\n    mov  r0, #0\n    vmov s1, r0              @ accumulator = 0.0 (bits, and 0 is 0.0)\n1:  vldr s0, [r1]\n    vadd.f32 s1, s1, s0\n    add  r1, r1, #4\n    subs r2, r2, #1\n    bne  1b\n    vmov r0, s1' },
    { t: 'h', x: 'The cost you are buying' },
    { t: 'p', x: 'VFP operations have longer latency than integer ones — a multiply-accumulate might not deliver its result for four or five cycles. In a loop that accumulates into a single register, every iteration waits for the previous one. The fix is the same as in Unit 7: <b>several accumulators</b>, combined at the end.' },
    { t: 'code', cap: 'Four accumulators break the chain', x: '1:  vldr s0, [r1]\n    vldr s4, [r1, #4]\n    vldr s8, [r1, #8]\n    vldr s12, [r1, #12]\n    vadd.f32 s1, s1, s0\n    vadd.f32 s5, s5, s4\n    vadd.f32 s9, s9, s8\n    vadd.f32 s13, s13, s12\n    add  r1, r1, #16\n    subs r2, r2, #4\n    bne  1b\n    vadd.f32 s1, s1, s5\n    vadd.f32 s9, s9, s13\n    vadd.f32 s1, s1, s9' },
    { t: 'p', x: 'Floating-point addition is not associative, so regrouping changes the result in the last bits. For most signal processing that is fine and is done routinely; for anything that must reproduce a reference result exactly, it is not.' }
  ],
  real: {
    title: 'Not every ARMv7 core has VFP',
    text: 'VFP is optional. A Cortex-M0 or M3 has none; a Cortex-M4F has single precision only; some Cortex-A parts omit double precision. Code compiled for hardware float will not run on a core without it, which is exactly what Linux\'s "armhf" versus "armel" distinction is about.',
    code: '@ armhf passes floats in VFP registers; armel passes them in r0-r3.\n@ Mixing the two in one binary is a link error at best.'
  },
  deep: {
    kind: 'cores',
    title: 'A Cortex-M3 has nowhere to run VADD.F32',
    text: 'VFP is optional silicon, not a guaranteed part of ARMv7 the way the integer pipeline is. A Cortex-M3 has none of it at all, and a plain Cortex-M4 has none either — only the Cortex-M4F adds a single-precision unit, which is exactly what the <code>F</code> in its name means. Send <code>VADD.F32</code> to a core with no FPU and it does not run slowly, it raises an undefined-instruction fault, because there is no execution unit behind that encoding. The flag <code>-mfloat-abi</code> decides which binary you even get: <code>soft</code> never emits a VFP instruction and passes floats through <code>r0</code>-<code>r3</code>, so it runs anywhere; <code>hard</code> emits VFP instructions and passes floats in <code>s0</code> upward, so it only runs where the FPU exists; <code>softfp</code> emits the same instructions as <code>hard</code> but keeps the <code>soft</code> calling convention, trading a register copy at every call for the ability to link against soft-float code.',
    code: '@ softfp ABI: the loop must move the result into a core register for every call\n    vadd.f32 s0, s1, s2\n    vmov r0, s0               @ softfp/soft: the argument travels in r0\n    @ ... the call happens here ...\n\n@ hard-float ABI: no transfer at all\n    vadd.f32 s0, s1, s2       @ hard: s0 already IS the argument register\n    @ ... the call happens here ...',
    note: 'The three ABIs link without complaint against each other, because the linker checks symbol names, not calling conventions — mix a <code>softfp</code> caller with a <code>hard</code>-float callee and the call succeeds while the argument arrives in the wrong register file entirely.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A2.6 — The Advanced SIMD and floating-point extensions', cite: 'VFP provides 32 single-precision registers s0–s31, which overlap the 16 double-precision registers d0–d15.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — VMOV (between ARM core register and single-precision register)', cite: 'VMOV transfers the bit pattern without conversion; VCVT performs numeric conversion between integer and floating-point formats.' }
  ],
  ex: [
    { k: 'code', q: 'Multiply the two floats at <code>f</code> (3.0 and 4.0) and leave the raw bits of the result in r0.', start: '    ldr  r1, =f\n\n.data\nf: .word 0x40400000, 0x40800000\n', check: [{ reg: 'r0', eq: 0x41400000 }], solution: '    ldr  r1, =f\n    vldr s0, [r1]\n    vldr s1, [r1, #4]\n    vmul.f32 s2, s0, s1\n    vmov r0, s2\n\n.data\nf: .word 0x40400000, 0x40800000\n', hints: ['<code>vldr</code> both values, <code>vmul.f32</code>, then <code>vmov</code> the bits back.'], why: '3.0 × 4.0 = 12.0, whose IEEE-754 single-precision encoding is 0x41400000.' },
    { k: 'code', q: 'Convert the integer 7 in r0 to a float, then back to an integer in r2.', start: '    mov  r0, #7\n', check: [{ reg: 'r2', eq: 7 }, { contains: 'vcvt' }], solution: '    mov  r0, #7\n    vmov s0, r0\n    vcvt.f32.s32 s0, s0\n    vcvt.s32.f32 s1, s0\n    vmov r2, s1\n', hints: ['<code>vmov s0, r0</code> moves the bits; <code>vcvt.f32.s32</code> then reinterprets them as an integer and converts.'], why: 'Round trip through the float format and back. Skip the VCVTs and you get 7 as a denormal float, not 7.0.' },
    { k: 'mcq', q: 'What does <code>vmov s0, r0</code> do when r0 holds the integer 1?', opts: ['Puts 1.0 in s0', 'Puts the bit pattern 0x00000001 in s0, which as a float is about 1.4e-45', 'Rounds it', 'Fails'], a: 1, why: 'VMOV moves bits. VCVT moves values. Confusing them is the classic VFP beginner bug.' },
    { k: 'code', q: 'Sum the four floats at <code>f</code> (1.0, 2.0, 3.0, 4.0) and leave the raw bits of the total in r0.', start: '    ldr  r1, =f\n    mov  r2, #4\n    mov  r0, #0\n    vmov s1, r0\n1:\n\n.data\nf: .word 0x3F800000, 0x40000000, 0x40400000, 0x40800000\n', check: [{ reg: 'r0', eq: 0x41200000 }], solution: '    ldr  r1, =f\n    mov  r2, #4\n    mov  r0, #0\n    vmov s1, r0\n1:  vldr s0, [r1]\n    vadd.f32 s1, s1, s0\n    add  r1, r1, #4\n    subs r2, r2, #1\n    bne  1b\n    vmov r0, s1\n\n.data\nf: .word 0x3F800000, 0x40000000, 0x40400000, 0x40800000\n', hints: ['Zero the accumulator with <code>vmov s1, r0</code> where r0 is 0 — the all-zero bit pattern really is 0.0.', '<code>vldr</code>, <code>vadd.f32</code>, bump the pointer.'], why: '1+2+3+4 = 10.0, encoded as 0x41200000.' },
    { k: 'mcq', q: 'Why use several VFP accumulators in a long summation loop?', opts: ['To use more registers', 'Floating-point latency is several cycles, so one accumulator makes each iteration wait for the previous one', 'It is more accurate', 'It avoids VCVT'], a: 1, why: 'It also slightly changes the result, because floating-point addition is not associative — usually acceptable, occasionally not.' }
  ]
},

/* ----------------------------------------------------------------- 11.2 */
{
  id: 'u11l2', title: 'Fixed point: fractions without floats', goal: 'Do fractional arithmetic with integer instructions.',
  teach: [
    { t: 'p', x: 'Fixed point stores a fraction as an integer with an implied binary point. In <b>Q15</b>, a 16-bit signed value represents a number in [−1, 1): the value 32767 means almost exactly 1.0, and −32768 means −1.0.' },
    { t: 'table', head: ['Format', 'Integer bits', 'Fraction bits', 'Range'], rows: [
      ['Q15', '1 (sign)', '15', '−1 … 0.99997'],
      ['Q31', '1 (sign)', '31', '−1 … 0.9999999995'],
      ['Q16.16', '16', '16', '−32768 … 32767.99998'],
      ['Q8.8', '8', '8', '−128 … 127.996']
    ] },
    { t: 'h', x: 'The rules' },
    { t: 'p', x: '<b>Adding</b> two Q15 values just works — add the integers. <b>Multiplying</b> does not: multiplying two Q15 values gives a Q30 result, so you must shift right by 15 to get back to Q15.' },
    { t: 'code', cap: 'Q15 multiply', x: '@ r0, r1 hold Q15 values; result in Q15\n    smulbb r2, r0, r1        @ 16x16 -> 32-bit product, now Q30\n    asr    r2, r2, #15       @ back to Q15' },
    { t: 'code', cap: 'Q16.16 multiply', x: '    smull  r2, r3, r0, r1    @ 64-bit product, Q32.32\n    lsr    r2, r2, #16\n    orr    r2, r2, r3, lsl #16   @ take the middle 32 bits' },
    { t: 'note', x: 'The <code>ASR</code> is a right shift, so it rounds towards negative infinity. To round to nearest, add half of the shifted-away amount first: <code>add r2, r2, #0x4000</code> before the <code>asr #15</code>. In an accumulating loop that bias is not academic — it accumulates too.' },
    { t: 'h', x: 'Saturation' },
    { t: 'p', x: 'Fixed-point values overflow silently and catastrophically — 0.9 + 0.9 in Q15 wraps to about −0.2. That is a full-amplitude click in audio. <code>SSAT</code> clamps instead:' },
    { t: 'code', cap: 'Add with saturation', x: '    add  r2, r0, r1\n    ssat r2, #16, r2         @ clamp to the signed 16-bit range' },
    { t: 'h', x: 'Why bother, when VFP exists?' },
    { t: 'p', x: 'Because a great many ARM cores have no floating-point unit, because fixed point is often faster even when they do, and because it is exactly predictable — the same input gives bit-identical output on every machine, which matters for codecs and control systems.' }
  ],
  real: {
    title: 'Audio codecs are fixed point',
    text: 'MP3, AAC, Opus, G.711, GSM and almost every speech codec have integer-only reference implementations, precisely so that every decoder in the world produces the same bits. CMSIS-DSP, the standard ARM Cortex-M signal-processing library, is built on Q7, Q15 and Q31 throughout.',
    code: '@ a Q15 biquad step: one multiply-accumulate per coefficient\n    smulbb r5, r0, r4\n    add    r6, r6, r5, asr #15\n    ssat   r6, #16, r6'
  },
  deep: {
    kind: 'pitfall',
    title: 'A logical shift does not know the product is negative',
    text: 'ASR and LSR do the same thing to a positive number and different things to a negative one. <code>SMULBB</code> gives a genuinely signed product, so shifting it back down to a Q15 result has to be <code>ASR</code>, which copies the sign bit into the vacated positions; <code>LSR</code> fills with zero instead and turns a small negative number into a large positive one. The bug is silent because the assembler does not check which one your value needs either way, both instructions are legal, and both run to completion without complaint.',
    a: { lab: 'Wrong: LSR', code: '    mov  r0, #0x8000         @ -32768 in the low 16 bits: -1.0 in Q15\n    mov  r1, #16384           @ 16384 in the low 16 bits: 0.5 in Q15\n    smulbb r2, r0, r1         @ product is Q30: -536870912\n    lsr  r2, r2, #15          @ WRONG: logical shift, no sign extension\n    ssat r2, #16, r2          @ 114688 is out of range: saturates to 32767' },
    b: { lab: 'Right: ASR', code: '    mov  r0, #0x8000         @ -32768 in the low 16 bits: -1.0 in Q15\n    mov  r1, #16384           @ 16384 in the low 16 bits: 0.5 in Q15\n    smulbb r2, r0, r1         @ product is Q30: -536870912\n    asr  r2, r2, #15          @ RIGHT: arithmetic shift keeps the sign\n    ssat r2, #16, r2          @ -16384 is already in range: unchanged' },
    note: 'Feed that large positive number into <code>SSAT</code> afterwards and the damage compounds: −1.0 × 0.5, which is −0.5, comes out as 32767, the loudest possible sample instead of a quiet negative one.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — SSAT, USAT', cite: 'SSAT saturates a signed value to a specified bit position, optionally after a shift, and sets the Q flag if saturation occurred.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — SMULBB', cite: 'SMULBB multiplies the bottom halfwords of two registers as signed 16-bit values, producing a 32-bit result.' }
  ],
  ex: [
    { k: 'code', q: 'Multiply the Q15 values 0.5 (16384) and 0.5 (16384) and leave the Q15 result in r2. (0.25 in Q15 is 8192.)', start: '    mov  r0, #16384\n    mov  r1, #16384\n', check: [{ reg: 'r2', eq: 8192 }], solution: '    mov  r0, #16384\n    mov  r1, #16384\n    smulbb r2, r0, r1\n    asr  r2, r2, #15\n', hints: ['<code>smulbb</code> gives a Q30 product.', 'Shift right by 15 to return to Q15.'], why: '16384 × 16384 = 268435456, shifted right 15 gives 8192 — which is 0.25 in Q15.' },
    { k: 'code', q: 'Add 0.9 (29491) to itself in Q15, saturating rather than wrapping. Answer in r2.', start: '    ldr  r0, =29491\n', check: [{ reg: 'r2', eq: 32767 }, { contains: 'ssat' }], solution: '    ldr  r0, =29491\n    add  r2, r0, r0\n    ssat r2, #16, r2\n', hints: ['Add first, then <code>ssat r2, #16, r2</code>.'], why: '58982 exceeds the Q15 maximum, so it clamps to 32767 — just under 1.0. Without SSAT the 16-bit wrap would give a large negative value, which in audio is an audible click.' },
    { k: 'mcq', q: 'Why must a Q15 × Q15 multiply be shifted right by 15?', opts: ['To round it', 'The product of two Q15 values is Q30, so 15 fraction bits must be discarded to get back to Q15', 'To avoid overflow', 'It must not be'], a: 1, why: 'Fraction bits add when you multiply. Q15 × Q15 = Q30.' },
    { k: 'code', q: 'Q16.16 motion: position 3.5 is 0x00038000, velocity 1.25 is 0x00014000. Advance three frames and leave the integer pixel column in r2.', start: '    ldr  r0, =0x00038000\n    ldr  r1, =0x00014000\n    mov  r3, #3\n1:\n', check: [{ reg: 'r2', eq: 7 }], solution: '    ldr  r0, =0x00038000\n    ldr  r1, =0x00014000\n    mov  r3, #3\n1:  add  r0, r0, r1\n    subs r3, r3, #1\n    bne  1b\n    lsr  r2, r0, #16\n', hints: ['Adding fixed-point values is just adding.', 'The integer part is the top 16 bits: <code>lsr r2, r0, #16</code>.'], why: '3.5 + 1.25 × 3 = 7.25, whose integer part is 7. The fractional part carried correctly across all three frames with no special handling at all.' },
    { k: 'mcq', q: 'Why do audio codecs specify fixed-point reference implementations?', opts: ['Fixed point is more accurate', 'It is bit-exact and reproducible on every machine, and it runs on cores with no FPU', 'Floating point is illegal in codecs', 'It uses less memory'], a: 1, why: 'Every decoder producing identical bits is the point; running on an FPU-less Cortex-M is the bonus.' }
  ]
},

/* ----------------------------------------------------------------- 11.3 */
{
  id: 'u11l3', title: 'NEON: sixteen bytes at a time', goal: 'Load, operate on and store whole vectors.',
  teach: [
    { t: 'p', x: 'NEON is ARM\'s SIMD extension. The same 32 registers as VFP, but viewed as sixteen 128-bit <b>q</b> registers, each holding several elements that are all operated on at once.' },
    { t: 'table', head: ['Register view', 'Width', 'Holds'], rows: [
      ['<code>q0</code>–<code>q15</code>', '128 bits', '16 bytes, 8 halfwords, 4 words, or 4 floats'],
      ['<code>d0</code>–<code>d31</code>', '64 bits', 'half of a q register'],
      ['<code>s0</code>–<code>s31</code>', '32 bits', 'VFP view of d0–d15']
    ] },
    { t: 'note', x: 'They are the same physical registers. Writing q0 changes d0, d1, s0, s1, s2 and s3. That overlap is deliberate — it lets you compute with NEON and then read a single lane with VFP instructions — but it means you cannot use q0 and s2 for unrelated things at the same time.' },
    { t: 'h', x: 'Loading and storing' },
    { t: 'code', cap: 'VLD1 and VST1 move whole vectors', x: '    vld1.32 {d0, d1}, [r1]!   @ load 16 bytes into q0, advance r1 by 16\n    vst1.32 {d0, d1}, [r0]!   @ store 16 bytes, advance r0' },
    { t: 'h', x: 'Operating' },
    { t: 'code', cap: 'One instruction, four additions', x: '    vadd.i32 q2, q0, q1       @ four 32-bit adds\n    vadd.i16 q2, q0, q1       @ eight 16-bit adds\n    vadd.i8  q2, q0, q1       @ sixteen 8-bit adds\n    vadd.f32 q2, q0, q1       @ four float adds' },
    { t: 'p', x: 'The data-type suffix decides how the 128 bits are cut up. The same register, the same instruction, different arithmetic.' },
    { t: 'code', cap: 'A complete vector copy-and-add loop', x: '@ out[i] = a[i] + b[i], 32-bit, count in r3 (a multiple of 4)\n1:  vld1.32 {d0, d1}, [r1]!\n    vld1.32 {d2, d3}, [r2]!\n    vadd.i32 q2, q0, q1\n    vst1.32 {d4, d5}, [r0]!\n    subs r3, r3, #4\n    bne  1b' },
    { t: 'h', x: 'Broadcasting a scalar' },
    { t: 'code', cap: 'VDUP fills every lane', x: '    mov  r4, #5\n    vdup.32 q3, r4            @ q3 = [5, 5, 5, 5]' },
    { t: 'p', x: 'That is how you apply a constant to a whole vector: put it in every lane once, outside the loop, then use it every iteration. Loop-invariant hoisting, applied to a vector register.' }
  ],
  real: {
    title: 'Where NEON earns its keep',
    text: 'Image filters, audio mixing, colour-space conversion, video decoding, checksums, string search, and the memcpy path for large copies. The rule is: a loop with a simple body, no data-dependent branching, and lots of independent elements. A loop whose body branches on each element is a bad NEON candidate.',
    noasm: true,
    code: '@ alpha blend 16 pixels of one channel per iteration\n1:  vld1.8 {d0, d1}, [r1]!\n    vld1.8 {d2, d3}, [r2]!\n    vmull.u8 q2, d0, d4       @ widen and multiply\n    @ ... combine and narrow ...\n    subs r3, r3, #16\n    bne  1b'
  },
  deep: {
    kind: 'compiler',
    title: 'Autovectorising a float loop needs more than -O3',
    text: 'NEON is an optional extension on ARMv7-A and is not present on any Cortex-M core at all, so <code>-mfpu=neon</code> only changes what the compiler is allowed to emit, not what a given chip can run — checking <code>getauxval(AT_HWCAP)</code> against <code>HWCAP_NEON</code> at runtime is how a portable Linux binary finds out before it tries. Even assuming NEON exists, GCC will only autovectorise a suitable loop at <code>-O3</code>; loop vectorisation is not part of what <code>-O2</code> turns on. A loop of plain <code>float</code> arithmetic is usually left scalar even then, because ARMv7 NEON\'s single-precision arithmetic flushes denormals to zero and skips some IEEE-754 rounding behaviour, and the compiler will not swap in a less precise result without being asked.',
    a: { lab: 'C', lang: 'c', code: 'void scale(float *a, float k, int n) {\n    for (int i = 0; i < n; i++)\n        a[i] *= k;\n}' },
    b: { lab: 'gcc -O3 -mfpu=neon -ffast-math, ARMv7', code: '    vmov r2, s0                 @ k arrives in s0 under the hard-float ABI\n    vdup.32 q1, r2               @ broadcast its bits into all four lanes\n1:  vld1.32 {d0, d1}, [r0]       @ load four floats from a[i..i+3]\n    vmul.f32 q0, q0, q1          @ four multiplies\n    vst1.32 {d0, d1}, [r0]!      @ store, advance by 16 bytes\n    subs r1, r1, #4\n    bgt  1b' },
    note: '<code>-ffast-math</code> is the permission slip for that last restriction: it tells the compiler you accept NEON\'s looser floating-point contract, and only then does a <code>float</code> loop actually vectorise. Optimisation level and that flag are two separate gates, and a loop that looks vectorisable stays scalar if either one is missing.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A2.6 — Advanced SIMD', cite: 'The Advanced SIMD register file can be viewed as sixteen 128-bit quadword registers or thirty-two 64-bit doubleword registers; these views overlap.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — VLD1, VST1, VDUP', cite: 'VLD1 loads one or more whole registers from memory; VDUP replicates a scalar into every element of a vector.' }
  ],
  ex: [
    { k: 'code', q: 'Add the two 4-word vectors at <code>a</code> and <code>b</code> into <code>out</code> using one VADD.', start: '    ldr  r1, =a\n    ldr  r2, =b\n    ldr  r0, =out\n\n.data\na:   .word 1,2,3,4\nb:   .word 10,20,30,40\nout: .space 16\n', check: [{ memLabel: 'out', words: [11, 22, 33, 44] }, { maxInsn: 10 }], solution: '    ldr  r1, =a\n    ldr  r2, =b\n    ldr  r0, =out\n    vld1.32 {d0, d1}, [r1]\n    vld1.32 {d2, d3}, [r2]\n    vadd.i32 q2, q0, q1\n    vst1.32 {d4, d5}, [r0]\n\n.data\na:   .word 1,2,3,4\nb:   .word 10,20,30,40\nout: .space 16\n', hints: ['<code>{d0, d1}</code> is q0; <code>{d2, d3}</code> is q1; <code>{d4, d5}</code> is q2.', 'One <code>vadd.i32 q2, q0, q1</code> does all four adds.'], why: 'Four additions in one instruction. Four loads, one add, one store — six instructions for what the scalar version would take about fourteen to do.' },
    { k: 'code', q: 'Fill <code>out</code> with four copies of the value 9 using VDUP.', start: '    ldr  r0, =out\n    mov  r4, #9\n\n.data\nout: .space 16\n', check: [{ memLabel: 'out', words: [9, 9, 9, 9] }, { contains: 'vdup' }], solution: '    ldr  r0, =out\n    mov  r4, #9\n    vdup.32 q0, r4\n    vst1.32 {d0, d1}, [r0]\n\n.data\nout: .space 16\n', hints: ['<code>vdup.32 q0, r4</code> puts r4 in all four lanes.'], why: 'Broadcasting a constant once, outside the loop, is how you apply a scalar to a whole vector.' },
    { k: 'mcq', q: 'How many 16-bit elements does <code>vadd.i16 q2, q0, q1</code> add?', opts: ['4', '8', '16', '2'], a: 1, why: '128 bits divided by 16 is eight lanes.' },
    { k: 'mcq', q: 'You write to q0. Which other registers change?', opts: ['None', 'd0 and d1, and s0–s3', 'All of them', 'Only d0'], a: 1, why: 'The views overlap: q0 is d0 and d1, and d0 is s0 and s1 while d1 is s2 and s3.' },
    { k: 'code', q: 'Multiply the four words at <code>a</code> by 3 using VDUP and VMUL, into <code>out</code>.', start: '    ldr  r1, =a\n    ldr  r0, =out\n    mov  r4, #3\n\n.data\na:   .word 5,6,7,8\nout: .space 16\n', check: [{ memLabel: 'out', words: [15, 18, 21, 24] }, { contains: 'vmul' }], solution: '    ldr  r1, =a\n    ldr  r0, =out\n    mov  r4, #3\n    vdup.32 q1, r4\n    vld1.32 {d0, d1}, [r1]\n    vmul.i32 q2, q0, q1\n    vst1.32 {d4, d5}, [r0]\n\n.data\na:   .word 5,6,7,8\nout: .space 16\n', hints: ['Broadcast 3 into q1 first.', 'Then one <code>vmul.i32</code>.'], why: 'Four multiplies in one instruction, with the constant prepared once.' }
  ]
},

/* ----------------------------------------------------------------- 11.4 */
{
  id: 'u11l4', title: 'Reducing a vector to a number', goal: 'Sum a vector loop\'s accumulators down to one value.',
  teach: [
    { t: 'p', x: 'Vector loops accumulate into vector registers, so at the end you have four partial sums rather than one total. Collapsing them is called a <b>reduction</b>, and it happens once, after the loop.' },
    { t: 'code', cap: 'Accumulate four lanes, then reduce', x: '@ sum r2 words (a multiple of 4) from r1\n    mov  r4, #0\n    vdup.32 q1, r4            @ four zero accumulators\n1:  vld1.32 {d0, d1}, [r1]!\n    vadd.i32 q1, q1, q0\n    subs r2, r2, #4\n    bne  1b\n\n@ reduce q1 (= d2, d3) to one value\n    vadd.i32 d2, d2, d3       @ fold the top half onto the bottom\n    vmov r5, r6, d2           @ pull the two remaining lanes into ARM regs\n    add  r0, r5, r6' },
    { t: 'note', x: 'The reduction is a few instructions paid once. For a loop over a thousand elements that is nothing; for a loop over eight it can cost more than the vectorisation saved. Vectorising very short loops is usually a loss.' },
    { t: 'h', x: 'Why not accumulate into one lane?' },
    { t: 'p', x: 'Because then you would be doing one add per iteration instead of four, and the vector unit would be idle for three quarters of its width. Keep every lane busy through the loop and pay the reduction once at the end.' },
    { t: 'h', x: 'Reductions that are not sums' },
    { t: 'table', head: ['Reduction', 'In the loop', 'At the end'], rows: [
      ['Sum', '<code>VADD</code>', 'fold halves, then add lanes'],
      ['Maximum', '<code>VMAX</code>', 'fold halves, then compare lanes'],
      ['Minimum', '<code>VMIN</code>', 'fold halves, then compare lanes'],
      ['Any bit set', '<code>VORR</code>', 'fold halves, then test'],
      ['All bits set', '<code>VAND</code>', 'fold halves, then test']
    ] },
    { t: 'p', x: 'Every one of them has the same shape: a lane-wise operation in the loop, then log₂(lanes) folding steps, then a transfer to an ARM register. Once you have written one you have written all of them.' }
  ],
  real: {
    title: 'Dot products and energy calculations',
    text: 'The dot product of two vectors — multiply pairwise, sum everything — is the core of correlation, filtering, machine-learning inference and audio level metering. It is a multiply-accumulate loop followed by a reduction, and it is probably the single most optimised loop shape in computing.',
    code: '@ dot product, four lanes at a time\n1:  vld1.32 {d0, d1}, [r1]!\n    vld1.32 {d2, d3}, [r2]!\n    vmla.i32 q2, q0, q1\n    subs r3, r3, #4\n    bne  1b\n    vadd.i32 d4, d4, d5\n    vmov r5, r6, d4\n    add  r0, r5, r6'
  },
  deep: {
    kind: 'pitfall',
    title: 'The horizontal add that ate the speedup',
    text: 'Every lane in <code>q1</code> is independent until something reduces them together, and a reduction is a dependency where none existed before. <code>VPADD</code> and <code>VPADDL</code> exist to make that fold cheap, adding adjacent lanes pairwise in one instruction, precisely because the fold is meant to happen once. Move it inside the loop instead and every pass now waits on the previous pass\'s cross-lane shuffle to finish, which is the same kind of chain Unit 7 taught you to break, except this time you built it yourself.',
    a: { lab: 'Folded every iteration', code: '1:  vld1.32 {d0, d1}, [r1]!\n    vadd.i32 q1, q1, q0\n    vadd.i32 d2, d2, d3        @ folding happens here...\n    vmov r5, r6, d2            @ ...inside the loop...\n    add  r0, r5, r6            @ ...on every single pass\n    subs r2, r2, #4\n    bne  1b' },
    b: { lab: 'Folded once, at the end', code: '1:  vld1.32 {d0, d1}, [r1]!\n    vadd.i32 q1, q1, q0        @ four lanes, kept independent\n    subs r2, r2, #4\n    bne  1b\n    vadd.i32 d2, d2, d3        @ folding happens here...\n    vmov r5, r6, d2            @ ...once...\n    add  r0, r5, r6            @ ...after the loop is done' },
    note: 'The four <code>VADD</code>s in the loop cost one cycle no matter what happens to their result afterwards, so folding every iteration is pure overhead stacked on top of the arithmetic it was meant to replace, often enough to leave the vectorised loop slower than the scalar one it was written to beat. Fold once and remember that the total will still differ from a linear scalar sum in its last bit, because floating-point addition is not associative and you have just regrouped it.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — VADD, VMAX, VMIN', cite: 'Advanced SIMD data-processing instructions operate element-wise on corresponding lanes of their operands.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — VMOV (between two ARM core registers and a doubleword register)', cite: 'VMOV transfers the two 32-bit halves of a doubleword register to a pair of ARM core registers.' }
  ],
  ex: [
    { k: 'code', q: 'Sum the 8 words at <code>a</code> using a NEON loop and a reduction. Answer in r0.', start: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r4, #0\n    vdup.32 q1, r4\n1:\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', check: [{ reg: 'r0', eq: 36 }], solution: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r4, #0\n    vdup.32 q1, r4\n1:  vld1.32 {d0, d1}, [r1]!\n    vadd.i32 q1, q1, q0\n    subs r2, r2, #4\n    bne  1b\n    vadd.i32 d2, d2, d3\n    vmov r5, r6, d2\n    add  r0, r5, r6\n\n.data\na: .word 1,2,3,4,5,6,7,8\n', hints: ['Two iterations of four lanes each.', 'Reduce with <code>vadd.i32 d2, d2, d3</code> then <code>vmov r5, r6, d2</code>.'], why: 'q1 ends holding [6, 8, 10, 12]; folding gives [16, 20]; adding gives 36.' },
    { k: 'code', q: 'Find the largest of the 8 words at <code>a</code> using VMAX and a reduction. Answer in r0.', start: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r4, #0\n    vdup.32 q1, r4\n1:\n\n.data\na: .word 4, 19, 7, 2, 31, 8, 12, 5\n', check: [{ reg: 'r0', eq: 31 }], solution: '    ldr  r1, =a\n    mov  r2, #8\n    mov  r4, #0\n    vdup.32 q1, r4\n1:  vld1.32 {d0, d1}, [r1]!\n    vmax.s32 q1, q1, q0\n    subs r2, r2, #4\n    bne  1b\n    vmov r5, r6, d2\n    vmov r7, r8, d3\n    cmp  r5, r6\n    movlt r5, r6\n    cmp  r5, r7\n    movlt r5, r7\n    cmp  r5, r8\n    movlt r5, r8\n    mov  r0, r5\n\n.data\na: .word 4, 19, 7, 2, 31, 8, 12, 5\n', hints: ['<code>vmax.s32</code> in the loop keeps a running maximum in each lane.', 'Pull all four lanes out with two <code>vmov</code>s and compare them.'], why: 'The first vector gives lane maxima [4, 19, 7, 2]; the second raises them to [31, 19, 12, 5]. The comparison chain then picks 31. VMAX does four comparisons per instruction; only the last four are scalar.' },
    { k: 'mcq', q: 'Why accumulate into all four lanes rather than one?', opts: ['It is more accurate', 'Using one lane leaves three quarters of the vector unit idle every iteration', 'It avoids the reduction', 'It uses fewer registers'], a: 1, why: 'The reduction is a fixed cost paid once; idle lanes are a cost paid every iteration.' },
    { k: 'mcq', q: 'When is vectorising a loop a net loss?', opts: ['When the array is huge', 'When the array is short enough that the setup and reduction cost more than the vectorised body saves', 'When the elements are 32-bit', 'Never'], a: 1, why: 'Which is why real vectorised routines check the length first and fall back to a scalar loop for small inputs.' },
    { k: 'mcq', q: 'What do sum, max, min and OR reductions have in common?', opts: ['Nothing', 'A lane-wise operation in the loop, a fold of the halves, then a transfer to ARM registers', 'They all need VADD', 'They all need floating point'], a: 1, why: 'One pattern, four operations. Learn the shape once.' }
  ]
},

/* ----------------------------------------------------------------- 11.5 */
{
  id: 'u11l5', title: 'The tail, again', goal: 'Handle element counts that are not a multiple of the vector width.',
  teach: [
    { t: 'p', x: 'A loop processing four elements at a time can only handle multiples of four. Unit 5\'s remainder problem returns, with the same three answers and one new one.' },
    { t: 'table', head: ['Strategy', 'Works when', 'Cost'], rows: [
      ['Scalar tail loop', 'always', 'up to 3 slow iterations'],
      ['Overlapping final vector', 'reprocessing is harmless', 'one extra vector op'],
      ['Pad the buffer to a multiple', 'you own the allocation', 'wasted memory, and the padding must be neutral'],
      ['Masked or predicated store', 'ARMv8 SVE, not ARMv7 NEON', '—']
    ] },
    { t: 'code', cap: 'Vector body plus scalar tail', x: '    lsr  r4, r2, #2          @ how many full vectors\n    cmp  r4, #0\n    beq  2f\n1:  vld1.32 {d0, d1}, [r1]!\n    vadd.i32 q1, q1, q0\n    subs r4, r4, #1\n    bne  1b\n2:  ands r5, r2, #3          @ 0..3 left over\n    beq  3f\n4:  ldr  r6, [r1], #4        @ plain scalar loop\n    add  r7, r7, r6\n    subs r5, r5, #1\n    bne  4b\n3:' },
    { t: 'note', x: 'Notice that the tail accumulates into an ARM register while the body accumulates into a vector register. The two have to be combined at the very end — a small bookkeeping trap that catches people the first time.' },
    { t: 'h', x: 'Padding' },
    { t: 'p', x: 'If you control the buffer, allocate it rounded up to a multiple of the vector width and fill the padding with a value that does not disturb the result — zero for a sum, the smallest possible value for a maximum, one for a product. The loop then has no tail at all, which is both faster and much simpler to get right.' },
    { t: 'h', x: 'What ARMv8 changed' },
    { t: 'p', x: 'SVE, in ARMv8, made vectors variable-length with a predicate register that masks off the inactive lanes. The tail simply disappears: the last iteration runs with a partial mask. NEON on ARMv7 has no such thing, so the tail is yours to handle.' }
  ],
  real: {
    title: 'Why vectorised library functions are so long',
    text: 'A NEON <code>strlen</code> or <code>memchr</code> is mostly not the vector loop. It is the alignment head, the vector body, the tail, and the special cases for short inputs. The fast part is a dozen instructions; the correctness is a hundred.',
    code: '@ typical structure of a vectorised routine\n@   cmp length against a threshold -> scalar path for small inputs\n@   align the pointer                -> head loop\n@   main vector loop\n@   tail: scalar, or one overlapping vector\n@   combine the partial results'
  },
  deep: {
    kind: 'compiler',
    title: 'GCC writes the scalar tail loop for you',
    text: 'Autovectorisation has the same remainder problem you do, and the compiler solves it the same way: when it cannot prove the trip count is a multiple of the vector width, it emits the vector loop <i>and</i> a scalar loop after it to mop up whatever is left, without being asked. You only see this by reading the generated assembly — the C source gives no hint that two loops exist where you wrote one. It is also why heavy unrolling combined with vectorisation can bloat a small function considerably: a trip-count check, a vector body, and a scalar epilogue, for what started as three lines of C.',
    a: { lab: 'C', lang: 'c', code: 'void add_vec(int *a, const int *b, int n) {\n    for (int i = 0; i < n; i++)\n        a[i] += b[i];\n}' },
    b: { lab: 'gcc -O3 -mfpu=neon, ARMv7', code: '    lsr  r3, r2, #2             @ full vectors = n / 4\n    cmp  r3, #0\n    beq  2f\n1:  vld1.32 {d0, d1}, [r0]\n    vld1.32 {d2, d3}, [r1]!\n    vadd.i32 q0, q0, q1\n    vst1.32 {d0, d1}, [r0]!\n    subs r3, r3, #1\n    bne  1b\n2:  ands r2, r2, #3             @ remainder gcc could not rule out\n    beq  3f\n4:  ldr  r4, [r0]\n    ldr  r5, [r1], #4\n    add  r4, r4, r5\n    str  r4, [r0], #4\n    subs r2, r2, #1\n    bne  4b\n3:' },
    note: 'That safety net exists only because the compiler wrote both loops itself. Hand-write the vector loop yourself and reach for the shortcut of an overlapping final vector instead of a real tail — reprocessing the last few elements to avoid a branch — and you have reintroduced exactly the bug the compiler\'s epilogue was quietly avoiding: harmless for a sum, wrong for anything where doing an element twice is not the same as doing it once, such as a store, a running counter, or a checksum built from XOR.'
  },
  refs: [
    { src: 'ARM ARM for ARMv8-A (DDI 0487), Scalable Vector Extension', cite: 'SVE provides predicate registers that allow the final iteration of a loop to operate on a partial vector, removing the need for a separate tail.' },
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — VLD1', cite: 'Advanced SIMD loads transfer whole registers; there is no predicated element-wise load in ARMv7.' }
  ],
  ex: [
    { k: 'code', q: 'Sum the 10 words at <code>a</code>: a NEON loop for the first 8, then a scalar tail for the last 2. Combine into r0.', start: '    ldr  r1, =a\n    mov  r2, #10\n    mov  r4, #0\n    vdup.32 q1, r4\n    mov  r7, #0        @ scalar accumulator\n\n.data\na: .word 1,2,3,4,5,6,7,8,9,10\n', check: [{ reg: 'r0', eq: 55 }], solution: '    ldr  r1, =a\n    mov  r2, #10\n    mov  r4, #0\n    vdup.32 q1, r4\n    mov  r7, #0\n    lsr  r5, r2, #2\n1:  vld1.32 {d0, d1}, [r1]!\n    vadd.i32 q1, q1, q0\n    subs r5, r5, #1\n    bne  1b\n    ands r6, r2, #3\n    beq  3f\n2:  ldr  r8, [r1], #4\n    add  r7, r7, r8\n    subs r6, r6, #1\n    bne  2b\n3:  vadd.i32 d2, d2, d3\n    vmov r5, r6, d2\n    add  r0, r5, r6\n    add  r0, r0, r7\n\n.data\na: .word 1,2,3,4,5,6,7,8,9,10\n', hints: ['<code>lsr r5, r2, #2</code> gives the number of full vectors; <code>and r6, r2, #3</code> gives the remainder.', 'Do not forget to add the scalar accumulator to the reduced vector total at the end.'], why: '1..10 sums to 55. The vector part handles 1..8 and the tail handles 9 and 10.' },
    { k: 'mcq', q: 'What is the most common bug when adding a scalar tail to a vector loop?', opts: ['Using the wrong vector width', 'Forgetting to combine the tail\'s accumulator with the vector reduction', 'Misaligning the pointer', 'Using VADD instead of VMAX'], a: 1, why: 'Two accumulators exist and only one gets reduced. The answer comes out slightly too small, which is easy to miss on small test data.' },
    { k: 'mcq', q: 'You pad a buffer so a max-finding loop has no tail. What should the padding contain?', opts: ['Zero', 'The most negative representable value, so it can never be the maximum', 'One', 'Anything'], a: 1, why: 'The padding must be neutral <i>for the specific reduction</i>. Zero is neutral for a sum but not for a maximum over negative data.' },
    { k: 'mcq', q: 'How does SVE remove the tail?', opts: ['Longer vectors', 'A predicate register masks the inactive lanes, so the final iteration can process a partial vector', 'It pads automatically', 'It does not'], a: 1, why: 'NEON on ARMv7 has nothing equivalent, which is why every ARMv7 vector routine carries tail code.' },
    { k: 'mcq', q: 'Why is a NEON strlen mostly not the vector loop?', opts: ['The vector loop is slow', 'Alignment, short-input special cases and tail handling dominate the source, even though the vector body dominates the runtime', 'strlen cannot be vectorised', 'It is all vector loop'], a: 1, why: 'A dozen instructions of speed wrapped in a hundred instructions of correctness.' }
  ]
},

/* ----------------------------------------------------------------- 11.6 */
{
  id: 'u11l6', title: 'The FIR filter', goal: 'Write the loop that defines digital signal processing.',
  teach: [
    { t: 'p', x: 'A finite impulse response filter computes each output sample as a weighted sum of the last N input samples. It is two nested loops: outer over output samples, inner over the N coefficients. The inner loop is a multiply-accumulate and nothing else.' },
    { t: 'code', cap: 'The mathematical core', x: '@ y[n] = sum over k of  h[k] * x[n-k]\n@ r1 = x pointer, r2 = h pointer, r3 = taps, r0 = accumulator\n    mov  r0, #0\n1:  ldr  r4, [r1], #4\n    ldr  r5, [r2], #4\n    mla  r0, r4, r5, r0      @ accumulate: one instruction\n    subs r3, r3, #1\n    bne  1b' },
    { t: 'p', x: '<code>MLA</code> — multiply and accumulate — does the entire body in one instruction. That single instruction is why DSP work maps so well onto ARM, and it is the reason the multiply-accumulate is the headline figure in every DSP chip\'s datasheet.' },
    { t: 'h', x: 'Fixed point, properly' },
    { t: 'code', cap: 'Q15 coefficients, Q31 accumulator', x: '1:  ldrsh r4, [r1], #2       @ sample, Q15\n    ldrsh r5, [r2], #2       @ coefficient, Q15\n    smlabb r0, r4, r5, r0    @ 16x16 -> 32, accumulate\n    subs r3, r3, #1\n    bne  1b\n    asr  r0, r0, #15         @ back to Q15\n    ssat r0, #16, r0         @ and clamp' },
    { t: 'note', x: 'Accumulating in 32 bits while the operands are 16 bits gives you headroom: you can add many products before overflow becomes possible. That headroom is the reason DSP accumulators are always wider than the data — and why the final shift-and-saturate happens once, at the end, not per tap.' },
    { t: 'h', x: 'The vectorised version' },
    { t: 'code', cap: 'Four taps per instruction', x: '1:  vld1.32 {d0, d1}, [r1]!\n    vld1.32 {d2, d3}, [r2]!\n    vmla.i32 q2, q0, q1      @ four multiply-accumulates\n    subs r3, r3, #4\n    bne  1b\n    vadd.i32 d4, d4, d5\n    vmov r5, r6, d4\n    add  r0, r5, r6' },
    { t: 'h', x: 'Why this is the last lesson of the unit' },
    { t: 'p', x: 'Because it uses everything. Pointer walks from Unit 3, a nested loop from Unit 4, hoisting and unrolling from Unit 7, fixed point and vectors from this one, and a reduction and a tail. If you can write a FIR filter well, you can write loops.' }
  ],
  real: {
    title: 'CMSIS-DSP',
    text: 'ARM ships a reference DSP library for Cortex-M with exactly these functions — arm_fir_q15, arm_fir_f32 and their relatives — hand-optimised per core. Reading its source is the best available guide to what a serious ARM inner loop looks like, and every technique in this course appears in it.',
    noasm: true,
    code: '@ the shape CMSIS uses: 4 taps unrolled, 4 outputs at a time\n1:  ldr  r4, [r1], #4\n    ldr  r5, [r2], #4\n    smlad r0, r4, r5, r0     @ two 16x16 MACs in one instruction\n    subs r3, r3, #2\n    bne  1b'
  },
  deep: {
    kind: 'cores',
    title: 'A single-cycle MAC makes NEON unnecessary here',
    text: 'The Cortex-M4 adds a DSP extension on top of the Cortex-M3\'s integer pipeline: a single-cycle multiply-accumulate, and packed-halfword instructions such as <code>SMLABB</code> that do not exist on the M3 at all. Feed it two samples packed two-to-a-word, which is how 16-bit audio is normally kept in memory, and <code>SMLABB</code> multiplies and accumulates straight out of the packed word; without the extension you unpack each half by hand first. None of this is NEON, or even VFP — it is plain integer silicon, added because multiply-accumulate is what DSP code spends nearly all of its time doing, and a microcontroller-class core was never going to carry a 128-bit vector unit to speed it up.',
    code: '@ r4, r5 each hold two packed 16-bit values; the tap needs the low halfword of each\n\n@ Cortex-M3 and earlier: unpack by hand, then a plain 32-bit multiply-accumulate\n    sxth r6, r4                 @ sign-extend the low halfword of r4\n    sxth r7, r5                 @ sign-extend the low halfword of r5\n    mla  r0, r6, r7, r0          @ three instructions for one tap\n\n@ Cortex-M4 with the DSP extension: the same tap, one instruction, one cycle\n    smlabb r0, r4, r5, r0        @ reads the low halfwords straight out of the packed words',
    note: 'The DSP extension is ordinary integer silicon, not a NEON-style bonus, and some Cortex-M cores simply do not have it: a Cortex-M0 has no equivalent instruction and falls back to the multi-instruction sequence regardless of how the loop is vectorised, because there is no vector unit to fall back on either. CMSIS-DSP ships a scalar code path for every core in the family for exactly this reason.'
  },
  refs: [
    { src: 'ARM ARM (DDI 0406C), Chapter A8 — MLA, SMLABB', cite: 'MLA multiplies two registers and adds a third in a single instruction; SMLABB does the same for signed 16-bit halfword operands with a 32-bit accumulator.' },
    { src: 'CMSIS-DSP Software Library, FIR filter functions', cite: 'The Q15 FIR implementation accumulates in a wider format and applies a single shift and saturation to the final result.' }
  ],
  ex: [
    { k: 'code', q: 'Compute a 4-tap FIR output: samples at <code>x</code> (1,2,3,4), coefficients at <code>h</code> (10,20,30,40). Answer in r0.', start: '    ldr  r1, =x\n    ldr  r2, =h\n    mov  r3, #4\n    mov  r0, #0\n1:\n\n.data\nx: .word 1,2,3,4\nh: .word 10,20,30,40\n', check: [{ reg: 'r0', eq: 300 }], solution: '    ldr  r1, =x\n    ldr  r2, =h\n    mov  r3, #4\n    mov  r0, #0\n1:  ldr  r4, [r1], #4\n    ldr  r5, [r2], #4\n    mla  r0, r4, r5, r0\n    subs r3, r3, #1\n    bne  1b\n\n.data\nx: .word 1,2,3,4\nh: .word 10,20,30,40\n', hints: ['<code>mla r0, r4, r5, r0</code> is the whole body.'], why: '1×10 + 2×20 + 3×30 + 4×40 = 10+40+90+160 = 300.' },
    { k: 'code', q: 'Now the NEON version: same data, four taps in one VMLA, then reduce. Answer in r0.', start: '    ldr  r1, =x\n    ldr  r2, =h\n    mov  r4, #0\n    vdup.32 q2, r4\n\n.data\nx: .word 1,2,3,4\nh: .word 10,20,30,40\n', check: [{ reg: 'r0', eq: 300 }, { contains: 'vmla' }], solution: '    ldr  r1, =x\n    ldr  r2, =h\n    mov  r4, #0\n    vdup.32 q2, r4\n    vld1.32 {d0, d1}, [r1]\n    vld1.32 {d2, d3}, [r2]\n    vmla.i32 q2, q0, q1\n    vadd.i32 d4, d4, d5\n    vmov r5, r6, d4\n    add  r0, r5, r6\n\n.data\nx: .word 1,2,3,4\nh: .word 10,20,30,40\n', hints: ['Zero q2 with VDUP first — VMLA accumulates into it.', 'Reduce d4 and d5 the usual way.'], why: 'The four products land in four lanes; the reduction adds them. Same 300, one multiply-accumulate instruction.' },
    { k: 'code', q: 'Q15 FIR: samples and coefficients are 16-bit at <code>xq</code> and <code>hq</code>. Accumulate with SMLABB, then shift right 15. Answer in r0.', start: '    ldr  r1, =xq\n    ldr  r2, =hq\n    mov  r3, #4\n    mov  r0, #0\n1:\n\n.data\nxq: .hword 16384, 8192, 4096, 2048\nhq: .hword 16384, 16384, 16384, 16384\n', check: [{ reg: 'r0', eq: 15360 }], solution: '    ldr  r1, =xq\n    ldr  r2, =hq\n    mov  r3, #4\n    mov  r0, #0\n1:  ldrsh r4, [r1], #2\n    ldrsh r5, [r2], #2\n    smlabb r0, r4, r5, r0\n    subs r3, r3, #1\n    bne  1b\n    asr  r0, r0, #15\n\n.data\nxq: .hword 16384, 8192, 4096, 2048\nhq: .hword 16384, 16384, 16384, 16384\n', hints: ['<code>ldrsh</code> loads a signed halfword and advances by 2.', 'One <code>asr r0, r0, #15</code> at the very end, not per tap.'], why: '0.5×(0.5+0.25+0.125+0.0625) = 0.46875, which in Q15 is 15360. Shifting once at the end preserves the accumulator\'s headroom.' },
    { k: 'mcq', q: 'Why accumulate a Q15 FIR in 32 bits?', opts: ['It is faster', 'Headroom: many products can be summed before overflow, so the shift and saturation happen once at the end', 'Q15 does not fit in 16 bits', 'To match the coefficients'], a: 1, why: 'Shifting every tap would throw away precision on every tap and still not prevent overflow.' },
    { k: 'mcq', q: 'What does <code>MLA</code> do in one instruction?', opts: ['Two multiplies', 'A multiply and an add', 'A multiply and a shift', 'A load and a multiply'], a: 1, why: 'It is the whole body of a FIR inner loop, which is why it is the headline instruction of every DSP.' }
  ]
}
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
